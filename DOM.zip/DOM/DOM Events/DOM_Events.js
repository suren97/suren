function Display()
{
    alert("Button Clicked ...");
}

let btnelem=document.querySelector("#btn");
btnelem.addEventListener("click",Display);

let link=document.querySelector("a");
link.addEventListener('click',(e)=>{
    e.preventDefault();
})

//DOMContentloaded event
document.addEventListener('DOMContentLoaded',()=>{
    console.log("The DOM is fully loaded...");
})

//handle load event
document.addEventListener("load",(e)=>{
    console.log("The page is fully loaded...");
})

//handle beforeunload event
document.addEventListener("beforeunload",()=>{
    console.log("The page beforeunload event...")
})

window.addEventListener("load",()=>{
    console.log("The page is fully loaded...");
})

window.onload=()=>{
    console.log("The page as fully loaded...")
}

//Mouse Events

//MouseDown
document.addEventListener("click",()=>{
    console.log("Mouse click...");
})