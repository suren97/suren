//---------------------------------Managing Attributes--------------------------------------------

//getAttributes
let input=document.querySelector("#inpid");
let nameAtt=input.getAttribute("value");
console.log(nameAtt);

//setAttributes
let inpelem=document.createElement("input");
inpelem.setAttribute("name","setname");
inpelem.setAttribute("id","setid");
inpelem.setAttribute("value","setValues");
inpelem.setAttribute("disabled","");
let setElem=document.getElementById("setatt");
setElem.after(inpelem)

//removeAttributes
let rematt=document.querySelector("#rematt");
rematt.removeAttribute("value");
rematt.removeAttribute("readonly");

//Check Element has an Attribute
let getElem=document.getElementById("setid");
console.log(getElem.hasAttribute("value"));
console.log(getElem.hasAttribute("readonly"));