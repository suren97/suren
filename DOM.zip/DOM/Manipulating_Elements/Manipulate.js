function CreateListItem()
{
   let li=document.createElement("li");
   return li; 
}

//Manipulating Element
let childelem=document.getElementById("child");
let list=document.createElement("li");
list.textContent="Home";
childelem.replaceChild(list,childelem.firstElementChild);

//Clone Node Element
let clonemenu=childelem.cloneNode(true);
clonemenu.id="clone-menu";
let hnode=document.querySelector("#clone");
hnode.after(clonemenu);

//RemoveChild
let clonemenu2=clonemenu.cloneNode(true);
clonemenu2.id="Rem-menu";
let childrem=document.getElementById("childrem");
childrem.after(clonemenu2);
clonemenu2.removeChild(clonemenu2.lastElementChild);

//Insert a Node Before Another(insertBefore)
let menuitem=document.getElementById("before")
let li=CreateListItem();
li.textContent="Blogs";
menuitem.insertBefore(li,menuitem.firstElementChild);