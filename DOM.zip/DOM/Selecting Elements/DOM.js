//------------ IMPORTANT:
// getElementsByTagName() and querySelectorAll() returns an NodeList which as a collection of nodes
// getElementById and querySelector() returns an object with Element type

//QuerySelectAll
// forEach(),Array.from(nodeList);

//-------------------------------------Selecting Elements-----------------------------------

document.title="DOM"
let values=1;
console.log("-----------------------------------Selecting Elements-------------------------------");
console.log("ElementById");
//Get Element By Id
let elem=document.getElementById("para");
console.log(elem)

//Get Element By Name
console.log("ElementByName");
let btn=document.getElementById("subbtn");
console.log(btn)
let output=document.getElementById("output");
btn.addEventListener("click",()=>{
    let rate=document.getElementsByName("language");
    rate.forEach((rate)=>{
          if(rate.checked)
          {
             output.innerText=`You Selected:${rate.value}`
          }
    })
})

//Get Element By TagName
console.log("GetElementByTagName");
let tagelem=document.getElementsByTagName("h2");
console.log(tagelem)
let count=document.getElementById("count");
let btnelem=document.getElementById("btncount");
btnelem.addEventListener("click",()=>
{
     count.innerHTML=`The total h2 elements are:<b>${tagelem.length}</b>`   
})

//Get Element By ClassName
console.log("GetElementByClassName");
let classElem=document.getElementsByClassName("item");
console.log(classElem)

//Query Selector
console.log("Query Selector");
let queryelem=document.querySelector(".cssclass");
queryelem.style.color="red";
console.log(queryelem);

//Query SelectorAll
console.log("Query SelectorAll");
let qall=document.querySelectorAll(".subclass");
qall.forEach((v)=>
{
    v.style.color="blue";
})


//-------------------------------------Traversing Elements-----------------------------------
//Parent Element
console.log("-----------------------------------Traversing Elements-------------------------------");
console.log("Parent NodeElement");
let childelem=document.querySelector(".element2");
console.log("ParentElement",childelem.parentNode)

//NextSibling Element
console.log("Siblings NextElement");
let sibelem=document.querySelector(".current");
let nextsib=sibelem.nextElementSibling;
while(nextsib)
{ 
    console.log(nextsib)
    nextsib=nextsib.nextElementSibling;
}

//Previous Sibling Element
console.log("Siblings PreviousElement");
let prevelem=document.querySelector(".current");
let prevsib=prevelem.previousElementSibling;
while(prevsib)
{
    // console.log(prevsib);
    prevsib=prevsib.previousElementSibling;
}

//Get All siblings Element
console.log("All Siblings Element");
let getSiblings=(e)=>
{
    let siblings=[]; //for collecting siblings

    if(!e.parentNode)
    {
        return siblings;  //If no parent doesn't return siblings
    }

    let sibling=e.parentNode.firstChild;
  
    while(sibling)
    {
        if(sibling.nodeType === 1 && sibling !== e)
        {
            siblings.push(sibling);
        }
        sibling = sibling.nextSibling;
    }
  return siblings;
}

let siblings=getSiblings(document.querySelector(".current"));
let siblingText=siblings.map((v)=> v.innerHTML);
console.log('getSiblings',siblingText);

//Get Child Element Siblings
console.log("Get First Child Elements");
let parentElement=document.getElementById("bar");
let firstChild=parentElement.firstChild;
let firstchildElement=parentElement.firstElementChild;
console.log(firstchildElement);

//Get Last Element Siblings
console.log("Get Last Child Elements");
let lastChild=parentElement.lastChild;
let lastChildElement=parentElement.lastElementChild;
console.log(lastChildElement);

//Get all Child Elements
console.log("All Child Elements");
let children=parentElement.children;
console.log(children)


//-----------------------------------Manipulating Elements----------------------------------
console.log("-----------------------------------Mainpulating Elements-------------------------------");
let div=document.createElement("div");
div.id="manelem";
div.className="elements"
div.innerHTML="<p>CreateElement example</p>";
elem.appendChild(div);
console.log(div);

// console.log("Adding Text to a div");
let text=document.createTextNode("CreateElement textnode");
div.appendChild(text);
console.log(div);

// console.log("Adding an Element to a div");
let h3=document.createElement("h3");
h3.textContent="Adding Text to h3 elements";
div.appendChild(h3);

function createListItem(listname)
{
  let li=document.createElement("li");
  li.textContent=listname;
  return li;
}

console.log("Create a new List item");
let menuelem=document.querySelector("#sample");
menuelem.appendChild(createListItem('Home'));
menuelem.appendChild(createListItem('Product'));
menuelem.appendChild(createListItem("About us"));
menuelem.appendChild(createListItem("Contact us"));

console.log("Moving a Node within the document example");
let firstList=document.querySelector("#first-list");
const everest=firstList.firstElementChild;
let secondlist=document.querySelector("#second-list");
secondlist.append(everest);

//JS TextContent
let note=document.getElementById("note");
console.log("textContent",note.textContent);
console.log("innerText",note.innerText);
console.log("--------------------------------");
let note2=document.getElementById("emptynote");
note2.textContent="Inner html textContent";
console.log("textContent",note2.textContent);

//Document Fragment
let languages=["JS","TypeScript","Elm","Dart","Scala"];
let langEl=document.querySelector("#language");
let fragment=new DocumentFragment();
languages.forEach((languages)=>{
    let li=document.createElement("li");
    li.innerHTML=languages;
    fragment.appendChild(li);
});
langEl.appendChild(fragment);
console.log(langEl);

//Insert a Node before Another Element
let docelem=document.querySelector("#nodebefore");
let h1elem=document.createElement("h1");
h1elem.innerText="JS DOM - before()";
docelem.before(h1elem);

//Insert a Multiple node before another element
const list = document.querySelector('#mulnodes');
const libs = ['React', 'Meteor', 'Polymer'];
const items = libs.map((lib) => {
    const item = document.createElement('li');
    item.innerText = lib;
    return item;
});
console.log(list)
list.firstChild.before(...items);

//Insert a Single Node After Another
const slist=document.querySelector("#singlenode");
const para=document.createElement("p");
para.innerText="single para node element";
slist.appendChild(para);

//Insert a Multiple Node After Another
const alist=document.querySelector("#nodeafter");
const navlist=['Mango','Citrus','Orange','PineApple'];
const navitems=navlist.map((val)=>{
    const navitem=document.createElement("li");
    navitem.innerText=val;
    return navitem;
});
alist.lastChild.after(...navitems);

//Append
const apelem=document.querySelector("#app");
apelem.append(para);

//Prepend
const prelem=document.querySelector("#preapp");
prelem.prepend(para);

//Insert AdjacentHTML
let listhtml=document.querySelector("#listelem");
listhtml.insertAdjacentHTML("beforebegin","<p>Adjacent Elements Before Begin</p>");
listhtml.insertAdjacentHTML("beforeend","<li>BeforeEnd</li>");
listhtml.insertAdjacentHTML("afterbegin","<li>Afterbegin</li>");
listhtml.insertAdjacentHTML("afterend","<p>AfterEnd</p>");

//Insert AdjacentElement
let header=document.getElementById("header");
let span=document.createElement("span");
span.innerText="Span element"
header.insertAdjacentElement("afterend",span);
