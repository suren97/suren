//Setting inLine Styles
let paraElem=document.getElementById("para");
paraElem.style.fontSize="18px";
paraElem.style.fontWeight="bold";
paraElem.style.fontStyle="italic";
paraElem.style.color="green"
console.log(paraElem);

//getComputedStyle
let elem=document.getElementById("main");
let getstyle=getComputedStyle(elem);
console.log("color",getstyle.color);

//getCssclasses
let menu=document.getElementById("menu");
console.log(menu.className);

//Manipulate Cssclasses
let divelem=document.querySelector("#content");
for(let css of divelem.classList)
{
    console.log(css);
}

//Adding class using classList
let addelem=document.querySelector("#content");
addelem.classList.add("paraelem");
addelem.style.color="blue"
console.log(addelem);

//Removing class using classList
let remelem=document.querySelector("#content");
remelem.classList.remove("paraelem");

//Offset Width and Height
let getclass=document.querySelector(".boxelem");
let width=getclass.offsetWidth;
let height=getclass.offsetHeight;
console.log("OffSet",width+" "+height);

//Client Width and Height
let getClient=document.querySelector(".boxelem");
let clwidth=getClient.clientWidth;
let clheight=getClient.clientHeight;
console.log("Client",clwidth+" "+clheight)