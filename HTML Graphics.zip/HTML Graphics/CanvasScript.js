//Basic usage of Canvas
let canvas=document.getElementById("mycanvas");
canvas.style.border="1px solid black"
let context=canvas.getContext("2d");
context.beginPath();
context.fillStyle = "#ff6";
context.fillRect(0,0,canvas.width,canvas.height);

context.fillStyle="rgba(0,0,200,0.5)";
context.fillRect(30,30,50,50);

// --------------------------------------------------------------------------------------------
// Drawing Shapes with canvas
let canvas1=document.getElementById("canvas1");
let context1=canvas1.getContext("2d");
context1.fillRect(40,40,120,120);
context1.clearRect(68,63,65,65);
context1.strokeRect(45,45,100,100);
//Drawing a Triangle
const triangle=document.getElementById("triangle");
const context2=triangle.getContext("2d");
context2.beginPath();
context2.strokeRect(20,20,100,100);
context2.moveTo(20,20);
context2.lineTo(80,80);
context2.stroke();

