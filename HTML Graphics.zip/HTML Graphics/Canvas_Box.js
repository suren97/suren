let canvas=document.getElementById("row");
canvas.style.border="1px solid black"
let context=canvas.getContext("2d");
//row
context.beginPath();
context.moveTo(0,100);
context.lineTo(500,100);
context.moveTo(0,200);
context.lineTo(500,200);
context.moveTo(0,300);
context.lineTo(500,300);
context.moveTo(0,400);
context.lineTo(500,400);
context.stroke();

//column
context.beginPath();
context.moveTo(100,0);
context.lineTo(100,500);
context.moveTo(200,0);
context.lineTo(200,500);
context.moveTo(300,0);
context.lineTo(300,500);
context.moveTo(400,0);
context.lineTo(400,500);
context.stroke();

//diagnol
context.beginPath();
context.moveTo(0,0);
context.lineTo(100,100);

context.moveTo(0,100);
context.lineTo(100,0);

context.moveTo(100,0);
context.lineTo(200,100);

context.moveTo(100,100);
context.lineTo(200,0);

context.moveTo(200,0);
context.lineTo(300,100);

context.moveTo(200,100);
context.lineTo(300,0);

context.moveTo(300,0);
context.lineTo(400,100);

context.moveTo(300,100);
context.lineTo(400,0);

context.stroke();


// context.beginPath();
// context.moveTo(0,0);
// context.lineTo(500,500);
// context.strokeStyle="green"
// context.lineWidth=10
// context.stroke();

// context.beginPath();
// context.moveTo(0,500);
// context.lineTo(500,0);
// context.strokeStyle="blue"
// context.lineWidth=10
// context.stroke();