let canvas=document.getElementById("row");
canvas.style.border="1px solid black"
let context=canvas.getContext("2d");
// //Dynamic Square box
// let rowsplit=canvas.width/5;
// context.beginPath();
// for(let i=1; i<5; i++)
// {
//     context.moveTo(0,rowsplit*i);
//     context.lineTo(canvas.width,rowsplit*i);
//     context.moveTo(rowsplit*i,0);
//     context.lineTo(rowsplit*i,canvas.width);
// }
// context.stroke();

//Rectangle square box

context.beginPath();
context.moveTo(0,80);
context.lineTo(400,80);
context.moveTo(0,160);
context.lineTo(400,160);
context.moveTo(0,240);
context.lineTo(400,240);
context.moveTo(0,320);
context.lineTo(400,320);

// context.moveTo(80,0);
// context.lineTo(80,400);
// context.moveTo(160,0);
// context.lineTo(160,400);
// context.moveTo(240,0);
// context.lineTo(240,400);
// context.moveTo(320,0);
// context.lineTo(320,400);
context.stroke();



// for(var row=1,initial=0;row<=canvas.width;row++)
// {
//     if(row%100 == 0)
//     {
//         context.moveTo(initial,row);
//         context.lineTo(canvas.width,row);
//         context.moveTo(row,initial);
//         context.lineTo(row,canvas.width);
//     }
// }
// context.stroke();