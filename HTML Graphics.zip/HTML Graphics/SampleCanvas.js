const canvas = document.getElementById("canvasid");

const context = canvas.getContext("2d");

const cellWidth = canvas.width / 2;

const cellHeight = canvas.height / 2;

const countStyle = "bold 20px Arial";

let count = 0;

// draw initial grid

drawGrid();

canvas.addEventListener("click", handleClick);

function drawGrid() {
  // draw the grid lines

  context.strokeStyle = "red";

  context.lineWidth = 1;

  context.beginPath();

  context.moveTo(cellWidth, 0);

  context.lineTo(cellWidth, canvas.height);

  context.moveTo(0, cellHeight);

  context.lineTo(canvas.width, cellHeight);

  context.stroke(); // draw the count in each cell

  //   context.font = countStyle;

  context.textAlign = "center";

  context.textBaseline = "middle";

  context.fillStyle = "black";

  context.beginPath();

  context.ellipse(
    cellWidth / 2,
    cellHeight / 2,
    cellWidth / 2,
    cellHeight / 2,
    0,
    0,
    2 * Math.PI
  );

  context.stroke();

  context.fillText(count + 1, (cellWidth * 3) / 2, cellHeight / 2);

  context.fillText(count + 2, cellWidth / 2, (cellHeight * 3) / 2);

  context.fillText(count + 3, (cellWidth * 3) / 2, (cellHeight * 3) / 2);
}

function handleClick(event) {

  const rect = canvas.getBoundingClientRect();

  const x = event.clientX - rect.left;

  const y = event.clientY - rect.top;

  const row = Math.floor(y / cellHeight);

  const col = Math.floor(x / cellWidth); // clear canvas and redraw grid

  context.clearRect(0, 0, canvas.width, canvas.height);

  drawGrid(); // highlight clicked cell

  context.fillStyle = "blue";

  context.fillRect(col * cellWidth, row * cellHeight, cellWidth, cellHeight); // draw count in clicked cell with border

  //   context.font = countStyle;

  context.fillStyle = "white";

  context.textAlign = "center";

  context.textBaseline = "middle";

  context.fillText(
    count + row * 2 + col,
    (col + 0.5) * cellWidth,
    (row + 0.5) * cellHeight
  ); // draw border around clicked cell

  context.strokeStyle = "black";

  context.lineWidth = 3;

  context.strokeRect(
    col * cellWidth + 2,
    row * cellHeight + 2,
    cellWidth - 4,
    cellHeight - 4
  );
}
