//Closure function

//Closure is a function which has a access for a parent scope 

console.log("-----------Closure")
let mainval=3;
let Parentfn=()=>
{
    let val1=1;
    console.log("mainval",mainval)
    let Childfn=()=>
    {
       val1+= 5;
       console.log("childval",val1)
       return val1
    }
    return Childfn;
}

let result=Parentfn();
console.log(result());
console.log(result());


//IIFE (Immediately invoked function)
console.log("---------------------IIFE");
const privateCounter=(()=>{
    let count=0;
    console.log(`intial value -${count}`);
    return ()=>{ count+=1;  console.log(count) }
})();
privateCounter();
privateCounter();

//Closure with IIFE and Parameter
console.log("---------------------Closure with IIFE and Params")
const credits=((num)=>{
    let credits=num;
    console.log("intial credits value:",(credits));
    return ()=>{
        credits-=1;
        if(credits >0)
        console.log("Credits deducted",credits);
        if(credits <=0)
        console.log("No Credits");
    }
})(3);

credits();
credits();
credits();

