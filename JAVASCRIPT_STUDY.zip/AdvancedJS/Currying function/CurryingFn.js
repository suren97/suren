//Currying Function
//The function which as many nested functions are called as currying function

//Currying takes a function that receives more than one parameter and
//breaks it into a series of unary (one parameter) functions

//Curried function which takes only one parameter at a time

//Example 1
const Sandwich = (ingredient1) => {
  return (ingredient2) => {
    return (ingredient3) => {
      return `${ingredient1},${ingredient2},${ingredient3}`;
    };
  };
};

const getingredients = Sandwich("I1")("I2")("I3");
console.log(getingredients);

//Example 2
const buildsammy = (ingred1) => (ingred2) => (ingred3) =>
  `${ingred1},${ingred2},${ingred3}`;
const getsammy = buildsammy("L")("B")("S");
console.log(getsammy);

console.log("-------------Example3---------------");

//Example 3
const addCustomer =
  (fn) =>
  (...args) => {
    console.log("saving customer info...");
    return fn(...args);
  };

const processOrder =
  (fn) =>
  (...args) => {
    console.log(`processing order #${args[0]}`);
    return fn(...args);
  };

let completeOrder = (...args) => {
  console.log(`Order #${[...args].toString()} completed.`);
};

completeOrder = processOrder(completeOrder);
completeOrder = addCustomer(completeOrder);
completeOrder(777);

console.log("-------------Example4---------------");
//Example 4
const curry = (fn) => {
  return (curried = (...args) => {
    if (fn.length !== args.length) {
      console.log(...args);
      return curried.bind(null, ...args);
    }
    return fn(...args);
  });
};

const total = (x, y, z) => x + y + z;
const curriedtotal = curry(total);
console.log(curriedtotal(10, 20, 30));
