//Decarotor function

//Decarotors wrap a function in another function

//These wrappers "decorate" the original function with new capabilities

//The concept of decorators is not exclusive to javascript

//Benefits:D.R.Y and clean code through compositon

//Example 1:
//Using closure to log how many times a function is called

