//Object Literals
const person={
    alive:true
}

const musician={
    plays:true
}

Object.setPrototypeOf(musician,person);
console.log(Object.getPrototypeOf(musician));
console.log(musician.alive);
console.log(musician.plays);

let obj1={id:2,name:"sjnsj",status:"inactive"};
let obj2={empid:33,role:"developer"};
Object.setPrototypeOf(obj2,obj1);
console.log(Object.getPrototypeOf(obj2));