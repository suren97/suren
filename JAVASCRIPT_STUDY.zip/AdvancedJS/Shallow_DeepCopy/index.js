//Shallow vs Deep Copy

//primitive pass values
let x=2;
let y=x;
y+=1;
// console.log(y);
// console.log(x);

//Structural type reference
let xArray = [1,2,3];
let yArray = xArray;
yArray.push(4);
// console.log(yArray);
// console.log(xArray);

//Mutable vs Immutable Data

