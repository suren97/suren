//Syntax - new Blob(blobparts,options);
// new Blob(array);
// new Blob(array, options);
//Blob = type + blobParts

//Blob
//Blob is a constructor returns a new Blob object
//Blob as arrayBuffer
//Blob as text
//Blob as url
//Blob as binarystring

//FileReader
// let files=[];
// let handlefile=e=>
// {
//   files.push(e.target.files[0]);
//   let reader=new FileReader();
//   reader.onload=async()=>
//   {
//     let imgelem = document.getElementById("insertimg");
//     imgelem.src=await reader.result;
//   }
//   reader.readAsDataURL(files[0]);
// }

// let exportfile = async () => {
//   if (files.length) {
//     const filehandle = await self.showSaveFilePicker();
//   }
// };

// // FileReader Upload and Download image
let files=[];
let handlefile=e=>
{
  files.push(e.target.files[0]);
  let reader=new FileReader();
  reader.onload=async()=>
  {
    let imgelem = document.getElementById("insertimg");
    imgelem.src=await reader.result;
  }
  reader.readAsDataURL(files[0]);
}

let exportfile=()=>
{
if(files.length)
{
let reader=new FileReader();
reader.onload=async()=>
{
 if ('showSaveFilePicker' in window) 
  {
  const options = {
        suggestedName: "Image",
        types: [
          {
            description: "image file",
            accept: {
              "image/png":[".png"]
            },
          },
        ],
      };
      const handle=await window.showSaveFilePicker(options);
      const writable=await handle.createWritable();
      await writable.write(reader.result);
      await writable.close();
    }
    else
    {
      const fileName="Sample"
       const blob = new Blob([reader.result], { type: "application/json" });

        const url = await URL.createObjectURL(blob);

        const link = document.createElement("a");

        link.download = fileName + ".json";

        link.href = url;

        document.body.appendChild(link);

        link.click();

        document.body.removeChild(link);
    }
}
reader.readAsArrayBuffer(files[0])
}
}