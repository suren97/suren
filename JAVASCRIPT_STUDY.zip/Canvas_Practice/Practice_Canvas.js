let canvas=document.getElementById("canvasid");
let ctx=canvas.getContext("2d");

//Direction
ctx.font="40px serif";
ctx.fillText("Surendar",50,50);
ctx.direction="ltr";