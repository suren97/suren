//Length property
const arrelem=[
    {id:1,name:'kiran'},
    {id:2,name:'joseph'},
    {id:3,name:'rajesh'},
    {id:4,name:'lokesh'},
    {id:5,name:'vimal'},
    {id:6,name:'vikram'}
];
// arrelem.length=8;
console.log("Length Method")
console.log(arrelem)

//Push
console.log("Push Method")
let n=arrelem.push({id:7,name:"ramu"});
console.log(n)

//Pop
console.log("Pop Method");
let n1=arrelem.pop();
console.log(arrelem)
console.log(n1)

//Unshift
console.log("Unshift Method");
let n3=arrelem.unshift({id:0,name:"throne"});
console.log(arrelem)
console.log(n3)

//Shift
console.log("Shift Method");
let n4=arrelem.shift();
console.log(n4);
console.log(arrelem)

//splice -> Delete,Insert and Replace
console.log("Splice Method");
let spelem=arrelem.splice(0,3);
console.log("Org element",arrelem);
// console.log("Deleted Element",spelem)
console.log("Insert Method");
//Insert Method
arrelem.splice(2,0,{id:2,name:'rocky'});
console.log(arrelem)
console.log("Replace Method")
//Replace Method
arrelem.splice(1,1,{id:5,name:"Praveen"});
console.log(arrelem)
//Slice Method
console.log("Slice Method");
let narrelem=["sam","george","mike","williams","kane","Jack","daniels","mike"];
let n1elem=narrelem.slice(0,-5);
console.log(n1elem)

//indexOf Method
console.log("indexOf Method");
console.log(narrelem.indexOf("mike"));
console.log(narrelem.lastIndexOf("mike"));

//find
console.log("find Method");
let elements=[
    {id:1,name:"Richard",status:"active"},
    {id:2,name:"Johnson",status:"inactive"},
    {id:3,name:"Marshall",status:"active"},
    {id:4,name:"Miller",status:"active"},
    {id:5,name:"Plunker",status:"inactive"}
];
let findelem=elements.find(v=>v.status=="active");
console.log(findelem)

//findIndex
console.log("findIndex Method");
let findindelem=elements.findIndex(v=>v.status=="inactive");
console.log(findindelem);

//includes
console.log("includes Method");
let elem2=[1,2,3,4,5,6,7];
let incl=elem2.includes(2);
console.log(incl);

//reduce
console.log("Reduce Method");
let num=[1,2,3,4,5,6,7];
let sum=num.reduce((p,c)=>p+c);
console.log(sum);

//Every
console.log("Every Method");
let evy=[1,2,3,5];
let res=evy.every((e)=>
{
   return e>0
});
console.log(res)

//Some
console.log("Some Method");
let som=evy.some((e)=>
{
    return e>3
})
console.log(som)

//forEach
console.log("forEach Method");
let arrmet=[
    {name:"A",id:1},
    {name:"B",id:2},
    {name:"C",id:3},
    {name:"D",id:4},
    {name:"E",id:5},
    {name:"F",id:6},
];
arrmet.forEach((v,i)=>
{
    if(i==3)
    {
      v.id="new"
    }
})
console.log(arrmet)

//Sort
console.log("Sort Method");
let nums=[1,4,2,56,21,5,59,3];
nums.sort( function( a , b){
    return a-b;
})
console.log(nums)

//concat
console.log("Concat Method");
let delem=[{id:7,name:"W",weight:23},{id:8,name:"S"},{id:9,name:"T"}];
let conelem=arrmet.concat(delem);
console.log(conelem)