//indexOf
console.log("indexOf");
let str="javascript methods";
let ind=str.indexOf("script");
console.log(ind);

//lastindexOf
console.log("lastindexOf");
let lastind=str.lastIndexOf("s");
console.log(lastind);

//startsWith
console.log("startsWith");
const stat="Jack and Jill went to the hill";
console.log(stat.startsWith("Jack"));

//endsWith
console.log("endsWith");
const endstat="Jack and Jill went to the hill";
console.log(stat.endsWith("hill"));

//padStart
console.log("PadStart")
let pad='abc'.padStart(5);
console.log(pad)

//padEnd
console.log("PadEnd");
let pend='mdke'.padEnd(8,"u");
console.log(pend)