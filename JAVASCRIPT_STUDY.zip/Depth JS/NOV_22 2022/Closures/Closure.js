function test1()
{
    function test2()
    {
      counter=counter+5;
      return counter;
    }
    let counter=0;
    return test2();
}
console.log(test1());

let obj1={name:"Ashok",empid:202,city:"Chennai"};
//1
let obj2=obj1;
console.log(obj2);
//2
let obj3=Object.assign({},obj2);
console.log(obj3)