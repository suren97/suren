function factorail(num)
{
let mul=1;
while(num>0)
{
    mul*=num;
    num--;
}
return mul;
}
console.log(factorail(3));

// //Object to array
// let obj={name:"Ajay",empid:202,status:"active"};
// let arr=Object.entries(obj);
// console.log(arr);
// //2
// let arr1=[];
// for(let x in obj)
// {
// arr1.push([x,obj[x]]);
// }
// console.log(arr1);

//Array to Object
let arr=[["name","Raju"],["Age",32],["Empid",203]];
// let obj=Object.assign({},arr);
// let obj={...arr};
// let obj=Object.fromEntries(arr);
// console.log(obj);

//Check whether the enetred input is array or not
let text=[10,20,30,40,50];
//Clone an array
console.log(Array.from(text));
let arr2=text;
console.log(arr2);
//Return first element in an array
let arr3=[1,2,3,4,5];
console.log(arr3.shift());
//Return last element in an array
console.log(arr3.pop());
//Sort an Array Items
var arr1 = [ 3, 8, 7, 6, 5, -4, 3, 2, 1 ];
// arr1.sort();                //Descending Order
// arr1.sort(function(x,y){    //Ascending Order
//     return y-x;
// });
console.log(arr1);
//Remove Duplicates in a string
var arrrep=[1,2,2,3,3,3,3,4,1,5,6,7,5,5];
var removedup=arrrep.filter((v,i)=>{  return arrrep.indexOf(v)===i; });
console.log(removedup);
console.log("-----------------------------------");
var num=10.133;
console.log(Number.isInteger(num));
let cat=[7,8,9,4,5];

console.log(mul(2,3,70));
function mul(...num)
{
let mul=1;
for(let x of num)
{
mul=mul*x;
}
return mul;
}
console.log(add(2)(3)(4));
function add (x) {
    return function (y) { // anonymous function
      return function (z) { // anonymous function
        return x * y * z;
      };
    };
  }
console.log("---------------------------------");
function s1()
{
    let j=0;
}
function s2()
{
 j=10;
}
s1();
s2();
console.log(j);
