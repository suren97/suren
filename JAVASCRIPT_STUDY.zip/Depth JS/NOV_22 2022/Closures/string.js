//input is string or not
var str="javascript";
console.log(typeof str);

//String is blank or not
var str1="";
if(str1.length==0)
{
    console.log(true);
}
else
{
    console.log(false);
}
//Capitalize first letter of a string
let str2="javascript elements";
let spstr=str2.split(" ");
let cap="";
for(i=0;i<spstr.length;i++)
{
for(j=0;j<spstr[i].length;j++)
{
  if(j==0)
  {
    // cap=cap+spstr[j].toUpperCase();
    cap=cap+" "+spstr[i].charAt(j).toUpperCase();
  }
  else
  {
   cap=cap+spstr[i].charAt(j)
  }
}
}
console.log(cap.trim());

// //get frequent element in an array
// let arrele=[1,2,3,4,4,4,5];
// let len=arrele.length;
// let maxcount=0;
// let maxfreq;
// for(i=0;i<len;i++)
// {
//     let count=0;
//     for(j=0;j<len;j++)
//     {
//         if(arrele[i]==arrele[j])
//         {
//             count++;
//         }
//     }
//     if(count > maxcount)
//     {
//         maxcount=count;
//         maxfreq=arrele[i];
//     }
// }
// console.log(maxfreq);

//Most frequent element in a string
var strg="Most javascript javascript javascript element";
let maxcount=0;
var spstrg=strg.split(" ");
let freq="";
for(i=0;i<spstrg.length;i++)
{
    let count=0;
    for(j=0;j<spstrg.length;j++)
    {
     if(spstrg[i]==spstrg[j])
     {
        count++;
     }
    }
    if(count > maxcount)
    {
     maxcount=count;
     freq=spstrg[i];
    }
}
console.log(freq)