// function job()
// {
//     return new Promise((resolve,reject)=>{
//         reject("Error");
//     })
// }
// let prom=job();
// prom
// .then(
//     ()=>
//     {
//      console.log("Success1");
//     }
// )
// .then(
//     ()=>
//     {
//      console.log("Success2");   
//     }
// )
// .then(
//     ()=>
//     {
//      console.log("Success3");   
//     }
// )
// .catch(
//     (error)=>
//     {
//     console.log(error);
//     }
// )
// .then(
//     ()=>
//     {
//      console.log("Success4");   
//     }
// )



//Exercise-2
// function job(state) {
//     return new Promise(function(resolve, reject) {
//         if (state) {
//             resolve('success');
//         } else {
//             reject('error');
//         }
//     });
// }

// let promise = job(true);

// promise

// .then(function(data) {
//     console.log(data);
//     return job(false);
// })

// .catch(function(error) {
//     console.log(error);

//     return 'Error caught';
// })

// .then(function(data) {
//     console.log(data);

//     return job(true);
// })

// .catch(function(error) {
//     console.log("err:"+error);
// });

//Exercise 3
function job(state)
{
    return new Promise((resolve,reject)=>{
        if(state)
        {
            resolve("Success");
        }
        else
        {
            reject("Failure")
        }
    })
}
let pro=job(true);

pro
.then(
    (value)=>
    {
     console.log(value);   
     return job(false); 
    }
)
.catch
(
    (error)=>
    {
        console.log(error);
        return "Err returned";
    }
)
.then
(
    (value)=>
    {
        console.log(value);
    }
)
.catch(
    (error)=>
    {
        console.log(error)
    }
)