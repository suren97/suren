function job()
{
  return new Promise((resolve,rej)=>{
    setTimeout(()=>{resolve("succc1")},3000);
  })
}
function job2()
{
  return new Promise((resolve,rej)=>{
    setTimeout(()=>{resolve("succc2")},1000);
  })
}
async function test()
{
let prom=await job();
let prom2=await job2();
console.log(prom);
console.log(prom2);
}
test();