var num=27;
if(num%5==0)
{
    console.log(true);
}
else
{
    console.log(false)
}
//Return last element in array
let arr=[1,2,3,4,5,6];
console.log(arr.slice(-1))

function sumArray(arr) {
console.log(arr);
 var sum=0;
  for (i=0; i<arr.length; i++) {
	  sum+=arr[i]
	}
  return sum
}
console.log(sumArray([1, 2, 3, 4, 5]))

//Destructuring
let ar1=[1,2,3,4,5,6];

//Invert an Array
let arele1=[1,2,3,-4,-5,6];
let newele=[];
arele1.forEach(repsign)
function repsign(value,index)
{
if(value<0)
{
newele.push(Math.abs(value));
}
else
{
    newele.push(-value);
}
}
console.log(newele)