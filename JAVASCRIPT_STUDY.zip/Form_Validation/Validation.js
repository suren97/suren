function validate()
{
    var name=document.getElementById("uname").value;
    var pwd=document.getElementById("pass").value;
    var errname=document.getElementById("err");
    var errpass=document.getElementById("errpass");

    //Username
    if(!name)
    {
    errname.innerHTML="Name cannot be blank";
    }
    else
    {
    let checkname=validatename(name);
    console.log(checkname);
    if(checkname)
    {
    errname.innerHTML="";
    }
    else
    {
    errname.innerHTML="Username will be of length 8";
    }
    }

    //Password
    if(!pwd)
    {
    errpass.innerHTML="Mobieno. cannot be blank";
    }
    else
    {
    let checkpass=valiatepassword(pwd);
    if(checkpass)
    {
    errpass.innerHTML="";
    }
    else
    {
    errpass.innerHTML="Mobile number will be of length 10 and only in numbers"
    }
    }
}

//Validating Username
function validatename(name)
{
  let val=false;
  //Validating length
  if(name.length > 8) 
  { val=true; } 
  else 
  { val=false; }

  //Validate username of only characters
  if(val)
  {
  var valid=/^[a-zA-Z]+$/;
  if(name.match(valid))
  {
    console.log("true");
    val=true;
  }
  else
  {
    console.log("false");
    val=false;
  }
 }
  return val;
}

//Validating Password
function valiatepassword(pass)
{
let val=false;
if(pass.length===10)
{
val=true;
}
else
{
val=false;
}
}