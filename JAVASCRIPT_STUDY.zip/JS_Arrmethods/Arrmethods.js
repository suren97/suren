// Length
console.log("Length");
let arr=[1,2,3,4,5,6];
arr.length=3;
console.log(arr.length);
//Push
console.log("Push");
let arele=["suren","john","marie"];
arele.push("Darwin");
console.log(arele);
//Pop
console.log("Pop");
arele.pop();
console.log(arele);
//Splice
let arr1=[1,2,3,4,5,6,7];
console.log("Splice");
arr1.splice(3,1,"ss");
console.log(arr1);
//Slice
console.log("Slice");
let arr2=["a","b","c","d","e","f"];
let gh=arr2.slice(3);
console.log(gh);
//Object
let obj={
    name:"Mahi",
    status:"Active",
    code:"SM1234",
    info:function()
    {
    return this.name+" "+this.status;
    }
};
console.log(obj.info())
console.log("----------------------------");
const name={
    person:"john",
    age:25,
    empid:200,
    full:function()
    {
        return this.person+" "+this.age+" "+this.empid;
    }
};
console.log(name.full());
console.log("----------------------------");
const person1={
    name:"Raki",
    empid:300
};
const person2={
    name:"Yzki",
    empid:200
};
const mergename={
    fulldetails:function()
    {
        return "Name:"+this.name+" "+"Empid:"+this.empid;
    }
};