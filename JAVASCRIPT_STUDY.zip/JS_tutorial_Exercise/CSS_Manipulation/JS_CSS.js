//Get scrollbar width and height of an element
const box=document.querySelector(".box");
const width=box.offsetWidth;
const height=box.offsetHeight;
console.log("Width:"+width,"Height:"+height);

//Toggle classList
const elem=document.getElementById("box");
elem.addEventListener("click",function(){
    elem.classList.toggle("box2");
});

//Getting styles of an element
const getstyl=document.getElementById("box").style;
console.log(getstyl);

//Adding styles of an element
const addsty=document.getElementById("box");
addsty.style.width="400px";

//Get and set the HTML content
var cont=document.getElementById("text");
console.log(cont.innerHTML);

//Insert an element after another
var para=document.createElement("p");
para.innerHTML="Inserting an element after the elements";
var clone=para.cloneNode(true);
cont.appendChild(para);
cont.appendChild(clone);


