//Check if an array contains a value in JS

//Check if an array contains string
let arr=["A","B","C","D","E"];
console.log("String:"+arr.includes("A"));

//Check if an array contains numbers
let arrnum=[1,2,3,4,5,6];
console.log("Number:"+arrnum.includes(3));

//Check if an array contains Object
const obj1={name:"Peter",status:"Active"};
const obj2={name:"Mary",status:"Active"};
const lists=[obj1,obj2];
console.log("Objects:"+lists.includes(obj2));

console.log("---------------------------------------");
//Check if a Variable is array in Javascript
console.log("CheckArr:"+Array.isArray(arr));
console.log("Instanceof:");
console.log(arr instanceof Array);

console.log("---------------------------------------");
//Remove Duplicates in an array
console.log("Remove Duplicates");
let duparr=[1,2,3,4,4,1,2,3,3];
let orgarr=duparr.filter((v,i)=>{ return duparr.indexOf(v)===i; });
console.log(orgarr);

console.log("---------------------------------------");
//Sorting an Object
console.log("Sorting an Object");
let employees = [
    {
        firstName: 'John',
        lastName: 'Doe',
        age: 27,
        joinedDate: 'December 15, 2017'
    },
    {
        firstName: 'Ana',
        lastName: 'Rosy',
        age: 25,
        joinedDate: 'January 15, 2019'
    },
    {
        firstName: 'Zion',
        lastName: 'Albert',
        age: 30,
        joinedDate: 'February 15, 2011'
    }
];
employees.sort((a,b)=>
{
    return a.age - b.age;
})
employees.reverse();
console.log(employees);

console.log("-------------------------------------------");
console.log("Retreiving the array of objects");
//Retreiving the array of Objects using forEach
let getres=[];
let ret=employees.forEach(itfunc);
function itfunc(value,index)
{
   console.log(value);
}

console.log("-------------------------------------------");
console.log("Sort an Object using Name");
employees.sort((a,b)=>{
    let fn=a.firstName.toLowerCase();
    let fn1=b.firstName.toLowerCase();
    if(fn > fn1)
    {
        return 1;
    }
    if(fn < fn1)
    {
        return -1;
    }
    return 0;
})
console.log(employees);

console.log("-------------------------------------------");
console.log("Sort an Object by Dates");
employees.sort((a,b)=>
{
   let d1=new Date(a.joinedDate);
   let d2=new Date(b.joinedDate);
   return d1-d2;
});
console.log(employees);

console.log("-------------------------------------------");
console.log("four ways to empty an array in JS");
let arry=[1,2,3,4,5,6,7,8];
//1.
// arry=[];
//2.
// arry.splice(arry[0]-1,arry.length)
//3.
// arry.length=0;
//4.
while(arry.length > 0)
{
    arry.pop();
}
console.log(arry);