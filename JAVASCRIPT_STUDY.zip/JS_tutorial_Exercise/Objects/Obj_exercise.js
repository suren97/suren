//Check property exists in Object

//hasOwnProperty()
const person={
    name:"Surendar",
    status:"Active",
    empid:1888
}
//Method one
console.log(person.hasOwnProperty('age'));
//Method two
console.log('status' in person);
//Method three
console.log(person.act!==undefined);
console.log("---------------------------------");
//----------------------------------------------------------------------
//Merging the objects
console.log("Merging over an Object");
const obj1={name:"John",empid:200,role:"HR"};
const obj2={salary:"25K",status:"Active"};
//Method one
let mergone=Object.assign({},obj1,obj2);
console.log(mergone);
//Method two
let mergtwo={...obj1,...obj2};
console.log(mergtwo);
console.log("---------------------------------");
//----------------------------------------------------------------------
//Iterate Object in Javascript
console.log("Iterate over an object");
const obj={
    firstname:"Rajesh",
    lastname:"V",
    age:20,
    Dob:'Oct 2022'
};
for(var x in obj)
{
 console.log(obj[x])
}
console.log("---------------------------------");
//----------------------------------------------------------------------
//Copy object in js
console.log("Copy Object");
const dupobj=obj;
console.log(dupobj);
let dupobj1=Object.assign({},obj);
console.log(dupobj1);
let dupobj2={...obj};
console.log(dupobj2);