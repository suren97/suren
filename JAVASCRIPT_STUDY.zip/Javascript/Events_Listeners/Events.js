var albtn=document.getElementById("btn");
albtn.addEventListener("click",function()
{
  alert("InDanger");  
})
albtn.addEventListener("mouseover",()=>
{
 alert("Cautious before touching");
})

//Input events handler
function handlers()
{
    var name=document.getElementById("name").value;
    var num=document.getElementById("mobile").value;
    console.log(name);
    console.log(num);
}
