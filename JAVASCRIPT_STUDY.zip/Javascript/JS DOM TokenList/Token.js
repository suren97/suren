function load()
{
var ele=document.getElementById("mydiv");
// ele.add("addstyle");
// ele.remove("addstyle");
// ele.toggle("addstyle");
if(ele.className=="addstyle")
{
    ele.className="addstyle2";
}
else
{
    ele.className="addstyle";
}
console.log(ele);
// document.getElementById("mins").innerHTML=d.getTime();

// let arr=[1,2,3,4,5,6,7,8,9,10];
// for(let i=0;i<arr.length;i++)
// {
//     setTimeout(()=>{console.log(arr[i])},1000);
// }
// for(var i=0;i<arr.length;i++)
// {
//     setTimeout(()=>{console.log(arr[i])},1000);
// }

//Object to Arrays
let obj={empid:202,name:"James",role:"Devops"};
console.log(Object.keys(obj));
console.log(Object.entries(obj));
console.log(Object.values(obj));

//Array to Object
let arr=["1","BMW",30000];
let subarr=[["id",1],["name","Sathish"],["role","HR"],["age",30]];
//Method 1
let newval=Object.assign({},arr);
console.log(newval)
//Method 2
let ob={...arr};
console.log(ob);
//Method 3
let val2=Object.fromEntries(subarr);
console.log(val2);
{
    let p=10;
    let q=20;
    console.log(p);
    console.log(q);
}
}
let text = "We are the so-called \"Vikings\" from the north.";
console.log(text);