console.log("-----Arrow Functions-----");

normal();

function normal()
{
    console.log("Normal Expression function");
}
const hello=function()
{
    console.log("Anonymous functions..");
}
x=10;
y=20;
var add=(x,y)=> 
{
console.log("Arrow functions"); 
return x + y;
}
hello();
add();
console.log("-------------------------------");
//Spread Operator(...)
console.log("Spread Operator");
let team1=["Akash","Browny","Charles","Denim"];
let team2=["Mathews","Brenden","Oslo","Warner"];
team1.push(...team2);
console.log(team1);
var numbers=[10,35,82,632,6232,64,374];
console.log(Math.max(...numbers));
console.log("-------------------------------");
console.log("for of loop");
//For of loop ->Value of an object or array
//for of using array
let vehicle=["Bike","Car","Bus","Auto","Lorry"];
let txt="";
for(const x of vehicle)
{
    txt+=x+" ";
}
console.log("Arrays:"+txt);
//for of using strings
let str="Javascript";
let txt1="";
for(const y of str)
{
    txt1+=y;
}
console.log("Strings:"+txt1);
//for in -> Properties of an array
let arrele=[10,20,30,40,50];
for(var z in arrele)
{
    // console.log(z);
}
//for each
var numbers=[10,20,30,40,50];
let finnum="";
numbers.forEach(fun);
function fun(value,index)
{
if(value==10)
{
    value=5;
}
finnum+=" "+value;
}
console.log(finnum)

