console.log("-----------------------------------");
console.log("Map");
var banks=new Map([
    ["HDFC",1],
    ["ICICI",2],
    ["Axis",3],
    ["Citi",4],
    ["YES",5],
    ["DBS",6],
    ["Jupiter",7],
    ["Indian",8],
]);
banks.set("Canara",9);
console.log("Delete YES Bank:"+banks.delete("YES"));
console.log("Check for DBS Bank:"+banks.has("DBS"));
console.log("Map Size:"+banks.size);
banks.forEach(function(value,key){
    console.log(value+" "+key)
})
//banks.clear();
console.log(banks);
console.log("-----------------------------------");
console.log("Set");
var states=new Set();
states.add("TamilNadu");
states.add("Delhi");
states.add("Karnataka");
states.add("Andhra Pradesh");
states.add("Madhya Pradesh");
states.add("Missoram");
states.add("Delhi");
console.log(states);
for(let v of states.entries())
{
    console.log(v);
}