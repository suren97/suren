console.log("-------------------------------");
console.log("Rest Parameter");
function restparam(...args)
{
let sum=args.reduce((p,c)=>{
    return p+c;
});
console.log(sum);
}
var x=restparam(150,100,200,250,5.245,40,30.98);
console.log("-------------------------------"); 
console.log("includes");
let st1="javascript";
let st2="script";
console.log(st1.includes(st2));
console.log("-------------------------------"); 
console.log("startsWith");
var m1="javascript";
console.log(m1.startsWith("java"));
console.log("-------------------------------"); 
console.log("endsWith");
console.log(m1.endsWith("java"));
console.log("-------------------------------"); 
console.log("from");
const getarr=Array.from("0182");
var result=getarr.reduce((p,c)=>{ return parseInt(p)+parseInt(c); });
console.log(result);