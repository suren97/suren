console.log("-----------------------------");
console.log("Symbols:");
let fname="Surendar";
let lname="Warrior";
console.log(Symbol("surendar"));
console.log(Symbol("surendar"));
console.log(sym);
