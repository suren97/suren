console.log("JS Classes");
class System
{
    constructor(brand,cost)
    {
        this.brand=brand;
        this.cost=cost;
    }
    show()
    {
        return "Brand:"+this.brand+"\nCost:"+this.cost;
    }
}
class getdetails extends System
{
    constructor(brand,cost,ram)
    {
        super(brand,cost)
        {
          this.ram=ram;
        }
    }
    display()
    {
    console.log("Loading information.....");
    return this.show()
    +"\nRAM:"+this.ram
    +"\nInvoice:"+Math.round(Math.random()*100000000);
    }
}
let s1=new getdetails("Dell",25000,"4gb");
console.log(s1.display());

//Getters and Setters in class
class A
{
    constructor(name)
    {
     this.setName(name);       
    }
    setName(name)
    {
        console.log("Setting a name....");  
        this.name=name;
    }
    getName()
    {
    return this.name;
    }
}
let g=new A("Mike");
g.getName();
console.log(g);

//Static Method in Class
class test
{
    constructor(name,year)
    {
        this.name=name;
        this.year=year;
    }
    static hello(x)
    {
        return "Hello"+" "+x.name+" "+x.year;
    }
}
let t1=new test("Jackson",2015);
console.log(test.hello(t1));

//Default Parameters Values
function putdefault(x,y=50)
{
return x+y;
}
let ret=putdefault(5);
console.log(ret);

