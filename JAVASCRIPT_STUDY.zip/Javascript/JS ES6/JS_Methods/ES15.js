console.log("trim()");
var s1="   Javascript";
var s2="Javascript   ";
console.log(s1.trim()==s2.trim());
console.log("------------------------");
console.log("String number access");
var ch="Getting a characters";
console.log(ch.charAt(3));
console.log("------------------------");
console.log("isArray");
let arr=[1,2,3,4,5,6];
console.log(Array.isArray(arr));
console.log("------------------------");
console.log("Array forEach()");
var fval="";
arr.forEach(filterit);
function filterit(value,index)
{
    if(value==3)
    value=25
    fval+=value+" ";
}
console.log(fval);
console.log("Array filter");
let farr=[1,2,3,4,5,6,7,8,9,10];
let fnum=farr.filter((v,i)=>{return v%2==0});
console.log(fnum);
let maxarr=[10,203,40,49,4,48];
console.log("Array reduce");
let fmax=maxarr.reduce((p,c)=>{ return p > c ? p : c})
console.log(fmax);
console.log("Array reduceRight");
let arr5=[10,203,40,49,4,48];
let redrt=arr5.reduceRight((p,c)=>{return p>c ? p :c});
console.log(redrt);
console.log("Sample practice");
let obj1={name:"Anand",empid:202,role:"Devops"};
let obj2={salary:25000,Doj:"Oct,2007"};
let combine;
//Method 1
// for(var x in obj1)
// {
// combine[x]=obj1[x];
// }
// for(var y in obj2)
// {
// combine[y]=obj2[y];
// }
// console.log(combine);
//Method 2
combine=Object.assign([],obj1,obj2);
console.log(combine);

let newobj=Object.create(obj1);
console.log(newobj);

let str="surendar javascript method";
console.log(str.split("").reverse().join(""));