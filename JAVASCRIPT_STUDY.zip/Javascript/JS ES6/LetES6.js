//ES6 Features
//Let and Const keyword

// var
console.log("var");
var x=10;
{
    var x=2;
    console.log(x);
}
console.log(x);
console.log("-----------------------");
// Let
console.log("Let");
let y=20;
{
    let y=3;
    console.log(y);
}
console.log(y);
console.log("Const");
console.log("------------------------");
// Const
const a=10;
{
const a=30;
console.log(a);
}
console.log(a);
//Const in Objects
console.log("Const in Objects");
const person={
    name:"Joseph",
    age:25,
    empid:21334
};
person.name="Akash";
person.location="Chennai";
console.log(person);
//Freezing an Object
console.log("Object Freezing");
const details=Object.freeze({
    Aadhar_no:1232983,
    mobile:8927326726,
    email:"yaki@gmail.com"
});
console.log(details);
//Example-2
const details_2=Object.freeze({
    door:23,
    Room:32,
    Apartment:"SSV",
    Charges:{
        water:250,
        maintanance:500,
        electricity:450
    }
});
details_2.Charges.trash=300;
details_2.Charges.others=100;
console.log(details_2);

 