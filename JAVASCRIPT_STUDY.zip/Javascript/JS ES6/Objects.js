console.log("----------------------------------");
console.log("Objects");
//Objects General
const persons={
    name:"Warrior",
    team:"Sonata",
    details:function(city,code)
    {
        return "Name:"+this.name+"<br>"+"Team:"+this.team+"<br>"+"City:"+city+"<br>"+"Empcode:"+code;
    }
};
var cont=document.getElementById("cont");
var p=document.createElement("p");
p.innerHTML=persons.details("Chennai","SM1888");
cont.appendChild(p);

// Constructor functions
function Bank(name,acctype,balance)
{
    this.name=name,
    this.acctype=acctype,
    this.balance=balance,
    this.getalldetails=function()
    {
        return this.name+" "+this.acctype+" "+this.balance;
    };
}
let putdetails=new Bank("Surendar","Savings",25000);
console.log(putdetails.getalldetails());

//Create object using own property
let engineers={
    name:"Anand",
};

const employee=Object.create(engineers,{
    details:{
    age:30,
    role:"Tester",
    }
});
console.log(employee.hasOwnProperty("details"));
console.log(employee.hasOwnProperty("age"));
console.log(Object.create({name:"Sample",id:0000}));
//Returning multiple values using the Object
function retobj()
{
let obj2={};
obj2.id=200,
obj2.name="Suren",
obj2.keys="243wwn";
return obj2;
}
console.log(retobj());

//Object destructuring
let pobj={
   brand:"Dell",
   cost:25000,
};
const {brand,cost,qty:qy=21}=pobj;
console.log(brand);
console.log(cost);
console.log(qy);

//Samples
let sampleobj={
    check1:"sjj",
    check2:122,
    check3:
    {
    n1:2,
    n2:4
    },
};
console.log(Object.hasOwnProperty(sampleobj));

for(const x in sampleobj)
{
    if(sampleobj.hasOwnProperty(x))
    {
    let y=sampleobj[x];
    console.log(y);
    }
}