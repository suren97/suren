function setlocal()
{
let name=document.getElementById("name").value;
let email=document.getElementById("email").value;
let mobile=document.getElementById("mobile").value;
let loc=document.getElementById("location").value;
let data=JSON.stringify({name,email,mobile,loc});
localStorage.setItem("data",data);
var get=localStorage.getItem("data");
console.log(get)
if(get)
{
    window.location.href="newpage.html";
}
}