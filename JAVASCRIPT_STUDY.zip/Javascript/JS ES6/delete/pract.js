//let and const keyword
var a=10;
let b=20;
const c=30;
{
    let b=55;
    var a=1000;
}
console.log(a);

//Spread Paramter
let arr=[7,8,9,4,5];
arr.push(...arr);
console.log(arr);

//Rest Parameter
function restparam(...args)
{
    let sum=0;
    for(let x of args)
    {
     sum=sum+x;
    }
    console.log(sum)
}
let result=restparam(12,3,4,5,6,8,9,10,12,4,76,1);

//Includes
let s1="Surendar javascript";
let s2="javascript";
console.log(s1.includes(s2));

class Demo
{
    constructor(name,age)
    {
        this.name=name;
        this.Age=age;
    }
    show()
    {
        return "Name:"+this.name+"\n"+"Age:"+this.age;
    }
}
class GetResult extends Demo
{
    constructor(name,age,productname,qty,cost)
    {
     super(name,age)
     {
        this.productname=productname;
        this.qty=qty;
        this.cost=cost;
     }
    }
}
let v1=new GetResult("Surendar",25,"Shipping",1,2300);
console.log(v1);

//Default parameter
function defaultparam(x,y=87)
{
return x+y;
}
let ftch=defaultparam(54);
console.log(ftch);

// //array from
let dl=Array.from("Javas");
let d2=Array.from(12345);
console.log(dl);

//Array keys
let arry=["A","B","C","D","E"];
const keys=arry.keys();
for(let x of keys)
{
    console.log(x);
}
console.log("-----------------------------");

//Array find()
var aele=[10,20,30,40,50,60];
var rslt=aele.find(valfun);
function valfun(v,i)
{
    return v > 30;
}
console.log(rslt);

//Array findIndex()
var fele=[32,38,54,32,43,98];
var indx=fele.findIndex(getindex);
function getindex(val,ind)
{
return val > 43;
}
console.log(indx);

