var sports=["cricket","Football","Hockey","Kabadi","Volleyball"];
const ent=sports.entries();
let newarr=[];
console.log("Object Entries");
//Object entries
for(var x of ent)
{
    console.log(x);
}
console.log("Cloning an Object");
//Cloning an object
let obj={name:"Ashok",id:202};
let obj2={name:"Dna",id:202};
//Method 1
let clo1=obj;
//Method 2
let clo2=Object.assign({},obj);
console.log(obj);
console.log("Object is");
let amount =100;
let amount2=100;
console.log(amount===amount2);
//string padding
let text="5";
text=text.padEnd(4,0);
console.log(text);
//Object values
console.log("Object Methods");
const person={
    firstname:"John",
    lastName:"Doe",
    age:25,
};
let entry=Object.entries(person);
let entvalue=Object.values(person);
console.log("Object entries");
for(var z of entry)
{
    console.log(z);
}
console.log("Object values");
for(var x of entvalue)
{
    console.log(x);
}
console.log("Rest Properties");
//Object Rest properties
let {p,q,...r}={p:1,q:2,r:3,s:4,t:5,u:6};
console.log(p);
console.log(q);
console.log(r);
//Object from entries
console.log("Object from entries:");
var pobj=[
    ["Object1",100],
    ["Object2",200],
    ["Object3",300],
    ["Object4",400]
];
const gobj=Object.fromEntries(pobj);
console.log(gobj);