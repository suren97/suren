var prom=new Promise((resolve,reject)=>
{
 fetch("https://randomuser.me/api/")
 .then((response)=>response.json())
 .then((data)=>resolve(data.results[0]));
})
async function getdatas()
{
    let result=await prom;
    console.log(result);
}
getdatas();
