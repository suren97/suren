//DOM Methods
//finding HTML elements
var main=document.getElementById("dom");

//Creating a para tag
var inp=document.createElement("p");
inp.innerHTML="Created a Paragraph";
inp.style.padding="12px";
inp.style.backgroundColor="green";
inp.style.color="white";
main.appendChild(inp);

//Creating a label elements
var lab=document.createElement("label");
lab.innerHTML="Enter_Name:";
lab.style.padding="5px";
main.appendChild(lab);

//Creating a input elements
var ele=document.createElement("input");
ele.type="text";
ele.style.padding="3px";
main.appendChild(ele);

//Creating a table element
var tab=document.createElement("table");
//Row
var r=document.createElement("tr");
//Heading
var h=document.createElement("th");
//Data
var d=document.createElement("td");
tab.appendChild(r);
tab.appendChild(h);
tab.appendChild(d);
main.appendChild(tab);
console.log(tab);