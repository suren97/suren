const getresponse=fetch("https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits")
.then((response)=>response.blob())
.then(async(data)=>{
   
})