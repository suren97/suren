function Valid()
{
//Validate only letters
//  var exp=/^[A-Za-z]+$/;
// ------------------------------------
//Validate only numbers
//  var exp=/^[0-9]+$/;
// ------------------------------------
// Validate only special characters
// var exp=/^[!@#$%^&*()?./]+$/
// ------------------------------------
//Validate only numbers and strings
// var exp=/^[a-zA-Z]+[0-9][^!@#$%^&*()?.]+$/;
// ------------------------------------
//Validate only strings and special characters
//var exp=/^[a-zA-Z]+[!@#$%^&*()?.][^0-9]+$/;
// ------------------------------------
//Validation of enter only numbers of 4 digits by adding max length in html
var exp=/^[0-9]+$/;
var v=document.getElementById("inp").value;
console.log(v.match(exp));
}