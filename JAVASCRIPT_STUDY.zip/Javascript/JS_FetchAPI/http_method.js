HTTP Methods:
Get
Post
Put