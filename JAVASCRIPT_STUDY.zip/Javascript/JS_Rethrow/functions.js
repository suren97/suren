//Call method
const person={
    name:"Surendar",
    age:25,
    empid:1888,
    salary:"25k",
    status:"Active",
    tech:"JS",
    others:function()
    {
        return this;
    }
}
const empdetails={
   display:function(city,pin)
   {
    this.city=city;
    this.pin=pin;
    return this;
   }
};
const others={
   team:"sonata",
   address:"chennai"
 };

//Call is used to obtain the method belonging to object.
//Call Method
console.log(empdetails.display.call(person,"Chennai",603202));

//Apply method is similar to call method but the argument passed in apply is in the form of array.
//Apply method
console.log(empdetails.display.apply(person,["Address","Sonata"]));

//Bind method 
//Bind method is used to borrow the method from one object to another Object

let get=person.others.bind(others);
console.log(get());

//Callbacks
function result(scores)
{
return scores.toString();
}
function generatemark(marks,callback)
{
  return result(Object.entries(marks))
}
let marks={sub1:80,sub2:50,sub3:53};
console.log(generatemark(marks,result));

//asynchronous functions
var state=true;
let prom1=new Promise((resolve,reject)=>
{
  fetch("https://randomuser.me/api/")
  .then((response)=>{ return response.json()})
  .then((data)=>{ reject("Data1") })
});

let prom2=new Promise((resolve,reject)=>
{
  fetch("https://randomuser.me/api/")
  .then((response)=>{ return response.json()})
  .then((data)=>{ reject("Data2") })
});

let prom3=new Promise((resolve,reject)=>
{
  fetch("https://randomuser.me/api/")
  .then((response)=>{ return response.json()})
  .then((data)=>{ resolve("Data3") })
});

let getres=Promise.race([prom1,prom2,prom3]);
getres.then(
    (value)=>{
        console.log(value);
    }
)
getres.catch(
    (error)=>
    {
        console.log(error);
    }
)
console.log(getres);