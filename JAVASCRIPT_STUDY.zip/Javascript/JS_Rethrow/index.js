//Functions
//Normal function
function f1()
{
    //code
}

//Anonymous function
const f2=function()
{
    //code
}

//Arrow function
let f3=()=>
{
  console.log("f3...");
}

//Function call
//function apply
//function bind
//function closure




//Objects
const obj1={name:"Suren",empid:200,status:"Active"};
const obj2=[{name:"Vasanth",empid:350,status:"Inactive"}];
const obj3=new Object();
const obj4={};
obj4.name="sss";
//Object methods
// assign,freeze,isfrozen,seal,entries,values,keys,issealed
//String methods
//Array methods

//Classes
//class constructor
//super


//JSON
//JSON Datatypes
//JSON Parse
//JSON Stringify
//JSON Objects
//JSON Arrays

//Webstorage (localstorage,sessionstorage)
//Fetch
//this keyword
//HTML DOM, Events

//Promise,Asynchronous function,Async/await