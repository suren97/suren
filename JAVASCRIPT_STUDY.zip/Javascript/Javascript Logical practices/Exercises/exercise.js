var str="Javascript Javascript demo";
let n=str.length;
let count=0;
let replong="";
for(i=0;i<n;i++)
{
 for(j=i+1;j<n;j++)
 {
   if(str.substring(i,n)===str.substring(j,n))
   {
    console.log(str)
   }
 }
}

var ele=document.getElementById("listen");
ele.addEventListener("mouseover",function()
{
    ele.style.fontSize="20px";
})
ele.addEventListener("click",function()
{
    ele.style.color="red";
})

//sum of an array
var arr=[54,35,43,32,55];
let pos=1;
var getindex=arr.filter((item,index)=>{  return arr.indexOf(item)===pos;  })
console.log(getindex);

//string methods
var str="javascript";
console.log(str.search("as"));
console.log(str.match("java"));
console.log(str.includes("pt"));
console.log(str.indexOf('s'));
console.log(str.charAt(5));
console.log(str.charCodeAt(4));

//count no. of occurences of given strings
var s1="javascript";
var cot=0;
for(i=0;i<s1.length;i++)
{
    if(s1.charAt(i)=="s")
    {
        cot++;
    }
}
console.log(cot)

//entries
let fruits=['Apples','Orange','Banana','Citrus'];
let val={};
for(let x of fruits)
{
    fruits.forEach((v,i)=>{
       val[`value${i}`]=v;
    });
}
console.log(val)

//Remove dup
let rem=[1,2,3,4,5,1,2,3,4];
var resp=rem.filter((v,i)=>{
  return rem.indexOf(v)===i;
})
console.log(resp);

//Remove duplicates in string
var s3="java javascript java";
var c=0;
var fstr=s3.split(" ");
var resp=fstr.filter((v,i)=>{
   return fstr.indexOf(v)===i
});
console.log(resp);

//delete specified element
var dele=[1,2,3,4,5,6];
var r=2;
var fect=dele.filter((v,i)=>{
   return v!==r;
})
console.log(fect);

//Object to Array
var obary={name:"victory",miles:25,location:"Chennai"};
let arrobj=[];
for(var z in obary)
{
    arrobj.push(obary[z]);
}
console.log(arrobj);
var num="surendar javascript";
console.log(num.slice(2,-1));
console.log(num.substring(2));

//filters
var farr=[1,2,3,4,5,6,5,4,2];
var fresult=farr.filter((v,i)=>{
    return farr.indexOf(v)===i;
});
console.log(fresult);
//Repeatative numbers of an array
var rresult=farr.filter((v,i)=>{
    return farr.indexOf(v)!==i;
});
console.log(rresult);
//Iterating over a string
let strname="java script java";
let sarr=strname.split(" ");
let frst=sarr[0];
let long="";
for(i=0;i<sarr.length;i++)
{
    if(sarr[i]==frst)
    {
     frst=sarr[i];
     long=sarr[i];
    }
    else
    {
        frst=sarr[i];
    }
}
console.log(long);
//checking for even or odd
var empobj={person:"suresh",location:"Chennai",id:230};
// for(var x of empobj)
// {
// delete empobj[x];
// }
//empobj={};
console.log(empobj);
//Merge two arrays and sort in descending order
var a1=[1,2,3,4];
var a2=[5,6,7,8];
a1.push(...a2);
var a3=a1;
a3.sort((a,b)=>{
    return b-a;
});
console.log(a3);