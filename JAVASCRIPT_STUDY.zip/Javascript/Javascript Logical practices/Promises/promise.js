//function closure
const hello=function()
{
    let count=0;
    return function() { count+=1; return count;}
}();
function produce()
{
    document.getElementById("btn").innerHTML=hello();
}
function f1()
{
    console.log("f1");
}
function getvalue()
{
    console.log("f2");
    var prom=new Promise((resolve,reject)=>
    {
        setTimeout(()=>{resolve("Success")},2000);
    })
    var prom1=42;
    var prom2=setTimeout(()=>{Promise.resolve(3)},3000);
    prom.then(
        (value)=>
        {
            console.log(value);
        },
        (error)=>
        {
            console.log(error)
        }
    )
    Promise.race([prom,prom1,prom2]).then(
        (value)=>{console.log(value)}
    );
}
function f3()
{
    console.log("f3");
}
function f4()
{
    console.log("f4");
}
f1();
getvalue();
f3();
f4();
var p=new Promise((resolve,reject)=>{
   setTimeout(()=>{resolve("Success")},2000);
})
async function runprom()
{
var get=await p;
console.log(get);
}
runprom();
//Reverse a number
var ab=1234;
var rev=ab.toString().split("").reverse().join("");
console.log(Number(rev));
//Max of array
let maxnum=[10,20,50,100,60,70];
var getmax=maxnum.reduce((p,c)=>{return p > c;});
console.log(getmax);

var map=new Map([
    ["apples",100],
    ["banana",300],
    ["citrus",400],
]);
map.set("guava",300);
console.log(map);