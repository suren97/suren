function workpromise()
{
var names=document.getElementById("name").value;
var age=document.getElementById("age").value;
var num=document.getElementById("mobile").value;
loadData(names,age,num);
}
function loadData(n,a,m)
{
let prom=new Promise(function(resolve,reject)
{
    var ele=document.getElementById("content");
    ele.innerHTML="Loading data..."; 
    if(n&&a&&m)
    setTimeout(()=>{resolve("Success");},3000);
    else
    reject("Failed");
})
prom.then(
    function(value)
    {
    document.getElementById("content").innerHTML="The Entered Name is:"+ n+
    "<br></br>"
    +"The Entered Age is:"+a+"<br></br>"+
    "The Entered Number is"+m;
    }
)
prom.catch(
    function(error)
    {
        console.log(error);
        document.getElementById("content").innerHTML="Please Fill out the fields...";
    }
)
}