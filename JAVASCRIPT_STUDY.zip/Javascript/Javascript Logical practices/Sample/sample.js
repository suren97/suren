//Duplicate
let arry=[1,2,3,4,4,5,7,19,9];
var res=arry.filter((v,i)=>{ return arry.indexOf(v)===i;  })
console.log(res);
//max number
var res=arry.reduce((p,c)=>{ return p > c ? p :c });
console.log(res);
//check all elements are equals
var ele=["test","test","test","test"];
var frst=ele[0];
let val=true;
var out=checkelem(ele,frst);
function checkelem(ele,frst)
{
  // Method-1
  // let res=ele.every(function(e)
  // {
  //  return e==frst
  // })
  // console.log(res);
   // Method-2
    // for(i=ele.length-1;i>=0;i--)
    // {
    //   if(ele[i]!==frst)
    //   {
    //     val=false;
    //     return val;
    //   }
    // }
    // return val;
}
//console.log(out);
//nth element of an array
var elem=[1,2,3,4,5,6];
let pos=5;
var out=hello(elem,pos);
function hello(elem,pos)
{
let val=elem.filter((v,i)=>{return i+1==pos && v })
return val;
}
console.log(out);
//Sort Descending order
var values=["Suren","Andrews","Clarke","Ben","Alan","Denim"];
var resp=values.sort((prev,curt)=>{
  return prev - curt;
})
console.log(resp)
//Swap two variables
var a=10;
var b=20;
var c=a;
a=b;
b=c;
console.log("a:"+a);
console.log("b:"+b);
//Largest among 3 numbers
var a=220,b=1040,c=130;
var d=()=>{ return (a>b)?a:(b>c)?b:c}
console.log(d());
//program to check prime number
var num=17;
let count=0;
for(i=0;i<=num;i++)
{
  if(num%i==0)
  {
   count++; 
   if(count>2)
   console.log(count);
  }
}
if(count==2)
console.log("prime");
//program to print armstrong number
var arrnum=153;
var n=arrnum;
var sum=0,rem=0;
while(n>0)
{
rem=n%10;
sum=sum+rem*rem*rem;
n=parseInt(n/10);
}
if(sum==arrnum)
 console.log("Armstrong");
else
console.log("Not Armstrong");
//program to remove a property from an object
var acc={name:"Warrior",age:25,medal:"Gold"};
for(let x in acc)
{
delete acc[x];
}
console.log(acc);
//program to convert object to strings
var aobj={name:"Dell",price:20000,ram:"4gb",disk:"28gb"};
var res=JSON.stringify(aobj);
console.log(res);
//Program to compare Two strings
var str1="Surendar";
var str2="Surendar";
console.log(str1===str2);
//program to remove specifi stirng from an array
var sample=[1,2,3,4,5,6];
var remov=3;
var result=sample.filter((v,i)=>{
  if(v!==remov)
  {
    return v;
  }
});
console.log(result)
//Merge two arrays
var arr1=[1,2,3,4,7];
var arr2=[3,5,6,4,12];
arr1.push(...arr2);
var result=arr1.filter((v,i)=>{ return arr1.indexOf(v)===i; })
console.log(result);
console.log("-------------------------------");
//Replace all occurences in a string
var strele="javas";
const upd=strele.replace("s","script");
console.log(upd);
//display date and time
function display()
{
  var dt=new Date();
  document.getElementById("date").innerHTML="Today Date:"+ dt.toISOString().split("T")[0];
  document.getElementById("time").innerHTML="Time is:"+dt.toLocaleTimeString();
}
const one=24*60*60*1000;
const d1=new Date();
const d2=new Date("1997-10-16");
const nod=Math.round(Math.abs((d1-d2)/one));
console.log(nod);
//Clone of JS Objects
console.log("----------------------");
var obele={Name:"test",Age:25,Status:"danger"};
var obele2=obele;
var cobj={...obele};
var cobj2=Object.assign({},obele);
console.log(cobj2);
console.log(cobj);
//Convert array to object
var atob1=[1,2,3];
var gobj=Object.assign({},atob1);
var gobj2={};
for(i=0;i<atob1.length;i++)
{
  gobj2[i]=atob1[i]
}
console.log(gobj);
console.log(gobj2);
//Convert object to array
var parr=[];
for(var x in obele)
{
  let val={};
  val[x]=obele[x];
  parr.push(val);
}
console.log(parr);
//check whether the given obj is array
console.log(Array.isArray(obele));
//instance of operator
var m=[1,2,3,4];
document.getElementById("inst").innerHTML=(m instanceof Object);
//factorial of number
let n1=5;
let mul=1;
for(i=n1;i>=1;i--)
{
  mul=mul*i;
}
console.log(mul);
//reverse a number
var rnum="madam";
let finl=0;
var rev=rnum.split("").reverse().join("");
if(rnum==rev)
{
  console.log("palindrome");
}
// for(i=0;i<rev.length;i++)
// {
//   finl=finl+parseInt(rev[i]);
// }
// console.log(finl)
//Sum of array
var ary=[1,2,3,5];
var result=ary.reduce((p,c)=>{ return p*c;})
console.log(result);
//foreach
var astr=["network","security","vulnerability","intruders"];
astr.forEach(itrele);
function itrele(item,index)
{
console.log(item);
console.log(index);
}
console.log("----------------------");
//count no of odd and even
let evencount=0;
let evennum="",oddnum="";
let oddcount=0;
var oeven=[1,2,3,4,4,4];
oeven.forEach(countoven);
function countoven(item,index)
{
  if(item%2==0)
  {
    evennum+=" "+item;
    evencount++;
  }
  else
  {
    oddnum+=" "+item;
    oddcount++;
  }
}
console.log(evencount);
console.log(evennum);
console.log(oddcount);
console.log(oddnum)