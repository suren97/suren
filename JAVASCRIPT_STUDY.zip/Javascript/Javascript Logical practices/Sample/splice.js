var arr=[1,2,3,4,5,6];
//Get Data of first 4 element
arr.splice(4);
console.log(arr);   
//Insert data of 3rd position
arr.splice(1,0,"ins","ins","sss");
console.log(arr);
//Delete data of 'ins'
arr.splice(1,3);
console.log(arr);
console.log("----------Slice-----------");
//Slice
var arr2=[1,2,3,4,5,6,7];
console.log(arr2.slice(1,3));
console.log("-------------------------------");
//sorting an array of string
var alpha=["Suren","Andrews","Clarke","Ben","Alan","Denim"];
alpha.sort();
alpha.reverse();
console.log(alpha);
console.log("-------------------------------");
//Reverse a String
console.log("Reversing a String");
var str="surendar studying javascript";
var fin="";
var in2="";
for(i=str.length-1;i>=0;i--)
{
   fin=fin+str.charAt(i);
}
console.log(fin)
console.log("Reversing a string by word");
var sepstr=str.split(" ");
for(i=0;i<sepstr.length;i++)
{
for(j=sepstr[i].length-1;j>=0;j--)
{
in2=in2+sepstr[i].charAt(j);
}
}
console.log(in2);
//create Object in diff ways
//1
let obj={name:"suren",age:25};
console.log(obj);
//2
let obj1=new Object();
obj1.name="akash";
obj1.age=30;
console.log(obj1);
//3
let obj2={};
obj2.name="Prakash",
obj2.age=35;
console.log(obj2);