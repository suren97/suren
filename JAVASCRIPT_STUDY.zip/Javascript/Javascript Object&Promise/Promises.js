const getresult=new Promise((resolve,reject)=>
{
   fetch("https://randomuser.me/api/")
   .then((response)=>response.json())
   .then((data)=>{
     if(data)
     {
        resolve(data);
     }
     else
     {
        reject("Error");
     }
   });
});
// console.log(getresult);
async function fetchrec()
{
    let prom=await getresult;
    console.log(prom);
}
fetchrec();