var employee={
    name:"Mohan",
    empid:3022,
    mobile:9283392332,
    location:"Chennai"
};
let dupobj=Object.assign({},employee);
console.log(dupobj);
Object.defineProperty(dupobj,"property",{value:20});
console.log(dupobj);
Object.defineProperties(dupobj,{"Marks":{value:100},"Card":{value:"SE"}});
console.log(dupobj.Marks);

var num=1029939929929299227n;
console.log(typeof(num));

var str="I love cats. Cats are very easy to love. Cats are very popular.";
var rslt=str.matchAll(/Cats/g);

//Nullish Coalescing
let name="javascript";
let text=null;
let text3=null;
let finalres=text ?? name; 
console.log(finalres);

//Optional chaining operator
const car={type:"Fiat",year:2015,color:"white"};
let objrs=car ?.name;
console.log(objrs);