var prom1=new Promise((resolve,reject)=>{
    setTimeout(()=>{resolve("Success1")},2000);
});
var prom2=new Promise((resolve,reject)=>{
    setTimeout(()=>{reject("Success2")},2500);
});
var prom3=new Promise((resolve,reject)=>{
    setTimeout(()=>{resolve("Success3")},1000);
});
//All
Promise.all([prom1,prom2,prom3])
.then((values)=>{
console.log(values);
})
.catch((error)=>{
    console.log(error);
})
//Any
Promise.any([prom1,prom2,prom3])
.then((values)=>
{
console.log(values);
})
.catch(
(error)=>
{
console.log(error);
}
)
//Race
Promise.race([prom1,prom2,prom3])
.then((value)=>{
    console.log(value);
})

let createjson='{"firstname":"nord","age":20,"lastname":"Mitchell","Details":{"mobile":293874382,"money":287827}}';
console.log(createjson);

console.log("toFixed");
let num=2.3343;
console.log(num.toFixed(2));
console.log("toPrecision");
// let prenum=0.00028728;
let prenum=11.223627;
console.log(prenum.toPrecision(4));