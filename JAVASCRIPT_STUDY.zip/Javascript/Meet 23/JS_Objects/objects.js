const person={
    name:"smash",
    age:22,
    empid:200,
    details:function()
    {
      return this;
    }
}
const others={
    salary:"25k",
    acc:"Savings"
}
console.log(person);