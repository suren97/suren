let objsons='{"name":"harry","empid":100,"role":"HT"}';
let arrjsons='["jazzy",1,2,3,4,4,5]';
console.log(objsons);
console.log(arrjsons);


var prom=new Promise((resolve,reject)=>
{
    fetch("https://randomuser.me/api/")
    .then((response)=>response.json())
    .then((data)=> resolve(data));
})
async function getres()
{
    let result=await prom;
    console.log(result);
}
getres();

//Callback
function display(obj)
{
return obj;
}
function loadobject(Callback)
{
    const person={
        name:"Ajay",
        empid:200,
        status:"Active"
    }
 return Callback(person);
}
console.log(loadobject(display));

let arr=["ssm","233","243","24343"];
arr.fill(" ");
console.log(arr);

let elem=[10,20,30,40,50,60];
let findindex=40;

//find && findindex
let index=elem.find(getfun);
function getfun(value,index)
{
    return value>findindex;
}
console.log(index);

//every and some
let evy=elem.some(getelem);
let check=10;
function getelem(value,index)
{
   return value > 10;
}
console.log(evy);

let arrobj=[["name","nick"],["empid",200]];
let obj={name:"Cals",age:20};
console.log(Object.fromEntries(arrobj));

let sampleobj={empid:101,name:"Surendar"};
// Object.freeze(sampleobj);
sampleobj.name="Ashok";
console.log(sampleobj);

//Object own
let objon={
    name:"Southee",
    age:30,
    id:222
};
let objon1={
    name:"Southee",
    age:30,
    id:222
};

//hasOwn
let a=Object.hasOwn(objon,'age');
console.log(a);
console.log(objon);

let arrf=[1,,2,3];
let filele=arrf.filter((v,i)=>{ return v!==""; })
console.log(filele);

//json text to js object
let arrc=[1,2,3,3,44,5];
console.log(arrc);



