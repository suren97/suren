// //Longest subsequence
// var str1="Hello Javascript Javascript World";
// var splstr=str1.split(" ");
// let maxcount=0;

// let rep="";
// // console.log(splstr);
// for(i=0;i<splstr.length;i++)
// {
//     let count=0;
// for(j=0;j<splstr.length;j++)
// {
//     if(splstr[i]==splstr[j])
//     {
//        count++;
//     }
//     if(count > maxcount)
//     {
//         maxcount=count;
//         rep=splstr[i];
//     }
// }
// }
//  console.log(rep);
 
//  //Find the occurences in the array
//  let arr=[1,2,4,5,6];
//  let p=3;
// let filarr=arr.filter((v,i)=>{ return v==p; })
// console.log(filarr);

// //Move all negative elements to one side of an array
// var arrele=[1,2,3,-1,2,-3,4,-6,-7];
// let separr=[];
// let remarr=arrele.map((v,i)=>{
// if(v < 0)
// {
//     separr.push(v);
// }
// else
// {
//     separr.unshift(v);
// }
// });
// console.log(separr);

// //Object to Array
// let pele=[];
// const person={
//       name:"Raju",
//       empid:200,
//       role:"HR"    
// }
// console.log(Object.entries(person));

// //Array to Object
// let arrobj=["name","sathish","empid",200,"role","HR"];
// let obj=Object.assign({},arrobj);
// // console.log(obj); 
// let objele={...arrobj};
// console.log(objele);
// normal();
// function normal()
// {
// console.log("Normal");
// }
// let arrfun=()=>
// {
// console.log("Arrow function");
// }
// arrfun();

var prom=new Promise((resolve,reject)=>{
  reject("Succcess1");
});
var prom2=new Promise((resolve,reject)=>{
    resolve("Succcess2");
});
var prom3=new Promise((resolve,reject)=>{
    setTimeout(()=>{reject("Succcess3")},10);
});
var prom4=new Promise((resolve,reject)=>{
    setTimeout(()=>{resolve("Succcess4")},2000);
});
Promise.all([prom,prom2,prom3,prom4])
.then((value)=>{
    console.log(value);
})
.catch((err)=>{
    console.log(err);
})
Promise.any([prom,prom2,prom3,prom4])
.then((value)=>{
    console.log(value);
})
.catch((err)=>{
    console.log(err);
})
Promise.race([prom,prom2,prom3,prom4])
.then((value)=>{
    console.log(value);
})
.catch((err)=>{
    console.log(err);
})
const obj={name:"suren",empid:200,role:"HR"};
let {name,empid,Dept}=obj;
var a=12345;
let arr=Array.of(a);

//Slice
let arrele=[1,2,3,4,5,6,7,8];
// console.log(arrele.slice(3));
arrele.splice(2);
console.log(arrele);

//find the min
let arrmax=[10,20,30,400,30,50];
// let getmax=Math.min(...arrmax);
// console.log(getmax);

//remove dup
let arrdup=[1,2,3,1,3,4,5,7,9];
let getdp=arrdup.filter((v,i)=>{ return arrdup.indexOf(v)===i; });
console.log(getdp);

//second largest element
var arrelem=[10,30,20,40,50];
arrelem.sort();
console.log(arrelem[arrelem.length-1]);

//destructuring
var colors=["red","green","yellow","violet","orange"];
var [a,b,...args]=colors;
console.log(a);
console.log(args)