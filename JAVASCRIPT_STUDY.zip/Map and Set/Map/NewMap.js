//new Map() in JS 

//The Map object holds the key value pairs 
//and remembers the insertion order of the keys

//new Map() Methods
//1.set()
//2.get()
//3.clear()
//4.delete()
//5.has()
//6.forEach()
//7.entries()
//8.keys()
//9.values()
//10.size

const map1=new Map();
map1.set("a",23);
map1.set("b",20);
map1.set("c",3);
// console.log(map1.get("a"));
// map1.clear();
// map1.delete("a");
// console.log(map1.has("a"));
// map1.forEach(values=>
// {
//         console.log(values);
// })

// const iterator=map1.entries();
// console.log(iterator.next().value);
// console.log(iterator.next().value);
// console.log(iterator.next().value);

// console.log(map1.keys())
// console.log(map1.values())
// console.log(map1.size)

