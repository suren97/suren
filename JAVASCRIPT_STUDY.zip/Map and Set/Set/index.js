let arr=[1,2,3,4,1,1,5,6,7,2];

let getOrg=arr.filter((val,index)=>{
     return arr.indexOf(val)===index
})


let arrelem=[
    {id:1,name:"suren",empid:200},
    {id:2,name:"john",empid:300},
    {id:3,name:"suren",empid:200},
    {id:4,name:"vinoth",empid:400},
    {id:5,name:"lewis",empid:500}
]

let getElem=arrelem.filter((val,index)=>{
     
})