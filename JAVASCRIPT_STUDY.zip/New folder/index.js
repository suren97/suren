//JS Dates
console.log("Using Date Objects");
let a=new Date();
console.log(a);
console.log("------------------------------------------");
console.log("Using diff ways to create date by new Date");
//Date string
var d2=new Date("2022-10-25");
console.log("Datestring:"+d2);
//year,month
var d3=new Date("2022-10");
console.log("Year_Month:"+d3);
//year,month,day
var d4=new Date("2022-03-21");
console.log(d4);
//milliseconds
var d5=new Date("10000000000");
console.log(d5);

//Date Methods
console.log("------------------------------------------");
console.log("Date Methods");
var d6=new Date();
console.log("toString():"+d6.toString());
console.log("toDateString:"+d6.toDateString());
console.log("toUTCString:"+d6.toUTCString());
console.log("toISOString:"+d6.toISOString());

//Date Get Methods
console.log("--------------------------------------------");
console.log("Get Methods");
var d7=new Date();
console.log("getFullYear():"+d7.getFullYear());
console.log("getMonth():"+parseInt(d7.getMonth()+1));
console.log("getDate():"+d7.getDate());
console.log("getDay:"+d7.getDay());
console.log("getHours:"+d7.getHours());
console.log("getMinutes:"+d7.getMinutes());
console.log("getSeconds:"+d7.getSeconds());

//Date Set Methods
console.log("--------------------------------------------");
console.log("Set Methods");
var d8=new Date();
d8.setFullYear(2020);
d8.setDate(21);
d8.setMonth(6);
console.log(d8);

//Value exists in array or not
var arrele=[1,2,3,4,5];
if(arrele.indexOf(6)!==-1)
{
console.log("Exists")
}
else
{
console.log("Not Exists");
}

//call,apply,bind
const method={
    result:function(city,pin)
    {
        return this.name+" "+city+" "+pin;
    }
}
const obj={
   name:"Suren",
   empid:200,
   status:"active"
};
let fn=method.result.apply(obj,["chennai",600028]);
console.log(fn);

