const passengers = [
  {
    id: 1,
    passengerName: "Freddie Mercury",
    isVegetarianOrVegan: false,
    connectedFlights: 2,
  },
  {
    id: 2,
    passengerName: "Amy Winehouse",
    isVegetarianOrVegan: true,
    connectedFlights: 4,
  },
    {
    id: 3,
    passengerName: "Kurt Cobain",
    isVegetarianOrVegan: true,
    connectedFlights: 3,
  },
     {
    id: 3,
    passengerName: "Michael Jackson",
    isVegetarianOrVegan: true,
    connectedFlights: 1,
  },
];

//Getting the passengers name in descending order
console.log("Getting the passengers name in descending order using connected Flights");
console.log(passengers);
console.log("Descending order using connected flights:");
passengers.sort((x,y)=>
{
    return x.connectedFlights -y.connectedFlights;
})
console.log(passengers);
console.log("----------------------------------------");
console.log("Getting only passengers name:");
for(i=0;i<passengers.length;i++)
{
    console.log(passengers[i].passengerName);
}
console.log("----------------------------------------");
console.log("Getting only vegan");
let onlyvegan=passengers.filter((value,index)=>{
    return value.isVegetarianOrVegan===true;
});
console.log(onlyvegan);
console.log("-------------------------------------------");
let add=passengers.map((v,i)=>
{
    if(v.isVegetarianOrVegan===true)
    {
        v.id=200;
    }
    return v;
})
console.log(add);
console.log("-------------------------------------------");


//Password Visibility
function checkbox(e)
{
 var ps=document.getElementById("pwd");
 if(ps.type==="password")
 {
    ps.type="text";
 }
 else
 {
    ps.type="password";
 }
}

//Add classList
function addclass()
{
var ac=document.getElementById("btn");
// ac.classList.toggle("btnclass");
// ac.classList.add("btnclass");
ac.classList.replace("btnclass","repclass");
}

//Array.from()
var str="abcdaaa";
console.log(Array.from(str));