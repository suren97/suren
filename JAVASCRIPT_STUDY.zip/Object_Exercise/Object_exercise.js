// Write a function that takes two arrays (a and b) as arguments. 
// Create an object that has properties with keys 'a' and corresponding values 'b'. Return the object.
let a=['a','b','c'];
let b=[1,2,3];
let val={};
// let obj=createobj(a,b);
let fin=a.forEach(createobj);
function createobj(value,index)
{
   val[value]=b[index];
}
// console.log(val)


// Write a function that takes an object (a) and a number (b) as arguments. 
// Multiply all values of 'a' by 'b'. Return the resulting object.
let obj1={a:1,b:2,c:3};
let mul=3;
let mulfun=multifun(obj1,mul);
function multifun(obj,mul)
{
  let newval={};
  for(let x in obj)
  {
    newval[x]=obj[x]*mul;
  }
  return newval;
}
console.log(mulfun);

// Write a function that takes an object as argument. In some cases the object
//  contains other objects with some deeply nested properties. 
// Return the property 'b' of object 'a' inside the original object if it exists. 
// If not, return undefined

var sampobj={a:1,b:2,c:undefined,d:4};
var newobj={};
for(let x in sampobj)
{
   if(sampobj[x]!==undefined)
   {
     newobj[x]=sampobj[x];
   }
}
console.log(newobj);

//Sorting of objects
var sortobj={a:1,b:3,c:2,d:4};
var arr=Object.entries(sortobj);
arr.sort((x,y)=>
{
   return y[1] - x[1];
})
let sorted=Object.fromEntries(arr);
console.log(sorted);

//Array of Objects
let objsrt=[
    {id:1,name:"Rajesh",marks:40},
    {id:2,name:"Rakesh",marks:30},
    {id:3,name:"Vignesh",marks:20},
    {id:4,name:"Ganesh",marks:35},
    {id:5,name:"Ramesh",marks:60}
];

let filobj=objsrt.filter((v,i)=>{
    if(v.marks < 40)
    {
    return v.pass="fail";
    }
    else
    {
    return v.pass="pass"
    }
});
console.log(filobj);

