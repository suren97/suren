function load()
{
// var id=document.getElementById("id").value;
// var name=document.getElementById("name").value;
// var num=document.getElementById("mobile").value;

var table=document.getElementById("table");
var tab=document.createElement("table");
var rw=document.createElement("tr");
var h=document.createElement("th");
var d=document.createElement("td");

rw.appendChild(h);
h.innerHTML=300;

rw.appendChild(d);
tab.appendChild(rw);
console.log(tab);
}