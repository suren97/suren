function setdata()
{
    var name=document.getElementById("name").value;
    var id=document.getElementById("roll").value;
    var mark=document.getElementById("percent").value;
    var student=new Object();
    student.Name=name;
    student.Id=id;
    student.Mark=mark;
    console.log(student);

     //Create table
     var table=document.createElement("table");
     table.style.border="1px solid black";
     table.style.padding="3px";
     table.style.borderCollapse="collapse";
     table.style.width="40%";

     var r,h,d;
     r=document.createElement("tr");
     r.style.border="1px solid black";
     r.style.padding="3px";

     for(let x in student)
     {
     h=document.createElement("th");
     h.style.border="1px solid black";
     h.style.padding="3px";
     h.style.textAlign="center"
     h.innerHTML=x;
     r.appendChild(h);
     }
     table.appendChild(r);
     console.log(table);
     var create=document.getElementById("table");
     create.appendChild(table);
}



















// const display={
//     result:function()
//     {
//         return this;
//     }
// }

// const person1={
//     name:"Sathish",
//     empid:203
// };
// const person2={
//     name:"Kishore",
//     empid:210
// };

// let printval=display.result.call(person1);
// console.log(printval);

// //Generate random
// let rand=Math.floor(1000 + Math.random() * 9000);
// console.log(rand);




