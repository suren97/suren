// const employee={
//     name:"Johnson",
//     empid:202,
//     role:"HR",
//     status:"Active"
// };
// const details={
//     salary:"25,000",
//     hike:"10%",
//     software:"Data mining"
// };
// let keys=Object.keys(employee);
// let values=Object.values(employee);
// let entries=Object.entries(employee);
// let assign=Object.assign({},employee,details);
// let freeze=Object.freeze(employee);
// let seal=Object.seal(employee);
// console.log("Keys",keys);
// console.log("Values",values);
// console.log("Entries",entries);
// console.log("Assign",assign);
// console.log("Froze",Object.isFrozen(employee));


// //Object creation using object constructors
// function person(id,name,amount)
// {
//     this.empid=id;
//     this.empname=name;
//     this.salary=amount;
//     this.details=function()
//     {
//          return this.empid+" "+this.empname;
//     }
// }
// let entry=new person(200,"suren",25000);
// console.log(entry.details());

// const text=new Object();
// text.font="Italic";
// text.size="28";
// text.alphabets="alphabets";
// console.log(text);

// //dropdown
// let drop=document.getElementById("drop");
// var select=document.createElement("select");
// var option;
// for(let x in assign)
// {
// option=document.createElement("option");
// option.value+=[x];
// option.label+=assign[x];
// select.appendChild(option);
// }
// // for(i=1000;i<1010;i++)
// // {
// // option=document.createElement("option");
// // option.value+=i;
// // option.label+=i;
// // select.appendChild(option);
// // }
// console.log(select);
// drop.appendChild(select);


const passengers = [

    {

      id: 1,

      passengerName: "Freddie Mercury",

      isVegetarianOrVegan: false,

      connectedFlights: 2,

    },

    {

      id: 2,

      passengerName: "Amy Winehouse",

      isVegetarianOrVegan: true,

      connectedFlights: 4,

    },

      {

      id: 3,

      passengerName: "Kurt Cobain",

      isVegetarianOrVegan: true,

      connectedFlights: 3,

    },

       {

      id: 3,

      passengerName: "Michael Jackson",

      isVegetarianOrVegan: true,

      connectedFlights: 1,

    },
  ];

var arr=[2,4,6,7];
var felem=9;
let check=arr.includes(felem);
console.log(check);

