function getresult(list)
{
let prom;
if(list==1)
{
prom=new Promise((resolve,reject)=>
{
  resolve(userlist());
});
}
else if(list==2)
{
prom=new Promise((resolve,reject)=>
{
   resolve(adminlist());
});  
}
return prom;
}

async function fetchresult()
{
    var drop=document.getElementById("select");
    drop.addEventListener("change",async(v)=>
    {
     let getvalue=await getresult(v.target.value);
    if(getvalue)
    {
        var tab=document.getElementById("table"); 
        var th,td;
        var tr=document.createElement("tr");
        var tr1=document.createElement("tr");
        for(let x in getvalue)
        {
            th=document.createElement("th");
            th.style.color="red";
            th.innerHTML+=x;
            tr.appendChild(th); 
        }
        tab.appendChild(tr);
        for(let x in getvalue)
        {
            td=document.createElement("td");
            td.innerHTML+=getvalue[x];
            tr1.appendChild(td); 
        }
        tab.appendChild(tr1);
        console.log(tab);
    }
    });
}
fetchresult();

function userlist()
{
    let users={
        Name1:"John",
        Name2:"Ashok",
        Name3:"Dinesh",
        Name4:"Shyam"
    }
    return users;
}
function adminlist()
{
    let admins={
        Admin1:"Denim",
        Admin2:"Luci",
        Admin3:"Andrews",
        Admin4:"Richardson"
    }
return admins;
}
