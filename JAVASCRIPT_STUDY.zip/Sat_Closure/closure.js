function outer(outer)
{
    let counter=0;
    return function inner(inner)
    {
        counter++;
        console.log("Inner:"+inner);
        console.log("Outer:"+outer);
        return counter;
    }
}
let check=outer("outer");
console.log(check("inner"));

//sample

function loadres()
{
   return new Promise((resolve,reject)=>
    {
        setTimeout(()=>{  resolve("Success") },2000);
    })
}
async function result()
{
    let prom=await loadres();
    console.log(prom);
}
result();