//Client Storage

//FormData API
const formData=new FormData();
formData.append("name","sks");
formData.append("empid",100);
formData.append("salary",25000);
formData.append("status","active");
formData.delete("empid");
let entry=formData.entries();
console.log(formData.get("name"));

var elem=document.getElementById("elem");
var pr=document.createElement("p");
pr.innerHTML="Creating an element after the node";
elem.appendChild(pr);
var pr2=document.createElement("p");
pr2.innerHTML="Creating an element before the node";
elem.prepend(pr2);

//Setting up localStorage
let data={name:"Balaji",empid:100,status:"Active",action:"login"};
localStorage.setItem("data",JSON.stringify(data));
var local=JSON.parse(localStorage.getItem("data"));
console.log(local);
