import { useEffect, useState } from "react";

function Forms(props)
{
  return(
    <div>
    <div className="formcontent">
    <div className="forms">
    <label>Username:</label>
    <input type="text" onChange={(e)=>setname(e.target.value)} />
    <label>Date of Birth:</label>
    <input type="date" onChange={(e)=>setdob(e.target.value)} />
    <label>Email:</label>
    <input type="text" onChange={(e)=>setemail(e.target.value)} />
    <label>Mobile:</label>
    <input type="text" onChange={(e)=>setmobile(e.target.value)} />
    <button className="subbtn" onClick={()=>Submit()}>Submit</button>
    </div>
    </div>
    </div>
  )   
}

export default Forms;