import {createSlice} from "@reduxjs/toolkit";
import produce from "immer";


const initialState={
    users:[]
}

const useraction=createSlice({
    name:"Users",
    initialState,
    reducers:{
       add:(state,action)=>{
           return produce(state,(draft)=>
           {
             draft.users.push(action.payload)
           })
       }
    }
});

export const userReducer=useraction.reducer;
export const {add}=useraction.actions;

