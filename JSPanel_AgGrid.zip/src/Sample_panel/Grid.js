import { jsPanel } from "jspanel4";

function Form_Grid(props)
{

return(
    <div>
        <header>
        <h1>Ag-Grid</h1>
        </header>
        <label>Username:</label>
        <input type="text" />
        <label>Password:</label>
        <input type="text" />
    </div>
)
}
export default Form_Grid;