import { jsPanel } from "jspanel4";
import Grid from "./Grid";


function Sample()
{
jsPanel.create({
  headerTitle:"Sample panel",
  content:p=>
  {
    p.content.innerHTML="Sample panel"
  }
}).maximize();

return(
        <div>
            <h1>Sample panel</h1>
            <Grid data="sample" />
        </div>
    )
}

export default Sample;