import PanelPage from "./Screen/PanelPage";
import AgGrid_Component from "./Screen/AgGrid";
import AgClass from "./Screen/ClassAg";
import ExportCsv from "./Screen/Exportdata";
import ReduxStore from "./Redux/Store";
import { Provider } from "react-redux";
import {BrowserRouter,Routes,Route} from "react-router-dom";
import Rows from "./Rows/Rows";
import Checkfile from "./Screen/Checkfile";
import PanelClass from "./Screen/PanelClass";

function App() {
  return (
    <BrowserRouter>
    <Provider store={ReduxStore}>
      <Routes>
        <Route path="/" element={<PanelClass />} />
        {/* <Route path="/excel" element={<ExportCsv />} /> */}
        {/* <Route path="/ag" element={<AgGrid_Component />} /> */}
      </Routes>
    </Provider>
    </BrowserRouter>
    );
}

// <Provider store={ReduxStore}>
// {/* <ExportCsv /> */}
// {/* <AgClass /> */}
// <PanelPage />
// {/* <Memo_Comp /> */}
// {/* <BasMemo /> */}
// </Provider>


export default App;
