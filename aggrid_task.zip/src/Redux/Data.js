import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import produce from "immer";
import Axios from "axios";
const url = "http://localhost:4001/Data";

const initialState = {
  portmaster: [],
};

export const saveData = createAsyncThunk(`saveData`, async (data) => {
  console.log(data)
    let res = await Axios.post(url, data);
    return res.data;
});

export const deleteData=createAsyncThunk(`deleteData`,async(data)=>{
     let res=await Axios.delete(`${url}/${data.id}`);
     return res.data;
})

export const editData=createAsyncThunk('editData',async(data)=>{
      let res=await Axios.put(`${url}/${data.id}`,data);
      return res.data;
})

const Data = createSlice({
  name: "Port",
  initialState,
  reducers: {
    PortMaster: (state, action) => {
      return produce(state, (draft) => {
        draft.portmaster.push(action.payload);
      });
    },
  },
});

export const Datareducer = Data.reducer;
export const { PortMaster } = Data.actions;
