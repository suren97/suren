import { configureStore } from "@reduxjs/toolkit";
import { Datareducer } from "./Data";

const ReduxStore=configureStore({
    reducer:{
      portData:Datareducer
    }
})

export default ReduxStore;