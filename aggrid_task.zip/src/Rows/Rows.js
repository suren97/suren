import { AgGridReact } from "ag-grid-react";
import React,{Component} from "react";
import { RowData } from "./RowData";
import axios from "axios";

class Rows extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
          rowdata:RowData,
          GridApi:"",
          columnDefs:[
            {field:"make"},
            {field:"model"},
            {field:"price"}
          ],
          defaultColDef:({
            flex:1,
            sortable:true,
            filter:true
          })
        }
    }

GetDisplayedRow()
{
  var rowNode=this.state.GridApi.getDisplayedRowAtIndex(3);
  console.log(rowNode)
}

GetRowCount()
{
    var rowcount=this.state.GridApi.getDisplayedRowCount();
    console.log(rowcount)
}

GetAllRow()
{
    var count=this.state.GridApi.getDisplayedRowCount();
    for(let i=0;i<count;i++)
    {
        var rownode=this.state.GridApi.getDisplayedRowAtIndex(i);
        console.log(rownode.data)
    }
}

onGridReady=(params)=>
{
    this.setState({GridApi:params.api})
}

render()
{
    return(
            <div>
                <header>
                    <h1>AgGrid - Rows(Rendering API)</h1>
                </header>
                <button onClick={()=>this.GetDisplayedRow()}>Get Display Row using index</button>
                <button onClick={()=>this.GetRowCount()}>Get Displayed Row Count</button>
                <button onClick={()=>this.GetAllRow()}>Get All Displayed Row</button>
                <div className="ag-theme-alpine" style={{height:"270px",width:"99%",margin:"5% auto"}}>
                    <AgGridReact 
                    rowData={this.state.rowdata}
                    columnDefs={this.state.columnDefs}
                    defaultColDef={this.state.defaultColDef}
                    onGridReady={this.onGridReady}
                    />
                </div>
            </div>
    )
}

}

export default Rows;