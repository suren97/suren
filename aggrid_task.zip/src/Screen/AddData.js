import React,{Component} from "react";
import { jsPanel } from "jspanel4";

class AddData extends Component
{
componentDidMount()
{
    console.log("ss")
    jsPanel.create({

    })
}

render()
{
    return(
        <div>
        
        </div>
    )
}
}

export default AddData;