import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { PortMaster } from "../Redux/Data";
import Data from "./Data";
import { v4 as uuidv4 } from "uuid";
import {
  useEffect,
  useState,
  useRef,
  useCallback,
  useMemo,
  useLayoutEffect,
} from "react";
import {
  InsertDriveFileOutlined,
  SaveOutlined,
  HighlightOffOutlined,
  EditOutlined,
  PlagiarismOutlined,
  DeleteOutline,
  FileUploadOutlined,
  FileDownloadOutlined,
  PostAddOutlined,
  SaveAsOutlined,
  Close,
  UpdateOutlined,
} from "@mui/icons-material";
import {
  Icon,
  IconButton,
  Snackbar,
  Stack,
  Tooltip,
  Alert,
  Dialog,
  DialogActions,
  DialogTitle,
  DialogContent,
  Button,
  Divider,
  Typography,
} from "@mui/material";
import AddData from "./AddData";
import InputField from "./InputField";
import ColorField from "./ColorField";
import { useSelector, useDispatch } from "react-redux";
import { saveData, deleteData,editData } from "../Redux/Data";
import SnackAlert from "./Alert";
import { jsPanel } from "jspanel4";

function AgGrid_Component() {
  const GridRef = useRef(null);
  const [editdata, setdata] = useState();
  const dispatch = useDispatch();
    const [genid, setgenid] = useState();
  const [rowdata, setrow] = useState();
  const [cellvalues, setcellvalues] = useState([]);
  const [vertical, setvertical] = useState("top");
  const [horizontal, sethorizon] = useState("center");
  const [portcode, setportcode] = useState();
  const [opensnack, setsnack] = useState(false);
  const [btnmang, setmng] = useState({
    addbtn:true,addcolor:true,
    savebtn:false,savecolor:false,
    closebtn:false,closecolor:false,
    editbtn:true,editcolor:true,
    excelbtn:false,excelcolor:false}
  );
  const [openDiag, setDiag] = useState(false);
  const [Delid, setdel] = useState();
  // const [editstate, seteditstate] = useState({ color: false, disabled: false });
  const [clickedit, setclickedit] = useState(false);
  const [message,setmessage]=useState();
  const [alertColor,setalertcolor]=useState();
  const columnDefs = useMemo(()=>{return([
    {
      field: "portcode",
      headerName: "Port Code"
    },
    {
      field: "portname",
      headerName: "Port Name",
      cellEditor: InputField,
    },
    {
      field: "portcolor",
      headerName: "Port Color",
      cellRenderer: (p) => {
        return <input type="color" name="favcolor" value={p.value} disabled={!clickedit} />;
      },
      cellEditor: ColorField,
    },
    {
      field: "shortcode",
      headerName: "Short Port Code",
      cellEditor: InputField,
    },
    {
      field: "portbapile",
      headerName: "Port Bapile Version",
      cellEditor: InputField,
    },
    {
      headerName:"Action",
      field:"Action",
      editable: false,
      cellRenderer: (p) => Displaybtn(p),
    },
  ])
},[clickedit]);

  const Displaybtn = (params) => {
    let args = params;
    if (params.node) {
      return (
        <div>
          <IconButton onClick={() => (clickedit ? CellEdit(args) : CellEdit())}>
            <EditOutlined
              color="primary"
              fontSize="small"
              sx={clickedit ? {cursor:"pointer"} :{cursor:"not-allowed"}}
            />
          </IconButton>
          <IconButton onClick={() => (clickedit ? CellDelete(params) :CellDelete())}>
            <DeleteOutline 
            color="primary" 
            fontSize="small"
            sx={clickedit ? {cursor:"pointer"} :{cursor:"not-allowed"}}
            />
          </IconButton>
        </div>
      );
    } else {
      return "";
    }
  };

  let CellEdit = (params) => {
    if (params) {
      GridRef.current.api.startEditingCell({
        rowIndex: params.rowIndex,
        colKey: "portcode",
      });
    }
  };

  let CellDelete = (params) => {
    if(params)
    {
    setportcode(params.data);
    setDiag(true);
    }
  };

  let DeleteCell = (params) => {
    let n = rowdata.findIndex((v, i) => {
      if (v.id === params.id) {
        return i;
      }
    });
    dispatch(deleteData(params));
    rowdata.splice(n, 1);
    setrow(rowdata);
    setdel(params.id);
    setDiag(false);
  };

  useEffect(() => {
    axios.get("http://localhost:4001/Data").then((response) => {
      if (response.data.length) {
        setrow(response.data);
      }
    });
  }, [genid, Delid]);

  const AddRow = () => {
    const id = uuidv4();
    let data = { id: id };
    GridRef.current.api.applyTransaction({ add: [data], addIndex: 0 });
    setTimeout(() => {
      GridRef.current.api.startEditingCell({ rowIndex: 0, colKey: "portname" });
    }, 100);
    setmng((prev)=>
    {
      return {...prev,savebtn:true,savecolor:true,closebtn:true,closecolor:true,editbtn:false,editcolor:false}
    })
  };

  const defaultColDef = {
    flex: 1,
    editable: true,
    sortable: true,
  };

  const Add = () => {
    let getelem = document.querySelector(".ag-center-cols-container");
    getelem.style.pointerEvents = "none";

    let elem = getelem.querySelector('[row-id="' + 0 + '"]');
    elem.style.pointerEvents = "visible";
  };

  const Save = () => {
    GridRef.current.api.forEachNode(printnode);
  };

  let printnode = (v, i) => {
    setgenid(v.data.id);
    // dispatch(saveData(v.data));
    setmng((prev)=>
    {
      return {...prev,savebtn:false,savecolor:false,closebtn:false,closecolor:false,editbtn:true,editcolor:true}
    })
    setmessage("Added Successfully");
    setsnack(true);
    setalertcolor("success");
  };

  let DownloadExcel = () => {
    var params={ columnKeys:['portcode','portname','portcolor','shortcode','portbapile']};
    GridRef.current.api.exportDataAsExcel(params);
  };

  let handleClose = () => {
    setsnack(false);
    setDiag(false);
  };

  let Edit = () => {
    setclickedit(!clickedit);
    setmng((prev)=>
    {
      return {...prev,addbtn:false,
        addcolor:false,savebtn:true,
        savecolor:true,closebtn:true,
        closecolor:true,editbtn:false,editcolor:false,excelbtn:false,excelcolor:false}
    })
  };

  let Close=()=>
  {
   GridRef.current.api.setRowData(rowdata);
   setclickedit(false);
   setmng((prev)=>{
    return {...prev,addbtn:true,addcolor:true,
    savebtn:false,savecolor:false,
    closebtn:false,closecolor:false,
    editbtn:true,editcolor:true,
    excelbtn:false,excelcolor:false}
   })
  }

  const Update=()=>
  {
    console.log("update...");
    rowdata.map((v,i)=>
    {
      // dispatch(editData(v))
    })
    setmessage("Updated Successfully");
    setsnack(true);
    setalertcolor("warning");
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <Tooltip title="New">
          <IconButton onClick={() => AddRow()} disabled={!btnmang.addbtn}>
            <PostAddOutlined color={btnmang.addcolor ? "primary" : "disabled"} />
          </IconButton>
        </Tooltip>
        <Tooltip title="Save">
        <IconButton onClick={()=>(clickedit ? Update() : Save())} disabled={!btnmang.savebtn}>
            {clickedit ? (
                <SaveAsOutlined color="primary"  />
            ):(
             <SaveOutlined
               color={btnmang.savebtn ? "primary" : "disabled"}
            />
            )}
        </IconButton>
        </Tooltip>
        <Tooltip title="close">
          <IconButton onClick={()=>Close()} disabled={!btnmang.closebtn}>
            <HighlightOffOutlined
               color={btnmang.closecolor ? "primary" : "disabled"}
          />
          </IconButton>
        </Tooltip>
        <Tooltip title="Edit">
          <IconButton onClick={() => Edit()} disabled={!btnmang.editbtn}>
            <EditOutlined
              color={btnmang.editcolor ? "primary" : "disabled"}
            />
          </IconButton>
        </Tooltip>
        <Tooltip title="Download">
          <IconButton color="primary" onClick={() => DownloadExcel()}>
            <FileDownloadOutlined />
          </IconButton>
        </Tooltip>
      </div>
      <div
        className="ag-theme-alpine"
        style={{ height: "300px", margin: "0% auto", width: "99%" }}>
        <AgGridReact
          ref={GridRef}
          rowData={rowdata}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          editType="fullRow"
          suppressContextMenu={true}
          stopEditingWhenCellsLoseFocus={true}
          suppressClickEdit={!clickedit}
        />
      </div>
      {/* <a href="/excel">Move</a> */}
      <SnackAlert
        open={opensnack}
        message={message}
        color={alertColor}
        onClose={handleClose}
        vertical={vertical}
        horizontal={horizontal}
      />
      <Dialog open={openDiag} onClose={handleClose}>
        <DialogTitle>Delete Port</DialogTitle>
        <Divider />
        <DialogContent>
          <p className="para">Are you Sure want to Delete the Port Code ?</p>
          <Typography
            gutterBottom
            sx={{
              textAlign: "center",
              fontSize: 20,
              color: "red",
              fontWeight: "bold",
            }}
          >
            {portcode ? portcode.portcode : ""}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button
            variant="contained"
            color="error"
            onClick={() => DeleteCell(portcode)}>OK</Button>
          <Button variant="contained" color="primary" onClick={handleClose}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default AgGrid_Component;
