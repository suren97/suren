import { IconButton } from "@mui/material";
import { DeleteOutline, EditOutlined } from "@mui/icons-material";

function Displaybtn(params,clickedit) {
    // console.log(params)
    console.log(clickedit)
return(
    <div>
    <IconButton>
        <EditOutlined />
    </IconButton>
    <IconButton>
        <DeleteOutline />
    </IconButton>
    </div>
)
}

export default Displaybtn;