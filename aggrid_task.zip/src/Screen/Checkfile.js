import { useState } from "react";

function Checkfile() {
const [confirmPlanname,setconfirm]=useState([
    {
        vesselName: "PIRIKA MOSIRI MARU",
        voyageNo: "0063",
        planName: "test_aynr",
        checked: false
    },
    {
        vesselName: "PIRIKA MOSIRI MARU",
        voyageNo: "0063",
        planName: "test_aynur01",
        checked: false
    }
]);

const Checkconfirmplan=(handleStatus)=>
{
const confirmPlans = confirmPlanname.reduce((plans, plan) => {
        if(!plan.checked) return plans;

        if (handleStatus === 1)
        {      
            plans.push(`${plan.planName}_1`);      
        }    

        if (handleStatus === 2) 
        {        
            plans.push(plan.planName);     
        }
        return plans; 
}, []);   
return confirmPlans 
}

const handlebutton=(handleStatus)=>
{
    const getdata=Checkconfirmplan(handleStatus);
    console.log("getData",getdata);
}

return (
    <div>
      <button onClick={()=>handlebutton(1)}>Button 1</button>
      <button onClick={()=>handlebutton(2)}>Button 2</button>
    </div>
);

}

export default Checkfile;
