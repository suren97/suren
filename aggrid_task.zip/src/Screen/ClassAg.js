import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import Data from "./Data";


class AgClass extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            rowdata:Data,
            GridRef:React.createRef(),
            columnDefs:[
                { 
                    field: "portcode",
                    headerName:"Port Code",
                },
                { 
                    field: "portname",
                    headerName:"Port Name"
                },
                { 
                    field: "portcolor",
                    headerName:"Port Color",
                    cellRenderer:p=>{ return <div className={`circle-${p.value}`}></div>  }
                },
                { 
                    field: "shortcode",
                    headerName:"Short Port Code"
                },
                { 
                    field: "portbapile",
                    headerName:"Port Bapile Version"
                }
            ],
          defaultColDef : ({
                flex: 1,
                editable:true,
                // cellStyle:p=>{return this.setstyle(p)}
        }),
        getRowId:(p)=>
        {
          return p.data.id;
        },
        dispclick:false,
        rowClass:"visibleState",
        dummy:false,
        gridstate:"visible"
        }
}   

setstyle(p)
{
if(p.data.id) 
{ 
    return { "pointer-events":"visible" } 
}
else
{ 
  return this.state.dummy ? {"pointer-events":`${this.state.gridstate}`} : {"pointer-events":`${this.state.gridstate}`} 
} 
}

rowStyle() 
{ 
return {background:'black'} 
}

getRowStyle(p)
{
  console.log(p)
}

dispclick()
{
    // this.state.GridRef.current.api.redrawRows();
    this.setState({dispclick:true})
    setTimeout(()=>
    {
        let elem=document.querySelectorAll(".ag-center-cols-container");
        for(var i=0;i<elem[0].children.length;i++)
        {
           if(elem[0].children[i].getAttribute("row-id")=="0")
           {
              elem[0].children[i].style.pointerEvents="visible"
           }
           else
           {
            elem[0].children[i].style.pointerEvents="visible"
           }
        }
    },100)
}

Addrow()
{
    let data={id:0}
    let newdata=[{id:1}];
    this.state.rowdata.map((v,i)=>
    {
       newdata.push({...v})
    })
    this.state.GridRef.current.api.setRowData(newdata);
    setTimeout(()=>
    {
        let elem=document.querySelector(".ag-center-cols-container");
        console.log(elem)
        let getelem=elem.querySelector('[row-id='+0+']');
        console.log(getelem)
    },100)
}

render()
{
    console.log(this.state.rowClass)
    return(
        <div>
            <header>
                <h1>AgGrid Class Component</h1>
            </header>
            <button onClick={()=>this.Addrow()}>Add</button>
            <button onClick={()=>this.dispclick()}>Close</button>
            <br></br>
            <div className="ag-theme-alpine" style={{ height: "500px", margin:"2% auto",width:"99%" }}>
        <AgGridReact
          ref={this.state.GridRef}
          rowData={this.state.rowdata}
          columnDefs={this.state.columnDefs}
          defaultColDef={this.state.defaultColDef}
        />
      </div>
        </div>
    )
}
}

export default AgClass;