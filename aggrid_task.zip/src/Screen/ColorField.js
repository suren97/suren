import { forwardRef, useImperativeHandle, useState } from "react";

const ColorField = forwardRef((props, ref) => {
//   console.log(props);
  let column = props.colDef.field;

  const [value, setvalue] = useState({
    // [column]:props.value
    portcolor:props.data.portcolor,
  });

  useImperativeHandle(ref, () => {
    return {
      getValue() {
        // console.log(value)
        return value[column];
      },
    };
  });

  let handlecolor = (e) => {
    // console.log(e.target.value);
    // console.log(column)
    setvalue({ ...value, [column]: e.target.value });
  };

  return (
    <input
      type="color"
      name={props.colDef.field}
      value={value[column]}
      onChange={(e) => handlecolor(e)}
    />
  );
})

export default ColorField;
