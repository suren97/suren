const Data=[
    {portcode:"ABCBA",portname:"Italy",portcolor:"#ff0000",shortcode:2,portbapile:1.5},
    {portcode:"ABCBB",portname:"Germany",portcolor:"#ff0000",shortcode:"",portbapile:0},
    {portcode:"ABCBC",portname:"Austria",portcolor:"#cfe2f3",shortcode:"",portbapile:0},
    {portcode:"ABCBD",portname:"Boston",portcolor:"#6aa84f",shortcode:"",portbapile:0},
    {portcode:"ABCBE",portname:"Capenhegon",portcolor:"#cfe2f3",shortcode:"",portbapile:0},
    {portcode:"ABCBF",portname:"Port Blair",portcolor:"#6aa84f",shortcode:"",portbapile:0},
    {portcode:"ABCBG",portname:"Andaman",portcolor:"#ff0000",shortcode:"",portbapile:0},
    {portcode:"ABCBH",portname:"London",portcolor:"#cfe2f3",shortcode:"",portbapile:0},
    {portcode:"ABCBI",portname:"USA",portcolor:"#ff0000",shortcode:"",portbapile:0},
    {portcode:"ABCBJ",portname:"UK",portcolor:"#6aa84f",shortcode:"",portbapile:0},

    // {id:1,portcode:"ABCBA",portname:"port-dev",portcolor:"red",shortcode:2,portbapile:1.5},
    // {id:2,portcode:"ABCDE",portname:"terminal",portcolor:"green",shortcode:"",portbapile:0},
    // {id:3,portcode:"ABCDE",portname:"terminal",portcolor:"black",shortcode:"",portbapile:0},
    // {id:4,portcode:"ABCDE",portname:"terminal",portcolor:"green",shortcode:"",portbapile:0},
    // {id:5,portcode:"ABCDE",portname:"terminal",portcolor:"red",shortcode:"",portbapile:0},
    // {id:6,portcode:"ABCDE",portname:"terminal",portcolor:"black",shortcode:"",portbapile:0},
    // {id:7,portcode:"ABCDE",portname:"terminal",portcolor:"red",shortcode:"",portbapile:0},
    // {id:8,portcode:"ABCDE",portname:"terminal",portcolor:"green",shortcode:"",portbapile:0},
    // {id:9,portcode:"ABCDE",portname:"terminal",portcolor:"red",shortcode:"",portbapile:0},
    // {id:10,portcode:"ABCDE",portname:"terminal",portcolor:"black",shortcode:"",portbapile:0},
]

export default Data;