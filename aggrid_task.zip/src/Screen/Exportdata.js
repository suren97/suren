import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useState,useRef, useCallback, useImperativeHandle } from "react";
import "ag-grid-enterprise";

function ExportCsv()
{
const [columnDefs,setcolumn]=useState([
    { checkboxSelection: true, field: 'athlete', minWidth: 200 },
    { field: 'country', minWidth: 200 },
    { headerName: 'Group', valueGetter: 'data.country.charAt(0)' },
    { field: 'sport', minWidth: 150 },
    { field: 'gold', hide: true },
    { field: 'silver', hide: true },
    { field: 'bronze', hide: true },
    { field: 'total', hide: true },
  ]
);
const [rowdata,setrow]=useState();
const GridRef=useRef(null);

const defaultColDef={sortable: true,
filter: true,
resizable: true,
minWidth: 100,
flex: 1
}
const [ExcelData,setdata1]=useState([
  {name:"David",age:25},
  {name:"Surendar",age:25},
  {name:"Karthi",age:24}
]);
const [GridData,setdata2]=useState([
  {name:"David",age:27},
  {name:"Surendar",age:28},
  {name:"Jaswanth",age:23}
]);


let removeDuplicate=(ExcelData,GridData)=>
{
  // console.log(ExcelData);
  let getDuplicate=ExcelData.filter(v1=>GridData.some(v2=>v1.name===v2.name));
  let noDuplicate=ExcelData.filter(v1=>!GridData.some(v2=>v1.name===v2.name));
  let NoOverRide=[];
  let OverRideData=[];
  if(getDuplicate.length)
  {
    OverRideData=Object.assign(GridData,getDuplicate);
    OverRideData.push(...noDuplicate)
  }
  else
  {
    NoOverRide=Object.assign(GridData);
    NoOverRide.push(...noDuplicate)
  }
  // console.log("OverRideData",OverRideData);
  // console.log("NoOverRide",NoOverRide);
}



const duplicate=removeDuplicate(ExcelData,GridData);

// let confirm=window.confirm(`${duplicate} Already Exists ? Are you sure want to override?`)
// if(confirm)
// {
 
// }


// function removeDuplicate(val1,val2)
// {
// var names=[];
// let duplicates=val1.filter(v1=>val2.some(v2=>v1.name === v2.name));
// if(duplicates.length)
// {
//   duplicates.forEach((v,i)=>
//   {
//     names.push(v.name);
//   })
// }
// return names;
// }

let GridApi;

let onGridReady = (params) => {
    fetch('https://www.ag-grid.com/example-assets/small-olympic-winners.json')
    .then((resp) => resp.json())
    .then((data) => setrow(data.filter((rec) => rec.country != null)));

//   document.getElementById('selectedOnly').checked = true;
  }

let onBtExport=()=>
{
  let elem=document.getElementsByTagName("input");
  let selectedelem;
  for(var i=0;i<elem.length;i++)
  {
    if(elem[i].getAttribute("ref")==="eInput")
    {
      if(elem[i].checked)
      {
        selectedelem=selectedelem+elem[i];
      }
    }
  }
  console.log(selectedelem)
  GridRef.current.api.exportDataAsExcel({
    onlySelected:selectedelem
  });
}


return(
    <div>
        <header>
            <h1>Grid - ExportCSV</h1>
        </header>
        {/* <label className="option">
              <input id="selectedOnly" type="checkbox" />
              Selected Rows Only
            </label>
       */}
        <div>
              <button
                onClick={onBtExport}
                style={{ fontWeight: 'bold' }}
              >
                Export to Excel
              </button>
            </div> 
        <div className="ag-theme-alpine" style={{height:"300px",margin:"5% auto"}}>
            {/* <AgGridReact 
            ref={GridRef}
            rowData={rowdata}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            onGridReady={onGridReady}
            rowSelection="multiple"
            suppressRowClickSelection={true}
            /> */}
        </div> 
    </div>
)
}

export default ExportCsv;