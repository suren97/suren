import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { v4 as uuidv4 } from "uuid";
import {
    InsertDriveFileOutlined,
    SaveOutlined,
    HighlightOffOutlined,
    EditOutlined,
    PlagiarismOutlined,
    DeleteOutline,
    FileUploadOutlined,
    FileDownloadOutlined,
    PostAddOutlined,
    SaveAsOutlined,
    Close,
    UpdateOutlined,
  } from "@mui/icons-material";
  import {
    Icon,
    IconButton,
    Snackbar,
    Stack,
    Tooltip,
    Alert,
    Dialog,
    DialogActions,
    DialogTitle,
    DialogContent,
    Button,
    Divider,
    Typography,
  } from "@mui/material";
import InputField from "./InputField";
import ColorField from "./ColorField";
import SnackAlert from "./Alert";

class PanelClass extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            rowInd:"",
            GridRef:React.createRef(),
            columnDefs:[{
                field: "portcode",
                headerName: "Port Code"
              },
              {
                field: "portname",
                headerName: "Port Name",
                cellEditor: InputField,
              },
              {
                field: "portcolor",
                headerName: "Port Color",
                // cellRenderer: (p) => {
                //   return <input type="color" name="favcolor" value={p.value} disabled={!clickedit} />;
                // },
                cellEditor: ColorField,
              },
              {
                field: "shortcode",
                headerName: "Short Port Code",
                cellEditor: InputField,
              },
              {
                field: "portbapile",
                headerName: "Port Bapile Version",
                cellEditor: InputField,
              },
              {
                headerName:"Action",
                field:"Action",
                editable: false,
                cellRenderer: (p) => this.Displaybtn(p),
              }],
              rowdata:[],
              defaultColDef:({
                flex: 1,
                editable: true,
                sortable: true,
              })
        }
    }

    Displaybtn(params)
    {
        return (
            <div>
              <IconButton onClick={() =>this.CellEdit(params)}>
                <EditOutlined
                  color="primary"
                  fontSize="small"
                />
              </IconButton>
            </div>
          );
    }


    CellEdit = (params) => {
        if (params) {
         this.state.GridRef.current.api.startEditingCell({
            rowIndex: params.rowIndex,
            colKey: "portcode",
          });
        }
      };



   componentDidMount()
   {
    console.log("did")
    axios.get("http://localhost:4001/Data").then((response) => {
        if (response.data.length) {
            this.setState({rowdata:response.data})
        //   setrow(response.data);
        }
      });
   } 

   onCellClicked(params)
   {
    this.setState({rowInd:params.rowIndex})
   }
   
   Save()
   {
    let index=this.state.rowInd;
    let data=this.state.rowdata;
    React.forwardRef((props,ref)=>
    {
        return InputField;
    })
   }

    render()
    {
        return(
            <>
            <button>Add</button>
            <button>Edit</button>
            <button onClick={()=>this.Save()}>Save</button>
            <div className="ag-theme-alpine"
             style={{ height: "300px", margin: "0% auto", width: "99%" }}>
                <AgGridReact 
                  ref={this.state.GridRef}
                  rowData={this.state.rowdata}
                  columnDefs={this.state.columnDefs}
                  defaultColDef={this.state.defaultColDef}
                  editType="fullRow"
                  suppressContextMenu={true}
                  stopEditingWhenCellsLoseFocus={true}
                  onCellClicked={(p)=>this.onCellClicked(p)}
                //   suppressClickEdit={!clickedit}
                />
            </div>
            </>
        )
    }
}

export default PanelClass