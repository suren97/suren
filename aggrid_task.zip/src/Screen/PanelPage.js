import { Button } from "@mui/material";
import { jsPanel } from "jspanel4";
import AgGrid_Component from "./AgGrid";
import ReactDOM from 'react-dom/client';
import { useEffect,useContext } from "react";
import { useSelector } from "react-redux";
import {Provider} from "react-redux";
import ReduxStore from "../Redux/Store";

function PanelPage()
{
const stat=useSelector((state)=>{
    return state.portData.portmaster
});

let openpanel=()=>
{
    jsPanel.create({
        headerTitle:"Port Master",
        theme:"info",
        headerControls:"closeonly sm",
    }).maximize();
    const root = ReactDOM.createRoot(document.querySelector('.jsPanel-content'));
    root.render(
    <Provider store={ReduxStore}>
    <AgGrid_Component />
    </Provider>
    )
}

return(
    <div>
        <header>
            <h1>AG-Grid Panel</h1>
        </header>
        <div className="btncontainer">
        <Button variant="contained" color="info" onClick={()=>openpanel()}>Open Panel</Button>
        </div>
    </div>
)
}

export default PanelPage;