import Grid from "./Grid/Basic_Grid";
import StyleGrid from "./Grid/Styling_Grid";
import External_Grid from "./Grid/External_Grid";
import Row_selection from "./Grid/Row_selection";
import Pagination from "./Grid/Pagination";
import Hid_ShoCol from "./Grid/Hide_ShowCol";
import Practice_Grid from "./Practice_Grid/Practice_Grid";
import Global_Filter from "./Grid/GlobalFilter";
import DataGrid from "./Redux_DataGrid/DataGrid";
import Crud_Grid from "./CRUD_Operation/CRUD_Grid";
import { Provider } from "react-redux";
import Store from "./Redux/Store";

function App() {
  return (
  <div>
  <Provider store={Store}>
  {/* <Crud_Grid /> */}
 {/* <Grid /> */}
 {/* <StyleGrid /> */}
 {/* <External_Grid /> */}
 {/* <Row_selection /> */}
 {/* <Pagination /> */}
 {/* <Hid_ShoCol /> */}
 {/* <Practice_Grid /> */}
 {/* <Global_Filter /> */}
 {/* <DataGrid /> */}
 </Provider>
  </div>
  );
}

export default App;
