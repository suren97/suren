import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useEffect, useState } from "react";
import axios from "axios";
import { Modal_Users } from "./Component/Modal_User";

function Crud_Grid()
{
const [rowdata,setrow]=useState();
let Actionbtn=(params)=>
{
    return(
        <div>
        <button className="updatebtn" type="button" onClick={()=>updData(params)}>Update</button>
        <button className="delbtn" type="button" onClick={()=>delData(params)}>Delete</button>
        </div>
    )
};
const [columns,setcolumns]=useState([
    {field:"Empid"},
    {field:"name"},
    {field:"Dob"},
    {field:"role"},
    {field:"id",headerName:"Action",cellRendererFramework:params=>Actionbtn(params)}
]);
const [formdata,setformdata]=useState(
    {Empid:"",name:"",Dob:"",role:""}
);
const [id,setid]=useState();
const [newrow,setnewrow]=useState("");
const [curtstate,setcurt]=useState("Submit");

const defaultColumns=({
   sortable:true,
   filter:true,
   flex:1
});



let updData=v=>
{
    var modal=document.getElementById("modal");
    modal.style.display="block";
    setformdata((prev)=>
    {
      return {...prev,...v.data}
    })
    setcurt("Update");
}

let delData=v=>
{
  let conf=window.confirm("Are you sure want to delete ? ");
  if(conf)
  {
  axios.delete('http://localhost:5000/users'+`/${v.data.id}`)
  .then((response)=>
  {
    if(response.status==200)
    {
        setid(v.data.id)
    }
  })
}
}

let handleclose=()=>
{
    console.log("Close");
    var modal=document.getElementById("modal");
    modal.style.display="none"
}

let handleUser=()=>
{
  let id=rowdata[rowdata.length-1].id;
  setid(id);
  var modal=document.getElementById("modal");
  modal.style.display="block";
}

let handleinput=(e)=>
{
  setformdata((prev)=>
  {
    return {...prev,[e.target.id]:e.target.value}
  })
}

let submituser=()=>
{
axios.post(`http://localhost:5000/users`,formdata)
     .then((response)=>
     {
        setid(response.data.id);
        setnewrow(response.data)
     })
     alert("User Added Successfully");
     var modal=document.getElementById("modal");
     modal.style.display="none";
}

let handleupdt=()=>
{
    console.log(formdata)
    axios.put('http://localhost:5000/users'+`/${formdata.id}`,formdata)
    .then((response)=>
    {
        setid(response.data.id);
    })
    alert("Updated Successfully");
    var modal=document.getElementById("modal");
    modal.style.display="none";
    setcurt("Submit");
}

useEffect(()=>
{
    axios.get("http://localhost:5000/users")
    .then((response)=>{
        setrow(response.data);
    })
},[id]);

return(
    <div>
    <header>
    <h1>Grid CRUD Operation</h1>
    </header>
    <Modal_Users 
    curt={curtstate}
    id={id} 
    nrow={newrow}
    close={()=>handleclose()} 
    submit={()=>submituser()} 
    update={()=>handleupdt()}
    data={formdata}
    change={handleinput}
    />
    <div className="tablecontainer">
    <button className="userbtn" onClick={()=>handleUser()}>Add Users</button>
    <div className="ag-theme-alpine" style={{height:350}}>
    <AgGridReact
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultColumns}
    />
    </div>
    </div>
    </div>
)
}

export default Crud_Grid;