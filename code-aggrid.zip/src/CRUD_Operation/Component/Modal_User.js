export const Modal_Users=(props)=>
{
  const {id,data}=props;
  let {Empid,name,Dob,role}=props.data;
  if(props.nrow)
  {
  Empid="";
  name="";
  Dob="";
  role="";
  }
  return (
    <div className="modalspace">
    <div className="usermodal" id="modal">
    <div className="usrmodal-content">
     <h2>Create User</h2>
     <hr></hr>
     <div className="formflex">
     <label>Empid</label>
     <input id="Empid" type="text" value={Empid} onChange={props.change} />
     <label>Name</label>
     <input id="name" type="text" value={name} onChange={props.change} />
     <label>Date of Birth</label>
     <input id="Dob" type="date" value={Dob} onChange={props.change} />
     <label>Role</label>
     <input id="role" type="text" value={role} onChange={props.change} />
     <button type="button" className="actbtn" 
     onClick={props.curt==="Update" ? props.update : props.submit}>
        {props.curt}
    </button>
     <button type="button" className="delbtn" onClick={props.close}>Cancel</button>
     </div>
    </div>
    </div>
    </div>
  )
}