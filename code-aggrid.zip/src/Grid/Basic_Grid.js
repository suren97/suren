import {AgGridReact} from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { useState } from "react";

function Grid()
{
const [row,setrow]=useState([
    {Name:"Johnson",Age:23},
    {Name:"Kevin",Age:54},
    {Name:"Laurence",Age:40},
    {Name:"Marshall",Age:35},
    {Name:"Federo",Age:32}
]);

const [col,setcol]=useState([
    {field:"Name"},
    {field:"Age"},
    {field:"Action",floatingFilter:false,
    cellRenderer:(params)=><div>
        <button className="actbtn" onClick={()=>Actionbtn(params)}>Click Me</button>
    </div>
   }
]);

const Actionbtn=(params)=>
{
  alert(`Name is ${params.data.Name} and age is ${params.data.Age}`)
}

const defaultColDef=({
    sortable:true,
    filter:true,
    editable:true,
    floatingFilter:true,
    flex:1  
});

let Gridapi;

const GridReady=(params)=>
{
  Gridapi = params.api;
}

const Exportcsv=()=>
{
Gridapi.exportDataAsCsv();
}

return (
    <div>
        <header>
        <h1>Codenemy Ag_Grid</h1>
        </header>
        <div className="tablecontainer">
        <button className="btncsv" onClick={()=>Exportcsv()}>Export CSV</button>
        <div className="ag-theme-alpine" style={{height:300}}>
        <AgGridReact
         rowData={row}
         columnDefs={col}
         defaultColDef={defaultColDef}
         onGridReady={GridReady}
        />
        </div>
        </div>
    </div>
)
}
export default Grid;