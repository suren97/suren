import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import axios from "axios";
import { useState } from "react";

function External_Grid()
{
const [column,setcolumn]=useState([
    {field:"id"},
    {field:"name"},
    {field:"email"},
    {field:"body"}
]);
const [api,setapi]=useState();

const defaultColDef=({
    sortable:true,
    filter:true,
    flex:1
});

const onGridReady=(params)=>
{
  setapi(params.api);
   axios.get("https://jsonplaceholder.typicode.com/comments")
   .then((response)=>{
    // console.log(response.data)
    params.api.applyTransaction({add:response.data})
   })
}

const exportcsv=()=>
{
 api.exportDataAsExcel();
}

return(
    <div>
    <header>
    <h1>External APIGrid</h1>
    </header>
    <div className="tablecontainer">
    <button onClick={()=>exportcsv()}>Export CSV</button>
    <div className="ag-theme-alpine" style={{height:350}}>
     <AgGridReact
      columnDefs={column}
      defaultColDef={defaultColDef}
      onGridReady={onGridReady}
     />
    </div>
    </div>
    </div>
)
}

export default External_Grid;