import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";
import {useState} from "react";

function Global_Filter()
{
const [gridApi,setgridApi]=useState();
const [columns,setcolumns]=useState([
    {field:"athlete",headerName:"PlayerName"},
    {field:"country"},
    {field:"sport"},
    {field:"year"},
    {field:"date"},
    {field:"total",headerName:"MedalsWon"}
]);
const defaultCol=({
    sortable:true,
    flex:1,
});

let onGridReady=(params)=>
{
  setgridApi(params.api);
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
     params.api.applyTransaction({add:response.data});
  });
}

const Search=(e)=>
{
  gridApi.setQuickFilter(e.target.value);
}

return(
    <div>
    <header>
    <h1>Quick Global Filter</h1>
    </header>
    <div className="tablecontainer">
    <div className="searchbox">
    <input type="search" placeholder="Type here to search ..." onChange={(e)=>Search(e)} />
    </div>
    <div className="ag-theme-alpine" style={{height:350}}>
    <AgGridReact
    onGridReady={onGridReady}
    columnDefs={columns}
    defaultColDef={defaultCol}
    />
    </div>
    </div>
    </div>
)
}

export default Global_Filter;