import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";
import {useState,useEffect} from "react";

function Hid_ShoCol()
{
const [gridApi,setgridapi]=useState();
const [colapi,setcolapi]=useState();
const [hidecol,sethidecol]=useState(true);
const [text,setext]=useState("Hide");

const [columns,setcolumn]=useState([
    {field:"id"},
    {field:"name"},
    {field:"username"},
    {field:"email"},
    {field:"address.city",headerName:"City"}
]);

const defaultColDef=({
    sortable:true,
    filter:true,
    editable:true,
    flex:1
});

const onGridReady=(params)=>
{
   setgridapi(params.api);
   setcolapi(params.columnApi);

   axios.get("https://jsonplaceholder.typicode.com/users")
   .then((response)=>
   {
     params.api.applyTransaction({add:response.data});
   });
}

const showcolumn=()=>
{
// colapi.setColumnVisible("address.city",hidecol); // Hide the single columns in the AgGrid
 colapi.setColumnsVisible(["email","address.city"],hidecol); 
 gridApi.sizeColumnsToFit();
 sethidecol(!hidecol);
 setext(hidecol ? "Hide" : "Show");
}

return(
    <div>
    {console.log("renders")}
    <header>
    <h1>Hide and Show Columns in API</h1>
    </header>
    <div className="tablecontainer">
    <button className="btncsv" onClick={()=>showcolumn()}>{`${text} Email and Address`}</button>    
    <div className="ag-theme-alpine" style={{height:300}}>
    <AgGridReact 
    onGridReady={onGridReady}
    columnDefs={columns}
    defaultColDef={defaultColDef}
    />
    </div>
    </div>
    </div>
)
}

export default Hid_ShoCol;