import {useState} from "react";
import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";

function Pagination()
{
const [rows,setrow]=useState();
const [gridapi,setgridapi]=useState();
const [columns,setcolumn]=useState([
   {field:"id"},
   {field:"name"},
   {field:"email"},
   {field:"body"}
]);

const defaultColDef=({
    sortable:true,
    filter:true,
    floatingFilter:true,
    flex:1
});



const onGridReady=(params)=>
{
setgridapi(params);
axios.get("https://jsonplaceholder.typicode.com/comments")
.then((response)=>{
    params.api.applyTransaction({add:response.data});
    params.api.paginationGoToPage(3); //When the page loads it will directly loads the data from where it will starts
})
}

return(
    <div>
    <header>
    <h1>Grid Pagination</h1>
    </header>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:400}}>
    <AgGridReact 
    columnDefs={columns}
    defaultColDef={defaultColDef}
    pagination={true} //Displays the Page number in under the table
    // paginationPageSize={10} //Displays the number of data's want to be present in the single page
    // paginationAutoPageSize={true}  //Autofits the data in the table of the page
    onGridReady={onGridReady} // used for interacting with the grid including methods,properties and events
    />
    </div>
    </div>
    </div>
)
}
export default Pagination;