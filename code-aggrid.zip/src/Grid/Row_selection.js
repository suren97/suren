import {AgGridReact} from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import {useEffect,useState} from "react";
import axios from "axios";

function Row_selection()
{
const [rowdata,setrow]=useState();
const [column,setcolumn]=useState([
    {field:"athlete",checkboxSelection:true,headerCheckboxSelection:true},// To Add Checkbox in the athlete column
    {field:"age"},
    {field:"sport"},
    {field:"country"},
    {field:"bronze"},
    {field:"silver"},
    {field:"gold"},
    {field:"date"},
    {field:"total"}
]);

const defaultColDef=({
    sortable:true,
    filter:true,
    editable:true,
    floatingFilter:true,
    flex:1
});

useEffect(()=>{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
    response.data.length=100;
    setrow(()=>
    {
        return [...response.data];
    })
  })
},[]);

const onSelectionChanged=(params)=>
{
   console.log(params.api.getSelectedRows());
}

const isRowSelectable=(node)=>
{
  return node.data ? (node.data.age < 18 || node.data.country.includes('South Korea')):false;
}

return(
  <div>
    <header>
    <h1>Grid Row-Selection</h1>
    </header>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:400}}>
    <AgGridReact
    rowData={rowdata}
    columnDefs={column}
    defaultColDef={defaultColDef}
    rowSelection="multiple"   // Row selection of single and multiple rows
    onSelectionChanged={onSelectionChanged} // Selection of rows in the event
    rowMultiSelectWithClick={true} // Selection of rows with just click
    isRowSelectable={isRowSelectable} // Want to Select row and also for conditional selecting of rows
    />
    </div>
    </div>
  </div>
)
}
export default Row_selection;