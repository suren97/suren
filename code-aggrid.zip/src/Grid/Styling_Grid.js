import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { useState } from "react";
import axios from "axios";

function StyleGrid()
{
//const [rowdata,setrow]=useState();
const [columns,setcolumn]=useState([
    {field:"athlete",cellClass:(params)=>{
        return params.data.age > 18 ? "txtgreen" : "txtred"
    }},
    {field:"age",cellStyle:(params)=>{
        return params.data.age > 18 ? {color:"#41b141",fontWeight:"bold"} : {color:"red",fontWeight:"bold"}
     }},
    {field:"country"},
    {field:"year"},
    {field:"date"},
    {field:"sport"},
    {field:"silver"},
    {field:"gold"},
    {field:"bronze"},
    {field:"total"}
]);

const defaultColDef=({
    sortable:true,
    filter:true,
    flex:1,
    tooltipField:"athlete"
});

// useEffect(()=>{
//    axios.get('https://www.ag-grid.com/example-assets/olympic-winners.json')
//    .then((response)=>{
//        setrow(()=>{
//         return [...response.data];
//        })
//    })
// },[]);

let onGridReady=(params)=>
{
    axios.get('https://www.ag-grid.com/example-assets/olympic-winners.json')
    .then((response)=>{
         params.api.applyTransaction({add:response.data});
    })
}


return(
    <div>
    <header>
    <h1>Styling Grid Cell</h1>
    </header>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:400}}>
    <AgGridReact    
     columnDefs={columns}
     defaultColDef={defaultColDef}
     enableBrowserTooltips={true}
     tooltipShowDelay={{tooltipShowDelay:2000}}
     onGridReady={onGridReady}
    />
    </div>
    </div>
    </div>
)
}
export default StyleGrid;