import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { useState } from "react";

function Practice_Grid()
{
const [hidecol,sethidecol]=useState(false);
const [colapi,setcolapi]=useState();
const [text,setext]=useState("Hide");
const [columns,setcolumn]=useState([
    {field:"make",checkboxSelection:true,headerCheckboxSelection:true},
    {field:"model"},
    {field:"price"}
]);

const defaultColDef=({
    sortable:true,
    filter:true,
    flex:1,
    tooltipField:"make",
    cellStyle:params=>{
        return params.data.price > 35000 ? {color:"red",fontWeight:"bold"} : {color:"blue",fontWeight:"bold"}
    }
});

let onGridReady=(params)=>
{
  setcolapi(params.columnApi);
  axios.get("https://www.ag-grid.com/example-assets/row-data.json")
  .then((response)=>{
    params.api.applyTransaction({add:response.data});
  });
}

let onSelectionChanged=params=>
{
  console.log(params.api.getSelectedRows());
}

let isRowSelectable=(node)=>
{
 return node.data ? (node.data.make=="Ford" || node.data.price==72000) :false;
}

let BtnChange=()=>
{
//   colapi.setColumnVisible("price",hidecol);    //Single Hide of Rows
  colapi.setColumnsVisible(["model","price"],hidecol)  //Multiple Hide of columns
  colapi.sizeColumnsToFit();
  sethidecol(!hidecol);
  setext(hidecol ? "Hide" : "Show");
}

return(
    <div>
        <header>
        <h1>Sample Grid</h1>
        </header>
        <div className="tablecontainer">
        <button className="actbtn" onClick={()=>BtnChange()}>{`${text} Columns`}</button>
        <div className="ag-theme-alpine" style={{height:350}}>
        <AgGridReact
        onSelectionChanged={(e)=>onSelectionChanged(e)}
        onGridReady={onGridReady}
        columnDefs={columns}
        defaultColDef={defaultColDef}
        pagination={true}
        rowSelection="multiple"
        rowMultiSelectWithClick={true}
        isRowSelectable={isRowSelectable}
        enableBrowserTooltips={true}
        // paginationAutoPageSize={true}
        // paginationPageSize={5}
        />
        </div>
        </div>
    </div>
)
}
export default Practice_Grid;