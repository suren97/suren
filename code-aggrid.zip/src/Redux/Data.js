import { createSlice } from "@reduxjs/toolkit";
import produce from "immer";

const initialState={
     data:[],
};

const Data=createSlice({
    name:"Data",
    initialState,
    reducers:{
        Adddata:(state,action)=>
        {
         return produce(state,(draft)=>{
            draft.data.push(action.payload);
         })
        },
        updatedata:(state,action)=>
        {
        return produce(state,(draft)=>{
            let n=draft.data.findIndex((v,i)=>
            {
                if(v.id === action.payload.id)
                {
                    return i+1;
                }
            });
            draft.data.splice(n,1,action.payload);
        })
        },
        deleteData:(state,action)=>
        {
        return produce(state,(draft)=>
        { 
            let num=draft.data.findIndex((v,i)=>
            {
            if(v.id === action.payload.id)
                {
                    return i+1;
                }
              });
            draft.data.splice(num,1);
        })
        }
    }
});

export const Datareducer=Data.reducer;
export const {Adddata,updatedata,deleteData}=Data.actions;