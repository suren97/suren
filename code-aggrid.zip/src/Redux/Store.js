import { configureStore } from "@reduxjs/toolkit";
import { Datareducer } from "./Data";

const Store=configureStore({
    reducer:{
        userdata:Datareducer
    }
});

export default Store;

