import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useEffect, useState,useRef } from "react";
import { useDispatch } from "react-redux";
import { Adddata,updatedata,deleteData} from "../Redux/Data";
import Store from "../Redux/Store";

// getrownode();
function DataGrid()
{
const state=Store.getState();
const getusers = state => state.userdata.data;
let users=[...getusers(state)];

const dispatch=useDispatch();
const gridRef=useRef(null);
const [id,setid]=useState(1);
const [uname,setuname]=useState();
const [email,setemail]=useState();
const [mobile,setmobile]=useState();
const [city,setcity]=useState();
const [dept,setdept]=useState();
const [status,setstatus]=useState();
const [tempname,setname]=useState();
const [btntext,setbtntext]=useState("Submit");
const [updt,setupdt]=useState();

const defaultColDef=({
  sortable:true,
  filter:true,
  cellStyle:{fontSize:17},
  flex:1
});

const [rowdata,setrow]=useState();

const Actionbutton=(params)=>
{
  return (
    <div>
    <button className="updatebtn" onClick={()=>update(params)}>Update</button>
    <button className="delbtn" onClick={()=>handledelete(params)}>Delete</button>
    </div>
  )
};

const [columns,setcolumns]=useState([
    {field:"uname"},
    {field:"email"},
    {field:"mobile"},
    {field:"city"},
    {field:"dept"},
    {field:"status"},
    {field:"Action",cellRenderer:params=>Actionbutton(params)}
]);


const Deptoptions=[
    {label:"---- Select Options ----"},
    {label:"Human Resources",value:1},
    {label:"Finance and Payroll",value:2},
    {label:"Administration",value:3},
    {label:"Software Developer",value:4},
    {label:"Test Engineer",value:5},
    {label:"Database Administrator",value:6},
    {label:"Desktop Service",value:7}
];

const statoptions=[
    {label:"---- Select Options ----"},
    {label:"Active",value:1},
    {label:"Inactive",value:2}
];

useEffect(()=>{
    setrow(users);
},[id,updt]);

let update=(params)=>
{
  setbtntext("Update");
  setid(params.data.id);
  setuname(params.data.uname);
  setemail(params.data.email);
  setmobile(params.data.mobile);
  setcity(params.data.city);
  setdept(params.data.dept);
  setstatus(params.data.status);
}

const handledelete=(params)=>
{
   let confirm=window.confirm("Are you sure want to Delete ?");
   if(confirm)
   {
   dispatch(deleteData(params.data));
   setupdt(params.data.id);
   }
}

let handleupdate=()=>
{
  let confirm=window.confirm("Are you sure want to Update ?");
  if(confirm)
  {
    let data={};
    data.id=id;
    data.uname=uname;
    data.email=email;
    data.mobile=mobile;
    data.city=city;
    data.dept=dept;
    data.status=status;
    setbtntext("Submit");
    if(data)
    {
    dispatch(updatedata(data))
    setupdt(id);
    setuname("");
    setmobile("");
    setcity("");
    setemail("");
    setdept("");
    setstatus("");
    window.alert(`${uname}'s Data Updated Successfully`);
    }
  }
}

let handlesubmit=()=>
{
  let data={};
  data.id=id;
  data.uname=uname;
  data.email=email;
  data.mobile=mobile;
  data.city=city;
  data.dept=dept;
  data.status=status;
  var modal=document.getElementById("modal");
  modal.style.display="block";
  if(data)
  {
  setname(uname);
  dispatch(Adddata(data));
  setuname("");
  setmobile("");
  setcity("");
  setemail("");
  setdept("");
  setstatus("");
  setid(id+1);
  }
}

let handleselect=e=>
{
if(e.target.name=="Dept")
{
setdept(e.target.value);
}
else
{
setstatus(e.target.value);
}
}

let close=()=>
{
  var modal=document.getElementById("modal");
  modal.style.display="none";
}

const onGridReady=(params)=>
{
  params.api.sizeColumnsToFit();
}

return(
    <div>
    <header>
    <h1>Redux DataGrid</h1>
    </header>
    <div className="modal" id="modal">
    <div className="modal-content">
    <span className="close" id="close" onClick={()=>close()}>&times;</span>
    <p className="para">{`${tempname} Added Successfully`}</p>
    </div>
    </div>
    <div className="Addusers">
    <div className="flexcontainer">
    <div className="forms">
    <label>Username</label>
    <input type="text" value={uname} onChange={(e)=>setuname(e.target.value)} />
    </div>
    <div className="forms">
    <label>Email Id</label>
    <input type="text" value={email} onChange={(e)=>setemail(e.target.value)} />
    </div>
    <div className="forms">
    <label>Mobile No.</label>
    <input type="text" value={mobile} onChange={(e)=>setmobile(e.target.value)} />
    </div>
    <div className="forms">
    <label>City</label>
    <input type="text" value={city} onChange={(e)=>setcity(e.target.value)} />
    </div>
    <div className="forms">
    <label>Department</label>
    <select name="Dept" value={dept} onChange={(e)=>handleselect(e)}>
    {Deptoptions && Deptoptions.map((v,i)=>{
        return <option>{v.label}</option>
    })}
    </select>
    </div>
    <div className="forms">
    <label>Status</label>
    <select name="status" value={status} onChange={(e)=>handleselect(e)}>
    {statoptions && statoptions.map((v,i)=>{
        return <option>{v.label}</option>
    })}
    </select>
    </div>
    <div>
    <button className="formbtn" style={btntext==="Submit" ? {backgroundColor:"rgb(95, 141, 24)"} : {backgroundColor:"blue"}}
    onClick={btntext==="Submit" ? ()=>handlesubmit() : ()=>handleupdate() } >
      {`${btntext}`}
    </button>
    </div>
    </div> 
    </div>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:350}}>
    <AgGridReact
    ref={gridRef}
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultColDef}
    enableCellChangeFlash={true}
    onGridReady={onGridReady}
    />
    </div>
    </div>   
    </div>
)
}

export default DataGrid;