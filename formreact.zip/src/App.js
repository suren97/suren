import {BrowserRouter,Routes,Route} from "react-router-dom";
import Home from "./Components/Home";
import Blogs from "./Components/Blogs";
import ClassNav from "./Components/Classnav";
import Mainpage from "./Components/Mainpage";
import Register from "./Components/Register";
import Message from "./Components/Message";
import Login from "./Components/Loginpage";
import Store from "./Redux/Store";
import { Provider } from "react-redux";
import Task from "./Components/Screens/Task";
import Info from "./Components/Info";

function App() {
  const item=localStorage.getItem("display");
  // console.log(item)
  return (
    <div className="App">
    <BrowserRouter>
    <Provider store={Store}>
    <Routes>
    <Route path="/" element={<ClassNav />} >
      {item==="true" ? (
      <>
      <Route index element={<Home />}/>
      <Route path="/Tasks" element={<Task />} />
      <Route path="/message" element={<Message />} />
      <Route path="/info" element={<Info />}/>
      </>
      ):(
      <Route index element={<Mainpage />} />
      )}
      <Route path="/main" element={<Mainpage />} />
      <Route path="/register" element={<Register />} />
      <Route path="/home" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/info" element={<Info />} />
    </Route>
    </Routes>
    </Provider>
    </BrowserRouter>
    </div>
  );
}

export default App;
