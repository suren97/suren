import React,{Component} from "react";
import { Link,Outlet } from "react-router-dom";

class Classnav extends Component
{
constructor(props)
{
  super(props)
  this.state={
    show:false
  }
}
componentDidMount()
{
//getItem
var item=localStorage.getItem("display");
if(item==="true")
{
  this.setState({show:item});
}
}

Logout()
{
  localStorage.setItem("display",false);
  localStorage.clear();
  this.setState({show:false});
  window.location.href="/main";
}

componentDidUpdate()
{
var ele=document.getElementById("nav");
let sub=ele.getElementsByTagName("a");
for(let x of sub)
{
  x.addEventListener("click",()=>
  {
    x.setAttribute("id","active");
    x.classList.add("active");
    for(var i=0;i<sub.length;i++)
    {
    if(sub[i].id!=="active")
    {
     sub[i].className="link";
     sub[i].id="";
    }
    else
    {
     sub[i].id="";
    }
    }
  })
}
}
render()
{
  return(
        <>
        <div>
         <nav>
           <ul id="nav">
            <li>
                <Link className="link active" to="/">Home</Link>
            </li>
            {this.state.show ? (
            <>
            <li>
                 <Link className="link" to="/Tasks">Tasks</Link>
            </li>
            <li>
                <Link className="link" to="/info">Info</Link>
            </li>
            <li className="logout">
                <Link to="/" onClick={()=>this.Logout()}>Logout</Link>
            </li>
            </>
            ):( " " )}
           </ul>
         </nav>
        </div>
        <Outlet />
        </>
    )
 }
}

export default Classnav;