function Home()
{
 return(
    <div>
    <h1>HomePage</h1>
    </div>
 )
}

export default Home;