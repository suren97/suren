import { useEffect, useState } from "react";

function Info()
{
const [info,setinfo]=useState({});

useEffect(()=>{
let data=JSON.parse(localStorage.getItem("userlist"));
console.log(data);
setinfo((prev)=>
{
    return {...prev,data}
});
},[])

return(
    <div>
    <div className="pageheader">
    <h1>Info</h1>
    </div>
    <div className="container">
    <table className="tasktable">
        {info.data ? (
        <tbody>
            <tr>
                <th>Name</th>
                <td>{info.data.name}</td>
            </tr>
            <tr>
                <th>Email</th>
                <td>{info.data.email}</td>
            </tr>
            <tr>
                <th>Mobile</th>
                <td>{info.data.mobile}</td>
            </tr>
            <tr>
                <th>Date of Birth</th>
                <td>{info.data.dob}</td>
            </tr>
            <tr>
                <th>Address</th>
                <td>{info.data.address}</td>
            </tr>
        </tbody>
        ):(
          " "
        )}
    </table>
    </div>
    </div>
)
}
export default Info;