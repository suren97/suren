import { useState } from "react";
import { useSelector } from "react-redux";

function Login()
{  
   const [name,setname]=useState();
   const [pass,setpass]=useState();
   const [namerr,setnamerr]=useState("");
   const [passerr,setpasserr]=useState("");
   const [nav,setnav]=useState(false);
   
   const Checkuser=()=>
   {
      let data=JSON.parse(localStorage.getItem("userlist"));
      console.log(data);
      
      const checkvalidation=()=>{
      if(data)
      {
        if(data.name!==name)
        {
           setnamerr("Invalid username");
           return false;
        }
        else
        {
         setnamerr("");
        }
        if(data.password!==pass)
        {
           setpasserr("Invalid password");
           return false;
        }
        else
        {
         setpasserr("");
        }
        return true;
      }
   }
   console.log("Validation:",checkvalidation())
   if(checkvalidation())
   {
      window.location.href="/home";
      localStorage.setItem("display",true)
   }
   }

   return(
    <>
    <div className="pageheader">
    <h1>Login</h1>
    </div>
    <div className="container">
    <div className="form-content">
    <label>Username:</label>
    <input type="text" onChange={(e)=>setname(e.target.value)} />
    <span className="errormsg">{namerr}</span>
    </div> 
    <div className="form-content">
    <label>Password:</label>
    <input type="password" onChange={(e)=>setpass(e.target.value)} />
    <span className="errormsg">{passerr}</span>
    </div>  
    <div className="btn">
    <button type="button" onClick={()=>Checkuser()}>Login</button>
    </div>
    </div>
    </>
   )
}

export default Login;