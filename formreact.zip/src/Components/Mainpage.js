function Mainpage()
{
    return(
        <div className="btncontainer">
        <button type="button" className="Regbtn" onClick={()=>window.location.href="/register"}>Register</button>
        <button type="button" className="Logbtn" onClick={()=>window.location.href="/login"}>Login</button>
        </div>
    )
}

export default Mainpage;