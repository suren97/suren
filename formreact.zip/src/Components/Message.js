const Message=(props)=>
{
const login=()=>
{
  window.location.href="/login"
}
return(
    <div>
    <div className="message">
    <h1>Welcome {props.name} - Thank you for Registering</h1>
    <div className="btn">
    <button type="button" onClick={()=>login()}>Login</button>
    </div>
    </div>
    </div>
)
}
export default Message;