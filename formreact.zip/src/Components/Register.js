import {useState} from "react";
import Message from "./Message";
import { useSelector,useDispatch } from "react-redux";
import {Adduser} from "../Redux/Users";

function Register()
{
  const users=useSelector((state)=>console.log(state));
  const dispatch=useDispatch();
  const [fname,setfname]=useState("");
  const [mobile,setmobile]=useState("");
  const [email,setemail]=useState("");
  const [Date,setDate]=useState("");
  const [Address,setadd]=useState("");
  const [password,setpass]=useState("");
  const [cpassword,setcpass]=useState("");
  const [mes,setmes]=useState(true);
  const [errmsg,seterr]=useState({
    namerr:"",
    numerr:"",
    emailerr:"",
    daterr:"",
    adderr:"",
    perr:"",
    cerr:""
  });

const submit=()=>
{
  // let setusers=[];
  let values={};
  values.name=fname;
  values.mobile=mobile;
  values.email=email;
  values.dob=Date;
  values.address=Address;
  values.password=password;
  values.cpassword=cpassword;
  // dispatch(Adduser(values));
  
  if(formvalidation(values))
  {
    // setusers.push(values);
    setmes(false);
    localStorage.setItem("userlist",JSON.stringify(values));
    alert("Registered Successfully");
  }
}

// Validation
const formvalidation=(data)=>
{
  let nameval=/^[A-Za-z]+$/;
  let numval=/^[0-9]+$/;
  var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
  if(data)
  {
  //Name Validation
    if(!data.name)
    {
      seterr((prev)=>
      {
        return {...prev,namerr:"Name should not be Empty"}
      })
      return false;
    }
    if(data.name.match(nameval))
    {
      seterr((prev)=>
      {
        return {...prev,namerr:" "}
      })
    }
    else
    {
      seterr((prev)=>
      {
        return {...prev,namerr:"Not a Valid username"}
      })
      return false;
    }
    //-------------------------------------------------------------------//
  //Number Validation
    if(!data.mobile)
    {
      seterr((prev)=>
      {
         return {...prev,numerr:"Mobile Number Cannot be Empty"};
      })
      return false;
    }
    if(data.mobile.match(numval))
    {
      console.log(data.mobile.length)
      if(data.mobile.length < 10 || data.mobile.length > 10)
      {
       seterr((prev)=>{
        return {...prev,numerr:"Invalid Mobile Number"}
       })
       return false;
      }
      seterr((prev)=>{
         return {...prev,numerr:""};
      });
    }
    else
    {
      seterr((prev)=>
      {
        return {...prev,numerr:"Invalid Mobile Number"}
      })
      return false;
    }
//-------------------------------------------------------------------//
   
// Email Validation
    if(!data.email)
    {
      seterr((prev)=>{
        return {...prev,emailerr:"Email Cannot be Empty"}
      });
      return false;
    }
    if(mailformat.test(data.email))
    {
      seterr((prev)=>{
        return {...prev,emailerr:""}
      })
    }
    else
    {
      seterr((prev)=>{
        return {...prev,emailerr:"Invalid Email Address"}
      })
      return false;
    }
 //-------------------------------------------------------------------//

 // Date Validation
    if(!data.dob)
    {
      seterr((prev)=>
      {
        return {...prev,daterr:"Date Cannot be empty"}
      })
      return false;    
    }
    if(data.dob)
    {
      var d = new window.Date(data.dob);
      var curtyear=new window.Date().getFullYear();
      var year=d.getFullYear();
      if(year < curtyear-100 || curtyear < year)
      {
       seterr((prev)=>
       {
        return {...prev,daterr:"Invalid Date of Birth"}
       })
       return false;
      }
      seterr((prev)=>{
        return {...prev,daterr:""}
      })
    }
    //-------------------------------------------------------------------//
   
 // Address Validation
    if(!data.address)
    {
      seterr((prev)=>{
        return {...prev,adderr:"Address Cannot be Empty"}
      })
      return false;
    }
    else
    {
      seterr((prev)=>{
        return {...prev,adderr:""}
      })
    }

  // Password Validation
    if(!data.password)
    {
      seterr((prev)=>{
        return {...prev,perr:"Password Cannot be Empty"}
      })
    }
    if(decimal.test(data.password))
    {
      seterr((prev)=>{
        var d=document.getElementById("tooltip");
        d.style.display="none";
        return {...prev,perr:""}
      })
    }
    else
    {
      var d=document.getElementById("tooltip");
      d.style.display="block";
      seterr((prev)=>{
        return {...prev,perr:"Invalid Password"}
      }) 
      return false;
    }

    //Confirm password validation
    if(!data.cpassword)
    {
      seterr((prev)=>{
        return {...prev,cerr:"Please Renter the Password"}
      })
    }
    if(data.cpassword == data.password)
    {
      seterr((prev)=>{
        return {...prev,cerr:""}
      })
    }
    else
    {
      seterr((prev)=>{
        return {...prev,cerr:"Password doesn't Match"}
      })
      return false;
    }
  }
  return true;
}

  return(
    <div>
    {mes ? (
    <>
    <div className="pageheader">
    <h1>Registration Page</h1>
    </div>
    <div className="container">

    <div className="form-content">
    <label>Username:</label>
    <input type="text" value={fname} onChange={(e)=>setfname(e.target.value)} />
    <span className="errormsg">{errmsg.namerr}</span>
    </div>

    <div className="form-content">
    <label>Mobile:</label>
    <input type="text" value={mobile} onChange={(e)=>setmobile(e.target.value)} />    
    <span className="errormsg">{errmsg.numerr}</span>
    </div>

    <div className="form-content">
    <label>Email Address:</label>
    <input type="text" value={email} onChange={(e)=>setemail(e.target.value)} />    
    <span className="errormsg">{errmsg.emailerr}</span>
    </div>

    <div className="form-content">
    <label>Date of Birth:</label>
    <input type="date" value={Date} onChange={(e)=>setDate(e.target.value)} />
    <span className="errormsg">{errmsg.daterr}</span>
    </div>

    <div className="form-content">
    <label>Address:</label>
    <textarea value={Address} onChange={(e)=>setadd(e.target.value)} />
    <span className="errormsg">{errmsg.adderr}</span>
    </div>

    <div className="form-content">
    <label>Password:</label>
    <input type="password" id="pass" value={password} onChange={(e)=>setpass(e.target.value)} />
    <span className="errormsg">{errmsg.perr}</span>
    <span className="tooltip" id="tooltip">
    Password contains 8 to 15 characters which contain at least 
    one uppercase letter, one numeric digit, and one special character
    </span>
    </div>

    <div className="form-content">
    <label>Confirm Password:</label>
    <input type="password" value={cpassword} onChange={(e)=>setcpass(e.target.value)} />
    <span className="errormsg">{errmsg.cerr}</span>
    </div>

    <div className="btn">
    <button type="button" onClick={()=>submit()}>Register</button>
    </div>
    </div>
    </>
    ):(
    <Message name={fname} />
    )}
    </div>
  )
}

export default Register;

