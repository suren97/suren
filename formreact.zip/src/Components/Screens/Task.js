import {useEffect, useState} from "react";
import { useDispatch } from "react-redux";
import { Tasklist, Updlist,Complist } from "../../Redux/Users";
import Store from "../../Redux/Store";

function Task()
{
    const state=Store.getState();
    const getItems=state=>state.user.tasks;
    const getcompleted=state=>state.user.comptask;
    const getupdated=state=>state.user.updtask;
    let compitems=[...getcompleted(state)];
    let items=[...getItems(state)];
    let upditems=[...getupdated(state)];
    // console.log(items)

    items.sort((a,b)=>
    {
        return a.priorityno - b.priorityno;
    });
  

    const dispatch=useDispatch();
    const [data,setdata]=useState();
    const [click,setclick]=useState(0);
    const [lists,setlist]=useState([
        {label:"Select Options",value:""},
        {label:"High",value:1},
        {label:"Medium",value:2},
        {label:"Low",value:3}
    ]);
    const [task,settask]=useState();
    const [id,setid]=useState(1);
    const [prior,setprior]=useState({value:"",label:""});
    const [comp,setcomp]=useState([]);
    const [box,setbox]=useState();


useEffect(()=>
{
setcomp(compitems);
setdata(items);
var li=document.getElementsByClassName("bar");
for(let li2 of li)
{
    li2.addEventListener("click",()=>
    {
       li2.setAttribute("id","active");
        li2.classList.add("baractive");
        for(var i=0;i<li.length;i++)
        {
           if(li[i].id!=="active")
           {
            li[i].className="bar";
            li[i].id="";
           }
           else
           {
            li[i].id="";
            setclick(i);
           }
        }
    }) 
}
},[click,box]);

let submit=()=>
{
let val={};
val.priorityname=prior.label;
val.priorityno=prior.value;
val.taskname=task;
val.id=id;
val.status="Pending";
val.checked=false;
dispatch(Tasklist(val));
settask("");
setprior({value:"",label:""});
setid(id+1);
alert("Submitted Successfully");
}

const handleopt=e=>
{
if(e.target.value)
{
let val=lists.filter((v,i)=>{
if(v.label === e.target.value)
{
   return v.value;
}
});
setprior((prev)=>
{
   return {...prev,label:val[0].label,value:val[0].value}
});
}
}

const handlebox=(e,val)=>
{
console.log(val);
let con=window.confirm(`${val.taskname} set as Completed`);
if(con)
{
setbox(val);
let elem=data.filter((v,i)=>
{
    if(v.id === val.id)
    {
    //   v.status="Completed";
      dispatch(Complist(v));
      dispatch(Updlist([v,e.target.checked]));
    }
    else
    {
      return v;
    }
});
}
}

return(
        <div>
        <div className="pageheader">
        <h1>Task Manager</h1>
        </div>
        <div className="container">
        <div className="bar baractive"><span>Add Tasks</span></div>
        <div className="bar"><span>Task Lists</span></div>
        <div className="bar"><span>Completed</span></div>

        {/* Add Tasks */}
        {click===0 ? (
        <div className="taskcont">
        <label>Enter the Task Name:</label>
        <input type="text" value={task} onChange={(e)=>settask(e.target.value)} />
        <label>Select Priority:</label>
        <select value={prior.label} onChange={(e)=>handleopt(e)}>
        {lists.map((v,i)=>
        {
           return <option value={v.label}>{v.label}</option>
        })}
        </select>
        <div className="btn">
        <button type="button" onClick={()=>submit()}>Submit</button>
        </div>
        </div>
        ):(" ")}

        {/* Task Lists */}
        {click === 1 ? (
        <div className="taskcont">
        <h1>Task Lists</h1>
        <table className="tasktable">
        <tbody>
        <tr>
            <th>TaskName</th>
            <th>Priority</th>
            <th>Status</th>
            {/* <th>Action</th> */}
        </tr>
        {data.length ? data.map((v,i)=>{
     return <tr>
            <td>{v.taskname}</td>
            <td>{v.priorityname}</td>
            <td><input type="checkbox" checked={v.checked} className="checkstatus" onChange={(e)=>handlebox(e,v)} /></td>
            {/* <td><button type="button" className="delbtn">Delete</button></td> */}
            </tr>
        }):(
        <p style={{textAlign:"center"}}>"No Records Found"</p>
        )}
        </tbody>
        </table>
        </div>  
        ):(" ")}

        {/* Completed */}
        {click === 2 ? (
        <div className="taskcont">
        <h1>Completed List</h1>
           <div className="taskcont">
             <table className="tasktable"> 
             <tbody>
                <tr>
                    <th>SI.NO</th>
                    <th>Completed Task List</th>
                </tr>
                {comp.length ? comp.map((v,i)=>{
                  return( <tr>
                    <td>{i+1}</td>
                    <td>{v.taskname}</td>
                 </tr> 
                 )    
                }):(
                    " "
                )}
                </tbody>
             </table>
           </div>
        </div>
        ):(" ")}

        </div>
        </div>
    )
}
export default Task;