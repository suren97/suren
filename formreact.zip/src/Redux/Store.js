import { configureStore } from "@reduxjs/toolkit";
import {usersReducer} from "./Users";

const Store=configureStore({
  reducer:{
    user:usersReducer
  }
});

export default Store;