import { compose, createSlice } from "@reduxjs/toolkit";
import produce from "immer";

const initialState={
   users:[],
   tasks:[],
   comptask:[],
   updtask:[]
};

const userReducer=createSlice({
    name:"user",
    initialState,
    reducers:{
        Adduser:(state,action)=>
        {
          return produce(state,(draft)=>{
             draft.users.push(action.payload)
          })
        },
        Tasklist:(state,action)=>
        {
          return produce(state,(draft)=>{
             draft.tasks.push(action.payload);
         })
        },
        Updlist:(state,action)=>
        {
           return produce(state,(draft)=>
           {
           let[obj,bool] =action.payload;
            let n=draft.tasks.findIndex((v,i)=>
            {
               if(v.id === obj.id)
               {
                   return i+1;
               }
            });
            console.log(n);
            draft.tasks[n].checked=bool;
            draft.tasks.splice(n,1);
            // draft.tasks[1];
           })
        },
        Complist:(state,action)=>
        {
           return produce(state,(draft)=>{
            draft.comptask.push(action.payload);
           })
        }
    }
});

export const usersReducer=userReducer.reducer;
export const {Adduser,Complist,Tasklist,Updlist}=userReducer.actions;
