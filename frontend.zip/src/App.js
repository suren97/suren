import React from "react";
import Sample from "./Screens/Counter_Screen";
import Counter from "./Screens/Counter";
import Hovercounter from "./HigherOrder/Hovercounter";
import Hooks_Rev from "./Screens/Hooks_Rev";
import User_redux from "./Screens/User_redux";
import {Provider} from "react-redux";
import Store from "./Redux/Store";
import Hooks from "./Hooks/Hook";
import UIscreen from "./Screens/UIscreen";
import FetchData from "./Hooks/FetchData";
import Contextfun from "./Hooks/context/usecontext";
import Usemem from "./Hooks/Memo/Usemem";
import Parent from "./Hooks/Memo/Parent";
import Useref from "./Hooks/Ref/funRef";
import Classtimer from "./Timer/classTimer/Classtimer";
import Funtimer from "./Timer/Functimer/Functimer";
import FileSaver from "./Screens/FileSaver";
import HOF from "./HigherOrderFunction/HOF";
import HomePage from "./Home";
import CanvasReact from "./Canvas/Canvas";
import FooterComp from "./Footer";
import { BrowserRouter,Routes,Route } from "react-router-dom";
import ImportExcel from "./ImportExcel/ImportExcel";
import EventElement from "./EventEmitter/EventElement";
import BasicEvents from "./EventEmitter/BasicEvents";
import SelectCanvas from "./Canvas/SelectCanvas";
import InputType from "./Samplefunction/InputType";
import EscapeHatch from "./EscapeHatches/EscapeRef/Escape";
import Interval from "./EscapeHatches/EscapeRef/Interval";
import DOMRef from "./EscapeHatches/ManipulateDOM/DOMRef";
import ScrollElement from "./EscapeHatches/ManipulateDOM/ScrollElement";
import CanvasSelection from "./Canvas/CanvasSelection";

export const usercontext=React.createContext();
export const channelcontext=React.createContext();


function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<CanvasSelection />}>
            <Route path="/canvas" element={<CanvasReact />}></Route>
            <Route path="/excel" element={<ImportExcel />}></Route>
          </Route>
        </Routes>
      </BrowserRouter>

      {/* <CanvasReact />
      <FooterComp /> */}
      {/* <SampleCanvas /> */}

      {/* <Hovercounter /> */}
      {/* <FileSaver /> */}
      {/* <Classtimer /> */}
      {/* <Funtimer /> */}
      {/* <Useref /> */}
      {/* <Parent /> */}
      {/* <Usemem /> */}
      {/* <usercontext.Provider value="Suren">
      <channelcontext.Provider value="Warriors">
      <Contextfun />
      </channelcontext.Provider>
      </usercontext.Provider> */}
      {/* <FetchData /> */}
      {/* <Provider store={Store}>
      <UIscreen />
      </Provider> */}
      {/* <Hooks /> */}
      {/* <Provider store={Store}>
      <User_redux />
      </Provider> */}
      {/* <Hovercounter /> */}
      {/* <Hooks_Rev /> */}
    </div>
    //   <div className="App">
    //     <Sample render={(color,text,handlecolor,handletext)=>(
    //     <div>
    //      {/* <Counter text={text} color={color} handlecolor={handlecolor} handletext={handletext} /> */}
    //     </div>
    // )}
    // />
    //   </div>
  );
}

export default App;
