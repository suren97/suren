import { useEffect, useState } from "react";

function CanvasReact()
{  
  const [color, setcolor] = useState();

  useEffect(() => {
     let events=require("events");
     let eventEmitter=new events.EventEmitter();
      
     eventEmitter.on("count",()=>{
       console.log("counting...");
     })

     eventEmitter.emit("Count");

     let docelem = document.querySelectorAll(".flexfootcontainer")[0].children;

     for (let i = 0; i < docelem.length; i++) {
       docelem[i].addEventListener("click", () => {
         docelem[i].style.border = "4px solid yellow";
         setcolor({
           bgcolor: docelem[i].style.backgroundColor,
           txtcolor:
             docelem[i].style.color === "" ? "black" : docelem[i].style.color,
         });
       });
     }

    //Box
    let canvas = document.getElementById("canvasid");
    canvas.style.border = "1px solid black";
    let ctx = canvas.getContext("2d");

    let height = canvas.height / 5;
    let width = canvas.width / 5;

    let ellipses = [];
    let xposition = width / 2;
    let w = width;
    let yposition = "";

    let c = 1;
    while (w <= canvas.width) {
      yposition = height / 2;
      for (let i = 1; i < 6; i++) {
        ctx.rect(0, 0, width, height);
        ctx.rect(0, height * i, width, height);
        ctx.rect(w, 0, width, height);
        ctx.rect(w, height * i, width, height);
        ctx.stroke();

        ctx.beginPath();
        if (c === i) {
          ctx.ellipse(
            xposition,
            yposition,
            width / 2,
            height / 2,
            0,
            0,
            2 * Math.PI
          );
          // ellipses.push({
          //   row: i,
          //   x: xposition,
          //   y: yposition,
          //   w: width / 2,
          //   h: height / 2,
          //   rot: 0,
          //   start: 0,
          //   end: 2 * Math.PI,
          // });
        }
        ctx.stroke();
        c = c === 5 ? 1 : i + 1;
        yposition = yposition + height;
      }
      xposition = xposition + width;
      w = w + width;
    }

    let getclicked = "";
    let row = "";
    let col = "";

    canvas.addEventListener("click", (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      row = Math.floor(y / height);
      col = Math.floor(x / width);

      getclicked = ellipses.filter((val, ind) => {
        return val.row == row + 1;
      });
      if (getclicked) {
        HoverClick(getclicked);
      }
    });

    const HoverClick = (getclicked) => {
      ctx.beginPath();
      ctx.ellipse(
        getclicked[col].x,
        getclicked[col].y,
        getclicked[col].w,
        getclicked[col].h,
        getclicked[col].rot,
        getclicked[col].start,
        getclicked[col].end
      );
      ctx.fillStyle =color.bgcolor;
      ctx.fill();
      ctx.closePath();

      ctx.beginPath();
      ctx.textAlign = "center";
      ctx.font = "15px Arial";
      ctx.fillStyle=color.txtcolor
      ctx.fillText(`${row + 1 + ','+ (col+1)}`,getclicked[col].x,getclicked[col].y);
      ctx.closePath();
    };

  },[color]);

  return (
    <>
      <div>
        <header>
          <h1>Canvas React</h1>
        </header>
        <div className="canvascontainer">
          <canvas id="canvasid" width="700" height="300"></canvas>
        </div>
      </div>
    </>
  );
}

export default CanvasReact;