import { useEffect,useState } from "react";
import Rector from "./Rector";

function CanvasSelection()
{
const [selected,setselected]=useState(false);
const [canvaselem,setelem]=useState({
    x:-1,
    y:-1,
    w:-1,
    h:-1
})

let onSelected=(rect)=>{
    setselected(true);
    setelem(()=>{
        return {...rect}
    });
}

let getSelectionStr=()=>{
    if(selected){
        return `x:${canvaselem.x},y:${canvaselem.y},w:${canvaselem.w},h:${canvaselem.h}`
    }
    return "Not Selected";
}

// useEffect(()=>{

//   ctx.rect(0, 0, 120, 60);
//   ctx.rect(0, 60, 120, 60);
//   ctx.rect(0, 120, 120, 60);
//   ctx.rect(0, 180, 120, 60);
//   ctx.rect(0, 240, 120, 60);

//   ctx.rect(120, 0, 120, 60);
//   ctx.rect(120, 60, 120, 60);
//   ctx.rect(120, 120, 120, 60);
//   ctx.rect(120, 180, 120, 60);
//   ctx.rect(120, 240, 120, 60);

//   ctx.rect(240, 0, 120, 60);
//   ctx.rect(240, 60, 120, 60);
//   ctx.rect(240, 120, 120, 60);
//   ctx.rect(240, 180, 120, 60);
//   ctx.rect(240, 240, 120, 60);

//   ctx.rect(360, 0, 120, 60);
//   ctx.rect(360, 60, 120, 60);
//   ctx.rect(360, 120, 120, 60);
//   ctx.rect(360, 180, 120, 60);
//   ctx.rect(360, 240, 120, 60);

//   ctx.rect(480, 0, 120, 60);
//   ctx.rect(480, 60, 120, 60);
//   ctx.rect(480, 120, 120, 60);
//   ctx.rect(480, 180, 120, 60);
//   ctx.rect(480, 240, 120, 60);

//   ctx.stroke();
// },[])

return (
  <>
    <div>
      <header>
        <h1>Canvas Selection</h1>
      </header>
    </div>
    <Rector width="640" height="480" onSelected={onSelected} />
    {getSelectionStr()}
  </>
);
}
export default CanvasSelection;
