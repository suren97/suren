import { useEffect } from "react";

export default function Rector(props)
{
    const defaultProps={
        width:320,
        height:200,
        strokeStyle:"#F00",
        lineWidth:1,
        onSelected:()=>{},
    }

   let canvas=null,
    ctx=null,
    isDirty=false,
    isDrag=false,
    startX=-1,
    startY=-1,
    curX=-1,
    curY=-1

    useEffect(()=>{
      ctx = canvas.getContext("2d");
      ctx.strokeStyle = props.strokeStyle;
      ctx.lineWidth = props.lineWidth;
      ctx.rect(0, 0, 120, 60);
      ctx.rect(0, 60, 120, 60);
      ctx.rect(0, 120, 120, 60);
      ctx.rect(0, 180, 120, 60);
      ctx.rect(0, 240, 120, 60);
      
      ctx.rect(120, 0, 120, 60);
      ctx.rect(120, 60, 120, 60);
      ctx.rect(120, 120, 120, 60);
      ctx.rect(120, 180, 120, 60);
      ctx.rect(120, 240, 120, 60);
      
      ctx.rect(240, 0, 120, 60);
      ctx.rect(240, 60, 120, 60);
      ctx.rect(240, 120, 120, 60);
      ctx.rect(240, 180, 120, 60);
      ctx.rect(240, 240, 120, 60);
      
      ctx.rect(360, 0, 120, 60);
      ctx.rect(360, 60, 120, 60);
      ctx.rect(360, 120, 120, 60);
      ctx.rect(360, 180, 120, 60);
      ctx.rect(360, 240, 120, 60);
      
      ctx.rect(480, 0, 120, 60);
      ctx.rect(480, 60, 120, 60);
      ctx.rect(480, 120, 120, 60);
      ctx.rect(480, 180, 120, 60);
      ctx.rect(480, 240, 120, 60);
      
      ctx.stroke();
      addMouseEvent();
    },[]);
    
    let updateCanvas=()=>
    {
        if(isDrag){
            requestAnimationFrame(updateCanvas)
        }
        if(!isDirty){
            return
        }
        ctx.clearRect(0,0,props.width,props.height);
        if(isDrag){
            const rect={
                x:startX,
                y:startY,
                w:curX - startX,
                h:curY - startY
            }
        ctx.strokeRect(rect.x,rect.y,rect.w,rect.h)
        }
        isDirty=false;
    }

    let addMouseEvent=()=>{
        document.addEventListener("mousedown", onMouseDown, false);
        document.addEventListener("mousemove", onMouseMove, false);
        document.addEventListener("mouseup",onMouseUp, false);
    }

    let onMouseDown=e=>{
        isDrag=true;
        curX=startX=e.offsetX
        curY=startY=e.offsetY
        requestAnimationFrame(updateCanvas)
    }

    let onMouseMove=e=>{
        if(!isDrag) return 
        curX=e.offsetX
        curY=e.offsetY
        isDirty=true
    }

    let onMouseUp=e=>{
        isDrag=false;
        isDirty=true

        const rect={
            x:Math.min(startX,curX),
            y:Math.min(startY,curY),
            w:Math.abs(e.offsetX - startX),
            h:Math.abs(e.offsetY - startY)
        }
        props.onSelected(rect)
    }

    return(
        <>
            <canvas width={props.width} height={props.height} ref={(c)=>{canvas=c}} />
        </>
    )
}