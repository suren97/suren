import { useEffect } from "react";

function SelectCanvas()
{
    
useEffect(()=>
{
  let canvas = document.getElementById("canvasid");
  canvas.style.border = "1px solid black";

  let canvas2=document.getElementById("rectcanvas");
  let ctx1 = canvas2.getContext("2d");
  
  const drawSelection = (e) => {
    ctx1.strokeStyle = "#000";
    ctx1.beginPath();
    ctx1.rect(origin.x, origin.y, e.offsetX - origin.x, e.offsetY - origin.y);
    ctx1.stroke();
  };

  const clear = () => {
    ctx1.strokeStyle = "#fff";
    ctx1.clearRect(0, 0, canvas.width, canvas.height);
  };

  const render = (e) => {
    clear();
    DrawRect();
    
    if(origin) drawSelection(e);
  };

  window.onload = DrawRect();

  let origin = null;
  canvas.onmousedown = (e) => {
    origin = { x: e.offsetX, y: e.offsetY };
  };
  
  canvas.onmouseup = (e) => {
    origin = null;
    render(e);
  };

  canvas.onmousemove = render;

  function DrawRect()
  {
    let ctx = canvas.getContext("2d");
    ctx.rect(0, 0, 120, 60);
    ctx.rect(0, 60, 120, 60);
    ctx.rect(0, 120, 120, 60);
    ctx.rect(0, 180, 120, 60);
    ctx.rect(0, 240, 120, 60);

    ctx.rect(120, 0, 120, 60);
    ctx.rect(120, 60, 120, 60);
    ctx.rect(120, 120, 120, 60);
    ctx.rect(120, 180, 120, 60);
    ctx.rect(120, 240, 120, 60);

    ctx.rect(240, 0, 120, 60);
    ctx.rect(240, 60, 120, 60);
    ctx.rect(240, 120, 120, 60);
    ctx.rect(240, 180, 120, 60);
    ctx.rect(240, 240, 120, 60);

    ctx.rect(360, 0, 120, 60);
    ctx.rect(360, 60, 120, 60);
    ctx.rect(360, 120, 120, 60);
    ctx.rect(360, 180, 120, 60);
    ctx.rect(360, 240, 120, 60);

    ctx.rect(480, 0, 120, 60);
    ctx.rect(480, 60, 120, 60);
    ctx.rect(480, 120, 120, 60);
    ctx.rect(480, 180, 120, 60);
    ctx.rect(480, 240, 120, 60);

    ctx.stroke();
    }

},[])

    return (
      <>
        <header>
          <h1>Selecting Canvas Element</h1>
        </header>
        <div>Selected Image Parts</div>
        <canvas
          id="canvasid"
          width={600}
          height={300}
          style={{ margin: "5%" }}
        ></canvas>
        <canvas id="rectcanvas"></canvas>
        <img id="img" src="https://i.imgur.com/okSIKkW.jpg" />
      </>
    );
}

export default SelectCanvas;