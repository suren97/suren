import { useRef } from "react";
import { useState } from "react";

function EscapeHatch()
{
const inputelem=useRef(null);
const [name,setname]=useState();

let handleClick=(e)=>{
   inputelem.current=e.target.value;
}

let handlechange=e=>{
     setname(e.target.value);
}

return (
  <>
    <header>
      <h1>Escape Hatches</h1>
    </header>
    <div style={{ margin: "2%" }}>
      <label>Username(Ref):</label>
      <input type="text" onChange={(e) => handleClick(e)} />
      <label>Renders(useState):</label>
      <input type="text" onChange={(e) => handlechange(e)} />
      {inputelem.current}
    </div>
  </>
);
}

export default EscapeHatch;