import { useState } from "react";

function Interval()
{
   const [startTime,setTime]=useState();
   const [now,setNow]=useState(null);

   let handleStart=()=>{
     setTime(Date.now())
     setNow(Date.now())

     setInterval(()=>{
        setNow(Date.now())
     },1000);
   }

   let secondspassed=0;

   if(startTime != null && now!=null){
    secondspassed = (now - startTime) / 1000;
   }
   console.log("seconds",secondspassed);

   return(
    <>
    <div>
        <h1>Time passed:{secondspassed.toFixed(3)}</h1>
        <button onClick={handleStart}>Start</button>
    </div>
    </>
   )
}

export default Interval;