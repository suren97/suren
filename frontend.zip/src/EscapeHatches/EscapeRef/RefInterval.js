function RefInterval()
{
return(
    <>
    <div>
        <header>
            <h1>Stopwatch Ref</h1>
        </header>
    </div>
    </>
)
}

export default RefInterval;