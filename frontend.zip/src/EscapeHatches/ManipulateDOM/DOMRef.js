import { useRef } from "react"; 

function DOMRef()
{
    const inputRef=useRef(null);

    let handleClick=()=>{
        inputRef.current.focus();
    }

    return(
        <>
        <div>
            <header>
                <h1>DOM Ref</h1>
            </header>
        </div>
        <input ref={inputRef} />
        <button onClick={()=>handleClick()}>Focus the input</button>
        </>
    )
}

export default DOMRef;