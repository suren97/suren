import { useRef } from "react";

function ScrollElement()
{
  const frstcatref=useRef(null);
  const secondcatref=useRef(null);
  const thirdcatref=useRef(null);
  console.log(frstcatref)

  function handleScrollCat(){
     frstcatref.current.scrollIntoView({
           behavior:"smooth",
           block:"nearest",
           inline:"center"
     });
  }

  function handleSecScrollCat(){
    secondcatref.current.scrollIntoView({
      behavior: "smooth",
      block: "nearest",
      inline: "center",
    });
  }

  function handleThrdScrollCat() {
      thirdcatref.current.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
        inline: "center",
      });
  }

  return (
    <>
      <div>
        <header>
          <h1>Ref Input Element</h1>
        </header>
      </div>
      <nav>
        <button onClick={handleScrollCat} style={{ margin: 10, padding: 5 }}>
          Button-1
        </button>
        <button onClick={handleSecScrollCat} style={{ margin: 10, padding: 5 }}>
          Button-2
        </button>
        <button
          onClick={handleThrdScrollCat}
          style={{ margin: 10, padding: 5 }}
        >
          Button-3
        </button>
      </nav>
      <div>
        <ul>
          <li>
            <img
              src="https://placekitten.com/g/200/200"
              alt="Tom"
              ref={frstcatref}
            />
          </li>
          <li>
            <img
              src="https://placekitten.com/g/300/200"
              alt="Maru"
              ref={secondcatref}
            />
          </li>
          <li>
            <img
              src="https://placekitten.com/g/250/200"
              alt="Jellylorum"
              ref={thirdcatref}
            />
          </li>
        </ul>
      </div>
    </>
  );

}

export default ScrollElement;