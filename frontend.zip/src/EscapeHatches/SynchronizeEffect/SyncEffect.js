function SyncEffect()
{
return(
    <>
    <div>
        <header>
            <h1>Synchronizing with Effects</h1>
        </header>
    </div>
    </>
)
}

export default SyncEffect;