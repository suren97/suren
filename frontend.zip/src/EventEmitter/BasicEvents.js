import EventEmitter from "./EventEmit";

function BasicEvents()
{
   const myEmitter=new EventEmitter();
   
   //1.Creating an Event Emitter and register for couple of callbacks    
    let c1=()=>
    {
       console.log("An Event Occured....");
    }

    let c2=()=>
    {
        console.log("An Event2 Occured....");
    }

    myEmitter.on("eventone",c1);
    myEmitter.on("event2",c2);

    myEmitter.emit("eventone");
    myEmitter.emit("event2");
  
    //2. Registering for the event to be fired only one time using once
    myEmitter.once("eventOnce", () => console.log("eventonce fired..."));
    myEmitter.emit("eventOnce");
    
    //3.Registering for the event with callback parameters
    myEmitter.on("status",(code,msg)=>console.log(`Got ${code} and ${msg}`));
    myEmitter.emit('status',200,'OK');

    //4.Unregistering events
    myEmitter.off("eventone",c1);
    console.log("Offf")
    myEmitter.emit("eventone");
    console.log(myEmitter.listenerCount("eventOne"));

}

export default BasicEvents;