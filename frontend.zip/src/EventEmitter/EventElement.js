import EventEmitter from "./EventEmit";
import { useState } from "react";

function EventElement() {
    const [events,setevents]=useState([]);

    let emitter=new EventEmitter();
    
    emitter.on("click",(data)=>{
        console.log(data)
        appendEvent(data)
    })
    
    emitter.emit("click", { message: "Click!" });

    emitter.on("hover",(data)=>{
        appendEvent(data)
    })

    function appendEvent(data)
    {
       events.push(data)
    }

 let handleClick=()=>
 {
 }

  return (
    <>
      <div>
        <h1>Welcome to the Event Emitter Exercise</h1>
      </div>
      <hr></hr>
      <p className="paraelem">Lets practice about the event emitters</p>
      <div>
        <button 
        className="targetbtn"
        onClick={()=>handleClick()}
        >
            Target
        </button>
      </div>
    </>
  );
}

export default EventElement;
