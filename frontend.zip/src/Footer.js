import { useEffect,useState,createContext } from "react";

function FooterComp()
{
const [color,setcolor]=useState();

useEffect(()=>
{
  let docelem = document.querySelectorAll(".flexfootcontainer")[0].children;
  for(let i=0;i<docelem.length;i++)
  {
    docelem[i].addEventListener("click",()=>
    {
      docelem[i].style.border="4px solid yellow"
      setcolor({
        bgcolor: docelem[i].style.backgroundColor,
        txtcolor:
        docelem[i].style.color === ""
        ? "black"
        : docelem[i].style.color,
      });
    })
  }
  },[color])
  
  return (
    <>
    <div className="footer">
      <div className="flexfootcontainer">
        <div className="borderbox">AAAAA</div>
        <div className="borderbox" style={{backgroundColor:"red",color:"yellow"}}>BBBBB</div>
        <div className="borderbox" style={{backgroundColor:"blue",color:"white"}}>CCCCC</div>
        <div className="borderbox" style={{backgroundColor:"lightgrey"}}>DDDDD</div>
        <div className="borderbox" style={{backgroundColor:"lightpink"}}>EEEEE</div>
        <div className="borderbox" style={{backgroundColor:"lightcoral"}}>FFFFF</div>
        <div className="borderbox" style={{backgroundColor:"darkcyan",color:"lightgray"}}>GGGGG</div>
        <div className="borderbox" style={{backgroundColor:"darkgoldenrod",color:"lightgreen"}}>HHHHH</div>
      </div>
    </div>
  </>
);
}

export default FooterComp;