import React,{Component} from "react";
import UpdateComp from "./UpdateComp";

class Hovercounter extends Component
{
render()
{
    const {count,Increment}=this.props;
    return(
        <div>
        <h1>HoverCounter</h1>
        {count}
        <button type="button" onMouseOver={Increment}>Click</button>
        </div>
    )
}
}

export default UpdateComp(Hovercounter);