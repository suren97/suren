import React, {Component} from "react";

const UpdateComp=(Wrappedcomponent,count)=>{
class UpdateComp extends Component{
  constructor(props)
  {
    super(props)
    this.state={
       count:0
    }
  }
  Increment=()=>
  {
    this.setState((prev)=>
    {
     return {...prev,count:prev.count+1}
    });
  }
  render()
  {
    return(
        <div>
        <Wrappedcomponent
         count={this.state.count}
         Increment={this.Increment}
        />      
        </div>
    )
  }
}
return UpdateComp;
}

export default UpdateComp;