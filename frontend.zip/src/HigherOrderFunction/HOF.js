function HOF() {
  return (
    <>
      <div>
        <header>
          <h1>Higher Order Functions (Map,Filter and Reduce)</h1>
        </header>
      </div>
    </>
  );
}

export default HOF;
