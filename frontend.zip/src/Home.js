import { createContext, useEffect,useState } from "react";
import { Outlet } from "react-router-dom";

function HomePage()
{
return (
  <>
    <div>
      <header>
        <h1>HomePage</h1>
      </header>
      <Outlet />
      <div className="footer">
        <div className="flexfootcontainer">
          <div className="borderbox" style={{ backgroundColor: "greenyellow" }}>
            AAAAA
          </div>
          <div
            className="borderbox"
            style={{ backgroundColor: "red", color: "yellow" }}
          >
            <p>BBBBB</p>
          </div>
          <div
            className="borderbox"
            style={{ backgroundColor: "blue", color: "white" }}
          >
            CCCCC
          </div>
          <div className="borderbox" style={{ backgroundColor: "lightgrey" }}>
            DDDDD
          </div>
          <div className="borderbox" style={{ backgroundColor: "lightpink" }}>
            EEEEE
          </div>
          <div className="borderbox" style={{ backgroundColor: "lightcoral" }}>
            FFFFF
          </div>
          <div
            className="borderbox"
            style={{ backgroundColor: "darkcyan", color: "lightgray" }}
          >
            GGGGG
          </div>
          <div
            className="borderbox"
            style={{ backgroundColor: "darkgoldenrod", color: "lightgreen" }}
          >
            HHHHH
          </div>
        </div>
      </div>
    </div>
  </>
);
}

export default HomePage;