import { useEffect,useState } from "react";
import axios from "axios";

function FetchData()
{
const [data,setdata]=useState();
const [id,setid]=useState(1);
//Fetching Group of Data

// useEffect(()=>
// {
//   axios
//   .get("https://jsonplaceholder.typicode.com/users")
//   .then((response)=>{
//     setdata(response.data);
//   })
// },[]);

//Fetching data with Id
useEffect(()=>
{
    axios
    .get(`https://jsonplaceholder.typicode.com/posts/${id}`)
    .then((response)=>setdata(response.data))
},[id]);

return(
    <div>
    <header>
    <h1>Fetching Data</h1>
    </header>
    <div className="Datacontent">
    <label>Enter the Id to Get Detail:</label>
    <input type="text" value={id} onChange={(e)=>setid(e.target.value)} />
    <br></br>
    {data ? (
    <div>
    <label>Id:{data.id}</label>
    <label>title:{data.title}</label>
    <label>Body:{data.body}</label>
    </div>
    ):(
      " "
    )}
    {/* {data && data.map((v,i)=>
    {
    return <p key={v.id}>{v.name}</p>
    })} */}
    </div>
    </div>
)
}
export default FetchData;