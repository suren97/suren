import {useEffect, useState} from "react";

function Hooks()
{
const [x,setx]=useState();
const [y,sety]=useState();

useEffect(()=>
{
  console.log("Events")
  window.addEventListener("mousemove",Mouseposition)
},[]);

const Mouseposition=(e)=>
{
  setx(e.clientX);
  sety(e.clientY);
}

return(
    <div>
    <h1>React Hooks</h1>
    X Co-ordinates - {x}, y Co-ordinates - {y}
    </div>
)
}
export default Hooks;