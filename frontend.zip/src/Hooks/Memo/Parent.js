import Child from "./Child";
import { useCallback, useMemo, useState } from "react";

function Parent()
{
const [num,setnum]=useState(0);
const increment=()=>
{
  setnum(num+1);
}
const handlenum=useCallback(()=>
{

},[])
const getChild=useMemo(()=><Child handlenum={handlenum} />,[handlenum]);

return(
<div>
<h2>{num}</h2>
{getChild}
<button type="button" onClick={()=>increment()}>Add</button>
</div>
)
}
export default Parent;