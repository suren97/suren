import { useMemo, useState } from "react";

function Usemem()
{
const [value1,setvalue1]=useState(0);
const [value2,setvalue2]=useState(0);

const incrementone=()=>
{
 setvalue1(value1+1);
}

const incrementtwo=()=>
{
  setvalue2(value2+1);
}

const isEven=useMemo(()=>
{
for(var i=0;i<2000000000;i++)
{
    if(value1 % 2==0)
    {
       return true;
    } 
}
},[value1]);

return(
    <div>
    <h1>Use Memo</h1>
    {value1}
    <button type="button" onClick={()=>incrementone()}>Count</button>
    <span>{isEven ? "Even" : "Odd"}</span>
    <br></br>
    {value2}
    <button type="button" onClick={()=>incrementtwo()}>Count</button>
    </div>
)
}
export default Usemem;