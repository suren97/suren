import { useEffect, useRef } from "react";

function Useref()
{
const inpref=useRef(null);

useEffect(()=>
{
  inpref.current.focus();
  inpref.current.value="Default"
},[]);

return(
   <div>
    <h1>Function Ref</h1>
    <input ref={inpref} type="text" />
   </div>
)
}

export default Useref;