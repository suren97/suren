import Context3 from "./context3";
import { useContext } from "react";
import { channelcontext, usercontext } from "../../App";

function Context2()
{
const user=useContext(usercontext);
const channel=useContext(channelcontext);
return(
    <div>
     {user}-{channel}
     <Context3 />
    </div>
)
}
export default Context2;