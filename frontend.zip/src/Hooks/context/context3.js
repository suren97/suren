import { usercontext,channelcontext } from "../../App";

function Context3()
{
return(
    <div>
    <usercontext.Consumer>
    {user =>{
      return (
        <channelcontext.Consumer>
         {channel =>{
            return <h1>The Screen is accessed by {user} and from the channel {channel}</h1>
         }}
        </channelcontext.Consumer>
    )
}}
    </usercontext.Consumer>
    </div>
)
}
export default Context3;