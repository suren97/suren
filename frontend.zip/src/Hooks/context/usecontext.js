import Context2 from "./context2";

function Contextfun()
{
return(
    <div>
    <Context2 />
    </div>
)
}
export default Contextfun;