import { useEffect } from "react";

function ImportExcel()
{

 let file = require("./Import.xlsx");
 
 const url = file;
 const xhr = new XMLHttpRequest();
 xhr.open("GET", url, true);
 xhr.responseType = "blob";

 xhr.onload = function () {
   if (this.status === 200) {
     const blob = this.response;

     const reader = new FileReader();
     reader.onload =async function () {
           console.log("ArrayBufferofExcel",reader.result)
     };
     reader.readAsArrayBuffer(blob);
   }
 };
 xhr.send();

return (
  <>
    <div>
      <h1>Import Excel Without button</h1>
    </div>
  </>
);
}

export default ImportExcel;