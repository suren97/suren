import {ADD_USER} from "./Type";

const Adduser=(users)=>
{
return{
    type:ADD_USER,
    payload:users
}
}

export default Adduser;

