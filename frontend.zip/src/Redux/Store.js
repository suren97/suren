import { createStore } from "redux";
import { userReducer } from "./reducers";

const store=createStore(userReducer);
store.subscribe(()=>store.getState());

export default store;