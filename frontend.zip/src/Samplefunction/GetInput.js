const GetInput=(Wrappedcomponent,props)=>{
    function SetInputComp(props)
    {
    return(
        <Wrappedcomponent />
    )
  }
  return SetInputComp;
}

export default GetInput;