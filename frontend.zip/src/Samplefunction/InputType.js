import { useState } from "react";
import GetInput from "./GetInput";

function InputType()
{
    const [textelem,setelem]=useState();
    
    return(
        <>
        <div>
            <input type="text" onChange={(e)=>setelem(e.target.value)} />
        </div>
        </>
    )
}

export default GetInput(InputType);