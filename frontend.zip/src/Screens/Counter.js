function Counter(props)
{
return(
    <div>
    <label>Color:</label>
    <input type="text" onChange={(e)=>props.handlecolor(e)} />
    <label>Text:</label>
    <input type="text" onChange={(e)=>props.handletext(e)}/>
    <button type="button" style={{backgroundColor:`${props.color}`}} className="btnstyle">{props.text}</button>
    </div>
)
}

export default Counter;