import React,{ Component } from "react";

class Sample extends Component
{
  constructor(props)
  {
    super(props)
    this.state={
       color:"",
       text:""
    }
  }

  handlecolor=(e)=>
  {
  this.setState((prev)=>{
    return {...prev,color:e.target.value}
  })
  }

  handletext=(e)=>
  {
   this.setState((prev)=>{
    return {...prev,text:e.target.value}
   })
  }

  render()
  {
    return(
        <div>
       {this.props.render(this.state.color,this.state.text,this.handlecolor,this.handletext)}
        </div>
    )
  }
}

export default Sample;