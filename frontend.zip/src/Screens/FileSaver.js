import { AES, enc } from 'crypto-js';
import { useState } from 'react';

function FileSaver()
{
const [confirmplan,setOpenconfirmCont]=useState(false);
const [alertplan,setConfirmPopupAlert]=useState(false);
const schdl=[];
const redirectToCapstan=true;
const save="Sample"

const savePlan = async e => {

          if (schdl.length === 0 && !redirectToCapstan) {
        
           alert('Please select Voyage');
        
          } else {
        
           if (save === 'globalSave') {
        
            setOpenconfirmCont(true);
        
           } else {
        
            // let body = getPlanDetails('Local Plan');
            let body=[{voyage:"DTX"},{voyage:"TTX"},{voyage:"AMD"},{voyage:"CHE"},{voyage:"TMX"}];
        
            const fileName = 'Plan';
            const encrypted_data=AES.encrypt(JSON.stringify(body),'SecretKey').toString();
            console.log("Encrypted",encrypted_data);

            
            //Decryption
            var bytes  = AES.decrypt(encrypted_data, 'SecretKey');
            var originalText = bytes.toString(enc.Utf8);
            console.log('orgtext',originalText);
        
            try {
            
             if ('showSaveFilePicker' in window) {
            //   // Use the showSaveFilePicker API if available
        
              const options = {
        
               suggestedName: 'Plan.json', // default file name
        
               types: [
        
                {
        
                 description: 'JSON file',
        
                 accept: {
        
                  'application/json': ['.json'],
        
                 },
        
                },
        
               ],
        
              };
        
              const handle = await window.showSaveFilePicker(options);
        
              const writable = await handle.createWritable();
        
              await writable.write(encrypted_data); //write data into file
        
              await writable.close();
        
            } else {
        
            //   // Use the download attribute on an anchor tag to initiate the download
        
              const blob = new Blob([encrypted_data], { type: 'application/json' });
              console.log(blob)
              const url = await URL.createObjectURL(blob);
        
              const link = document.createElement('a');
        
              link.download = fileName + '.json';
        
              link.href = url;
        
              document.body.appendChild(link);
        
              link.click();
        
              document.body.removeChild(link);
        
             }
                
            } catch (err) {
        
             console.error('Failed to save file:', err);
        
            }
    
            setConfirmPopupAlert(true);
        
            // dispatch(closePanel('SPN')); //the popup closed (when we click save button)
        
            if (redirectToCapstan) {
        
            //  openSelectedScenario()
        
            }
        
           }
        
          }
        
};

// const object={};
// object.id=1;
// object.name="sam";
// object.mobile=06
// console.log(object)

    return(
        <>
        <header>
            <h1>FileSaver</h1>
        </header>
        <button onClick={()=>savePlan()}>File Saver</button>
        <a href="https://jsonplaceholder.typicode.com/users" download="Plan.json">Download</a>
        </>
    )
}

export default FileSaver;