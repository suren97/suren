import { useEffect, useState, useRef} from "react";


function Hooks_Rev()
{
const [text,setext]=useState();
const [name,setname]=useState();
const [samp,setsamp]=useState();
const ref_name=useRef(null);

useEffect(()=>
{
  console.log(text);
  console.log(name);
},[text,name]);

const handleinput=()=>
{
    console.log("values");
    ref_name.current.value="suren_warrior";
    console.log(ref_name.current.value)
}

return(
    <div>
    <h1>Hooks_Revised</h1>
    <label>Name:</label>
    <input type="text" onChange={(e)=>setext(e.target.value)} />
    <label>Username:</label>
    <input type="text" onChange={(e)=>handleinput(e.target.value)} ref={ref_name} />
    <label>Password:</label>
    <input type="password" onChange={(e)=>setsamp(e)} />
    <button onClick={()=>handleinput()}>Click</button>
    </div>
)
}
export default Hooks_Rev;