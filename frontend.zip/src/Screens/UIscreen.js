import { useDispatch, useSelector } from "react-redux";
import  Adduser  from "../Redux/Action";
import {useState} from "react";

function UIscreen()
{
const [input,setinput]=useState("");
const users=useSelector((state)=>{return state});
const dispatch=useDispatch();
const handleinp=()=>
{
setinput("");
}
return(
    <div>
    <header>
    <h1>Adding List</h1>
    </header>
    <div className="flexcontainer">
        <div className="left">
        <h1>FirstPanel</h1>
        <label>Username:</label>
    <input type="text" value={input} onChange={(e)=>setinput(e.target.value)} />
    <button type="button" style={{padding:5,margin:8}} 
    onClick={()=>dispatch(Adduser(input),handleinp())}
    >
    Add
    </button>
        </div>
        <div className="right">
        <h1>SecondPanel</h1>
        <div>
    {users && users.userlist.map((v,i)=>
    {
      return <p>{v}</p>;
    })}
    </div>
        </div>
    </div>
    </div>
)
}
export default UIscreen;