import { useDispatch, useSelector } from "react-redux";
import  Adduser  from "../Redux/Action";
import {useState} from "react";

function User_redux()
{
const [input,setinput]=useState("");
const users=useSelector((state)=>{return state});
const dispatch=useDispatch();
const handleinp=()=>
{
setinput("");
}
return(
    <div>
    <header>
    <h1>Adding UserList using Redux</h1>
    </header>
    <div className="userclass">
    <label>Username:</label>
    <input type="text" value={input} onChange={(e)=>setinput(e.target.value)} />
    <button type="button" style={{padding:5,margin:8}} 
    onClick={()=>dispatch(Adduser(input),handleinp())}
    >
    Add
    </button>
    <br></br>
    <div>
    {users && users.userlist.map((v,i)=>
    {
      return <p>{v}</p>;
    })}
    </div>
    </div>
    </div>
)
}
export default User_redux;