import { useEffect, useRef, useState } from "react";

function Funtimer()
{
const [timer,settimer]=useState(0);
let timeref=useRef();

useEffect(()=>
{
  timeref.current=setInterval(()=>
  {
    settimer(timer+1);
  },1000)
},[timer]);

let clear=()=>
{
clearInterval(timeref.current);
}

return(
    <div>
    <h1>Function Timer</h1>
    {/* {timer} */}
    <button type="button" onClick={()=>clear()}>Count</button>
    </div>
)
}

export default Funtimer;