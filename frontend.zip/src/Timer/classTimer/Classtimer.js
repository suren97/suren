import React,{ Component } from "react";

class Classtimer extends Component
{ 
interval
constructor(props)
{
   super(props)
   this.state={
     count:0
    }
}

componentDidMount()
{
 this.interval=setInterval(()=>{
  this.setState((prev)=>
  {
    return {...prev,count:prev.count +1}
  })
 },1000)
}

componentWillUnmount()
{
  clearInterval(this.interval)
}

render()
{
    return(
        <div>
            <h2>Class Timer</h2>
            <h3>{this.state.count}</h3>
            <button type="button" onClick={()=>clearInterval(this.interval)}>Clear</button>
        </div>
    )
}
}

export default Classtimer;