import Sample from "./Screens/Sample";
import Move from "./Screens/Move";
import Single_Group from "./Screens/GroupPivot/Single_Group";
import Multi_Group from "./Screens/GroupPivot/Multiple_Group";
import Rowgroup_Panel from "./Screens/GroupPivot/Rowgroup_Panel";
import Group_Rows from "./Screens/GroupPivot/Group_Rows";
import GroupOrder from "./Screens/GroupPivot/GroupOrder";
import StickyGroup from "./Screens/GroupPivot/StickyGroup";
import SortingGroup from "./Screens/GroupPivot/SortingGroup";
import Forms from "./Screens/Forms/Forms";
import PanelClass from "./Screens/Editor/Cell_Editors";
import GridLayout from "./Screens/Layouts/Gridlayout";
import Column_State from "./Screens/ColumnState/Columns";
import Column_Menu from "./Screens/ColumnState/Column_Menu";
import CheckBox from "./Screens/CheckBox/ClassCheckBox";
import HeaderMenu from "./Screens/HeaderMenu/HeaderMenu";
import Schedule from "./Screens/Schedule/Schedule";


function App() {
  return (
    <div className="App">
      <Schedule />
      {/* <HeaderMenu /> */}
      {/* <CheckBox /> */}
      {/* <Column_Menu /> */}
      {/* <Column_State /> */}
      {/* <GridLayout /> */}
      {/* <PanelClass /> */}
    {/* <Sample /> */}
    {/* <Row_Grouping /> */}
    {/* <Single_Group /> */}
    {/* <Multi_Group /> */}
    {/* <Rowgroup_Panel /> */}
    {/* <Group_Rows /> */}
    {/* <GroupOrder /> */}
    {/* <StickyGroup /> */}
    {/* <SortingGroup /> */}
    {/* <Forms /> */}
    </div>
  );
}

export default App;
