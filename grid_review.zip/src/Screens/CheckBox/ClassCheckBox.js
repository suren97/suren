import React,{Component, createRef} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import PortColumnDefs  from "./PortColumnDefs";
import { Button } from "@mui/material";

class CheckBox extends Component {
  constructor(props) {
    super(props);
    this.state = {
      GridApi:createRef(null),
      checkbox: true,
    //   columnDefs:portColumnDefs(this.state.checkbox),
      rowdata: [],
      gridOptions: {
        columnDefs: [],
      },
      defaultColDef: {
        flex: 1,
      },
    };
  }

  componentDidMount() {
    let data = [
      { make: "Toyota", model: "Celica", price: 35000 },
      { make: "Ford", model: "Mondeo", price: 32000 },
      { make: "Porsche", model: "Boxster", price: 72000 },
    ];
    this.setState({ rowdata: data });
  }

  AddRow() {
    console.log("AddRow");
    let data=[{make:"Hyundai"}]
    this.state.GridApi.current.api.applyTransaction({add:data,addIndex:0});
    this.setState({checkbox:false})
  }

  SaveRow(){
    this.setState({checkbox:true})
  }

  render() {
    return (
      <>
        <header>
          <h1>Class CheckBox</h1>
        </header>
        <Button variant="contained" sx={{ m: 2 }} onClick={() => this.AddRow()}>
          Add
        </Button>
        <Button variant="contained" onClick={()=>this.SaveRow()}>Save</Button>
        <div
          className="ag-theme-alpine"
          style={{
            width: "88%",
            marginLeft: "5%",
            marginTop: "3%",
            height: 400,
          }}
        >
          <AgGridReact
            ref={this.state.GridApi}
            columnDefs={PortColumnDefs(this.state.checkbox)}
            rowData={this.state.rowdata}
            defaultColDef={this.state.defaultColDef}
          />
        </div>
      </>
    );
  }
}

export default CheckBox;