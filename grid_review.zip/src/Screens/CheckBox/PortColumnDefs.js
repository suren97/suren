const PortColumnDefs=(checkbox)=>
{
    return[
        {
        field:"",
        checkboxSelection:params=>
        {
            return checkbox
        }
        // checkboxSelection:params=>{
        //     console.log(params)
        // }
    },
    {
        field:"make"
    },
    {
        field:"model"
    },
    {
        field:"price"
    }
    ]
}

export default PortColumnDefs;