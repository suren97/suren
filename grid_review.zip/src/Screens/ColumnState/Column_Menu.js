import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useEffect, useState } from "react";

function Column_Menu()
{
    const [columnDef,setcolumn]=useState([
        {
            field:"athlete"
        },
        {
            field:"age"
        },
        {
            field:"country"
        },
        {
            field:"sport"
        },
        {
            field:"total"
        }
    ]);
    const [rowdata,setrow]=useState();

    useEffect(()=>
    {
      fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
      .then((response)=>response.json())
    },[])

    return(
        <>
        <header>
            <h1>Column - Menu</h1>
        </header>
        <div className="ag-theme-alpine" style={{height:400,marginTop:"5%"}}>
         <AgGridReact
         columnDefs={columnDef} 
         rowData={rowdata}
         />
        </div>
        </>
    )
}

export default Column_Menu;