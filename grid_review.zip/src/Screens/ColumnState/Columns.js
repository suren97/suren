import React,{Component, useEffect,useState,useRef,useCallback} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";

function Column_State()
{
const [rowdata,setrow]=useState();
const GridRef=useRef();
const [columnDefs,setcolumn]=useState([
    {
        field:"name"
    },
    {
        field:"username"
    },
    {
        field:"email"
    },
    {
        headerName:"Street",
        field:"address.street"
    }
]);

const defaultColDefs=({
    flex:1,
    sortable:true
})

useEffect(()=>
{
  axios.get("https://jsonplaceholder.typicode.com/users")
  .then((response)=>{
    setrow(response.data)
  })
},[])

let SaveState=()=>
{
    console.log("Columns Save State");
    window.colState=GridRef.current.columnApi.getColumnState();
}

let restoreState=useCallback(()=>
{
    if (!window.colState) {
        console.log('no columns state to restore by, you must save state first');
        return;
      }
      GridRef.current.columnApi.applyColumnState({
        state: window.colState,
        applyOrder: true,
      });
      console.log('column state restored');
},[])

const resetState = useCallback(() => {
    GridRef.current.columnApi.resetColumnState();
    console.log('column state reset');
  }, []);

return(
    <>
    <div>
        <header>
            <h1>Column_State</h1>
        </header>
    </div>
    <button onClick={()=>SaveState()}>Save State</button>
    <button onClick={()=>restoreState()}>Restore State</button>
    <button onClick={()=>resetState()}>Reset State</button>
    <div className="ag-theme-alpine tablecontainer">
       <AgGridReact 
       ref={GridRef}
       columnDefs={columnDefs}
       rowData={rowdata}
       defaultColDef={defaultColDefs}
       />
    </div>
    </>
)
}

export default Column_State;