import { Snackbar,Alert } from "@mui/material";

const SnackAlert=(props)=>
{
    const vertical=props.vertical;
    const horizontal=props.horizontal;
    return(
    <Snackbar 
    anchorOrigin={{vertical,horizontal}}
    open={props.open}
    onClose={props.onClose}
    autoHideDuration={3000}
    >
      <Alert variant="standard" severity={props.color} onClose={props.onClose}>{props.message}</Alert>
    </Snackbar>
    )
}

export default SnackAlert;