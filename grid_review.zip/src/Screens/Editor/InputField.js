import { forwardRef, useImperativeHandle, useState } from "react";

const InputField = forwardRef((props, ref) => {
  let column = props.colDef.field;

  const [value, setvalue] = useState({
    portcode:props.data.portcode,
    portname:props.data.portname,
    portcolor:props.data.portcolor,
    shortcode:props.data.shortcode,
    portbapile:props.data.portbapile,
  });

  useImperativeHandle(ref, () => {
    return {
      getValue() {
        // console.log(value)
        return value[column];
      },
    };
  });

  let handleinput = (e) => {
    setvalue({ ...value, [column]: e.target.value });
  };

  return (
    <input
      type="text"
      name={props.colDef.field}
      value={value[column]}
      onChange={(e) => handleinput(e)}
    />
  );
})

export default InputField;
