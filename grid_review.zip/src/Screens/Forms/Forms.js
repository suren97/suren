import React, { useCallback, useEffect, useMemo, useState } from 'react';
import useDebounce from './useDebounce';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import {Data} from "./Data";
import axios from "axios";


function SearchBar() {
  const [searchTerm, setSearchTerm] = useState();
  const debouncedSearchTerm = useDebounce(searchTerm, 1000);
  const [data,setdata]=useState(Data);
  const [columnDefs,setcolumn]=useState([
    {field:"name"},
    {field:"username"},
    {field:"email"}
  ])
  const defaultColDef=({
    flex:1
  })

useEffect(()=>
{
  let timer=setTimeout(()=>
    {
        if(searchTerm)
        {
            console.log("rendering");
           Data.filter((v,i)=>
           {
               if(v.name.toLowerCase().includes(searchTerm.toLowerCase()))
               {
                   setdata([v])
               }
           })
        }
    },1000);

    return ()=>
    {
     clearTimeout(timer)
    }

},[searchTerm])

// useEffect(()=>
// {
//  console.log("rendering")
// },[searchTerm])


function handleSearch(e)
{
    let value=e.target.value;
    setSearchTerm(value)
    // Data.filter((v,i)=>
    // {
    //     if(v.name.toLowerCase().includes(value.toLowerCase()))
    //     {
    //         setdata([v])
    //     }
    // })
}

return (
    <>
    <label>Search</label>
    <input
      type="text"
      onChange={(e)=>handleSearch(e)}
    //   onChange={(e) => setSearchTerm(e.target.value)}
    />
    {/* {debouncedSearchTerm} */}
    <div className='ag-theme-alpine tablecontainer'>
      <AgGridReact 
      rowData={data}
      columnDefs={columnDefs}
      defaultColDef={defaultColDef}
      />
    </div>
    </>
  );
}


export default SearchBar;