import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";

class Group_Rows extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
          rowdata:[],
          columnDefs:[
            {field:"athlete",rowGroup:true},
            {field:"country",rowGroup:true},
            {field:"age"},
            {field:"sport"},
            {field:"total"}
          ],
          defaultColDef:({
            flex:1,
            sortable:true,
            filter:true
          })
        }
    }

componentDidMount()
{
  fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>response.json())
  .then((data)=>{
    this.setState({rowdata:data})
  })
}  

render()
{
    return(
        <div>
            <header>
                <h1>AgGrid - RowGroup</h1>
            </header>
            <div className="ag-theme-alpine tablecontainer">
                <AgGridReact 
                rowData={this.state.rowdata}
                columnDefs={this.state.columnDefs}
                defaultColDef={this.state.defaultColDef}
                groupDisplayType="groupRows"
                />
            </div>
        </div>
    )
}
}

export default Group_Rows;