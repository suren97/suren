import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";

//Topics
//Enabling MultiGroup Columns

class Multi_Group extends Component
{
constructor(props)
{
    super(props)
    this.state={
        rowdata:[],
        columnDefs:[
            // {field:"country",rowGroup:true,hide:true},
            // {field:"age",rowGroup:true,hide:true},
            {field:"country",rowGroup:true},
            {field:"age",rowGroup:true},
            {field:"sport",rowGroup:true},
            {field:"year"},
            {field:"total"}
        ],
        defaultColDef:({
            flex:1
        }),
    }
}

componentDidMount()
{
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>response.json())
    .then((data)=>{
        data.length=20
        this.setState({rowdata:data})
    })
}

render()
{
    return(
            <div>
                <header>
                    <h1>AgGrid - MultiGroupColumns</h1>
                </header>
                <div className="ag-theme-alpine tablecontainer">
                    <AgGridReact 
                    rowData={this.state.rowdata}
                    columnDefs={this.state.columnDefs}
                    defaultColDef={this.state.defaultColDef}
                    groupDisplayType="multipleColumns"
                    />
                </div>
            </div>
        )
    }
}

export default Multi_Group;