import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";

//Topics
//Enable Row Grouping -> Line 18 and 49
//Keeping Columns Visible-> Line 54

class Rowgroup_Panel extends Component
{
constructor(props)
{
    super(props)
    this.state={
       rowdata:[],
       columnDefs:[
        {field:"country",enableRowGroup:true},
        {field:"athlete"},
        {field:"age",enableRowGroup:true},
        {field:"sport"},
        {field:"year"},
        {field:"total"}
       ],
       defaultColDef:({
         flex:1,
         sortable:true
       })
    }
}

componentDidMount()
{
  fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>response.json())
  .then((data)=>{this.setState({rowdata:data})})
}

render()
{
    return(
        <div>
            <header>
                <h1>AG-Grid RowGroup_Panel</h1>
            </header>
            <div className="ag-theme-alpine tablecontainer">
               <AgGridReact 
               rowData={this.state.rowdata}
               columnDefs={this.state.columnDefs}
               defaultColDef={this.state.defaultColDef}
               rowGroupPanelShow={"always"}
               rowGroupPanelSuppressSort={true}
               suppressDragLeaveHidesColumns={true}
               suppressMakeColumnVisibleAfterUnGroup={true}
               suppressRowGroupHidesColumns={true}
               />
            </div>
        </div>
    )
}
}

export default Rowgroup_Panel;


