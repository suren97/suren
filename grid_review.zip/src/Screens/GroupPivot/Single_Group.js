import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";

//Topics
//Enabling single group -->Line 59
//Group column Config --> Line 28
//Showing Open Groups --> Line 63
//Adding values to Leaf node -->

class Single_Group extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            rowdata:[],
            columnDefs:[
                // {field:"country",rowGroup:true,hide:true},
                // {field:"age",rowGroup:true,hide:true},
                {field:"country",rowGroup:true},
                {field:"age"},
                {field:"sport"},
                {field:"year"},
                {field:"total"}
            ],
            defaultColDef:({
                flex:1
            }),
            GridApi:"",
            //Group column configuration
            autoGroupColDef:({
                headerName:"Groupping Column",
                minWidth:220,
                cellRendererParams:{
                    // suppressCount:true,
                    // checkbox:true
                }
            })
        }
    }

componentDidMount()
{
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>response.json())
    .then((data)=>{
        data.length=10
        this.setState({rowdata:data})
    })
}
    
ChangeSelection()
{
    this.state.GridApi.setGroupRemoveSingleChildren(true)
}

onGridReady(params)
{
    this.setState({GridApi:params.api})
}

ChangeRemove()
{
    this.state.GridApi.setGroupRemoveLowestSingleChildren(true)
}

Normalfun()
{
    this.state.GridApi.setGroupRemoveSingleChildren(false);
    this.state.GridApi.setGroupRemoveLowestSingleChildren(false);
}

render()
{
    return(
        <div>
            <header>
                <h1>AgGrid - SingleGroup</h1>
            </header>
            <button onClick={()=>this.Normalfun()}>Set Normal</button>
            <button onClick={()=>this.ChangeSelection()}>Remove Single Children</button>
            <button onClick={()=>this.ChangeRemove()}>Remove Lowest Single Children</button>
            <div className="ag-theme-alpine tablecontainer">
                <AgGridReact 
                rowData={this.state.rowdata}
                columnDefs={this.state.columnDefs}
                defaultColDef={this.state.defaultColDef}
                autoGroupColumnDef={this.state.autoGroupColDef}
                groupDisplayType="singleColumn"
                showOpenedGroup={true}
                animateRows={true}
                onGridReady={(p)=>this.onGridReady(p)}
                />
            </div>
        </div>
    )
}
}

export default Single_Group;