import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";

class SortingGroup extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
          rowdata:[],
          columnDefs:[
            {field:"country",rowGroup:true},
            {field:"athlete",rowGroup:true},
            {field:"age"},
            {field:"total"}
          ],
          defaultColDef:({
            flex:1,
            sortable:true
          }),
          obj:{id:1,name:"suren"}
        }
    }

 componentDidMount()
 {
  const {obj}=this.state;

  this.setState((prev)=>
  {
    return {prev,obj:{...obj,age:26}}
  })
  // this.setState({obj:{obj,age:26}})
    // fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
    // .then((response)=>response.json())
    // .then((data)=>{this.setState({rowdata:data})})
 }  

 onRowClicked(params)
 {
    console.log(params.event)
    // params.event.isTrusted
    // params.event.isTrusted=false
 }

render()
{
  console.log(this.state.obj);
        return(
            <div>
                <header>
                    <h1>Sorting Group</h1>
                </header>
                <div className="ag-theme-alpine tablecontainer">
                  <AgGridReact 
                  rowData={this.state.rowdata}
                  columnDefs={this.state.columnDefs}
                  defaultColDef={this.state.defaultColDef}
                  groupDisplayType="multipleColumns"
                  onRowClicked={this.onRowClicked}
                  />
                </div>
            </div>
        )
}

}

export default SortingGroup;