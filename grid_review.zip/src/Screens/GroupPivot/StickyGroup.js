import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";

class StickyGroup extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            rowdata:[],
            columnDefs:[
                {field:"athlete"},
                {field:"country",rowGroup:true},
                {field:"age",rowGroup:true},
                {field:"sport"},
                {field:"total"}
            ],
            defaultColDefs:({
                flex:1,
                sortable:true,
                filter:true
            })
        }
    }

componentDidMount()
{
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>response.json())
    .then((data)=>{
      this.setState({rowdata:data})
    })
}

    render()
    {
        return(
            <div>
                <header>
                    <h1>AgGrid - StickyGroup</h1>
                </header>
                <div className="ag-theme-alpine tablecontainer">
                   <AgGridReact 
                   rowData={this.state.rowdata}
                   columnDefs={this.state.columnDefs}
                   defaultColDef={this.state.defaultColDefs}
                //    groupDisplayType="groupRows"
                //    groupRowsSticky={true}
                   />
                </div>
            </div>
        )
    }
}

export default StickyGroup;