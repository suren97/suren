import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { AgGridReact } from "ag-grid-react";
import { useEffect, useState } from "react";

function HeaderMenu() {
  const [columnDefs,setcolumn]=useState([
    {field:"year"},
    {field:"athlete"},
    {field:"sport"},
    {field:"country"},
  ]);
  const [rowdata,setrow]=useState();

  const defaultColDef=({
    flex:1
  })

  let onGridReady=()=>
  {
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>response.json())
    .then((response)=>{
        response.length=20
       setrow(response)
     })
  }

  useEffect(()=>
  { 
     let paraelem=document.getElementById("para");
     console.log(paraelem.style.color)
  },[])

  return (
    <>
      <div>
        <header>
          <h1>AgGrid - HeaderMenu</h1>
        </header>
      </div>
      <div style={{backgroundColor:"red"}}>
        <p id="para" style={{color:"white",mixBlendMode:"difference"}}>Tesxtvwdhw</p>
      </div>
      <div
        className="ag-theme-alpine"
        style={{ margin: "5% auto", width: "98%", height: 400 }}
      >
        <AgGridReact
          columnDefs={columnDefs}
          rowData={rowdata}
          defaultColDef={defaultColDef}
          onGridReady={onGridReady}
        />
      </div>
    </>
  );
}

export default HeaderMenu;
