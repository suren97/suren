import { AgGridReact } from "ag-grid-react";
import React,{Component} from "react";

class GridLayout extends Component
{
constructor(props)
{
    super(props)
    this.state={
     GridRef:React.createRef(),
     rowdata:[],
     columnDefs:[
        {field:"athlete"},
        {field:"country"},
        {field:"age"},
        {field:"sport"},
        {field:"date"},
        {field:"total"}
     ],
     defaultColDef:({
        flex:1,
        sortable:true,
        editable:true
     })   
    }
}

componentDidMount()
{
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>response.json())
    .then((data)=>{
      this.setState({rowdata:data})
    })
}

Add()
{
    let data={id:""}
    this.state.GridRef.current.api.applyTransaction({add:[data],addIndex:0});
    this.state.GridRef.current.api.redrawRows();
}

render()
    {
        console.log("render");
        return(
            <div>
                <header>
                    <h1>AgGrid - GridLayout</h1>
                </header>
                <button onClick={()=>this.Add()}>Add</button>
                <div className="ag-theme-alpine tablecontainer">
                    <AgGridReact 
                    disabled
                    ref={this.state.GridRef}
                    rowData={this.state.rowdata}
                    columnDefs={this.state.columnDefs}
                    defaultColDef={this.state.defaultColDef}
                    suppressContextMenu={true}
                    />
                </div>
            </div>
        )
    }
}

export default GridLayout;