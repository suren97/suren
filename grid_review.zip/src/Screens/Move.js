function Move()
{
    return(
        <h1>Move Grid</h1>
    )
}

export default Move;