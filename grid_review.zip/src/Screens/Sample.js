import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import React,{Component} from 'react';
import Move from "./Move";

//document.addEventListener("DOMContentLoaded",ready);

window.onbeforeunload=function(){
    alert("There are unsaved changes.Leave now?");
}

class Sample extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            rowdata:[],
            columnDefs:[
                {field:"id"},
                {field:"name"},
                {field:"username"},
                {field:"email"}
            ],
            defaultColDef:({
                flex:1
            })
        }
    }

    componentDidMount()
    {
        fetch("https://jsonplaceholder.typicode.com/users")
        .then((response)=>response.json())
        .then((data)=>
        {
            this.setState({rowdata:data})
        })
    }

   Move()
   {
     return(
        <Move />
     )
   }

    render()
    {
        return(
            <div>
                <header>
                    <h1>Sample Grid</h1>
                </header>
                <div className="ag-theme-alpine" style={{height:300}}>
                <AgGridReact 
                rowData={this.state.rowdata}
                columnDefs={this.state.columnDefs}
                defaultColDef={this.state.defaultColDef}
                />
                </div>
                <button onClick={()=>this.Move()}>Mpove</button>
            </div>
        )
    }
}

export default Sample;