import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useState,useEffect } from "react";
import * as XLSX from "xlsx";
import { render } from "@testing-library/react";

function Schedule() {
   const [rowdata,setrow]=useState();
   const [html,sethtml]=useState();
   const [columnDef,setcolumn]=useState([
         {field:"make"},
         {field:"model"},
         {field:"price"}
   ]);
   const defaultColDef=({
        flex:1
   })

   useEffect(()=>{
       
   },[]);

   let ImportExcel=async()=>{
       let Files = await window.showOpenFilePicker();
       let excel=await Files[0].getFile();
       const blobfile = new Blob([excel], {
         type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
       });
       const buffarr=await blobfile.arrayBuffer();
       const workbook = XLSX.read(buffarr);
       const worksheet=workbook.Sheets[workbook.SheetNames[0]];
       const rowjsondata=XLSX.utils.sheet_to_json(worksheet,{
        header:2    
       });
       console.log(rowjsondata);
   }

  return (
    <>
      <div>
        <header>
          <h1>Schedule Master</h1>
        </header>
      </div>
      <button onClick={()=>ImportExcel()}>Import Excel</button>
      <div className="ag-theme-alpine" style={{margin:"5% auto",width:"97%",height:300}}>
          <AgGridReact 
          columnDefs={columnDef}
          defaultColDef={defaultColDef}
          rowData={rowdata}
          />
      </div>
    </>
  );
}

export default Schedule;
