import {BrowserRouter,Routes,Route} from "react-router-dom"; 
import Panel_Grid from "./JSPanel_AgGrid/JSPanel_Grid";
import Home from "./JSPanel_AgGrid/Home";
import Forms from "./JSPanel_AgGrid/Forms";
import View_user from "./JSPanel_AgGrid/View_user";
import { Provider } from "react-redux";
import Store from "./Redux/Store";
import Sample from "./Sample_panel/Sample";

function App() {
  return (
    <div>
   <BrowserRouter>
   <Provider store={Store}>
   <Routes>
       <Route path="/" element={<Panel_Grid/> } /> 
       <Route path="/home" element={<Home />} />
       <Route path="/view" element={<View_user />} />
       <Route path="/forms" element={<Forms />}/>
   </Routes>
   </Provider>
   </BrowserRouter>
   </div>
  )
}

export default App;
