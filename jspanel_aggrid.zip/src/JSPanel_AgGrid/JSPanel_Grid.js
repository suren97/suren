import {AgGridReact} from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import { jsPanel } from "jspanel4";

function JSPanel_Grid()
{
const Open_panel=()=>
{
   jsPanel.create({
    headerTitle:"AG-Grid Panel",
    theme:"teal500",
    headerToolbar:"HomePage",
    callback:(panel=>{
        let header=panel.headertoolbar;
        header.style.padding="10px";
        header.style.backgroundColor="#DCEDC8";
        header.style.color="black";
        header.style.fontSize="18px"
    }),
    contentOverflow: 'hidden',
    content:panel=>
    {
      let frame=document.createElement("iframe");
      frame.src="http://localhost:3001/home";
      frame.style.width="100%";
      frame.style.height="100%";
      frame.style.border="none";
      panel.content.appendChild(frame);
    }
   }).maximize();
}

return(
        <div>
        <header>
            <h1>JSPanel_AgGrid</h1>
        </header>
        <div className="container">
            <div className="content">
                <div className="regcont">
                   <div onClick={Open_panel()}>Open panel</div>
                </div>
            </div>
        </div>
        </div>
    )
}

export default JSPanel_Grid;