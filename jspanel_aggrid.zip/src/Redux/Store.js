import { configureStore } from "@reduxjs/toolkit";
import { userReducer } from "./Action";

const Store=configureStore({
    reducer:{
        userdata:userReducer
    }
});

export default Store;
