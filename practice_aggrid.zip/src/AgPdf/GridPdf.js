import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useEffect, useState, useRef } from "react";
import axios from "axios";
import { Button } from "@mui/material";
import jsPDF from "jspdf";
import "jspdf-autotable";
import FileSaver from "file-saver";

function GridPdf() {
  const GridRef = useRef();
  const [rowdata, setrow] = useState();
  const [columnDef, setcolumn] = useState([
    {
      field: "athlete",
      headerCellRenderer: function (params) {
        return (
          '<div style="text-align: center;">' + params.displayName + "</div>"
        );
      },
    },
    {
      field: "age",
      headerCellRenderer: function (params) {
        return (
          '<div style="text-align: center;">' + params.displayName + "</div>"
        );
      },
    },
    { field: "sport" },
    { field: "date" },
    { field: "year" },
    { field: "bronze" },
    { field: "silver" },
    { field: "gold" },
    { field: "total" },
  ]);
  const defaultColdef = {
    sortable: true,
    flex: 1,
  };

  useEffect(() => {
    axios
      .get("https://www.ag-grid.com/example-assets/olympic-winners.json")
      .then((response) => {
        response.data.length = 50;
        setrow(response.data);
      });
  }, []);

    let Generate = () => {
      const users = [
        { fname: "Michael", lname: "L", age: 25 },
        { fname: "Philips", lname: "M", age: 20 },
        { fname: "William", lname: "S", age: 25 },
        { fname: "martin", lname: "L", age: 50 },
        { fname: "martin", lname: "L", age: 50 },
      ];
      let output = users.reduce((prev, curt) => {
        prev.push(curt);
        return prev;
      }, []);
    };

  let Exportpdf =async () => {
    const doc = new jsPDF();

    const bodyStyles = {
      textColor: "#000",
      lineColor: "#000",
      lineWidth: 0.2,
      cellWidth:"auto",
    };
    const headStyles = {
      fontStyle: "bold",
      halign:"left",
      cellPadding:1,
      cellWidth:"auto"
    };

    doc.setFontSize(12);
    doc.text("SAMPLE PDF", 90, 10);

    doc.autoTable({
      theme: "grid",
      head: [],
      body: [
        ['Vessel:Toranto',"Date:2022"],
        ["Voyage:Vishak","Terminal:Nicobar"],
        ["Service:ST1","Bound:1"]
      ],
      startY:30,
      margin:10,
      bodyStyles
    });
    doc.line(10,58,200,58);
    let pdfdata=rowdata.reduce((acc,curt)=>{ 
      acc.push(Object.values(curt)) 
      return acc  
    },[]);

    doc.autoTable({
      theme: "plain",
      head: [
        [
          "Athlete",
          "Age",
          "Country",
          "Year",
          "Date",
          "Sport",
          "Bronze",
          "Silver",
          "Gold",
          "Total",
        ],
      ],
      body: [...pdfdata],
      bodyStyles: bodyStyles,
      headStyles: headStyles,
      didParseCell: function (data) {
        if (data.row.raw.includes(2008)) {
          data.cell.styles.fontStyle = "bold";
          data.cell.styles.fillColor = [25, 118, 210];
          data.cell.styles.textColor="white"
        }
      },
      margin:10,
  });

  const PdfArrBuffer=doc.output("arraybuffer");

  const options = {
    suggestedName: "ExportPdf", // default file name

    types: [
      {
        description: "PDF file",

        accept: {
          "application/pdf": [".pdf"],
        },
      },
    ],
  };

  const handle = await window.showSaveFilePicker(options);
  const writable = await handle.createWritable();
  await writable.write(new Blob([PdfArrBuffer], { type: "application/pdf" })); //write data into file
  await writable.close();
};

    // let Exportpdf = () => {
    //   const doc = new jsPDF();
    //   //Rows
    //   let rows = GridRef.current.props.rowData;
    //   console.log(rows)

    //   //Columns
    //   let getcols = GridRef.current.api.columnModel.displayedColumns;
    //   let tablecols = [];
    //   getcols.map((v) => {
    //     tablecols.push({
    //       header: v.colId.charAt(0).toUpperCase() + v.colId.slice(1),
    //       dataKey: v.colId,
    //     });
    //   });

    //   doc.autoTable({
    //     columns: tablecols,
    //     body: rows,
    //     bodyStyles: { fillColor: [255, 255, 255], cellWidth: "auto" },
    //     headStyles: {
    //       fillColor: [255, 255, 255],
    //       cellWidth: "auto",
    //       fontStyle: "bold",
    //       textColor: [0, 0, 0],
    //     },
    //   });
    //   // doc.save("Sample.pdf");
    // };

  return (
    <>
      <header>
        <h1>AgGrid - PDF</h1>
      </header>
      {/* <Button onClick={() => Generate()}>Generate</Button> */}
      <Button variant="contained" sx={{ m: 2 }} onClick={() => Exportpdf()}>
        Export PDF
      </Button>
      {/* <a href="#" download={"../Editing/Cell_Editing"}><Button variant="contained" sx={{m:2}}>Download AS PDF</Button></a> */}
      <div
        className="ag-theme-alpine"
        style={{ margin: "3% auto", height: 400 }}
      >
        <AgGridReact
          id="table"
          ref={GridRef}
          rowData={rowdata}
          columnDefs={columnDef}
          defaultColDef={defaultColdef}
        />
      </div>
    </>
  );
}

export default GridPdf;
