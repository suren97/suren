import { useEffect } from "react";

function PdfDownload()
{
return(
    <>
    <div>
        <header>
            <h1>PDF Download</h1>
        </header>
    </div>
    </>
)
}

export default PdfDownload;