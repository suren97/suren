import Ag_Grid from "./Practice_Grid/Ag_grid";
import CellRender_Component from "./Practice_Grid/CellRenderer";
import ParentInp from "./ForwardRef/ParentInp";
import Header_Comp from "./Practice_Grid/Header_Comp";
import Add_Remove from "./ColumnDefinition/Add_Remove";
import Update_Def from "./ColumnDefinition/Update_Def";
import ApplyTransaction from "./AsyncTransaction/Applytransaction";
import Grid_Events from "./Grid_Events/Grid_Events";
import Access_Data from "./Client-SideData/AccessingData/Access";
import Cell_Editing from "./Editing/Cell_Editing";
import GridPdf from "./AgPdf/GridPdf";
import PdfDownload from "./AgPdf/Pdfdownload";

function App() {
  return (
    <div>
      <PdfDownload />
      {/* <GridPdf /> */}
      {/* <Row_Select /> */}
      {/* // <Grid_Events />
      // <ApplyTransaction />
    // <Update_Def />
    // <Add_Remove />
    // <ParentInp />
    // <Header_Comp />
    // <CellRender_Component />
    // <Ag_Grid /> */}
      {/* <Cell_Editing /> */}
      {/* <GridPdf /> */}
    </div>
  );
}

export default App;
