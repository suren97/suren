import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useEffect,useState,useRef } from "react";
import axios from "axios";

function Access_Data()
{
const GridRef=useRef(null);
const [rowdata,setrow]=useState();
const [columndefs,setcolumn]=useState([
    {
        headerName:"SSHSSSSS SSSSSSSSSSSSSSS",
        field:"athlete",
        headerClass:"breakspace"
    },
    {
        field:"age",
        cellStyle:{color:"red",fontWeight:"bold"}
    },
    {
        field:"sport",
        cellClass:"cellcolor"
    },
    {
        field:"bronze",
        cellClassRules:{
            "cellcolor":p=>p.value < 4
        }
    },
    {field:"silver"},
    {field:"gold"},
    {field:"total"}
]);

const defaultColDef=({
    flex:1,
})

useEffect(()=>
{
 axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
 .then((response)=>{
    setrow(response.data)
 })
},[]);

let getRowId=p=>p.data.id;

let update=()=>
{
  const bronze=1+1;
  GridRef.current.api.forEachNode((node)=>
  {
    node.updateData({ ...node.data,bronze });
  })    
}

let onGridReady=params=>
{
    console.log(params)
}

let setcol=()=>
{ 
   let data={field:"date"};
   let oldcol=[];
   columndefs.forEach((cols)=>
   {
       oldcol.push(cols);
   })
   oldcol.unshift(data);
   GridRef.current.api.setColumnDefs(oldcol);
}

return(
   <div>
    <header>
        <h1>AgGrid - AccessRow</h1>
    </header>
    <button onClick={()=>setcol()}>Set Column</button>
    <button onClick={()=>update()}>Update Data</button>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:350,margin:"5% auto"}}>
       <AgGridReact 
        ref={GridRef}
        rowData={rowdata}
        columnDefs={columndefs} 
        defaultColDef={defaultColDef}
        animateRows={true}
        enableCellChangeFlash={true}
        onGridReady={onGridReady}
       />
    </div>
    </div>
    </div>
)
}
export default Access_Data;