import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";

function ClientSide()
{
return(
   <div>
    <div className="ag-theme-alpine">

    </div>
   </div>
)
}
export default ClientSide;