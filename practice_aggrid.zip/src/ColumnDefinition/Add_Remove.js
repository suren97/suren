import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useEffect,useState,useRef} from "react";
import axios from "axios";

function Add_Remove()
{
const GridRef=useRef(null);
const [rowdata,setrow]=useState();
const columnDefs=[
    {field:"athlete"},
    {field:"year"},
    {field:"sport"},
    {field:"date"},
    {field:"gold"},
    {field:"silver"},
    {field:"total"}
]

const excludeMedal=[
    {field:"athlete"},
    {field:"year"},
    {field:"sport"},
    {field:"date"}
];

const defaultColDef=({
    flex:1
})

useEffect(()=>
{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>
  {
    setrow(response.data)
  })
},[]);

let Excludebtn=()=>
{
  GridRef.current.api.setColumnDefs(excludeMedal);
}

let Includebtn=()=>
{
   GridRef.current.api.setColumnDefs(columnDefs); 
}

return(
    <div>
      <header>
        <h1>Add and Remove ColumnDefinition</h1>
      </header>
        <button onClick={()=>Excludebtn()}>Exclude Medal</button>
        <button onClick={()=>Includebtn()}>Include Medal</button>
        <div className="ag-theme-alpine" style={{height:400,margin:"5% auto"}}>
            <AgGridReact 
            ref={GridRef}
            rowData={rowdata}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            />
        </div>
    </div>
)
}

export default Add_Remove;