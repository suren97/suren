import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useRef,useState,useEffect, useCallback } from "react";
import axios from "axios";
import { useSelector,useDispatch } from "react-redux";
import { Productmaster } from "../Redux/Data";

function Update_Def()
{
const GridRef=useRef(null);
const [rowdata,setrow]=useState();
const getColumnDefs=()=>
{
    return[
        {field:"athlete"},
        {field:"year"},
        {field:"sport"},
        {field:"date"},
        {field:"gold"},
        {field:"silver"},
        {field:"total"}
    ]
}
const [columnDefs,setcolumn]=useState(getColumnDefs());

const defaultColDef=({
    flex:1
});

useEffect(()=>
{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>
  {
    setrow(response.data)
  })
},[]);

let setHeader=useCallback(()=>
{
  const colDef=getColumnDefs();
  colDef.forEach((v,i)=>
  {
    v.headerName=v.field+" "+i;
  })
  GridRef.current.api.setColumnDefs(colDef);
},[]);

let remHeader=useCallback(()=>
{
    const colDef=getColumnDefs();
    colDef.forEach((v,i)=>
    {
       v.headerName=undefined
    })
    GridRef.current.api.setColumnDefs(colDef);
},[]);

const setvalue=useCallback(()=>
{
  const colDef=getColumnDefs();
  colDef.forEach((val,ind)=>{
    val.valueFormatter=function(params){
        return '['+params.value+']';
    }
  })
  GridRef.current.api.setColumnDefs(colDef);
},[]);

const remvalue=useCallback(()=>
{
    const colDef=getColumnDefs();
    colDef.forEach((val,ind)=>{
       return val;
    })
  GridRef.current.api.setColumnDefs(colDef);
},[]);

return(
    <div>
        <header>
            <h1>Updating ColDef</h1>
        </header>
        <button onClick={()=>setHeader()}>setHeader Names</button>
        <button onClick={()=>remHeader()}>Remove header Name</button>
        <button onClick={()=>setvalue()}>Set valueformatters</button>
        <button onClick={()=>remvalue()}>Remove valueformatters</button>
        <div className="ag-theme-alpine" style={{height:300,margin:"5% auto"}}>
           <AgGridReact
           ref={GridRef}
           columnDefs={columnDefs}
           rowData={rowdata}
           defaultColDef={defaultColDef}
           maintainColumnOrder={true}
           />
        </div>
    </div>
)
}

export default Update_Def;