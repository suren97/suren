import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import axios from "axios";

class Cell_Editing extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
           GridRef:React.createRef(),
           rowdata:[],
           columnDefs:[
            {field:"athlete"},
            {field:"age"},
            {field:"country"},
            {field:"year"},
            {field:"sport"},
            {field:"gold"},
            {field:"bronze"},
            {field:"total"}
           ],
           defaultColDef:({
            flex:1,
            // editable:true
            //----Conditional Editing
            editable:params=>params.data.age > 23
           })
        }
    }

    componentDidMount()
    {
        axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
        .then((response)=>
        {
            this.setState({rowdata:response.data})
        })
        const elem=document.getElementById("def");
        console.log(elem)
    }

    onCellValueChanged(params)
    {
        console.log(params)
    }

    onCellEditingStarted(params)
    {
        console.log(params)
    }

    onCellEditingStopped(params)
    {
      console.log(params)
    }

    onRowEditingStarted(params)
    {
        console.log(params)
    }

    onRowEditingStopped(params)
    {
        console.log(params)
    }

    onCellClicked(params)
    {
      console.log(params)
    }

    Add()
    {
       this.state.rowdata.unshift({id:0});
    //    this.state.GridRef.current.api.applyTransaction({add:[data],addIndex:0})
       this.state.GridRef.current.api.setRowData(this.state.rowdata);
    //    let elem=document.querySelectorAll(".ag-row")
    //    elem.forEach((v,i)=>
    //    {
    //     if(i==0)
    //     {
    //         console.log(v)
    //        console.log(v.getAttribute("row-index"));
    //         v.style.pointerEvents="visible";
    //     }
    //     else
    //     {
    //      v.style.pointerEvents="none";
    //     }
    //    })
    }

    Close()
    {

    }

    render()
    {
        return(
            <div>
                <header>
                    <h1>AgGrid - CellEditing</h1>
                </header>
                <button onClick={()=>this.Add()}>Add</button>
                <button onClick={()=>this.Close()}>close</button>
                <div className="ag-theme-alpine" style={{height:"350px",width:"99.4%",margin:"7% auto"}}>
                <AgGridReact
                ref={this.state.GridRef}
                rowData={this.state.rowdata}
                columnDefs={this.state.columnDefs}
                defaultColDef={this.state.defaultColDef}
                // onCellClicked={this.onCellClicked}
                // editType="fullRow"
                // onCellValueChanged={this.onCellValueChanged}
                // onCellEditingStarted={this.onCellEditingStarted}
                // onCellEditingStopped={this.onCellEditingStopped}
                // onRowEditingStarted={this.onRowEditingStarted}
                // onRowEditingStopped={this.onRowEditingStopped}
                />
                </div>
            </div>
        )
    }
}

export default Cell_Editing;