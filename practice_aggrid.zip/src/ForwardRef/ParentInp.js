import ChildInp from "./ChildInp"
import { useRef } from "react";
import React,{Component} from "react";

function ParentInp()
{
const GridRef=useRef(null);
let clickhandler=()=>
{
   GridRef.current.focus();
}

return(
        <div>
            <ChildInp ref={GridRef} />
            <button onClick={()=>clickhandler()}>Focus</button>
        </div>
)
}

export default ParentInp;