import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import axios from "axios";
import { useEffect,useState,useRef,useMemo, useCallback } from "react";

function Grid_Events()
{
    const GridRef=useRef(null);
    const [rowdata,setrow]=useState();
    const columnDefs=[
        {
            field:"athlete",
            hide:true
        },
        {
            field:"year",
            hide:true
        },
        {field:"sport"},
        {field:"date"},
        {field:"gold"},
        {field:"silver"},
        {field:"total"}
    ];
    const defaultColDef=({
        flex:1,
        editable:true
    });
    useEffect(()=>
    {
      axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
      .then((response)=>
      {
        setrow(response.data)
      })
    },[]);

let setvisible=()=>
{
    GridRef.current.columnApi.setColumnsVisible(["athlete","year"],true);
}

let hidevisible=()=>
{
    GridRef.current.columnApi.setColumnsVisible(["athlete","year"],false);
}

let onGridReady=()=>
{
    GridRef.current.api.sizeColumnsToFit();
}

let onRowValueChanged=(p)=>
{
    console.log(p)
}

return(
    <div>
        <header>
            <h1>AG-Grid Events</h1>
        </header>
        <button onClick={()=>setvisible()}>SetColumnsVisible(athlete & year)</button>
        <button onClick={()=>hidevisible()}>HideColumns(athlete & year)</button>
        <div className="ag-theme-alpine" style={{height:400,margin:"7% auto"}}>
           <AgGridReact 
           ref={GridRef}
           rowData={rowdata}
           columnDefs={columnDefs}
           defaultColDef={defaultColDef}
           editType="fullRow"
        //    onGridReady={onGridReady}
           onRowValueChanged={onRowValueChanged}
           />
        </div>
    </div>
)
}

export default Grid_Events;