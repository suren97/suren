import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useEffect, useState, useRef} from "react";
import axios from "axios";

function Ag_Grid()
{
const [rowdata,setrow]=useState();
const gridRef=useRef(null);
const [columns,setcolumns]=useState([
  {field:"athlete"},
  {field:"country",rowGroup:true},
  {field:"sport"},
  {field:"year"},
  {field:"bronze"},
  {field:"silver"},
  {field:"gold"},
  {field:"total",aggFunc:'sum'}
]);

const defaultColDef=({
    flex:1,
    filter:true,
    sortable:true,
});

useEffect(()=>
{
    axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>
    {
        setrow(response.data)
    })
},[]);

const onRowSelected=(params)=>
{
  console.log(params.api.getSelectedRows());
}

const updategrid=()=>
{
    let updated=[];
    updated=gridRef.current.props.rowData.map((v,i)=>
    {
        if(v.bronze===0 || v.silver===0 || v.gold===0)
        {
            v.bronze=v.bronze + 1;
            v.silver=v.silver + 1;
            v.gold=v.gold +1;
        }
        return v;
    });
    gridRef.current.api.applyTransaction({update:updated})
}

return(
    <div>
        <header>
        <h1>Practice AG-Grid</h1>
        </header>
        <button onClick={()=>updategrid()}>Update Grid</button>
        <div className="ag-theme-alpine" style={{height:400}}>
        <AgGridReact
        ref={gridRef}
        rowData={rowdata}
        columnDefs={columns}
        defaultColDef={defaultColDef}
        rowSelection="multiple"
        enableCellChangeFlash={true}
        onRowSelected={onRowSelected}
        suppressAggFuncInHeader={true}
        />
        </div>
    </div>
 )
}

export default Ag_Grid