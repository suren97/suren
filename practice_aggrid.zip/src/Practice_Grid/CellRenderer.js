import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useEffect, useState, useRef} from "react";
import axios from "axios";
import { MenuItem, Select } from "@mui/material";

function CellRender_Component()
{
const [rowdata,setrow]=useState();
const [secdata,setsec]=useState([]);
const GridRef=useRef(null);
const [columnDef,setcolumn]=useState([
    {field:"id"},
    {field:"name"},
    {field:"username"},
    {field:"email"},
    {field:"action",editable:false}
]);
const defaultColDef=({
    sortable:true,
    flex:1,
    editable:true,
    cellRenderer:p=>getCell(p),
    getRowId:p=>{
      return p.data.id;
    }
});

const getCell=p=>
{
  if(p.colDef.field=="action")
  {
    return <button onClick={()=>Editbtn(p)}>Edit</button>
  }
  else
  {
  return p.value;
  }
}

const Editbtn=(p)=>
{
  console.log("Edit..");
  var rowNode = GridRef.current.api.getRowNode(p.rowIndex);
  let data={id:p.rowIndex+1,name:getSelect(),username:getSelect2()};
  rowNode.setData(data);
}

useEffect(()=>
{
  if(secdata.length)
  {
    var rowNode = GridRef.current.api.getRowNode("0");
    console.log(rowNode)
    rowNode.setDataValue("username",getSelect2());
  }
},[secdata]);

const handleSelect=e=>
{
 let newdata=rowdata.filter((v,i)=>
  {
    if(v.name==e.target.value)
    {
      return v;
    }
  });
  setsec(newdata);
}

const getSelect=()=>
{
  return (
    <Select
    fullWidth
    onChange={handleSelect}
    >
      {rowdata.map((v,i)=>
      {
       return <MenuItem value={v.name}>{v.name}</MenuItem>
      })}
    </Select>
  )
}

const getSelect2=()=>
{
  return (
    <Select
    fullWidth
    onChange={handleSelect}
    >
      {secdata.map((v,i)=>{
        console.log(v)
      return <MenuItem value={v.name}>{v.name}</MenuItem>
    })}
    </Select>
  )
}

const Add=()=>
{
  let data={id:0,name:getSelect(),username:getSelect2(),email:getSelect()};
  let hdata=[...rowdata];
  hdata.unshift(data);
  console.log(hdata)
  setrow(hdata)
  // GridRef.current.api.applyTransaction({add:[hdata],addIndex:0});
}

const onGridReady=()=>
{
axios.get("https://jsonplaceholder.typicode.com/users")
.then((response)=>
{
  setrow(response.data)
})  
}

return(
    <div>
        <header>
            <h1>CellRenderer_Component</h1>
        </header>
        <button onClick={()=>Add()}>Add</button>
        <div className="ag-theme-alpine" style={{height:300,margin:"7% auto"}}>
        <AgGridReact 
        ref={GridRef}
        rowData={rowdata}
        columnDefs={columnDef}
        defaultColDef={defaultColDef}
        editType={"fullRow"}
        onGridReady={onGridReady}
        />
        </div>
    </div>
)
}

export default CellRender_Component