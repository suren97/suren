import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useEffect,useState } from "react";
import axios from "axios";

function Header_Comp()
{
const [rowdata,setrow]=useState();
const [columnDefs,setcolumn]=useState([
    {field:"id"},
    {field:"name"},
    {field:"username"},
    {field:"email"}
]);
const defaultColDef=({
      flex:1,
      sortable:true
});

useEffect(()=>
{
  axios.get("https://jsonplaceholder.typicode.com/users")
  .then((response)=>{
    setrow(response.data)
  })
},[]);

return(
   <div>
    <header>
        <h1>Header_Components</h1>
    </header>
    <div className="ag-theme-alpine" style={{margin:"7% auto",height:300}}>
        <AgGridReact 
        rowData={rowdata}
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
        />
    </div>
   </div>
)
}

export default Header_Comp;