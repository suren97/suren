import { createSlice } from "@reduxjs/toolkit";
import produce from "immer";

const initialState={
    productmaster:[]
}

const Data=createSlice({
    name:"Products",
    initialState,
    reducers:{
    Productmaster:(state,action)=>
     {
        return produce(state,(draft)=>{
            // console.log(action)
            draft.productmaster.push(action.payload.value);
        })
     }
    }
})

export const Datareducer=Data.reducer;
export const {Productmaster}=Data.actions;
