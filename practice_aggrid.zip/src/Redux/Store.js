import { configureStore } from "@reduxjs/toolkit";
import { Datareducer } from "./Data";

const ReduxStore=configureStore({
    reducer:{
      productData:Datareducer
    }
})

export default ReduxStore;