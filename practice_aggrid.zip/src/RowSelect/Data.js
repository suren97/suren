const Rowdata=[
    { id: 1, name: "surendar", email: "suren@gmail.com",mobile:948747733,location:"Chennai"},
    { id: 2, name: "william", email: "william@gmail.com",mobile:7373736663,location:"Erode"},
    { id: 3, name: "george", email: "george@gmail.com",mobile:9763535522,location:"Salem"},
    { id: 4, name: "philips", email: "philips@gmail.com",mobile:8376352662,location:"Porur"},
    { id: 5, name: "kevin", email: "kevin@gmail.com",mobile:7465355353,location:"Guindy"},
    { id: 6, name: "dennis", email: "dennis@gmail.com",mobile:8736352522,location:"Arcot"},
    { id: 7, name: "richard", email: "richard@gmail.com",mobile:8954423445,location:"Vellore"},
    { id: 8, name: "samuel", email: "samuel@gmail.com",mobile:8373652521,location:"Mangalore"},
    { id: 9, name: "marshall", email: "marshall@gmail.com",mobile:6766235651,location:"Tanjore"},
    { id: 10, name: "kepler", email: "kepler@gmail.com",mobile:7363563621,location:"Tirupur"},
];

export default Rowdata