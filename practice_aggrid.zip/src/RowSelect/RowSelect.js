import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useEffect, useState } from "react";
import * as React from "react";
import axios from "axios";
import Data from "./Data";
import {
  Dialog,
  DialogContentText,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
  Button,
  Stack,
} from "@mui/material";

function Row_Select() {
  const [rowdata, setrow] = useState(Data);
  const [open, setopen] = useState(false);
  const [columnDefs, setcolumn] = useState([
    { field: "id" },
    { field: "name" },
    { field: "email" },
    {
      field: "action",
      cellStyle: { textAlign: "left" },
      cellRenderer: (p) => getPopup(p),
    },
  ]);
  const defaultColDef = {
    filter: true,
    flex: 1,
    sortable: true,
  };
  const [diagdata,setdiag]=useState();
  const showdetail = (p) => {
    setopen(true);
    setdiag(p.data)
  };

  function getPopup(p) {
    return <Button onClick={() => showdetail(p)}>Show Details</Button>;
  }

  let handleClose = () => {
    setopen(false);
  };

  return (
    <div>
      <header>
        <h1>AgGrid - RowSelect</h1>
      </header>
      <div
        className="ag-theme-alpine"
        style={{ height: 300, margin: "5% auto" }}
      >
        <AgGridReact
          rowData={rowdata}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
        />
      </div>
    <Dialog 
    open={open}
    onClose={handleClose} 
    maxWidth="sm"
    fullWidth
    >
      <DialogTitle>Check Details</DialogTitle>
      <DialogContent>
      <Stack direction={"column"} spacing={4}>
        <TextField
        id="name"
        label="Name"
        type="text"
        variant="standard"
        value={diagdata.name}
        />
        <TextField 
        id="email"
        label="Email"
        type="email"
        variant="standard"
        />
        <TextField 
        id="mobile"
        label="Mobile"
        type="number"
        variant="standard"
        />
        <TextField 
        id="location"
        label="Location"
        type="text"
        variant="standard"
        />
      </Stack>
      </DialogContent>
    </Dialog>
    </div>
  );
}

export default Row_Select;
