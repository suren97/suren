import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-enterprise';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import axios from 'axios';
import {useState,useRef, useCallback} from "react";

//forEachNode ->Return the rowNode
//forEachNodeAfterfilter ->Returns only the filtered rows
//forEachNodeAfterfilterandsort ->It is same as the filtered rows but it maintains the order in the grid
//forEachLeafNode -> //clari

function Access_Row()
{
// const gridRef=useRef(null);
// const [columns,setcolumn]=useState([
//     {field:"id"},
//     {field:"name"},
//     {field:"username"},
//     {field:"email"},
//     {field:"address.street"},
//     {field:"address.city"}
// ])

// const defaultCol=({
//     flex:1,
//     editable:true,
//     filter:true,
//     sortable:true
// });

// const onGridReady=(params)=>
// {
//     axios.get("https://jsonplaceholder.typicode.com/users")
//     .then((response)=>
//     {
//       params.api.applyTransaction({add:response.data})
//     })
// }

const [columns,setcolumn]=useState([
    {field:"athlete"},
    {field:"year"},
    {field:"date"},
    {field:"country",hide:true,rowGroup:true}
]);
const gridRef=useRef(null);

const defaultCol=({
    flex:1,
    editable:true,
    filter:true,
    sortable:true
})

const onGridReady=(params)=>
{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>
  {
    params.api.applyTransaction({add:response.data})
  })
}

const foreachnode=()=>
{
  //Normal Data
  gridRef.current.api.Test=1;
  gridRef.current.api.forEachNode(printNode);
}
const foreachfilterednode=()=>
{
  // Filtered Data
  gridRef.current.api.Test=2;
  gridRef.current.api.forEachNodeAfterFilter(printNode);
}

const foreachnodefiltersort=()=>
{
  gridRef.current.api.Test=3;
  gridRef.current.api.forEachNodeAfterFilterAndSort(printNode);
}

const printNode=(node,index)=>
{
 if(node.group && gridRef.current.api.Test===1)
 {
    // console.log(node)
    // console.log(node);
   console.log("Group:",node.key);
   console.log("Total no. of groups",node.childrenAfterGroup.length);
 }  
 else if(node.group && gridRef.current.api.Test===2)
 {
    console.log(node)
    console.log("Group:",node.key);
    console.log("Total no. of RowsFiltered",node.childrenAfterFilter.length)
 }
 else if(node.group && gridRef.current.api.Test===3)
 {
    console.log("Group:",node.key);
    console.log("Total no. of RowsFilteredandSort",node.childrenAfterSort.length);
 }
}


return(
    <div>
        <header>
        <h1>Grid - Accessing Rows</h1>
        </header>
        <div className="tablecontainer">
        <button className="updbtn" onClick={foreachnode}>ForEachNode</button>
        <button className="updbtn" onClick={foreachfilterednode}>ForEachFilteredNode</button>
        <button className="updbtn" onClick={foreachnodefiltersort}>ForEachNodeAfterfilterandsort</button>
        <div className="ag-theme-alpine" style={{height:350}}>
        <AgGridReact
        ref={gridRef}
        columnDefs={columns}
        defaultColDef={defaultCol}
        groupDefaultExpanded={1}
        onGridReady={onGridReady}
        />
        </div>
        </div>
    </div>
)
}
export default Access_Row;