import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-enterprise';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

function Grid_Context()
{
const rowdata=[
    {product:"product1",price:{currency:"EUR",amount:644}},
    {product:"product2",price:{currency:"USD",amount:723}},
    {product:"product3",price:{currency:"GBP",amount:523}},
    {product:"product1",price:{currency:"EUR",amount:644}},
    {product:"product2",price:{currency:"USD",amount:723}},
    {product:"product3",price:{currency:"GBP",amount:523}}
];

const getCurrencyCellRenderer=()=>
{
   var gbpformatter=new Intl.NumberFormat("en-US",{
       style:"currency",
       currency:"GBP",
       minimumFractionDigits:2
   })

   var usdformatter=new Intl.NumberFormat("en-US",{
    style:"currency",
    currency:"USD",
    minimumFractionDigits:2
   })

   var eurformatter=new Intl.NumberFormat("en-US",{
    style:"currency",
    currency:"EUR",
    minimumFractionDigits:2
   })
}

function reportingCurrencyValueGetter(params) {
    // Rates taken from google at time of writing
    var exchangeRates = {
      EUR: {
        GBP: 0.72,
        USD: 1.08,
      },
      GBP: {
        EUR: 1.29,
        USD: 1.5,
      },
      USD: {
        GBP: 0.67,
        EUR: 0.93,
      },
    }
}


const columnDef=[
    {field:"product"},
    {
        headerName:"Currency",
        field:"price.currency"
    },
    {
        headerName:"Price_Local",
        field:"price",
        cellRenderer:getCurrencyCellRenderer(),
        valueGetter:reportingCurrencyValueGetter
    },
    {
        headerName:"GBP",
        field:"price.amount"
    },
];

const defaultColDef=({
    sortable:true,
    flex:1
});



return(
   <>
   <header>
    <h1>Grid context</h1>
   </header>
   <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:300}}>
   <AgGridReact 
   rowData={rowdata}
   columnDefs={columnDef}
   defaultColDef={defaultColDef}
   />
   </div>
   </div>
   </>
)
}

export default Grid_Context;