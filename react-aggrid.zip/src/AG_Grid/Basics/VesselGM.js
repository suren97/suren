import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useEffect,useState } from "react";


function VesselGM()
{
  const [rowdata,setrow]= useState(
    [{id:1,name:233},{id:2,name:4322},
    {id:3,name:733},{id:4,name:"Default"},
    {id:5,name:637},{id:6,name:535},
    {id:7,name:6552},{id:8,name:3.35}
   ]
  )
  const columnDef=[
    {field:"name"}
  ];

  useEffect(()=>{
      let sorted=rowdata.findIndex(v=>v.name === "Default");
      let sliceddata=rowdata.splice(sorted,1)
      rowdata.unshift(...sliceddata);
      console.log(rowdata)
  },[])

return(
        <>
        <div>
            <header>
                <h1>Vessel GM</h1>
            </header>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:300}}>
        <AgGridReact 
        rowData={rowdata}
        columnDefs={columnDef}
        defaultColDef={{flex:1}}
        />
    </div>
    </div>
        </div>
        </>
)
}

export default VesselGM;
