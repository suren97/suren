import {AgGridReact} from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import axios from "axios";
import { useState } from "react";

function Cell_editors()
{
const [rowdata,setrow]=useState();

const [columns,setcolumn]=useState([
    {field:"id"},
    {
        field:"name",
        editable:true,
        cellEditor:'agTextCellEditor',
        cellEditorPopup:true
    },
    {
        field:"username",
        editable:true,
        cellEditorSelector:params=>{
           console.log("editor",params)
            return{
                component:"agRichSelectCellEditor",
                params:{values:[params.data.name]},
                popup:true
            }
        }
    },
    {field:"email"}
]);

const defaultCol=({
     sortable:true,
     filter:true,
     flex:1
});

const GridReady=(params)=>
{
  axios.get("https://jsonplaceholder.typicode.com/users")
  .then((resp)=>{
    setrow(resp.data);
  })
}

return(
    <div>
    <header>
        <h1>Cell Editors</h1>
    </header>
    <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:300}}>
            <AgGridReact
            rowData={rowdata}
            columnDefs={columns}
            defaultColDef={defaultCol}
            onGridReady={GridReady}
            />
        </div>
    </div>
    </div>
)
}
export default Cell_editors;