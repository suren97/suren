import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useState,useMemo } from "react";
import axios from "axios";
import Custom_CellRender from "./Custom_CellRender";

function Loading_CellRender()
{
const [rowdata,setrow]=useState();
const [columns,setcolumn]=useState([
    {field:"id"},
    {field:"athlete"},
    {field:"sport"},
    {field:"year"}
]);

const defaultCol=({
    sortable:true,
    filter:true,
    flex:1
});

const GridReady=(params)=>
{
    axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((resp)=>{
        if(resp.data)
        {
            resp.data.map((v,i)=>
            {
                v.id=i+1;
            })
        }
        setrow(resp.data);
    })
}

const loadingCellRenderer=useMemo(()=>
{
   return Custom_CellRender;
},[]);

const loadingCellRendererParams=useMemo(()=>
{
  return{
    loadingMessage:"Please wait..."
  }
},[]);

return(
    <div>
        <header>
        <h1>Loading Cell_Renderer</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:550}}>
        <AgGridReact
           rowData={rowdata}
           columnDefs={columns}
           defaultColDef={defaultCol}
           loadingCellRenderer={loadingCellRenderer}
           loadingCellRendererParams={loadingCellRendererParams}
           onGridReady={GridReady}
        />
        </div>
        </div>
    </div>
)
}

export default Loading_CellRender;