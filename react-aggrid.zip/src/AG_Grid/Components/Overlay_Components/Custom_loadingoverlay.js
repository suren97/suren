function Custom_loadingoverlay(props)
{
return(
    <div className="ag-overlay-loading-center"
    style={{backgroundColor:"lightblue",padding:10,fontSize:17}}>
   <i className="fa-fa"></i>Please wait Content is Loading...
    </div>
)
}

export default Custom_loadingoverlay;