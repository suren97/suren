import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { useState,useMemo,useRef } from "react";
import Custom_loadingoverlay from "./Custom_loadingoverlay";

function Overlay_Component()
{
const [rowdata,setrow]=useState();
const gridRef=useRef(null);
const columns=[
    {field:"athlete"},
    {field:"year"},
    {field:"date"},
    {field:"bronze"},
    {field:"silver"},
    {field:"gold"},
    {field:"total"}
];

const onGridReady=params=>
{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
     setrow(response.data)
  })
}

const loadingOverlayComponent=useMemo(()=>
{
  return Custom_loadingoverlay
},[]);

const showOverlay=()=>
{
  gridRef.current.api.showLoadingOverlay();  
}

const hideOverlay=()=>
{
 gridRef.current.api.hideOverlay();
}

const NoOverlay=()=>
{
 gridRef.current.api.showNoRowsOverlay();
}


return(
    <div>
      <header>
        <h1>Grid - Overlay_Components</h1>
      </header>
      <div className="tablecontainer">
        <button className="updbtn" onClick={()=>showOverlay()}>Show Overlays</button>
        <button className="updbtn" onClick={()=>hideOverlay()}>Hide Overlays</button>
        <button className="updbtn" onClick={()=>NoOverlay()}>No Overlays</button>
        <div className="ag-theme-alpine" style={{height:400}}>
            <AgGridReact
             ref={gridRef}
             onGridReady={onGridReady}
             rowData={rowdata}
             columnDefs={columns}
             loadingOverlayComponent={loadingOverlayComponent}
             enableCharts={true}
             enableRangeSelection={true}
            />
        </div>
      </div>
    </div>
)
}
export default Overlay_Component;