function Custom_Tooltip(props)
{
let data=props.data;
let check=props.location;
return (
    <div>
    {check === "cell" ? (
    <div className="custom-tooltip" style={{backgroundColor:props.color}}>
    {props.colDef.id==="name" ? (
    <>
    <p>
    <span>Name:&nbsp;{props.value}</span>
    </p>
    <p>
    <span>Country:&nbsp;{data.country}</span>
    </p>
    <p>
    <span>Age:&nbsp;{data.age}</span>
    </p>
    </>
    ):(
     <>
     <p>
     <span>Total Medals:&nbsp;{data.total}</span>
     </p>
     <p>
     <span>Bronze:&nbsp;{data.bronze}</span>
     </p>
     <p>
     <span>Silver:&nbsp;{data.silver}</span>
     </p>
     <p>
     <span>Gold:&nbsp;{data.gold}</span>
     </p>
     </>
    )}
    </div>
    ):(
    <div className="custom-tooltip" style={{backgroundColor:props.color}}>
    <p><span>{props.value}</span></p>
    </div>
    )}
    </div>
)
}

export default Custom_Tooltip;