import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { useState,useMemo,useRef } from "react";
import Custom_loadingoverlay from "../Overlay_Components/Custom_loadingoverlay";

function GroupTooltip()
{
const [rowdata,setrow]=useState();
const [columnDef,setcolumn]=useState([
    {field:"athlete"},
    {field:"year"},
    {field:"country",rowGroup:true},
    {field:"date"},
    {field:"total"}
])

const defaultCol=({
    sortable:true,
    flex:1
});

const autoGroupCol=useMemo(()=>{
return{
   headerTooltip:"Group",
   minWidth:190,
   tooltipValueGetter:params=>
   {
      console.log(params)
      const count=params.node && params.node.allChildrenCount;
      if(count!=null)
      {
        return params.value + '('+ count +')';
      }
      return params.value;
   }
}
},[]);


const onGridReady=()=>
{
 axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
.then((response)=>{
    setrow(response.data)
 })
}

const loadingOverlayComponent=()=>
{
  return <Custom_loadingoverlay />
}

return(
    <div>
        <header>
        <h1>Grid - Column Group Tooltip</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:350}}>
        <AgGridReact
        onGridReady={onGridReady}
        columnDefs={columnDef}
        defaultColDef={defaultCol}
        rowData={rowdata}
        loadingOverlayComponent={loadingOverlayComponent}
        autoGroupColumnDef={autoGroupCol}
        />
        </div>
        </div>
    </div>
)
}

export default GroupTooltip;