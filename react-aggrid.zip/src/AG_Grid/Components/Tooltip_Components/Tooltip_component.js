import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { useState,useMemo,useRef } from "react";
import Custom_Tooltip from "./Custom_Tooltip";

function Tooltip_Component()
{
const [rowdata,setrow]=useState();
const gridRef=useRef(null);
const columnDefs=[
    {
        field:"athlete",
        id:"name",
        tooltipField:"athlete",
        tooltipComponentParams:{color:"lightblue"}
    },
    {
        field:"sport"
    },
    {field:"year"},
    {
        field:"total",
        tooltipField:"total",
        tooltipComponentParams:{color:"lightgrey"}
    }
];

const defaultCol=useMemo(()=>{
   console.log(gridRef)
    return{
     flex:1,
     sortable:true,
     tooltipComponent:Custom_Tooltip
    }
});

const onGridReady=()=>
{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
      setrow(response.data)
  })
}

return(
    <div>
    <header>
    <h1>Grid - Tooltip Component</h1>
    </header>
    <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:300}}>
            <AgGridReact
            ref={gridRef}
            rowData={rowdata}
            columnDefs={columnDefs}
            defaultColDef={defaultCol}
            onGridReady={onGridReady}
            />
        </div>
    </div>
    </div>
)
}

export default Tooltip_Component;