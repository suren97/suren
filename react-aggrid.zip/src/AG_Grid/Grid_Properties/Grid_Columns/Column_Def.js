import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import {useState,useCallback} from "react";
import axios from "axios";

function Column_Definition()
{
// const [rowdata,setrow]=useState();

// const onGridReady=useCallback(()=>
// {
// axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
//  .then((response)=>{
//  setrow(()=>{
//     return [...response.data]
//  })
//  })
// },[]);

//Noraml Column Definition
const ColDefs=[
    {field:"athlete"},
    {field:"sport"},
    {field:"age"}
];

//Group Column Definition
const groupColDef=[
  {
    headerName:"Group A",
    children:[
        {field:"year"},
        {field:"date"}
    ]
  } 
];

// Row data with notations
const rowdata=[
    {
        name:"surendar",
        role:"React Developer",
        status:'Active',
        address:{
            no:78,
            street:"JSS Nagar",
            area:"Guduvancherry"
        }
    },
];

//Columns for dot notations
const columndata=[
    {field:"name"},
    {field:"role"},
    {field:"status"},
    {
        headerName:"Address Details",
        children:[
            {
                headerName:"House No.",
                field:"address.no"
            },
            {
                headerName:"Street",
                field:"address.street"
            },
            {
                headerName:"Area",
                field:"address.area"
            }
        ]
    }
];

const defaultColDef=({
   sortable:true,
   flex:1
});

    return(
        <div>
            <header>
                <h1>Grid - Column Definition</h1>
            </header>
            <div className="tablecontainer">
                <div className="ag-theme-alpine" style={{height:300}}>
                    <AgGridReact
                    rowData={rowdata}
                    // onGridReady={onGridReady}
                    columnDefs={columndata}
                    defaultColDef={defaultColDef}
                    />
                </div>
            </div>
        </div>
    )
}

export default Column_Definition;