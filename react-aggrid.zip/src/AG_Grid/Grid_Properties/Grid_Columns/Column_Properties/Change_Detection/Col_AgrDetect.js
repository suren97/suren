import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useState,useMemo } from "react";

//Equals
function Aggr_Detection()
{
const getRow=()=>
{
  var rowdata=[];
  for(var i=1;i<20;i++)
  {
    rowdata.push({
        group:i < 5 ? "A" : "B",
        a:(i*328)%100,
        b:(i*213)%100,
        c:(i*254)%100,
        d:(i*342)%100
    })
  }
  return rowdata;
};

const [rowdata,setrow]=useState(getRow());
const [columns,setcolumn]=useState([
    {
        headerName:"Group",
        field:"group",
        rowGroup:true,
        editable:true,
        type:"totalColumn"
    },
    {field:"a",type:"valueColumn"},
    {field:"b",type:"valueColumn"},
    {field:"c",type:"valueColumn"},
    {field:"d",type:"valueColumn"},
    {
        headerName:"Total",
        field:"total",
        type:"totalColumn",
        valueGetter:'getValue("a")+getValue("b")+getValue("c")+getValue("d")'
    }
]);

const defaultCol=({
   sortable:true,
   filter:true,
   flex:1
});

const columntype=useMemo(()=>
{
    return {
        valueColumn:{
          editable:true,
          aggFunc:"sum",
          valueParser:'Number(newValue)',
          cellRenderer:'agAnimateShowChangeCellRenderer',
          filter:'agNumberColumnFilter'
        },
       totalColumn:{
        cellRenderer:'agAnimateShowChangeCellRenderer'
       }
    }
});

return(
    <div>
        <header>
        <h1>Grid - Column Aggregation_Detection</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine-dark" style={{height:550}}>
        <AgGridReact
        rowData={rowdata}
        columnDefs={columns}
        defaultColDef={defaultCol}
        columnTypes={columntype}
        groupDefaultExpanded={1} // Used to Expand the Group during rendering
        suppressAggFuncInHeader={true} //It hides the Agg func Header in the Grid
        />
        </div>
        </div>
    </div>
)
}
export default Aggr_Detection;