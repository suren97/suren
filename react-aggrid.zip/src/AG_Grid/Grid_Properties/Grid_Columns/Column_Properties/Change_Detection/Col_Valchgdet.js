import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import {useState} from "react";

function Col_ChnDetection()
{
const getRow=()=>
{
    let rowdata=[];
    for(var i=1;i<20;i++)
    {
        rowdata.push({
            a:(i*433)%100,
            b:(i*398)%100,
            c:(i*546)%100,
            d:(i*337)%100
        })
    }
    return rowdata;
}
const [rowdata,setrow]=useState(getRow());
const [columns,setcolumns]=useState([
    {field:"a"},
    {field:"b"},
    {field:"c"},
    {field:"d"},
    {
        field:"total",
        valueGetter:p=>
        {
          return parseInt(p.data.a)+parseInt(p.data.b)+parseInt(p.data.c)+parseInt(p.data.d)
        },
        cellStyle:{color:"yellow",fontWeight:"bold"}
    }
]);
const defaultCol=({
   sortable:true,
   editable:true,
   flex:1
});


return(
    <div>
    <header>
    <h1>Column_ChangeDetect</h1>
    </header>
    <div className="tablecontainer">
        <div className="ag-theme-alpine-dark" style={{height:400}}>
         <AgGridReact
        rowData={rowdata}
        columnDefs={columns}
        animateRows={true}
        enableCellChangeFlash={true}
        suppressChangeDetection={false} // It wont allow automatic change detection
        defaultColDef={defaultCol}
        pagination={true}
        paginationAutoPageSize={true}
        />
        </div>
    </div>
    </div>
)
}
export default Col_ChnDetection;