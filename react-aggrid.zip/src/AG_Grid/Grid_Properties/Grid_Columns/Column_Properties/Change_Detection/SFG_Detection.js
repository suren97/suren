import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useState,useMemo, useCallback,useRef } from "react";

function SFG_Detection()
{
const gridRef=useRef(null);
const getRow=()=>
{
  let rowdata=[];
  for(var i=1;i<16;i++)
  {
   rowdata.push({
    group:i < 6 ? "A" : "B",
    a:(i*324)%100,
    b:(i*253)%100,
    c:(i*643)%100,
    d:(i*137)%100,
   })
  }
  return rowdata;
};

const [rowdata,setrow]=useState(getRow());
const [columns,setcolumns]=useState([
    {field:"group",rowGroup:true,type:"totalColumn",editable:true},
    {
    field:"a",type:"valueColumn",
    checkboxSelection:true,
    showDisabledCheckboxes:true,
    headerCheckboxSelection:true
    },
    {
        field:"b",
        type:"valueColumn"
    },
    {field:"c",type:"valueColumn"},
    {field:"d",type:"valueColumn"},
    {
        field:"total",
        type:"totalColumn",
        valueGetter:'getValue("a")+getValue("b")+getValue("c")+getValue("d")'
    }
]);

const defaultCol=({
    flex:1,
    sortable:true
});

const columnType=useMemo(()=>{
    return {
        valueColumn:{
          editable:true,
          aggFunc:"sum",
          valueParser:"Number(newValue)",
          cellRenderer:'agAnimateShowChangeCellRenderer',
          filter:'agNumberColumnFilter'
        },
        totalColumn:{
            editable:false,
            cellRenderer:'agAnimateShowChangeCellRenderer',
        }
    }
});

const oncellvaluechanged=useCallback((params)=>
{
  var updata=[params.data];
  gridRef.current.api.applyTransaction({update:updata});
},[]);

const isRowSelectable=useCallback((params)=>{
  return params.data ? params.data.a > 20 : false;
},[]);

const onGridReady=(params)=>
{
    console.log(params.api)
}

let onselectionchange=params=>
{
  params.api.getSelectedRows();
}

return(
    <div>
        <header>
        <h1>Sorting, Filtering, Grouping Detection</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine-dark" style={{height:550}}>
        <AgGridReact
        ref={gridRef}
        rowData={rowdata}
        columnDefs={columns}
        onGridReady={onGridReady}
        defaultColDef={defaultCol}
        groupDefaultExpanded={1}
        suppressAggFuncInHeader={true}
        columnTypes={columnType}
        animateRows={true}
        onCellValueChanged={oncellvaluechanged}
       // onSelectionChanged={onselectionchange}
        isRowSelectable={isRowSelectable}
        />
        </div>
        </div>
    </div>
)
}
export default SFG_Detection;