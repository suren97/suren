import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import {useState, useCallback,useMemo,useRef} from "react";
import axios from "axios"

// Grid - Column properties
// 1.field - It specify the columns which has been access for dispalying the row in grid
// 2.colId - It is a unique id present in each column which access the column in api for sorting,filtering ...
// 3.valueGetter - It is a function used to get the values from the array.
// 4.valueFormatter - used for formatting the values based on user specific
// 5.refData- It is used to map columns to the respective data columns from the map
// 6.keycreator -->Clarify
// 7.equals --used for change value Detection in theGrid
// 8.checkboxSelection --used for selecting rows using checkbox
// 9.showDisabledCheckboxes --used for displaying the checkboxes in non-selectable rows 
//which is in disabled
// 10.toolPanelClass 

function Column_Prop()
{
const gridRef=useRef(null);
const [rowdata,setrow]=useState();
const [columns,setcolumn]=useState([
    {field:"athlete",colId:"Name"},
    {field:"year",type:"columndata"},
    {
        field:"sport",
        type:"columndata",
        valueGetter:p=>
        {
            return p.data.sport;
        },
        valueFormatter:p=>
        {
            return '['+p.data.sport+']';
        }
    },
    {
        headerName:"Medals won",
        marryChildren:true,
        children:[
            {field:"bronze",columnGroupShow:"open"},
            {field:"silver",columnGroupShow:"open"},
            {field:"gold",columnGroupShow:"open"},
            {field:"total",columnGroupShow:"close"}
        ]
    }
]);
const defaultCol=({
    sortable:true,
    editable:true,
    flex:1
})  

const onGridReady=useCallback((params)=>
{
axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
 .then((response)=>{
 setrow(()=>{
    return [...response.data]
 })
 })
},[]);

const columnTypes={
    columndata:{editable:false}
}

return(
      <div>
        <header>
            <h1>Grid - Columns Properties</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:300}}>
        <AgGridReact
        ref={gridRef}
        rowData={rowdata}
        defaultColDef={defaultCol}
        onGridReady={onGridReady}
        columnDefs={columns}
        columnTypes={columnTypes}
        />
        </div>
        </div>
      </div>
    )
}

export default Column_Prop;