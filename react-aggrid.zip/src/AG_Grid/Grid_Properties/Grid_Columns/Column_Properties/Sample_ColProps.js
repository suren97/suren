import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import {useState, useCallback,useMemo} from "react";
import axios from "axios"

//Grid - Column properties
//1.field - It specify the columns which has been access for dispalying the row in grid
//2.colId - It is a unique id present in each column which access the column in api for sorting,filtering ...
//3.valueGetter - It is a function used to get the values from the array.
//4.valueFormatter - used for formatting the values based on user specific

function Sample_ColProps()
{
const [rowdata,setrow]=useState();

const [columns,setcolumn]=useState([
    {field:"athlete",colId:"Name"},
    {field:"sport",
    // pinned:"left",
    // valueGetter:p=>
    // {
    //     return p.data.sport
    // },
    // valueFormatter:p=>
    // {
    //     return '['+p.data.sport+']';
    // }
},
    {field:"year",pinned:"right"},
    {
        headerName:"Medals",
        marryChildren:true, // Its is used to avoid moving columns from their groups
        children:[
            {field:"bronze"},
            {field:"silver"},
            {field:"gold"}
        ]
    },
    {field:"total"}
]);

const defaultCol=useMemo(()=>({
      sortable:true,
      resizable:true,
      lockPosition:true,
      lockPinned:true,
      width:150,
      maxWidth:200,
      minWidth:100,
      flex:1
}),[]);

var ColAction=(params)=>
{
    // console.log(params)
    return params.value
}


const onGridReady=useCallback((params)=>
{
axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
 .then((response)=>{
 setrow(()=>{
    return [...response.data]
 })
 })
},[]);

return(
      <div>
        <header>
            <h1>Grid - Columns Properties</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:300}}>
        <AgGridReact
        rowData={rowdata}
        defaultColDef={defaultCol}
        onGridReady={onGridReady}
        columnDefs={columns}
        />
        </div>
        </div>
      </div>
    )
}

export default Sample_ColProps;