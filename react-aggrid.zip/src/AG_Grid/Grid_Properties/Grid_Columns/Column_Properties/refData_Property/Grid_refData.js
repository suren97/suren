import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import getData from "./data";
import {useState,useMemo, useCallback} from "react";

function Grid_refData()
{
const [rowdata,setrow]=useState(getData());
const makemapping={
    tyt:"Toyota",
    frd:"Ford",
    prs:"Porsche"
};

const colormapping={
    fg:"Forest Green",
    bw:"Burlywood",
    cb:"Cadet Blue"
};

const extractValues=(mapping)=>
{
   return Object.keys(mapping);
}

const carBrands=extractValues(makemapping);
const colorBrands=extractValues(colormapping);

const removeSpaces = (str) => {
    return str ? str.replace(/\s/g, '') : str;
};

const Colorcell=params=>
{
   let colstr=removeSpaces(params.valueFormatted);
   return <span style={{color:colstr}}>{params.valueFormatted}</span>
}

const Formatcurrency=(params)=>
{
    return "$"+params.value
};

const [columns,setcolumns]=useState([
    {
        field:"make",
        cellEditor:"agSelectCellEditor",
        cellEditorParams:{
           values:carBrands
        },
        refData:makemapping
    },
    {
        field:"exteriorColour",
        cellEditor:"agRichSelectCellEditor",
        cellEditorPopup:true,
        cellEditorParams:{
            values:colorBrands,
            cellRenderer:Colorcell
        },
        refData:colormapping,
        cellRenderer:Colorcell
    },
    {
        field:"interiorColour",
        refData:colormapping,
        cellRenderer:Colorcell
    },
    {
        field:"price",
        colId:"retail price",
        cellRenderer:params=>Formatcurrency(params)
    },
    {
        headerName:"Retail price(incl. taxes)",
        field:"retail price",
        valueGetter:p=>
        {
           return "$"+p.getValue("retail price")*1.2
        }
    }
]);

const defaultCol=({
    sortable:true,
    editable:true,
    filter:true,
    flex:1
});

const onCellValueChanged=useCallback((p)=>
{
    console.log(p)
    //The Cell values remains the same key in the Values
//   console.log("params",p);
},[]);

return(
    <div>
        <header>
            <h1>Grid - RefProperty</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine-dark" style={{height:400}}>
        <AgGridReact
        rowData={rowdata}
        columnDefs={columns}
        defaultColDef={defaultCol}
        onCellValueChanged={onCellValueChanged}  //Returns the value when any of the cells get edited
        />
        </div>
        </div>
    </div>
)
}
export default Grid_refData;