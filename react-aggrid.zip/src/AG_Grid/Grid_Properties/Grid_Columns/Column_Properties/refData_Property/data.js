function getData() {
    var rowData = [
      { make: 'tyt', exteriorColour: 'fg', interiorColour: 'bw', price: 35000 },
      { make: 'frd', exteriorColour: 'bw', interiorColour: 'cb', price: 32000 },
      { make: 'prs', exteriorColour: 'cb', interiorColour: 'fg', price: 72000 },
      { make: 'tyt', exteriorColour: 'fg', interiorColour: 'bw', price: 35000 },
      { make: 'frd', exteriorColour: 'bw', interiorColour: 'cb', price: 32000 },
      { make: 'prs', exteriorColour: 'cb', interiorColour: 'fg', price: 72000 },
      { make: 'tyt', exteriorColour: 'fg', interiorColour: 'bw', price: 35000 },
      { make: 'frd', exteriorColour: 'bw', interiorColour: 'cb', price: 32000 },
      { make: 'prs', exteriorColour: 'cb', interiorColour: 'fg', price: 72000 },
      { make: 'tyt', exteriorColour: 'fg', interiorColour: 'bw', price: 35000 },
      { make: 'frd', exteriorColour: 'bw', interiorColour: 'cb', price: 32000 },
      { make: 'prs', exteriorColour: 'cb', interiorColour: 'fg', price: 72000 },
      { make: 'tyt', exteriorColour: 'fg', interiorColour: 'bw', price: 35000 },
      { make: 'frd', exteriorColour: 'bw', interiorColour: 'cb', price: 32000 },
      { make: 'prs', exteriorColour: 'cb', interiorColour: 'fg', price: 72000 },
      { make: 'prs', exteriorColour: 'cb', interiorColour: 'fg', price: 72000 },
      { make: 'tyt', exteriorColour: 'fg', interiorColour: 'bw', price: 35000 },
      { make: 'frd', exteriorColour: 'bw', interiorColour: 'cb', price: 32000 },
    ];
    return rowData;
  }

  export default getData;
  