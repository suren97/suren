import React,{Component} from "react";

export class versionfoot extends Component{
    constructor(props)
    {
        super(props);
        this.state=
        {
          footerobj:{
            version:"11.0.11",
            created:"saezam",
            updated:"saezam"
          }
        }
    }
    render()
    {
        return(
            <div className="ag-status-name-value">
            <span className="component"><b>Version:</b>&nbsp;</span>
            <span className="ag-status-name-value">{this.state.footerobj.version}</span>
        </div>
        )
    }
}

export class createfoot extends Component
{
    constructor(props)
    {
        super(props);
        this.state={
            footerobj:{
                version:"11.0.11",
                created:"saezam",
                updated:"saezam"
              }
        }
    }
    render()
    {
        return(
            <div className="ag-status-name-value">
            <span className="component"><b>CreatedBy:</b>&nbsp;</span>
            <span className="ag-status-name-value">{this.state.footerobj.created}</span>
        </div>
        )
    }
}