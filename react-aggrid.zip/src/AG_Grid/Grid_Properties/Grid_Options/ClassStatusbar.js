import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import axios from "axios";
import {versionfoot,createfoot} from "./ClassFooter";


class GridStatusBar extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            columnDefs:[
                {field:"athlete"},
                {field:"country"},
                {field:"year"},
                {field:"date"},
                {field:"bronze"},
                {field:"gold"},
                {field:"total",aggFuncs:"sum"}
            ],
            rowdata:[],
            cellvalues:[],
        }
    }
  
    onGridReady=(params)=>
    {
        axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
        .then((response)=>{
            params.api.applyTransaction({add:response.data})
        })
    }

    onCellClicked=(params)=>
    {
       let element=document.getElementsByClassName("ag-theme-alpine");
       let divelem=document.createElement("div");
       let p=document.createElement("p");
       console.log(divelem)
    }
 
    render()
    {
        return(
            <div>
            <header>
            <h1>Grid Options - Grid StatusBar</h1>
            </header>
            <div className="tablecontainer">
            <div className="ag-theme-alpine" style={{height:400}}>
            <AgGridReact
            rowData={this.state.rowdata}
            columnDefs={this.state.columnDefs}
            enableRangeSelection={true}
            rowSelection="single"
            onGridReady={this.onGridReady}
            statusBar={this.state.statusBar}
            onCellClicked={this.onCellClicked}
            />
            </div>
            </div>
            </div>
        )
    }
}

export default GridStatusBar;