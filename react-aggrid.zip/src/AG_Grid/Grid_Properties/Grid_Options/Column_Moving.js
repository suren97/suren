import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css"
import axios from "axios";
import { useState,useRef } from "react";

function Column_Moving()
{
const gridRef=useRef(null);
const columnDefs=[
    {field:"id",suppressMovable:true},
    {field:"name",pinned:"left",lockpinned:true,lockPosition:true},
    {field:"username"},
    {field:"email"},
    {field:"address.city"}
];

const [rowdata,setrow]=useState();

const onGridReady=()=>
{
  axios.get("https://jsonplaceholder.typicode.com/users")
  .then((response)=>{
   setrow(response.data);
  })
}

const defaultColDef=({
      sortable:true,
      flex:1
});

const Movecolumn=()=>
{
 gridRef.current.columnApi.moveColumn("id",1)  //used for moving column in the Grid
}

const Movecolumns=()=>
{
 gridRef.current.columnApi.moveColumns(["name","username"],3);
}

const Movecolumnbyindex=()=>
{
 gridRef.current.columnApi.moveColumnByIndex(0,4);
}

return(
    <div>
        <header>
            <h1>Column Moving</h1>
        </header>
        <button className="updbtn" onClick={()=>Movecolumn()}>Move Id Col to second</button>
        <button className="updbtn" onClick={()=>Movecolumns()}>Move Name and Username columns at last</button>
        <button className="updbtn" onClick={()=>Movecolumnbyindex()}>Move Columnsbased on Index</button>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:300}}>
            <AgGridReact
            ref={gridRef}
            onGridReady={onGridReady}
            rowData={rowdata}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            headerHeight={35}
            // suppressDragLeaveHidesColumns={true}// when drag a columns out of the grid it cannot be get hidden
            // allowDragFromColumnsToolPanel={true}
            // suppressMovableColumns={true} used for suppressing the columns from dragging
            // suppressColumnMoveAnimation={true} used for suppress the column animation
            // suppressFieldDotNotation={false} used to suppress dot fields in the column
            />
        </div>
        </div>
    </div>
)
}

export default Column_Moving;