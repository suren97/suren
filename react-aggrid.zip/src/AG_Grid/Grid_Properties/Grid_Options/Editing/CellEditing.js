import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { useState,useMemo,useRef } from "react";

function CellEditing()
{
const [rowdata,setrow]=useState();
const [columnDef,setcolumn]=useState([
    {field:"athlete"},
    {field:"year"},
    {field:"country",rowGroup:true},
    {field:"date"},
    {field:"total",type:"totalcolumn"}
])

const columnType=useMemo((params)=>
{
  return{
    totalcolumn:{
        editable:true,
        valueParser:'Number(newValue)',
        aggFunc:"sum"
    }
  }
},[]);

const defaultCol=({
    sortable:true,
    flex:1,
    editable:true
});

const onGridReady=()=>
{
 axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
.then((response)=>{
    setrow(response.data)
 })
}

return(
    <div>
        <header>
        <h1>Grid - Cell Editing</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:350}}>
        <AgGridReact
        onGridReady={onGridReady}
        columnDefs={columnDef}
        defaultColDef={defaultCol}
        rowData={rowdata}
        columnTypes={columnType}
        // singleClickEdit={true}
        // stopEditingWhenCellsLoseFocus={true}
        // enterMovesDown={true}
        // enterMovesDownAfterEdit={true}
        // editType="fullRow"
        // singleClickEdit={true}
        // suppressClickEdit={true}
        />
        </div>
        </div>
    </div>
)
}

export default CellEditing;