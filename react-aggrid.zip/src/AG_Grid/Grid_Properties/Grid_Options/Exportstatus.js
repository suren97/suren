import {versionfoot,createfoot,updatefoot} from "./Footer";

export const Exportstatus=()=>
{
return {
    statusPanels: [
      {statusPanel:versionfoot,align:"left"},
      {statusPanel:createfoot,align:"right"},
      {statusPanel:updatefoot,align:"center"}
      // {statusPanel:"agTotalRowCountComponent",align:"left"},
      // {statusPanel:"agTotalAndFilteredRowCountComponent"},
      // {statusPanel:"agFilteredRowCountComponent"},
      // {statusPanel:"agSelectedRowCountComponent"},
      // {statusPanel:"agAggregationComponent",align:"center",statusPanelParams:{aggFuncs:["sum","min","max"]}}
    ]
}
}