let footerObj={
    version:"11.7.25.0",
    Created:"saezma-30/04/2020 17:26",
    Updated:"saezma-08/10/2020 15:39"
};

export const versionfoot=()=>
{
    return(
        <>
        <div className="ag-status-name-value">
            <span className="component"><b>Version:</b>&nbsp;</span>
            <span className="ag-status-name-value">{footerObj.version}</span>
        </div>
        </>
    )
}


export const createfoot=()=>
{
    return(
        <>
         <div className="ag-status-name-value">
            <span className="component"><b>CreatedBy:</b>&nbsp;</span>
            <span className="ag-status-name-value">{footerObj.Created}</span>
        </div>
        </>
    )
}

export const updatefoot=()=>
{
    return(
        <>
        <div className="ag-status-name-value">
           <span className="component"><b>UpdatedBy:</b>&nbsp;</span>
           <span className="ag-status-name-value">{footerObj.Updated}</span>
        </div>
        </>
    )
}
