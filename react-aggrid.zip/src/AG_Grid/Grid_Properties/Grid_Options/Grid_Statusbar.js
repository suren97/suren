import {AgGridReact} from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useEffect,useState,useMemo } from "react";
import axios from "axios";
import {versionfoot,createfoot,updatefoot} from "./Footer";

function Grid_StatusBar()
{
const [rowdata,setrow]=useState();
const [columns,setcolumn]=useState([
  {field:"athlete"},
  {field:"country"},
  {field:"year"},
  {field:"date"},
  {field:"bronze"},
  {field:"gold"},
  {field:"total",aggFuncs:"sum"}
]);

const defaultCol=({
   sortable:true,
   filter:true,
   floatingFilter:true,
   flex:1
});

useEffect(()=>
{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
    setrow(()=>
    {
      return [...response.data];
    })
  })
},[]);

let footerobj=[
  {
  version:"11.7.25.0",
  Created:"saezma-30/04/2020 17:26",
  Updated:"saezma-08/10/2020 15:39"
 }
];
console.log(footerobj)

//Staus Bar---------------------------------------------
const statusBar=useMemo(()=>
{
  return {
    statusPanels: [
      {statusPanel:versionfoot,align:"left"},
      {statusPanel:createfoot,align:"right"},
      {statusPanel:updatefoot,align:"center"}
      // {statusPanel:"agTotalRowCountComponent",align:"left"},
      // {statusPanel:"agTotalAndFilteredRowCountComponent"},
      // {statusPanel:"agFilteredRowCountComponent"},
      // {statusPanel:"agSelectedRowCountComponent"},
      // {statusPanel:"agAggregationComponent",align:"center",statusPanelParams:{aggFuncs:["sum","min","max"]}}
    ]
}
},[]);


return(
    <div>
    <header>
    <h1>Grid Options - Grid StatusBar</h1>
    </header>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:400}}>
    <AgGridReact
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultCol}
    enableRangeSelection={true}
    rowSelection="multiple"
    statusBar={statusBar}
    />
    </div>
    </div>
    </div>
)
}

export default Grid_StatusBar;