import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css"
import { useState,useEffect, useCallback, useMemo,useRef} from "react";
import axios from "axios";

function Getcontext()
{
const gridRef=useRef();
const [rowdata,setrow]=useState();
const [columns,setcolumns]=useState([
    {field:"athlete",headerName:"Name"},
    {field:"sport"},
    {field:"year"},
    {field:"age"},
    {field:"gold"},
    {field:"total"}
]);
const defaultCol=({
    sortable:true,
    filter:true,
    flex:1,
    editable:true
})

useEffect(()=>
{
 axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
 .then((response)=>{
 setrow(()=>
 {
    return [...response.data]
 })
 })
},[]);

let getContextMenuItems=useCallback((params)=>
{
  var result=[
    {
      name:"Alert"+" "+params.value,
      action:()=>{
        window.alert("You have clicked the" + params.value);
      }
    },
    
    //Menu Item Defintions
    {
        name:"Country",
        subMenu :[
            {
                name:"Ireland",
                action:()=>
                {
                    window.alert("Ireland was pressed");
                },
                tooltip:"Displaying an item",
                shortcut:'Alt + S',
                // disabled:true,
                // checked:false
                // icon
                // cssClasses
            }
        ]
    },
    "separator",
    {
        name:"Checked",
        checked:true,
        action:()=>
        {
         // console.log(params.node.data)
        }
    },
    "copy",
    "separator",
    "chartRange",
    "autoSizeAll",
    "expandAll",
    "contractAll",
    "csvExport",
    "copyWithHeaders",
    "copyWithGroupHeaders",
    "paste",
    "resetColumns",
    "export",
    "excelExport",
  ]
  return result;
},[]);

let onGridReady=(params)=>
{
  console.log(params)
}

let popupParent=useMemo(()=>
{
    return document.querySelector("body");
});

let onCellContextMenu=(params)=>
{
    console.log(params)
}

const refresh=()=>
{
  gridRef.current.api.refreshCells();
}

return(
    <div>
    <header>
    <h1>Grid Options - getContextMenuItems</h1>
    </header>
    <div className="tablecontainer">
    <button onClick={refresh}>Refresh Cells</button>
    <div className="ag-theme-alpine" style={{height:300}}>
    <AgGridReact
    ref={gridRef}
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultCol}
    allowContextMenuWithControlKey={true}
    enableRangeSelection={true}
    rowSelection="multiple"
    suppressContextMenu={false} // Hide or show the context menu in the Grid
    getContextMenuItems={getContextMenuItems}
    onGridReady={onGridReady}
    popupParent={popupParent}
    onCellDoubleClicked={true}
   // ----clarify:preventDefaultOnContextMenu
    />    
    </div>
    </div>
    </div>
)
}

export default Getcontext;