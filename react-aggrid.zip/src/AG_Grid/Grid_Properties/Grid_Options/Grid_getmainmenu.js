import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css"
import {useState,useEffect,useCallback,useMemo} from "react";
import axios from "axios";

function Grid_mainmenu()
{
const [rowdata,setrow]=useState();
const [columns,setcolumn]=useState([
    {
       groupId:"athleteId",
       headerName:"Athlete Details",
       marryChildren:true,
       children:[
        {
            headerName:"Name",
            field:"athlete",
            columnsMenuParams:{
                suppressColumnFilter: true,
            }
        },
        {
            field:"age",
        },
        {
            field:"year"
        },
        {
            field:"sport"
        }
       ],
    },
    {
        groupId:"medalsId",
        marryChildren:true,
        headerName:"Medals Details",
        children:[
            {
                field:"bronze"
            },
            {
                field:"silver"
            },
            {
                field:"gold"
            },
            {
                field:"total"
            }
        ]
    }
]);


const defaultCol=useMemo(()=>{
    return {
        flex:1,
        sortable:true,
        //-------GetMenuItems methods------
        // menuTabs:["filterMenuTab"],
        columnsMenuParams: {
            // suppresses updating the layout of columns as they are rearranged in the grid
            suppressSyncLayoutWithGrid: false,
            contractColumnSelection:true,
          },
    }
});

//Customizing the Main Menu Items
const getMainMenuItems=useCallback((params)=>
{
  let id=params.column.getId();
  switch(id)
  {
    case "athlete":
    const athleteItems=params.defaultItems.slice(0);
    athleteItems.push({
        name:"AG Grid",
        action:()=>
        {
            alert("Clicked the AG Grid items");
        }
    })
    athleteItems.push({
        name:"Sample",
        action:()=>
        {
            alert("Sample Menu")
        }
    })
    return athleteItems;
    
    case "sport":
    const sportitems=[];
    sportitems.push({
        name:"Sports",
        subMenu:[
            {
            name:"Cricket",
            action:()=>
            {
                alert("you clicked the sports cricket");
            }
        },
    ]});
    return sportitems;

    case "year":
    const yearitem=[];
    yearitem.push({
        name:"Display",
        action:()=>
        {
            alert("You have clicked the Display...");
        }
    },
    "pinSubMenu",
    "valueAggSubMenu",
    "autoSizeThis",
    "autoSizeAll",
    "rowGroup",
    "rowUnGroup",
    "resetColumns"
    );
    return yearitem;

    default:
    return params.defaultItems;
  }
},[]);

//////////////////////////////////////////////////////

const onGridReady=useCallback(()=>
{
axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
 .then((response)=>{
 setrow(()=>{
    return [...response.data]
 })
 })
},[]);

const statusbar=useMemo(()=>
{
 return {
    statusPanels:[
        {statusPanel:"agTotalRowCountComponent",align:"left"},
        {statusPanel:"agAggregationComponent"}
    ]
 }  
},[]);

return(
    <div>
        <header>
        <h1>Grid Options - Grid-getMainMenuItems</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:300}}>
        <AgGridReact 
        rowData={rowdata}
        columnDefs={columns}
        defaultColDef={defaultCol}
        enableRangeSelection={true}
        getMainMenuItems={getMainMenuItems}
        animateRows={true}
        onGridReady={onGridReady}
        statusBar={statusbar}
        />
        </div>
        </div>
    </div>
)
}

export default Grid_mainmenu;