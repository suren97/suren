import { AgGridReact } from "ag-grid-react";
import axios from "axios";
import { useEffect,useMemo,useState } from "react";

function Grid_Sidebar()
{
const [rowdata,setrow]=useState();
const [gridapi,setapi]=useState();
const [columns,setcolumn]=useState([
      {field:"athlete"},
      {field:"country"},
      {field:"year"},
      {field:"date"},
      {field:"bronze"},
      {field:"gold"},
      {field:"total"}
]);

const defaultCol=({
    sortable:true,
    filter:true,
    floatingFilter:true,
    flex:1
 });
    
useEffect(()=>
{
    axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>{
    setrow(()=>
    {
        return [...response.data];
    })
})
},[]);

const onGridReady=(params)=>
{
setapi(params);
// params.api.getSideBar();  // Return the current selected sidebar
// params.api.setSideBarVisible(true); // It is set whether to return sidebar visible or not
// params.api.isSideBarVisible(); // Returns whether the sidebar is visible or not
// params.api.setSideBarPosition("left"); // used to set the sidebar position whether it is in left or right 
// params.api.openToolPanel("columns"); // used for opening first toolpanel during first render
// params.api.closeToolPanel("filters"); //used for closing toolpanel 
// params.api.refreshToolPanel(); //used for refreshing the panel in the grid
// params.api.getToolPanelInstance("columns");
}

const sideBar=useMemo(()=>
{
  return {
    toolPanels:[
        {
            id:"columns",
            toolPanel:'agColumnsToolPanel',
            labelKey:"columns",
            iconKey:"columns",
            labelDefault:"Columns",
            width:200,
            minWidth:200,
            maxWidth:200
        },
        {
            id:"filters",
            toolPanel:"agFiltersToolPanel",
            labelKey:"filters",
            iconKey:"filter",
            labelDefault:"Filters",
            width:200,
            minWidth:200,
            maxWidth:200
        }
    ],
    position:"left",
    defaultToolPanel:"filters"
  }
},[]);

let refresh=()=>
{
  gridapi.api.refreshToolPanel();
}

return(
    <div>
    <header>
        <h1>Grid Options - GridSidebar</h1>
    </header>
    <div className="tablecontainer">
    <button onClick={()=>refresh()}>Refresh Tool</button>
    <div className="ag-theme-alpine" style={{height:400}}>
    <AgGridReact
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultCol}
    // sideBar={true} // string-columns,filter boolean-true,false,null
    sideBar={sideBar} //Customized SideBar
    onGridReady={onGridReady}
    rowSelection="multiple"
    />
    </div>
    </div>
    </div>
)
}
export default Grid_Sidebar;