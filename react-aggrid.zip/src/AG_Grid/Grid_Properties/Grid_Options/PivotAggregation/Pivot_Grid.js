import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";
import { useState,useMemo } from "react";

function Pivot_Grid()
{
const [rowdata,setrow]=useState();
const [columnDef,setcolumn]=useState([
    {field:"athlete"},
    {field:"age"},
    {field:"sport",pivot:true},
    {field:"country",rowGroup:true,enableRowGroup:true,hide:true},
    {field:"year"},
    {field:"bronze",aggFunc:"sum"},
    {field:"silver",aggFunc:"sum"},
    {field:"gold",aggFunc:"sum"},
    {field:"total",aggFunc:"sum"}
]);

const defaultColDef=({
     sortable:true,
     flex:1,
     minWidth:200,
     Floatingfilter:true,
     resizable:true
});

const autoGroupColumnDef = useMemo(() => {
    return {
      minWidth: 250,
    };
  }, []);

const onGridReady=()=>
{
 axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
 .then((response)=>
 {
    setrow(()=>
    {
        return [...response.data];
    })
 })
}

 return(
    <div>
        <header>
        <h1>Grid - Pivot_Grid</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:"350px"}}>
          <AgGridReact 
          rowData={rowdata}
          columnDefs={columnDef}
          onGridReady={onGridReady}
          pivotMode={true}
          defaultColDef={defaultColDef}
          autoGroupColumnDef={autoGroupColumnDef}
          />
        </div>
        </div>
    </div>
 )
}

export default Pivot_Grid;