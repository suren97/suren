import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";
import { useEffect,useState,useRef } from "react";

function Grid_Rendering()
{
const [rowdata,setrow]=useState();
const gridRef=useRef(null);
const [columns,setcolumn]=useState([
    {field:"athlete"},
    {field:"age"},
    {field:"country"},
    {field:"bronze"},
    {field:"silver"},
    {field:"gold"},
    {field:"total"}
]);

const defaultColDef=({
    sortable:true,
    filter:true
});

const onGridReady=()=>
{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
     setrow(()=>{
        return [...response.data];
     })
  })
}

const Flashrows=()=>
{
let data=gridRef.current.props.rowData;
let updated;
   updated=rowdata.map((v,i)=>
    {
        if(v.age>20)
        {
            v.age="updated";
        }
        return v;
    })
    console.log(updated)
   gridRef.current.api.applyTransaction({update:updated})
}

return(
    <div>
    <header>
    <h1>Grid - Rendering</h1>
    </header>
    <div className="tablecontainer">
    <button onClick={()=>Flashrows()}>Update Rows</button>
    <div className="ag-theme-alpine" style={{height:400}}>
    <AgGridReact
    ref={gridRef}
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultColDef}
    animateRows={true}
    enableCellChangeFlash={true}
    onGridReady={onGridReady}
    // enableRtl={true}
    // cellFadeDelay={5000}
    // cellFlashDelay={5000}
     />
    </div>
    </div>
    </div>
)
}
export default Grid_Rendering;