import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css"
import { useState,useEffect, useCallback, useMemo,useRef} from "react";
import axios from "axios";
import { useSelector,useDispatch } from "react-redux";
import { Button } from "@mui/material";

function Review_Grid()
{
const [rowdata,setrow]=useState([]);
const GridRef=useRef(null);
const [columnDefs,setcolumn]=useState([
    {field:"make"},
    {field:"model"},
    {field:"price"}
]);
const state=useSelector((state)=> state.Griddata.data );
console.log("states",state);

let InsertRows=()=>
{
    for(var i=0;i<10;i++)
    {
        setrow((prev)=>
        {
            return [...prev,{make:"ford",model:"v2",price:75000,value:i}]
        })
    }
}

let updateRows=()=>
{
    if(rowdata)
    {
        rowdata.map((v,i)=>
        {
            if(v.model=="v2")
            {
               v.model="v4";
               GridRef.current.api.applyTransaction({update:[v]})
            }
        })
    }
}

let DeleteRows=()=>
{
    if(rowdata)
    {
        GridRef.current.api.applyTransaction({remove:rowdata})
    }
}

const defaultColDef=({
    flex:1,
    sortable:true
}); 

 return(
    <div>
        <header>
            <h1>Grid-Review</h1>
        </header>
        <div className="tablecontainer">
            <Button style={{margin:10}} variant="contained" color="success" onClick={()=>InsertRows()}>ADD</Button>
            <Button style={{margin:10}} variant="contained" color="primary" onClick={()=>updateRows()}>Update</Button>
            <Button style={{margin:10}} variant="contained" color="error" onClick={()=>DeleteRows()}>Delete</Button>
            <div className="ag-theme-alpine" style={{height:350}}>
            <AgGridReact
            ref={GridRef}
            rowData={rowdata}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            animateRows={true}
            enableCellChangeFlash={true}
            />
            </div>
        </div>
    </div>
 )
}

export default Review_Grid;