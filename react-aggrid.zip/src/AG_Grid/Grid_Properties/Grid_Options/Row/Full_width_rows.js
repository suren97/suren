import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";
import { useEffect,useState,useRef } from "react";

function Full_width_rows()
{
const [rowdata,setrow]=useState();
const gridRef=useRef(null);
const [columns,setcolumn]=useState([
    {field:"athlete"},
    {field:"age"},
    {field:"country"},
    {field:"bronze"},
    {field:"silver"},
    {field:"gold"},
    {field:"total"}
]);

const defaultColDef=({
    sortable:true,
    filter:true
});

const onGridReady=()=>
{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
     setrow(()=>{
        return [...response.data];
     })
  })
}

const isFullWidthRow=(params)=>
{
   return params.rowNode.data.country==="Russia";
}

const fullWidthCellRenderer=(params)=>
{
  return (
    <div>
    <span className="spancont">{params.data.athlete}</span>
    <span className="spancont">{params.data.country}</span>
    </div>
  )
}

return(
    <div>
    <header>
    <h1>Grid - Full Width Rows</h1>
    </header>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:400}}>
    <AgGridReact
    ref={gridRef}
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultColDef}
    isFullWidthRow={isFullWidthRow}
    fullWidthCellRenderer={fullWidthCellRenderer}
    onGridReady={onGridReady}
     />
    </div>
    </div>
    </div>
)
}
export default Full_width_rows;