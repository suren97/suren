import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";
import {useState,useRef, useEffect,useMemo, useCallback} from "react";

function Row_Grouping()
{
    const [rowdata,setrow]=useState();
    const gridRef=useRef(null);
    const [columns,setcolumn]=useState([
        // {
        //     headerName:"Country",
        //     showRowGroup:"country",
        //     cellRenderer:"agGroupCellRenderer",
        //     minWidth:200,
        //     maxWidth:400
        // },
        // {
        //     headerName:"Year",
        //     showRowGroup:"year",
        //     cellRenderer:"agGroupCellRenderer"
        // },
        {field:"athlete"},
        {field:"age"},
        {field:"country",rowGroup:true,hide:true},
        {field:"year",rowGroup:true,hide:true},
        {field:"sport"},
        {field:"bronze",aggFunc:"sum"},
        {field:"silver",aggFunc:"sum"},
        {field:"gold",aggFunc:"sum"},
        {field:"total",aggFunc:"sum"}
    ]);
    // const groupDisplayType="singleColumn";->used for grouping the single columns
    // const groupDisplayType="groupRows";->used for grouping the columns but occupies the fullwidth of the rows
    // const groupDisplayType="multipleColumns";->used for grouping the columns it occupies the multiple columns for grouping
    // const groupDisplayType="custom" ->It is customizable grouping in which we can select the columns that where to group
    const groupDisplayType="custom";

    const defaultColDef=({
        sortable:true,
        filter:true,
        flex:1
    });   

    // const autoGroupColumn=useMemo(()=>
    // {
    // return{
    //  minWidth:300,
    //  cellRendererParams:{
    //     footerValueGetter:(params)=>{
    //         console.log(params)
    //     }
    //  }    
    // }
    // },[]);
     
    const onGridReady=(params)=>
    {
        axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
        .then((response)=>{
           setrow(()=>{
              return [...response.data];
           })
        })
    }

    const autoGroupColumnDef = useMemo(() => {
        return {
          minWidth: 300,
          cellRendererParams: {
            footerValueGetter: (params) => {
              const isRootLevel = params.node.level === -1;
              if (isRootLevel) {
                return "Grand Total"
              }
              return `Sub Total (${params.value})`;
            },
          },
        };
      }, []);

    const getRowStyle=(params)=>
    {
        if(params.node.footer)
        {
            return {fontWeight:'bold',color:'white',backgroundColor:'green'};
        }
    }
    
    return(
        <div>
        <header className="headersample">
        <h1>Grid - Row Grouping (Custom)</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:400}}>
        <AgGridReact
        ref={gridRef}
        rowData={rowdata}
        columnDefs={columns}
        defaultColDef={defaultColDef}
        onGridReady={onGridReady}
        // groupDisplayType={groupDisplayType}
        // groupHideOpenParents={true}
        // isGroupOpenByDefault={isGroupOpenByDefault}
        groupIncludeFooter={true}
        groupIncludeTotalFooter={true}
        suppressAggFuncInHeader={true}
        // suppressContextMenu={true}
        autoGroupColumnDef={autoGroupColumnDef}
        getRowStyle={getRowStyle}
        // showOpenedGroup={true}
         />
        </div>
        </div>
        </div>
    )
}

export default Row_Grouping;