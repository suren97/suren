import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";
import { useEffect,useState} from "react";
import Row_Grouping from "../Row/Row_Grouping";

function Row_style()
{
const [rowdata,setrow]=useState();
const columnDefs=[
     {field:"athlete"},
     {field:"age"},
     {field:"country"},
     {field:"year"},
     {field:"sport"}
];

useEffect(()=>
{
    axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>{
       setrow(()=>{
          return [...response.data];
       })
    })
},[]);

const getstyle=()=>
{
    let elem=document.getElementsByTagName("p");
    elem[0].style.overflowX="scroll";
    // elem[0].style.whiteSpace="nowrap";
    // console.log(elem)
}

const defaultColDef=({
    sortable:true,
    flex:1,
    cellClass:p=>
    {
      console.log(p)
    }
});

const getRowStyle=(params)=>
{
  if(params.rowIndex%2 === 0)
  {
    return {fontWeight:"bold"}
  }
}

return(
    <div>
        <header>
            <h1>Grid - RowStyle</h1>
        </header>
        {/* <button onClick={()=>getstyle()}>Apply</button> */}
        <div className="tablecontainer">
            <div className="ag-theme-alpine" style={{height:300}}>
            <AgGridReact
            rowData={rowdata}
            defaultColDef={defaultColDef}
            columnDefs={columnDefs}
            getRowStyle={getRowStyle}
            />
            </div>
        </div>
    </div>
)
}
export default Row_style;