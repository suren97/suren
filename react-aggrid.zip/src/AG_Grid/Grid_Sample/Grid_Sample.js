import {AgGridReact} from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import axios from "axios";


function Grid_sample()
{
const gridRef=useRef(null);
const [rowdata,setrow]=useState([
    {
      id:1,
      Empid:1233,
      Name:"Jagan",
      email:"jagan@gmail.com",
      status:"Active"
    },
    {
        id:2,
        Empid:1234,
        Name:"Akash",
        email:"akash@gmail.com",
        status:"Inactive"
    },
    {
        id:3,
        Empid:1235,
        Name:"Williams",
        email:"william@gmail.com",
        status:"Active"
    },
    {
        id:4,
        Empid:1236,
        Name:"Kishore",
        email:"kishore@gmail.com",
        status:"Active"
    },
    {
        id:5,
        Empid:1237,
        Name:"Rajesh",
        email:"rajesh@gmail.com",
        status:"Inactive"
    },
    {
        id:6,
        Empid:1238,
        Name:"Lokesh",
        email:"lokesh@gmail.com",
        status:"Active"
    },
    {
        id:7,
        Empid:1239,
        Name:"vinoth",
        email:"vinoth@gmail.com",
        status:"Active"
    },
    {
        id:8,
        Empid:1240,
        Name:"lewis",
        email:"lewis@gmail.com",
        status:"Active"
    }
]);

const [columns,setcolumns]=useState([
    {field:"id"},
    {field:"Empid"},
    {field:"Name"},
    {field:"email"},
    {
        field:"status",
        cellRenderer:p=>dispdot(p)
    },
    {
        headerName:"Double Click to change Action",
        field:"status",
        editable:true,
        cellEditorSelector:p=>{
            return {
                component:"agRichSelectCellEditor",
                params:{values:["Active","Inactive"]},
                popup:true,
            }
        }
    }
]);

function dispdot(p)
{
    if(p.type === "cellValueChanged")
    {
    gridRef.current.api.applyTransaction({update:[p.data]});
    // setupd(1);
    }
    if(p.data.status==="Active")
    {
       return(
          <span className="statgrncircle"></span>
       ) 
    }
    else
    {
        return(
            <span className="statredcircle"></span>
        )    
    }
}

const defaultCol=({
    flex:1,
    wrapHeaderText: true,
});

const onCellValueChanged=p=>
{
  if(p.value)
  {
    dispdot(p);
  }
}

return(
    <div>
    <header>
    <h1>Grid_Task</h1>
    </header>
    <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:300}}>
            <AgGridReact
            ref={gridRef}
            rowData={rowdata}
            columnDefs={columns}
            defaultColDef={defaultCol}
            onCellValueChanged={onCellValueChanged}
            />
            </div>
            </div>
    </div>
)
}
export default Grid_sample;