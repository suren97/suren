import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import * as XLSX from 'xlsx';
import { useState } from "react";

function Import_Excel()
{
const [rowdata,setrow]=useState();
const [columns,setcolumn]=useState([
    {field:"athlete"},
    {field:"sport"},
    {field:"year"},
    {field:"date"},
    {field:"bronze"},
    {field:"silver"},
    {field:"gold"},
    {field:"total"}
]);
const defaultCol=({
    flex:1
});

const handleExcel=async(e)=>
{
  let files=e.target.files[0];
  const data=await files.arrayBuffer();
  const workbook=XLSX.read(data);
  const worksheet=workbook.Sheets[workbook.SheetNames[0]];
  const jsonData=XLSX.utils.sheet_to_json(worksheet,{
    header:2,
  });
  console.log(jsonData);
  setrow(jsonData);
}

return(
    <div>
        <header>
            <h1>AG-Grid Import Excel</h1>
        </header>
        <div className="ag-theme-alpine" style={{height:300,width:"99%",margin:"5% auto"}}>
        <div className="excelcont">
        <label className="exlabel"><b>Upload the Excel file:</b></label>
        <input type="file" onChange={(e)=>handleExcel(e)} />
        </div>
            <AgGridReact
            columnDefs={columns}
            rowData={rowdata}
            defaultColDef={defaultCol}
            />
        </div>
    </div>
 )
}

export default Import_Excel;