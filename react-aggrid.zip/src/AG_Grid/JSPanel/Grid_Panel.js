import { jsPanel } from "jspanel4";

function Grid_Panel()
{
return(
    <div>
        <header>
        <h1>AG-Grid Panel</h1>
        </header>
    </div>
)
}

export default Grid_Panel;