import { AgGridReact } from "ag-grid-react";
import {useState,useMemo} from "react";
import axios from "axios";

function Practice_Grid1()
{
const [rowdata,setrow]=useState();
const [columns,setcolumns]=useState([
    {field:"make"},
    {field:"model"},
    {field:"price"}
]);
const defaultCol=({
    sortable:true,
    flex:1
})


const onGridReady=()=>
{
 axios.get("https://www.ag-grid.com/example-assets/row-data.json")
 .then((response)=>{
    setrow(response.data)
 })
}

const getContextMenuItems=(params)=>
{
    console.log(params)
 var result=[
    {
        name:"Capacity",
        action:()=>
        {
            alert("clicked the capacity button");
        },
        tooltip:"Loading...",
        checked:true,
        disabled:true
        // icon
        // cssClasses
        // checked
        // disabled
    },
    "separator",
    {
        name:"SubMenu's",
        subMenu:[{
            name:"Data",
            action:()=>
            {
                alert(params.value);
            },
            shortcut:"Alt + W"
        }]
    },
    "autoSizeAll",
    "expandAll",
    "contractAll",
    "separator",
    "export",
    "excelExport",
    "csvExport",
    "separator",
    "copy",
    "copywithheaders",
    "paste",
    "resetColumns"
 ];
 return result;
}

const popupParent=useMemo(()=>
{
 return document.querySelector("body");
},[]);

return(
    <div>
        <header>
            <h1>Practicing Grid-1</h1>
        </header>
        <div className="tablecontainer">
            <div className="ag-theme-alpine" style={{height:300}}>
                <AgGridReact
                rowData={rowdata}
                animateRows={true}
                defaultColDef={defaultCol}
                columnDefs={columns}
                // suppressMenuHide={true}
                popupParent={popupParent}
                // allowContextMenuWithControlKey={true}
                // suppressContextMenu={false}
                getContextMenuItems={getContextMenuItems}
                onGridReady={onGridReady}
                />
            </div>
        </div>
    </div>
 )
}
export default Practice_Grid1;