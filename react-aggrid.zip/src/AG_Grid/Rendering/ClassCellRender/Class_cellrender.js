import React,{Component} from "react";
import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";
import Showbutton from "./Showbutton";
import Showcase from "./Showcase";

const defaultColumn=({
    sortable:true,
    filter:true,
});

class ClassCellRender extends Component
{
  constructor(props)
  {
    super(props)
    this.state={
        rowdata:[],
        columns:[
            {field:"athlete"},
            {field:"age"},
            {field:"year"},
            {field:"bronze",cellRenderer:Showcase},
            {field:"silver",cellRenderer:Showcase},
            {field:"gold",cellRenderer:Showcase},
            {field:"total",cellClass:""}
            // {field:"total",cellRenderer:Showbutton}
        ],
    }
  };
  
componentDidMount()
{
    axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>{
      this.setState((state)=>{
         return {...state,rowdata:response.data}
      })
  });
}

render()
{
    return(
        <div>
        <header>
        <h1 id="cell">Class CellRender</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:300}}>
        <AgGridReact
        rowData={this.state.rowdata}
        columnDefs={this.state.columns}
        defaultColDef={defaultColumn}
        />
        </div>
        </div>
        </div>
    )
}
}

export default ClassCellRender;