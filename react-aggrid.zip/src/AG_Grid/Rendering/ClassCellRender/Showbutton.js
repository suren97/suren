import React,{Component} from "react";


class Showbutton extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            data:Showbutton.getValuefromProps(props)
        }
    }
static getDerivedStateFromProps(nextprops)
{
    return {
        data:Showbutton.getValuefromProps(nextprops)
    };
}
render()
{
    const {data}=this.state;
    return(
        <button onClick={()=>alert("The Total Medal Won is:"+data)}>Click total</button>
    )
}

static getValuefromProps(params)
{
// CellRenderer Params
// console.log("Value:"+params.value);
// console.log("ValueFormatted",params.valueFormatted)
// console.log("fullWidth",params.fullWidth);
// console.log("Pinned",params.pinned);
// console.log("Node",params.node);
// console.log("Data",params.data)
// console.log("rowIndex",params.rowIndex);
// console.log("ColDef",params.colDef);
// console.log("Column",params.column);
// console.log("EGridcell",params.eGridCell)
// console.log("Parentvalue",params.eParentOfValue)
// console.log("getValue",params.getValue());
// console.log("setValue",params.setValue());
// console.log("formatValue",params.formatValue());
// console.log("RefreshCell",params.refreshCell());
// console.log("Api",params.api);
// console.log("ColumnApi",params.columnApi);
// console.log("context",params.context);
  return params.value;
}
}

export default Showbutton;
