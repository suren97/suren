import React,{Component} from "react";

class Showcase extends Component
{
    constructor(props)
    {
        super(props);
        this.state={
           code:Showcase.getValuefromprops(props)
        }
    }
    render()
    {
        const {code}=this.state;
        return code;
    }
static getValuefromprops(params)
{
  return new Array(parseInt(params.value)).fill("#").join("");  
}
}

export default Showcase;