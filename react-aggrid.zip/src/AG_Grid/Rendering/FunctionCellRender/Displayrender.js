function Displayrender(props)
{
return(
    <div>
    <button onClick={()=>alert("The Total Medal won is"+" "+props.value)}>Click Total</button>
    </div>
)
}

export default Displayrender;