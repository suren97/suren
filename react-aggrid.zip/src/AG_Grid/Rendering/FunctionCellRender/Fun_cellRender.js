import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import axios from "axios";
import { useEffect,useState } from "react";
import Displayrender from "./Displayrender";
import StarRender from "./StarRender";

function FunCellRender()
{
const [rowdata,setrow]=useState();
const [columns,setcolumn]=useState([
    {field:"athlete"},
    {field:"age"},
    {field:"country"},
    {field:"bronze",cellRenderer:StarRender},
    {field:"silver",cellRenderer:StarRender},
    {field:"gold",cellRenderer:StarRender},
    {field:"total",cellRenderer:Displayrender}
]);

const defaultColDef=({
    sortable:true,
    filter:true
});

useEffect(()=>{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
     setrow(response.data);
  })
},[]);

return(
    <div>
    <header>
    <h1>Function CellRendering</h1>
    </header>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:400}}>
    <AgGridReact
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultColDef}
    animateRows={true}
     />
    </div>
    </div>
    </div>
)
}
export default FunCellRender;