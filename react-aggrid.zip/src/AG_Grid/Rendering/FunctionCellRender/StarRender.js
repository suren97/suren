import { useState } from "react";

function StarRender(props)
{
return <span>{new Array(parseInt(props.value)).fill("#").join("")}</span>
}

export default StarRender;