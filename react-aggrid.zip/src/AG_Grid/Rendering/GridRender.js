import { AgGridReact } from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import { useEffect,useRef,useState } from "react";
import axios from "axios";
import ClassCellRender from "./ClassCellRender/Class_cellrender";

function GridRender()
{
const [rowdata,setrow]=useState();
const [columns,setcolumn]=useState([
    {field:"athlete"},
    {field:"age"},
    {field:"country"},
    {field:"year"},
    {field:"bronze"},
    {field:"gold"},
    {field:"silver"},
    {field:"total"}
]);

function Agerender(params)
{
   return params.value;
}

const defaultColDefs=({
    sortable:true,
    filter:true,
    cellRenderer:Agerender,
    rowPinned:"top"
});

useEffect(()=>{
 axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
 .then((response)=>{
   setrow(()=>
   {
    return [...response.data];
   })
 })
},[]);

let cellListener=(e)=>
{
  console.log(e)  
}

return(
        <div>
        <header>
        <h1>Cell Rendering</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:400}}>
        {/* <ClassCellRender /> */}
        <AgGridReact
        onCellClicked={(e)=>cellListener(e)}
        rowData={rowdata}
        columnDefs={columns}
        defaultColDef={defaultColDefs}
        />
        </div>
        </div>
        </div>
    )
}

export default GridRender;