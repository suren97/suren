import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import {useState,useMemo,useCallback} from "react";

function Sample_workout()
{
const [rowdata,setrow]=useState();
const [api,setapi]=useState();

const [columns,setcolumn]=useState([
    {field:"name"},
    {field:"username"},
    {field:"email"},
    {
        headerName:"Street",
        field:"address.street"
    },
    {
        headerName:"City",
        field:"address.city"
    },
    {
        headerName:"Age",
        field:"age",
        cellClassRules:{
            greencolor:(params)=>
            {
               return params.value < 25;
            }
        }
    }
]);

const excelStyles=useMemo(()=>
{
    return [ 
        {
        id:"greencolor",
        interior:{
           pattern:"Solid",
           color:"#90EE90"
        },
        font:{
            bold:true,
            color:"#FF0000"
        }
    }
]
},[]);

const onGridReady=(params)=>
{
 setapi(params.api);
  axios.get("https://jsonplaceholder.typicode.com/users")
  .then((response)=>{
     setrow(()=>
     {
        if(response.data)
        {
            response.data.map((v,j)=>
            {
               if(v.id<=5)
               {
                 v.age=18
               }
               else
               {
                 v.age=25
               }
            })
        }
        return [...response.data];
     })
  })
}

const defaultCol=({
    flex:1,
    editable:true
})

const exportcsv=()=>
{
  api.exportDataAsExcel();
}

const gridOptions=useCallback((params)=>
{
    console.log(params)
},[]);

const getRowStyle=useCallback((p)=>
{
    console.log(p)
},[]);

 return(
    <div>
    <header>
    <h1>AG-Grid EditType</h1>
    </header>
        <div className="tablecontainer">
        <button className="excelbtn" onClick={()=>exportcsv()}>Export CSV</button>
        <div className="ag-theme-alpine" style={{height:300}}>
        <AgGridReact
        onGridReady={onGridReady}
        rowData={rowdata}
        columnDefs={columns}
        defaultColDef={defaultCol}
        excelStyles={excelStyles}
        gridOptions={gridOptions}
        getRowStyle={getRowStyle}
        singleClickEdit={true}
        />
        </div>
        </div>
    </div>
 )
}
export default Sample_workout;