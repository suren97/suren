import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { useState,useMemo } from "react";

function Cell_Renderer()
{

const [rows,setrow]=useState();

const imgrender=p=>
{
 if(p.colDef.id=="max")
 {
  return (
    <div>
    <img src="https://www.ag-grid.com/example-assets/weather/fire-plus.png"/>&nbsp;&nbsp;{p.value}
    </div>
  )
 }
 else if(p.colDef.id==="min")
 {
    return (
        <div>
        <img src="https://www.ag-grid.com/example-assets/weather/fire-minus.png"/>&nbsp;&nbsp;{p.value}
        </div>
      )
 }
 else if(p.colDef.id=="rain")
 {
    return (
        <div>
        <img src="https://www.ag-grid.com/example-assets/weather/rain.png"/>&nbsp;&nbsp;{p.value}
        </div>
      )
 }
 else if(p.colDef.id=="sun")
 {
    return (
        <div>
        <img src="https://www.ag-grid.com/example-assets/weather/sun.png"/>&nbsp;&nbsp;{p.value}
        </div>
      )
 }
}

const [columns,setcolumn]=useState([
    {field:"group",type:"totalcolumn",rowGroup:true,hide:true},
    {field:"Month",type:"valuecolumn"},
    {
        field:"Max temp (C)",
        id:"max",
        type:"valuecolumn",
        cellRenderer:p=>imgrender(p)
    },
    {
        field:"Min temp (C)",
        id:"min",
        type:"valuecolumn",
        cellRenderer:p=>imgrender(p)
    },
    {
        field:"Rainfall (mm)",
        id:"rain",
        type:"valuecolumn",
        cellRenderer:p=>imgrender(p)
    },
    {
        field:"Sunshine (hours)",
        id:"sun",
        type:"valuecolumn",
        cellRenderer:p=>imgrender(p)
    },
    {
        field:"total",
        valueGetter:'getValue("Max temp (C)")+getValue("Min temp (C)")+getValue("Rainfall (mm)")+getValue("Sunshine (hours)")'
    }
]);

const columntype=useMemo(()=>{
    return{
      valuecolumn:{
        aggFunc:"sum",
        valueParser:'Number(newValue)',
        editable:true
      }
    }
},[]);

const defaultCol=({
    flex:1
});

const onGridReady=()=>
{
  axios.get("https://www.ag-grid.com/example-assets/weather-se-england.json")
  .then((response)=>{
      setrow(()=>
      {
        if(response.data)
        {
            response.data.map((v,i)=>
            {
                v.group=""
                v.total=""
            })
        }
        return [...response.data];
      })
  })    
}

return(
    <div>
        <header>
        <h1>CellRenderer - Components</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:350}}>
        <AgGridReact
        rowData={rows}
        columnDefs={columns}
        defaultColDef={defaultCol}
        onGridReady={onGridReady}
        groupDefaultExpanded={1}
        columnTypes={columntype}
        suppressAggFuncInHeader={true}
        enableCellChangeFlash={true}
        animateRows={true}
        />
        </div>
        </div>
    </div>
)
}
export default Cell_Renderer;