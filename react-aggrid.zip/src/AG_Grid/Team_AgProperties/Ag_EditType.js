import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useEffect,useState,useCallback} from "react";
import axios from "axios";

function Ag_EditType()
{

const [columns,setcolumn]=useState([
    {field:"make"},
    {field:"model"},
    {
        field:"field2",
        headerName:"ReadOnly",
        editable:false
    },
    {field:"price"},
    {
        field:"field3",
        headerName:"suppressNavigable",
        suppressNavigable:true  // Cannot tab the columns
    },
    {
        field:"field4",
        editable:false,
    }
]);

const defaultCol=({
    editable:true,
    flex:1
});

const getrow=()=>
{
    let rowdata=[];
    for(var i=1;i<20;i++)
    {
     rowdata.push({
        make:"Toyota",
        model:"Celica",
        price:32000,
        field2:"aa",
        field3:"cc",
        field4:"dd"
     })
     rowdata.push({
        make:"Ford",
        model:"Mondeo",
        price:42000,
        field2:"aa",
        field3:"cc",
        field4:"dd"
     })
     rowdata.push({
        make:"Porsche",
        model:"Boxster",
        price:72000,
        field2:"aa",
        field3:"cc",
        field4:"dd"
     });
    }
    return rowdata;
};
const [rowdata,setrow]=useState(getrow());

const oncellvaluechanged=(p)=>
{
  console.log("cellValueChanged:",p);
}

const onrowvaluechanged=(p)=>
{
  console.log("rowValueChanged:"+p.data.make+","+p.data.model+","+p.data.price);
}


return(
    <div>
    <header>
    <h1>AG-Grid EditType</h1>
    </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:450}}>
        <AgGridReact 
        rowData={rowdata}
        columnDefs={columns}
        defaultColDef={defaultCol}
        editType={"fullRow"}
        onCellValueChanged={oncellvaluechanged}
        onRowValueChanged={onrowvaluechanged}
        // suppressClickEdit={true}
        />
        </div>
        </div>
    </div>
  )
}
export default Ag_EditType;