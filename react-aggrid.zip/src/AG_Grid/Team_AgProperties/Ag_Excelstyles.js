import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import {useEffect, useState,useMemo, useRef,useCallback} from "react";
import axios from "axios";

function AG_Excelstyle()
{
const gridRef=useRef(null);
const [rowdata,setrow]=useState();
const [gridApi,setApi]=useState();
const [columns,setcolumn]=useState([
    {
        headerName:"Athlete Details",
        cellClass:"ag-header-viewport",
        children:[
              {field:"athlete"},
              {
                field:"age",
                cellClassRules:{
                    greencolor:(params)=>{
                       return params.value < 23;
                    },
                }
              },
              {
                field:"year",
              },
              {field:"date"},
              {field:"sport"},
              {
                field:"Rs",
                valueFormatter:p=>
                {
                  return `$${p.value}`
                },
                cellClass:"currencyFormat",
              }
        ]
    },
    {
        headerName:"Medals Won",
        children:[
            {
                field:"bronze",
            },
            {
                field:"silver"
            },
            {
                field:"gold",
            },
            {
                field:"total",
                cellClassRules:{
                    medborder:(params)=>{
                        return params.data.total > 5;
                    },
                },
            }
        ]
    }
]);

const defaultCol=({
     sortable:true,
     filter:true,
     flex:1,
     cellClassRules:{
        exclbg:(params)=>{
            return params.rowIndex % 2 === 0;
        }
     }
});

const onGridReady=useCallback((params)=>
{
  setApi(params.api);
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>
   {
     setrow(()=>
     {
        if(response.data)
        {
            response.data.map((v,i)=>
            {
                v.Rs=100
            })
        }
        return [...response.data];
     })
  })
},[]);

const excelStyles=useMemo(()=>
{
    return [
        {
            id:'greencolor',
            interior:{
                 color:"#b5e6b5",
                 pattern:"Solid"
            },
            font:{
                bold:true,
                color:"#FF0000",
                shadow:true,
                verticalAlign:'Subscript'
            }
        },
        {
            id:"ag-header-viewport",
            interior:{
                pattern:"Solid",
                color:"lightblue"
            }
        },
        {
            id:"exclbg",
            interior:{
                pattern:"Solid",
                color:"#d3d3d3"
            },
            alignment:{
               vertical:"Center"
            }
        },
        {
          id:"currencyFormat",
          numberFormat:{
            format:"$ #,##0.00"
          },
          protection:{
            protected:true
          }
        },
        {
            id:"medborder",
            borders:{
                borderBottom:{
                    color:"black",
                    lineStyle:"Continuous",
                    weight:2
                },
                borderLeft:{
                    color:"black",
                    lineStyle:"Continuous",
                    weight:2
                },
                borderRight:{
                    color:"black",
                    lineStyle:"Continuous",
                    weight:2
                },
                borderTop:{
                    color:"black",
                    lineStyle:"Continuous",
                    weight:2
                }
            }
        }
    ]
},[]);

const exportcsv=useCallback((params)=>
{
  gridRef.current.api.exportDataAsExcel();
},[]);

const pinnedTopRowdata=[
    {
        athlete:"James Bond",
        age:25,
        year:2007,
        date:"24/10/2007",
        sport:"Wrestling",
        bronze:4,
        silver:2,
        gold:10,
        total:16,
        Rs:100
    }
];

const pinnedBottomRowdata=[
    {
      athlete:"Morris",
      age:30,
      year:2008,
      date:"23/08/2008",
      sport:"skirtting",
      bronze:0,
      silver:4,
      gold:2,
      total:6,
      Rs:100
    }
];

return(
    <div>
    <header>
        <h1>Excel Styles</h1>
        </header>
        <div className="tablecontainer">
        <button className="excelbtn" onClick={()=>exportcsv()}>Export CSV</button>
        <div className="ag-theme-alpine" style={{height:450}}>
        <AgGridReact
         ref={gridRef}
         rowData={rowdata}
         columnDefs={columns}
         defaultColDef={defaultCol}
         excelStyles={excelStyles}
         onGridReady={onGridReady}
         pinnedTopRowData={pinnedTopRowdata} //used for pinning the row at the top
         pinnedBottomRowData={pinnedBottomRowdata} //used for pinning the column at the top
        />
        </div>
        </div>
        </div>
  )
}

export default AG_Excelstyle;