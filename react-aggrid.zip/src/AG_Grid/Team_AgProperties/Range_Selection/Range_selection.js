import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { useState,useRef, useCallback } from "react";

function Range_selection()
{
    const [columns,setcolumn]=useState([
           {field:"athlete"},
           {field:"country"},
           {field:"sport"},
           {field:"age"},
           {field:"year"},
           {field:"silver"},
           {field:"gold"},
           {field:"total"}
        ]);
    const [rowdata,setrow]=useState();
    const gridRef=useRef(null);

const onGridReady=p=>
{
    axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>{
      setrow(()=>{ 
        // if(response.data)
        // {
        //     response.data.map((v,i)=>
        //     {
        //         v.id=i;
        //     })
        // }
          return [...response.data];
      })
    })
}

const onRangeSelectionChanged=e=>
{
   console.log("Range",e);
   console.log("GetCellRanges",gridRef.current.api.getCellRanges());
}

const clearSelection=()=>
{
 gridRef.current.api.clearRangeSelection();
}

const addRange=useCallback(()=>
{
    gridRef.current.api.addCellRange({
        rowStartIndex:0,
        rowEndIndex:10,
        columns:["age"]
    })
},[]);

return(
    <div>
        <div className="tablecontainer">
            <button onClick={clearSelection}>ClearRange</button>
            <button onClick={addRange}>Add Range</button>
            <div className="ag-theme-alpine" style={{height:400}}>
                <AgGridReact
                ref={gridRef}
                 rowData={rowdata}
                 columnDefs={columns}
                 onGridReady={onGridReady}
                 enableRangeSelection={true}
                 enableRangeHandle={true}
                //  suppressMultiRangeSelection={true}
                 onRangeSelectionChanged={onRangeSelectionChanged}
                />
            </div>
        </div>
    </div>
)
}
export default Range_selection;