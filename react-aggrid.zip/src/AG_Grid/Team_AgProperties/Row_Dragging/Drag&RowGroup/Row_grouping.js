import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { useState } from "react";

function Row_DragGroup()
{
const [rowdata,setrow]=useState();

var rowDrag=(p)=>
{
  return !p.node.group;
}

const columns=[
    {field:"athlete",rowDrag:rowDrag},
    {field:"country",rowGroup:true,hide:true},
    {field:"year"},
    {field:"date"},
    {field:"sport"}
];

const [gridApi,setapi]=useState();

const defaultColDef=({
      flex:1
});

const GridReady=(params)=>
{
  setapi(params.api)
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>
  {
    response.data.length=50;
    setrow(response.data)
  })
}
if(rowdata)
{
var immutableStore=[...rowdata];
}

const onRowDragMove=(e)=>
{
  var movdata=e.node.data;
  var ovrdata=e.overNode.data;
  var ovrnode=e.overNode;
  var grpcountry;
  if(ovrnode.group)
  {
    grpcountry=ovrnode.key;
  }
  else
  {
    grpcountry=ovrnode.data.country;
  }
  var needtoChngparnt=movdata.country!==grpcountry;
  if(needtoChngparnt)
  {
    var moved=movdata;
    moved.country=grpcountry;
    gridApi.applyTransaction({update:[moved]});
    gridApi.clearFocusedCell();
  }
  var fromindex=immutableStore.indexOf(movdata);
  var toindex=immutableStore.indexOf(ovrdata);
  var movrownode=movdata!==ovrdata;
  var newStore=immutableStore.slice();
  if(movrownode)
  {
    moveinArray(newStore,fromindex,toindex);
    immutableStore=newStore;
    gridApi.setRowData(immutableStore);
  }
  function moveinArray(arr,from,to)
  {
     var ele=arr[from];
     arr.splice(from,1);
     arr.splice(to,0,ele);
  }
}
console.log("rendering");
return(
    <div>
        <header>
            <h1>Grid - Row Dragging and Grouping</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:600}}>
            <AgGridReact
            onGridReady={GridReady}
            columnDefs={columns}
            rowData={rowdata}
            defaultColDef={defaultColDef}
            groupDefaultExpanded={1}
            onRowDragMove={onRowDragMove}
            suppressMoveWhenRowDragging={true}
            />
        </div>
        </div>
    </div>
)
}
export default Row_DragGroup;