import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";

import { useState } from "react";

function Row_Drag()
{
const [gridApi,setgridapi]=useState();
const [columns,setcolumn]=useState([
    {field:"id"},
    {field:"name",rowDrag:true},
    {field:"username"},
    {field:"email"}
]);
const [rowdata,setrowdata]=useState();

const defaultcolDef=({
    sortable:true,
    filter:true,
    flex:1
})

const GridReady=(params)=>
{ 
  setgridapi(params.api); 
  axios.get("https://jsonplaceholder.typicode.com/users")
  .then((response)=>{
     params.api.applyTransaction({add:response.data})
  })
}

const suppressDrag=()=>
{
 gridApi.setSuppressRowDrag(true);
}

const removeDrag=()=>
{
 gridApi.setSuppressRowDrag(false);
}

return(
    <div>
        <header>
            <h1>Row Dragging - Managed Dragging</h1>
        </header>
        <div className="tablecontainer">
        <button className="updbtn" onClick={suppressDrag}>Suppress Row</button>
        <button className="updbtn" onClick={removeDrag}>Remove Suppress Row</button>
            <div className="ag-theme-alpine" style={{height:300}}>
            <AgGridReact
            columnDefs={columns}
            defaultColDef={defaultcolDef}
            rowDragManaged={true}
            enableMultiRowDragging={true}
            rowMultiSelectWithClick={true}
            rowSelection="multiple"
            // suppressMoveWhenRowDragging={true}
            // animateRows={true}
            onGridReady={GridReady}
            />
            </div>
        </div>
    </div>
)
}
export default Row_Drag;