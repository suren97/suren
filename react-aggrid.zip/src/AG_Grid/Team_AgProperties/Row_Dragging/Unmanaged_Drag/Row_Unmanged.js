import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import { useState } from "react";

function Row_Unmanaged()
{
const [rowdata,setrowdata]=useState();
const [gridApi,setgridapi]=useState();
const [column,setcolumn]=useState([
    {field:"id"},
    {field:"name",rowDrag:true},
    {field:"username"},
    {field:"email"}
]);

const GridReady=(params)=>
{
  setgridapi(params.api);
  axios.get("https://jsonplaceholder.typicode.com/users")
  .then((response)=>
  {
    setrowdata(response.data)
    // params.api.applyTransaction({add:response.data})
  })
}

const defaultColDef=({
      sortable:true,
      filter:true,
      flex:1
});

const onRowDragEnter=(e)=>
{
  console.log("RowDragEnter",e)
}

const onRowDragEnd=(e)=>
{
  console.log("RowDragEnd",e)
}
if(rowdata)
{
var immutableStore=[...rowdata];
}

const onRowDragMove=e=>
{
    var movnode=e.node;
    var overNode=e.overNode;
    var rowNeedstomove=movnode !== overNode;
    if(rowNeedstomove)
    {
      var movdata=movnode.data;
      var ovrdata=overNode.data;
      var fromIndex=immutableStore.indexOf(movdata);
      var toIndex=immutableStore.indexOf(ovrdata);
      var newStore=immutableStore.slice();
      moveInArray(newStore,fromIndex,toIndex);
      immutableStore=newStore;
      gridApi.setRowData(newStore);
      gridApi.clearFocusedCell();
    }
function moveInArray(arr,fromInd,toInd)
{
  var ele=arr[fromInd];
  arr.splice(fromInd,1);
  arr.splice(toInd,0,ele);
}
}



return(
    <div>
        <header>
            <h1>Row Dragging - Unmanaged Dragging</h1>
        </header>
        <div className="tablecontainer">
            <div className="ag-theme-alpine" style={{height:300}}>
            <AgGridReact
            rowData={rowdata}
            onGridReady={GridReady}
            columnDefs={column}
            defaultColDef={defaultColDef}
            rowSelection="multiple"
            onRowDragMove={onRowDragMove}
            suppressMoveWhenRowDragging={true}
            // onRowDragEnter={onRowDragEnter}
            // onRowDragEnd={onRowDragEnd}
            // onRowDragLeave={onRowDragLeave}
            />
            </div>
        </div>
    </div>
)
}
export default Row_Unmanaged;