import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import {useState,useEffect,useMemo, useCallback,useRef} from "react";

function Group_select()
{
const [rowdata,setrow]=useState();
const gridRef=useRef();
const [columns,setcolumn]=useState([
//    {
//     field:"athlete",checkboxSelection:true,
//     headerCheckboxSelection:true,
//     headerCheckboxSelectionFilteredOnly:false
//    },
   {field:"country",rowGroup:true,hide:true},
   {field:"sport",rowGroup:true},
   {field:"age"},
   {field:"year"},
   {field:"silver"},
   {field:"gold"},
   {field:"total"}
]);

const defaultCol=({
    sortable:true,
    filter:true,
    flex:1,
});

const checkbox=params=>
{
  return params.node.group === true;
}

const autoGroupCol=useMemo(()=>{
  return{
    headerName:"Group",
    field:"athlete",
    minWidth:400,
    cellRenderer:'agGroupCellRenderer',
    cellRendererParams:{
        checkbox:true
    }
  }
},[]);

useEffect(()=>{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
    setrow(()=>{ 
        return [...response.data];
    })
  })
},[]);

const onselectchanged=(params)=>
{
//   console.log(params.api.getSelectedNodes());
//   console.log(params.api.getSelectedRows());
}
// Enter the number from 0-500
// find the repeating nos..
// Add the given numbers and if the given number is 5 print "red" else "green"

const filterswim=useCallback(()=>
{
  var d=gridRef.current.api.setFilterModel({
    sport:{
        type:"set",
        values:['Swimming'],
    },
    age:{
        type:"set",
        values:['18','20']
    }
  });
},[]);

const clear=()=>
{
   gridRef.current.api.setFilterModel("");
}

const quickFilter=useCallback((e)=>
{
 gridRef.current.api.setQuickFilter(e.target.value);  
},[]);

const onrowselected=useCallback((e)=>
{
    console.log(e.node.data.athlete);
    console.log(e.node.isSelected());
},[]);

const isrowselectable=(val)=>
{
    return val.data ? (val.data.year === 2004 || val.data.year === 2008) : false
  
}
const filteryear=()=>
{
  gridRef.current.api.setFilterModel({
     sport:{
        type:"set",
        values:["Swimming"]
     }
  });
}

const selectfiltered=()=>
{
//    gridRef.current.api.selectAll();
     gridRef.current.api.selectAllFiltered();
}

const deselectall=()=>
{
    gridRef.current.api.deselectAll();
}

const onRowClicked=e=>
{
    console.log(e)
}
// const selectAllFiltered=useCallback((p)=>
// {
//     console.log(p)
// },[]);
const onRowDoubleClicked=e=>
{
    console.log(e)
}

 return(
    <div>
    <header>
    <h1>Grid - RowSelection</h1>
    </header>
    <div className="tablecontainer">
    <button onClick={filteryear}>Filter year 2004 & 2008</button>
    <button onClick={selectfiltered}>Select All</button>
    <button onClick={deselectall}>Deselect All</button>
    <div className="ag-theme-alpine" style={{height:350}}>
    <AgGridReact
    ref={gridRef}
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultCol}
    autoGroupColumnDef={autoGroupCol}
    rowMultiSelectWithClick={true}
    rowSelection="multiple"
    groupSelectsChildren={true}
    suppressRowClickSelection={true}
    groupSelectsFiltered={true}
    suppressRowDeselection={true}
    onRowSelected={onrowselected}
    groupDefaultExpanded={2}
    onRowClicked={onRowClicked}
    onRowDoubleClicked={onRowDoubleClicked}
    />
    </div>
    </div>
    </div>
 )
}
export default Group_select;