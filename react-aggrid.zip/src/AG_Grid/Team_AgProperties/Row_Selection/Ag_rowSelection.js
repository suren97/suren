import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import {useState,useEffect,useMemo, useCallback,useRef} from "react";

function Row_selection()
{
const [rowdata,setrow]=useState();
const gridRef=useRef();
const [columns,setcolumn]=useState([
   {
    field:"athlete",checkboxSelection:true,
    headerCheckboxSelection:true,
    headerCheckboxSelectionFilteredOnly:false
},
   {field:"country"},
   {field:"sport"},
   {field:"age"},
   {field:"date"},
   {field:"silver"},
   {field:"gold"},
   {field:"total"}
]);

const defaultCol=({
    sortable:true,
    filter:true,
    flex:1
});

const checkbox=params=>
{
 return params.node.group === true;
}

// const autoGroupCol=useMemo(()=>{
//   return{
//     headerName:"Group",
//     field:"athlete",
//     minWidth:400,
//     cellRenderer:'agGroupCellRenderer',
//     cellRendererParams:{
//         checkbox
//     }
//   }
// },[]);

useEffect(()=>{
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>{
    setrow(()=>{ 
        return [...response.data];
    })
  })
},[]);

const onselectchanged=(params)=>
{
//   console.log(params.api.getSelectedNodes());
//   console.log(params.api.getSelectedRows());
}
// Enter the number from 0-500
// find the repeating nos ..
// Add the given numbers and if the given number is 5 print "red" else "green"

const filterswim=useCallback(()=>
{
  gridRef.current.api.setFilterModel({
    sport:{
        type:"set",
        values:['Swimming'],
    },
    age:{
        type:"set",
        values:['18','20']
    }
  })
  
},[]);

const clear=()=>
{
   gridRef.current.api.setFilterModel("");
}

const quickFilter=useCallback((e)=>
{
 gridRef.current.api.setQuickFilter(e.target.value);  
},[]);

const onrowselected=useCallback((e)=>
{
  console.log(e.node.data.athlete);
  console.log(e.node.isSelected());
},[]);

 return(
    <div>
    <header>
    <h1>Grid - RowSelection</h1>
    </header>
    <div className="tablecontainer">
    {/* <button onClick={filterswim}>Filter only swimming and age of 18 and 20</button> */}
    {/* <button onClick={filterage}>Filter only age 18 to 20</button> */}
    {/* <button onClick={clear}>Clear</button> */}
    <input type="search" 
    placeholder="quick filter..." 
    id="quickFilter" 
    onChange={(e)=>quickFilter(e)}
    />
    <div className="ag-theme-alpine" style={{height:350}}>
    <AgGridReact
    ref={gridRef}
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultCol}
    // rowSelection="single"  //single row selection
    rowSelection="multiple"  //multi row selection with ctrl
    rowMultiSelectWithClick={true} //select the multi-row with click
    onSelectionChanged={onselectchanged}
    groupSelectsFiltered={true}
    suppressRowClickSelection={true}
    onRowSelected={onrowselected}
    // suppressRowClickSelection={true} //Disable row selection while clicking
    // autoGroupColumnDef={autoGroupCol} //used for grouping the grouped columns in the grid
    groupSelectsChildren={true} //when set it true the grouping column in the grid,will select all the child data if false it will deselect all the child components 
    />
    </div>
    </div>
    </div>
 )
}
export default Row_selection;