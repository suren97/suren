import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useCallback, useState,useRef } from "react";
import axios from "axios";

function Column_sizing()
{
const [gridApi,setApi]=useState();
const [rowdata,setrow]=useState();
const gridRef=useRef(null);
const [columns,setcolumn]=useState([
    {field:"athlete"},
    {field:"age",suppressSizeToFit:true},
    {field:"year",width:100,maxWidth:130,minWidth:70},
    {field:"date"},
    {field:"sport"},
    {field:"bronze"},
    {field:"silver"},
    {field:"gold"},
    {field:"total"}
]);
const defaultCol=({
   filter:true,
   sortable:true,
   flex:1,
   resizable:true
});


let GridReady=(params)=>
{
  setApi(params.api);
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>
  {
   setrow(response.data);
   console.log(response.data.length)
  })
}

let FitCol=()=>
{
    gridApi.sizeColumnsToFit();
}

const onColumnResized=params=>
{
    console.log(params)
}

const autosizeall=useCallback((skipheader)=>
{
 console.log(skipheader);
  const columndata=[];
  gridRef.current.columnApi.getColumns().forEach((col)=>
  {
    columndata.push(col.getId());
  });
  gridRef.current.columnApi.autoSizeColumns(columndata,skipheader)
},[]);

return(
    <div>
        <header>
            <h1>Grid - Column Sizing</h1>
        </header>
        <div className="tablecontainer">
            <button onClick={FitCol}>Size To Fit</button>
            <button onClick={()=>autosizeall(false)}>AutoSize All</button>
            <button onClick={()=>autosizeall(true)}>AutoSize All(Skip header)</button>
            <div className="ag-theme-alpine" style={{height:400}}>
            <AgGridReact
            ref={gridRef}
            columnDefs={columns}
            rowData={rowdata}
            defaultColDef={defaultCol}
            onGridReady={GridReady}
            onColumnResized={onColumnResized}
            skipHeaderOnAutoSize={true}
            />
            </div>
        </div>
    </div>
)
}
export default Column_sizing;