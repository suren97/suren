import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useState,useRef,useMemo } from "react";

function Team_Props()
{
const refdata=useRef(null);
const getRow=()=>
    {
    let rowdata=[];
      for(var i=1;i<16;i++)
      {
       rowdata.push({
        group:i < 6 ? "A" : "B",
        a:(i*324)%100,
        b:(i*253)%100,
        c:(i*643)%100,
        d:(i*137)%100,
       })
    }
    return rowdata;
};
const [rowdata,setrow]=useState(getRow());
const [columns,setcolumn]=useState([
    {field:"a",type:"valueColumn"},
    {field:"b",type:"valueColumn"},
    {field:"c",type:"valueColumn"},
    {field:"d",type:"valueColumn"},
    {
        field:"total",
        type:"totalColumn",
        valueGetter:'getValue("a")+getValue("b")+getValue("c")+getValue("d")'
    }
]);

const defaultCol=({
   flex:1,
   editable:true
});

const onCellValueChanged=(params)=>
{
  refdata.current.api.applyTransaction({update:[params.data]})
}

const coltype=useMemo(()=>
{
    return{
        totalColumn:{
           editable:false
        },
        valueColumn:{
            valueParser:'Number(newValue)',
            cellRenderer:'agAnimateShowChangeCellRenderer',
        }
    }
},[]);

return(
    <div>
    <header>
    <h1>Team Properties</h1>
    </header>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:550}}>
    <AgGridReact
    ref={refdata}
    rowData={rowdata}
    columnDefs={columns}
    defaultColDef={defaultCol}
    onCellValueChanged={onCellValueChanged}
    columnTypes={coltype}
    enableCellChangeFlash={true}
    enterMovesDown={true}  // used for editing the rows in grid and after pressing hit it moves down next row
    enterMovesDownAfterEdit={true}  // if we use enterMovesDown then we must use enterMovesDownEdit for editing the rows
    />
    </div>
    </div>
    </div>
)
}
export default Team_Props;