import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useState } from "react";
import axios from "axios";

function Row_virtual()
{
const [gridApi,setApi]=useState();
const [rowdata,setrow]=useState();
const [columns,setcolumn]=useState([
    {field:"athlete"},
    {field:"age"},
    {field:"year"},
    {field:"date"},
    {field:"sport"},
    {field:"bronze"},
    {field:"silver"},
    {field:"gold"},
    {field:"total"}
]);
const defaultCol=({
   filter:true,
   sortable:true
});


let GridReady=(params)=>
{
  setApi(params.api);
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>
  {
   setrow(response.data);
   console.log(response.data.length)
  })
}

return(
    <div>
        <header>
            <h1>Grid - Row Virtualization</h1>
        </header>
        <div className="tablecontainer">
            <div className="ag-theme-alpine" style={{height:400}}>
            <AgGridReact
            columnDefs={columns}
            rowData={rowdata}
            defaultColDef={defaultCol}
            suppressRowVirtualisation={true}
            suppressColumnVirtualisation={true}
            onGridReady={GridReady}
            />
            </div>
        </div>
    </div>
)
}
export default Row_virtual;