import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useCallback, useState,useRef } from "react";
import axios from "axios";

function Column_Header()
{
const [gridApi,setApi]=useState();
const [rowdata,setrow]=useState();
const gridRef=useRef(null);
const [columns,setcolumn]=useState([
    {
        headerName:"Athlete Details",
        children:[
    {
        field:"athlete",
        enableRowGroup:true,
        headerTooltip:"Athlete name's",
        rowGroupIndex:0,
        suppressSizeToFit:true
    },
    {
        field:"age",
        width:90,
        enableRowGroup:true
    },
    {
        field:"year",
        enableRowGroup:true
    },
    {
        field:"date",
        enableRowGroup:true
    },
    {
        field:"sport",
        enableRowGroup:true
    },
    {
        field:"bronze",
        enableRowGroup:true,
        suppressMenu:true,
        enableValue:true,
        filter:"agNumberColumnFilter",
        aggFunc:"sum"
    },
    {
        field:"silver",
        enableRowGroup:true,
        suppressMenu:true,
        enableValue:true,
        filter:"agNumberColumnFilter",
        aggFunc:"sum"
    },
    {
        field:"gold",
        enableRowGroup:true,
        suppressMenu:true,
        enableValue:true,
        filter:"agNumberColumnFilter",
        aggFunc:"sum"
    },
    {
        field:"total",
        enableRowGroup:true,
        suppressMenu:true,
        enableValue:true,
        filter:"agNumberColumnFilter",
        aggFunc:"sum"
    }
    ]
    }
]);
const defaultCol=({
   filter:true,
   sortable:true,
   resizable:true,
   flex:1,
   wrapHeaderText:true,
   autoHeaderHeight: true,
   editable:true
});


let GridReady=(params)=>
{
  setApi(params.api);
  axios.get("https://www.ag-grid.com/example-assets/olympic-winners.json")
  .then((response)=>
  {
   setrow(response.data);
  })
}

const onCellEditingStarted=e=>
{
 console.log("Started",e)   
}

const onCellEditingStopped=e=>
{
  console.log("Stopped",e)
}

const onCellFocused=e=>
{
  console.log("Focused",e);
}

return(
    <div>
        <header>
            <h1>Grid - Column Header</h1>
        </header>
        <div className="tablecontainer">
            <div className="ag-theme-alpine" style={{height:500}}>
            <AgGridReact
            ref={gridRef}
            columnDefs={columns}
            rowData={rowdata}
            defaultColDef={defaultCol}
            onGridReady={GridReady}
            // groupHeaderHeight={75}
            // headerHeight={190}
            tooltipShowDelay={500}
            onCellEditingStarted={onCellEditingStarted}
            onCellEditingStopped={onCellEditingStopped}
            stopEditingWhenCellsLoseFocus={true}
            suppressAggFuncInHeader={true}
            onCellFocused={onCellFocused}
            />
            </div>
        </div>
    </div>
)
}
export default Column_Header;