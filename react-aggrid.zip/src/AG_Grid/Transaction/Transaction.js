import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";
import {useState,useEffect,useMemo, useCallback,useRef} from "react";

function Transaction()
{
const [rowdata,setrow]=useState();
const gridRef=useRef(null);
const [rowid,setrowid]=useState(0);
const [delrows,setdelrow]=useState();
const [columns,setcolumn]=useState([
    {
        field:"id",
        checkboxSelection:true
    },
    {field:"name"},
    {field:"username"},
    {field:"email"},
    {
        field:"address.street",
        headerName:"Street"
    },
    {
        field:"address.city",
        headerName:"City"
    }
]);

const defaulCol=({
    flex:1
});

let onGridReady=()=>
{
 axios.get("https://jsonplaceholder.typicode.com/users")
 .then((response)=>
 {
   setrow(response.data);
 });
}

const addRow=()=>
{
 let len=rowdata.length;
 if(rowid < len)
 {
  setrowid((prev)=>
  {
   return prev+1;
  })
  gridRef.current.api.applyTransaction({add:[rowdata[rowid]]});
 }
}

const updateRow=()=>
{
  if(rowdata)
  {
    rowdata.map((v,i)=>
    {
        if(i==0)
        {
          return v.username="Suren"
        }
    })
  }
  gridRef.current.api.applyTransaction({update:rowdata})
}

const onselectionchanged=(params)=>
{
 let delrows = params.api.getSelectedRows();
 setdelrow(()=>
 {
    return [...delrows];
 })
}

const DelRow=()=>
{
  console.log(delrows);
  gridRef.current.api.applyTransaction({remove:delrows})
}

return(
    <div>
        <header>
        <h1>Grid - Transaction</h1>
        </header>
        <div className="tablecontainer">
        <button className="addrow" onClick={addRow}>Add New Row</button>
        <button className="updbtn" onClick={updateRow}>Update Row one</button>
        <button className="delbtn" onClick={DelRow}>Delete Selected Rows</button>
            <div className="ag-theme-alpine" style={{height:300}}>
            <AgGridReact
            ref={gridRef}
            onGridReady={onGridReady}
            columnDefs={columns}
            defaultColDef={defaulCol}
            rowSelection="multiple"
            rowMultiSelectWithClick={true}
            onSelectionChanged={onselectionchanged}
            />
            </div>
        </div>
    </div>
)
}

export default Transaction;