import {BrowserRouter,Routes,Route} from "react-router-dom";
import Home from "./Home";
import VesselGM from "./AG_Grid/Basics/VesselGM";
import { Provider } from "react-redux";
import ReduxStore from "./Redux/Store";

function App() {
  return (
    <BrowserRouter>
    <Provider store={ReduxStore}>
    <Routes>
      <Route path="/" element={<VesselGM />}></Route>
    </Routes>
    </Provider>
    </BrowserRouter>
  );
}

export default App;
