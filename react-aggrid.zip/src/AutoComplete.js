import { TextField,Autocomplete,Box,Select,Divider,MenuItem } from "@mui/material";
import { forwardRef, useCallback, useEffect } from "react";
import {useState,useMemo} from "react";

function AutoComplete_Comp(props)
{
 const optionRef=[
    {label:"ss",value:1},
    {label:"sssjnj",value:2},
    {label:"fhbh",value:3},
    {label:"jejfdje",value:4}
 ];
 const [yearopt,setyear]=useState([]);
 const [nameopt,setname]=useState([]);
 const [inputValue,setInputValue]=useState();

 useEffect(()=>
 {
   if(props.data.select=="select")
   {
    let yeardata=[];
       props.data.rows.map((v,i)=>
       {
         return yeardata.push({label:v.Year,value:i});
       })
    setyear(yeardata);
   }
 },[nameopt]);

 let handleselect=(e)=>
 {
  let value=e.target.value;
  let second=[];
   if(value)
   {
    props.data.rows.map((v,i)=>
    {
      if(v.Year==value)
      {
        return second.push({label:v.Name,value:i});
      }
    })
   }
   console.log(second)
   if(second)
   {
     secondselect()
     props.api.refreshCells();
   }
   setname(second);
 }

let secondselect=()=>
{
  console.log("eee")
  return  <div>
  <label>Select-1</label>
  <TextField
      id="select2"
      label="select2"
      defaultValue="Select name"
      fullWidth
      select
      >
       {nameopt.map((v,i)=>
       {
         console.log(v)
         return <MenuItem key={i} value={v.label}>
         {v.label}
       </MenuItem>
       })}
      </TextField>
   </div>
  
};

let selection=useCallback(()=>
{
  return(
    <div>
    {props.data.select=="select" && props.colDef.field=="Year" ? (
      <div>
   <label>Select-1</label>
       <TextField
       id="select1"
       label="select1"
       defaultValue="Select year"
       fullWidth
       select
       onChange={(e)=>handleselect(e)}
       >
        {yearopt.map((v,i)=>
        {
          return <MenuItem key={i} value={v.label}>
          {v.label}
        </MenuItem>
        })}
       </TextField>
    </div>
    ):(
       props.value
    )}
    {props.data.select=="select" && props.colDef.field=="Name" ? (
        secondselect()
    ):(
     ""
    )}
    </div>
  )
},[yearopt]);

  return (
    <div>
     {selection()}
    </div>
  )
};

export default AutoComplete_Comp;