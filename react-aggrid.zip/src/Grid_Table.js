import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import {useState,useRef, useMemo, useCallback, useEffect} from "react";
import { Select,MenuItem } from "@mui/material";

function Grid_Table()
{
const GridRef=useRef(null);
const [rowdata,setrow]=useState([
  { id:1,Name: "Suren", Year:"2000", Email: "Suren@gmail.com" },
  { id:2,Name: "Kiran", Year: "2000", Email: "kiran@gmail.com" },
  { id:3,Name: "Robert", Year: "2003", Email: "robert@gmail.com" },
  { id:4,Name: "Lakshman", Year: "2003", Email: "Lakshman@gmail.com" },
  { id:5,Name: "Lokesh", Year: "2003", Email: "Lokesh@gmail.com" },
  { id:6,Name: "Henry", Year: "2003", Email: "Henry@gmail.com" },
  { id:7,Name: "Mike", Year: "2003", Email: "Mike@gmail.com" },
  { id:8,Name: "Suren", Year: "2000", Email: "Suren@gmail.com" },
  { id:9,Name: "Kiran", Year: "2000", Email: "kiran@gmail.com" },
  { id:10,Name: "Robert", Year: "2003", Email: "robert@gmail.com" },
  { id:11,Name: "Lakshman", Year: "2003", Email: "Lakshman@gmail.com" },
  { id:12,Name: "Lokesh", Year: "2003", Email: "Lokesh@gmail.com" },
  { id:13,Name: "Henry", Year: "2003", Email: "Henry@gmail.com" },
  { id:14,Name: "Mike", Year: "2003", Email: "Mike@gmail.com" },
  {id:15,Name:"Chris",Year:"2005",Email:"chris@gmail.com"}
]);
const [seconddata,setsecond]=useState([]);
const [showdrop,setdrop]=useState(false);

useEffect(()=>
{
  if(seconddata.length)
  {
    // console.log(seconddata)
    var rnode=GridRef.current.api.getRowNode("0");
    let data={id:0,Year:getSelect(),Name:getName()};
    rnode.setData(data);
  }
},[seconddata])

const handleSelect=e=>
{
  let val=e.target.value;
  let data=rowdata.filter((v,i)=>
  {
    if(v.Year==val)
    {
       return v
    }
  })
  setsecond(data);
}

const getSelect=p=>
{
  return(
    <Select
    fullWidth
    onChange={handleSelect}
    >
      {rowdata.map((v,i)=>
      {
        return  <MenuItem value={v.Year}>{v.Year}</MenuItem>
      })}
    </Select>
  )
}

const getName=()=>
{
  console.log("name");
  return(
    <Select
    fullWidth
    >
    {seconddata.map((v,i)=>
    {
      return <MenuItem value={v.Name}>{v.Name}</MenuItem>
    })}
    </Select>
  )
};


const getCell=p=>
{
  if(showdrop)
  {
    return <Select>
      {rowdata.map((v,i)=>
      {
       return <MenuItem>{v.Year}</MenuItem>
      })}
    </Select>
  }
  else
  {
  return p.value;
  }
}

const gridOptions={
  rowData:rowdata,
  columnDefs:[
    {
      field:"Year",
      cellRenderer:p=>getCell(p)
    },
    {
      field:"Name",
      cellRenderer:p=>getCell(p)
    },
    {
      field:"Email",
      cellRenderer:p=>getCell(p)
    },
    {
      field:"action",
      cellRenderer:p=>Editbtn(p)
    }
  ],
  getRowId: (params) => {
    return params.data.id;
  },
  defaultColDef:{
    sortable:true,
    flex:1,
    editable:true
  }
}

const Editbtn=(p)=>
{
  return(
    <button onClick={()=>Edit(p)}>Edit</button>
  )
}

const Edit=(p)=>
{
  console.log(p)
  console.log("Edit...");
  setdrop(true)
}

const Add=()=>
{
  let data={id:0,Year:getSelect(),Name:getName()};
 GridRef.current.api.applyTransaction({add:[data],addIndex:0});
}

return(
  <div>
    <header>
      <h1>Grid Table</h1>
    </header>
    <button onClick={()=>Add()}>Add</button>
    <div className="tablecontainer">
    <div className="ag-theme-alpine" style={{height:300}}>
    <AgGridReact 
     ref={GridRef}
     gridOptions={gridOptions}
    //  editType="fullRow"
    />
    </div>
    </div>
  </div>
 )
}

export default Grid_Table;