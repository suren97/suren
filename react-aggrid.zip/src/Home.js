import Ag_grid from "./AG_Grid/Basics/Ag_grid";
import GridRender from "./AG_Grid/Rendering/GridRender";
import FunCellRender from "./AG_Grid/Rendering/FunctionCellRender/Fun_cellRender";
import ClassCellRender from "./AG_Grid/Rendering/ClassCellRender/Class_cellrender";
import Grid_StatusBar from "./AG_Grid/Grid_Properties/Grid_Options/Grid_Statusbar";
import Grid_Sidebar from "./AG_Grid/Grid_Properties/Grid_Options/Grid_sidebar";
import Getcontext from "./AG_Grid/Grid_Properties/Grid_Options/Grid_getcontext";
import Grid_mainmenu from "./AG_Grid/Grid_Properties/Grid_Options/Grid_getmainmenu";
import Column_Definition from "./AG_Grid/Grid_Properties/Grid_Columns/Column_Def";
import Sample_ColProps from "./AG_Grid/Grid_Properties/Grid_Columns/Column_Properties/Sample_ColProps";
import Column_Prop from "./AG_Grid/Grid_Properties/Grid_Columns/Column_Properties/Column_Properties";
import Grid_refData from "./AG_Grid/Grid_Properties/Grid_Columns/Column_Properties/refData_Property/Grid_refData";
import Col_ChnDetection from "./AG_Grid/Grid_Properties/Grid_Columns/Column_Properties/Change_Detection/Col_Valchgdet";
import Aggr_Detection from "./AG_Grid/Grid_Properties/Grid_Columns/Column_Properties/Change_Detection/Col_AgrDetect";
import SFG_Detection from "./AG_Grid/Grid_Properties/Grid_Columns/Column_Properties/Change_Detection/SFG_Detection";
import Team_Props from "./AG_Grid/Team_AgProperties/Team_Properties";
import Sample_workout from "./AG_Grid/Sample_workout";
import Ag_EditType from "./AG_Grid/Team_AgProperties/Ag_EditType";
import AG_Excelstyle from "./AG_Grid/Team_AgProperties/Ag_Excelstyles";
import Row_selection from "./AG_Grid/Team_AgProperties/Row_Selection/Ag_rowSelection";
import Group_select from "./AG_Grid/Team_AgProperties/Row_Selection/Ag_groupSelect";
import Cell_Renderer from "./AG_Grid/Team_AgProperties/Ag_Components/Cell_Renderer";
import Transaction from "./AG_Grid/Transaction/Transaction";
import Access_Row from "./AG_Grid/Access_Rowdata/Access_Row";
import Row_Drag from "./AG_Grid/Team_AgProperties/Row_Dragging/Managed_Drag/Row_dragging";
import Row_Unmanaged from "./AG_Grid/Team_AgProperties/Row_Dragging/Unmanaged_Drag/Row_Unmanged";
import Row_DragGroup from "./AG_Grid/Team_AgProperties/Row_Dragging/Drag&RowGroup/Row_grouping";
import Row_virtual from "./AG_Grid/Team_AgProperties/Virtualisation/Row_virtualization";
import Column_sizing from "./AG_Grid/Team_AgProperties/Sizing/Column_sizing";
import Column_Header from "./AG_Grid/Team_AgProperties/column_Header/column_Header";
import Range_selection from "./AG_Grid/Team_AgProperties/Range_Selection/Range_selection";
import Cell_editors from "./AG_Grid/Components/Cell_Editors";
import Grid_Context from "./AG_Grid/Basics/Context";
import Loading_CellRender from "./AG_Grid/Components/Loading_Render";
import Grid_sample from "./AG_Grid/Grid_Sample/Grid_Sample";
import Practice_Grid1 from "./AG_Grid/Practice/Practice1";
import Grid_Panel from "./AG_Grid/JSPanel/Grid_Panel";
import Import_Excel from "./AG_Grid/Import_Excel/Excel_import";
import Column_Moving from "./AG_Grid/Grid_Properties/Grid_Options/Column_Moving";
import Overlay_Component from "./AG_Grid/Components/Overlay_Components/Overlay_Components";
import Tooltip_Component from "./AG_Grid/Components/Tooltip_Components/Tooltip_component";
import GroupTooltip from "./AG_Grid/Components/Tooltip_Components/GroupTooltip";
import CellEditing from "./AG_Grid/Grid_Properties/Grid_Options/Editing/CellEditing";
import Grid_Rendering from "./AG_Grid/Grid_Properties/Grid_Options/Rendering/Grid_Rendering";
import Full_width_rows from "./AG_Grid/Grid_Properties/Grid_Options/Row/Full_width_rows";
import Row_Grouping from "./AG_Grid/Grid_Properties/Grid_Options/Row/Row_Grouping";
import Row_style from "./AG_Grid/Grid_Properties/Grid_Options/Styling/Row_style";
import Pivot_Grid from "./AG_Grid/Grid_Properties/Grid_Options/PivotAggregation/Pivot_Grid";
import Review_Grid from "./AG_Grid/Grid_Properties/Grid_Options/Review_Grid";
import Grid_Table from "./Grid_Table";
import AutoComplete_Comp from "./AutoComplete";

function Home()
{
  return (
    <div>
      {/* <Grid_StatusBar /> */}
        {/* <Ag_grid /> */}
        {/* <GridRender /> */}
        {/* <FunCellRender /> */}
        {/* <ClassCellRender /> */}
        {/* <!-----------------------Grid Options-----------------------!> */}
        {/* <Grid_StatusBar /> */}
        {/* <Grid_Sidebar /> */}
        {/* <Getcontext /> */}
        {/* <Grid_mainmenu /> */}
          {/* <Column_Moving /> */}
        {/* <Overlay_Component /> */}
        {/* <Tooltip_Component /> */}
        {/* <GroupTooltip /> */}
        {/* <CellEditing /> */}
        {/* <Grid_Rendering /> */}
        {/* <Full_width_rows /> */}
        {/* <Row_Grouping /> */}
        {/* <Row_style /> */}
      {/* <!-----------------------Grid Columns-----------------------!> */}
        {/* <Column_Definition /> */}
        {/* <Sample_ColProps /> */}
        {/* <Column_Prop /> */}
        {/* <Col_ChnDetection /> */}
        {/* <Aggr_Detection /> */}
        {/* <Grid_refData /> */}
        {/* <SFG_Detection /> */}
      {/* <!-----------------------Team Properties-----------------------!> */}
        {/* <Team_Props /> */}
        {/* <Import_Excel /> */}
        {/* <AG_Excelstyle /> */}
        {/* <Ag_EditType /> */}
        {/* <Row_selection /> */}
        {/* <Group_select /> */}
        {/* <Cell_Renderer /> */}
        {/* <Transaction /> */}
        {/* <Access_Row /> */}
        {/* <Row_Drag /> */}
        {/* <Row_Unmanaged /> */}
        {/* <Row_DragGroup /> */}
        {/* <Row_virtual /> */}
        {/* <Column_sizing /> */}
        {/* <Column_Header /> */}
        {/* <Range_selection /> */}
        {/* <Cell_editors /> */}
        {/* <Loading_CellRender /> */}
        {/* <Grid_sample /> */}
        {/* <Grid_Context /> */}
        {/* <Sample_workout /> */}
        {/* <Grid_Panel /> */}
        {/* <Pivot_Grid /> */}
        {/* <Review_Grid /> */}
        <Grid_Table />
        {/* <AutoComplete_Comp /> */}
        {/* <!------------------Practicing Grid-----------------!> */}
        {/* <Practice_Grid1 /> */}
    </div>
  )
}
export default Home;


