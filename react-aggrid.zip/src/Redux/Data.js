import {createSlice} from "@reduxjs/toolkit";
import produce from "immer";


const initialState={
    data:[]
};

const Datas=createSlice({
      name:"Data",
      initialState,
      reducers:{
          InsertData:(state,action)=>
          {
             return produce(state,(draft)=>
             {
                 draft.data.push(action.payload);
             })
          }
      }
});

export const DataReducer=Datas.reducer;
export const {InsertData}=Datas.actions;
