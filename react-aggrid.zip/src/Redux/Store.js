import { configureStore } from "@reduxjs/toolkit";
import { DataReducer } from "./Data";

const ReduxStore=configureStore({
    reducer:{
         Griddata:DataReducer
    }
});

export default ReduxStore;