import './App.css';
// import Sample from "./file";
// import Comp_class from "./comp_class";
import DispHook from "./React_Hook/Hook";
// import First from "./Class_State/First";
import Lifecycle from './Class_State/Lifecycle';
// import Mainpage from "./Demo/Calculation";
// import Calc from "./Demo/FunctionCalc";
// import Condition from './conditional/condition';
// import List from "./React_List/list";
// import Updatearr from "./React_Hook/updatearr";
// import WebSample from "./SampleDesign/sample";
// import Practice from './SampleDesign/Practice';
// import Mainpage from './SampleDesign/Mainpage';
// import Loop from './React_others/Loop';
// import Test from "./Class_State/test";
// import Higher from "./Higherorder/multiselect"
// import Temparature from './temperature/Convert';
import Search from './Search/searchfilter';
import Accord from './Accordion/Accord';
import Parent from './Updateparent/parent';
import Fetching from './Async/Fetching';

function App(props) {
  const person={name:"Surendar",empid:1888};
  return (
    <div>
      {/* <Fetching /> */}
      {/* <Parent /> */}
      {/* <Accord /> */}
      {/* <Search /> */}
      {/* <Temparature /> */}
      {/* <Higher /> */}
      {/* <Multi /> */}
      {/* <Loop /> */}
      {/* <Test /> */}
    {/* <div className="App"> */}
     {/* <h1>Hi {props.name} Welcome to ReactJs</h1>
    </div>  
     <p>React is used for</p>
     <ul>
      <li>Creating a Single Page Applications</li>
      <li>Declarative</li>
      <li>Component Based</li>
     </ul> */}
     {/* <Sample name="surendar" />  
     <Comp_class prop="property" /> */}
     {/* <HooksObj /> */}
     {/* <First /> */}
     {/* <DispHook /> */}
     <Lifecycle name="Ajay" empid="300" />
     {/* <Mainpage /> */}
     {/* <Calc /> */}
     {/* <Condition /> */}
     {/* <Updatearr/> */}
     {/* <List /> */}
     {/* <WebSample /> */}
     {/* <Practice /> */}
     {/* <Mainpage /> */}
     </div>
  );
}

export default App;
