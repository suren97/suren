import React,{ Component } from "react";
import axios from "axios";

class Fetching extends Component
{
    constructor(props)
    {
        super(props);
        this.state={
            name:""
        }
    }
componentDidMount()
{
var id=localStorage.setItem("id",100);
var getid=localStorage.getItem("id");
async function getdatas()
{
    let result=new Promise((resolve,reject)=>
    {
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((data)=>{ setTimeout(()=>{resolve(data)},3000)})  
    })
    await result.then((value)=>{
        console.log(value)
    })

    let result2=new Promise((resolve,reject)=>
    {
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((data)=>{ setTimeout(()=>{resolve(data)},1000)})  
    })
    await result2.then((value)=>{
        console.log(value)
    })
}
getdatas();
}
handleinp(e)
{
this.setState({name:e.target.value})
}
render()
{
    return(
        <div>
        <h1>API</h1>
        <label>Rerendering</label>
        <input type="text" onChange={(e)=>this.handleinp(e)} />
        </div>
    )
}
}
export default Fetching;