import React,{Component} from "react";
import StateComp from "./StateComp";

class First extends Component
{
    render()
    {
        return(
            <div>
            <h1>First Class Component</h1>
            <hr></hr>
            <StateComp />
            </div>
        )
    }
}
export default First;