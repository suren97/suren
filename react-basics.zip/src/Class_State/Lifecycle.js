import React,{Component} from 'react';

class Lifecycle extends Component
{  
    constructor(props)
    {
        super(props);
        this.state={
            name:""
        }
    }
    componentWillMount()
    {
        console.log("willMount");
    }
    componentDidMount()
    {
        console.log("DidMount");
    }
    componentDidUpdate()
    {
        console.log("Did update");
    }
    componentWillUnmount()
    {
        console.log("Unmount");
    }
    update=()=>
    {
        this.setState((state)=>({
             name:state.name="Surendar"
        }));
    }

    render()
    {
        console.log("Rendering");
        return(
            <div>
                <p>React Lifecycle consists of:</p>
                <ul>
                    <li>Initialization</li>
                    <li>Mounting</li>
                    <li>Updation</li>
                    <li>Unmounting</li>
                </ul>
                <h1>Lifecyle methods of Components</h1>
                <h2>Props:</h2>
                {this.props.name+"  "+this.props.empid}
                {this.state.name}
                <button type="button" onClick={()=>this.update()}>update</button>
                {/* {this.update} */}
            </div>
        )
    }
}
export default Lifecycle;