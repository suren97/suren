import React,{Component} from "react";


let obj={name:"bshs",key:222,address:{loc:"Chennai",pin:987678}};

class StateComp extends Component
{
    constructor(props)
    {
        super(props);
        this.state={
            counter:0
        }
    }
    increase=()=>
    {
        this.setState(state=>({
            counter:state.counter+1
        }))
    }
    decrease=()=>
    {
        this.setState(state=>({
            counter:state.counter-1
        }))
    }
    render()
    {
        return(
            <div>
                <h1>Stateful Component</h1>
                <button type="button" onClick={this.decrease}>Decrease</button>
                <p style={{margin:"10px"}}>{this.state.counter}</p>
                <button type="button" onClick={this.increase}>Increase</button>
            </div>
        )
    }
}
  
export default StateComp;