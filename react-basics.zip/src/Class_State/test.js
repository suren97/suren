import react,{ Component } from "react";
import axios from "axios";

class Test extends Component
{
    constructor(props)
    {
        super(props);
        this.state={
            data:[]
        }
    }
    componentDidMount()
    {
     //axios
     axios.get("https://jsonplaceholder.typicode.com/users")
     .then((response)=>{
        this.setState((prev)=>
        {
        return {data:response.data}
        })
    })
    //  ----------------------------------------------------------
    //Fetch
    // fetch("https://jsonplaceholder.typicode.com/users")
    // .then((response)=>response.json())
    // .then((data)=>this.setState({data}))
    }
render()
{
const {data}=this.state;
if(data)
{
   //Sorting of names
   data.sort((x,y)=>{
    return x.name.localeCompare(y.name)
   });
}
return(
      <div>
      <h1>React Fetching Components</h1>
      </div>
)
}
}
export default Test;