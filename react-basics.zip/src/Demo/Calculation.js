// function Calculation()
// {
import React,{Component} from "react";

class Calculation extends Component
{
    constructor(props)
    {
        super(props);
        this.state={
           value1:"",
           value2:"",
           output:""
        }
    }
    handleinput(e)
    {
        this.setState({[e.target.name]:e.target.value})
    }
    Add()
    {
     let v1=this.state.value1;
     let v2=this.state.value2;
     this.setState({output:parseInt(v1)+parseInt(v2)});
     document.getElementById("output").style.display="block"
    }
    Sub()
    {
     let v1=this.state.value1;
     let v2=this.state.value2;
     this.setState({output:parseInt(v1)-parseInt(v2)});
     document.getElementById("output").style.display="block"
    }
    Mul()
    {
     let v1=this.state.value1;
     let v2=this.state.value2;
     this.setState({output:parseInt(v1)*parseInt(v2)});
     document.getElementById("output").style.display="block"
    }
    Div()
    {
     let v1=this.state.value1;
     let v2=this.state.value2;
     this.setState({output:parseInt(v1)/parseInt(v2)});
     document.getElementById("output").style.display="block"
    }
    render()
    {
    return(
        <div className="content">
        <div className="subcont">
        <h1>Calculations Using Class Component</h1>
        <label>Enter Value1</label>
        <input type="text" name="value1" onChange={(e)=>this.handleinput(e)} />
        <label>Enter Value2</label>
        <input type="text" name="value2" onChange={(e)=>this.handleinput(e)} />
        <div id="output">
        <label>Output</label>
        <input type="text" name="output" value={this.state.output} />
        </div>
        <button className="btnclass" onClick={()=>this.Add()}>Add</button>
        <button className="btnclass" onClick={()=>this.Sub()}>Sub</button>
        <button className="btnclass" onClick={()=>this.Mul()}>Mul</button>
        <button className="btnclass" onClick={()=>this.Div()}>Div</button>
        </div>
        </div>
     )
    }
}
export default Calculation;