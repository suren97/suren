import { useEffect, useState } from "react";

function Calc()
{
    const [values,setvalues]=useState({
      v1:"",
      v2:"",
      output:""
    });
    useEffect(()=>
    {
      console.log("useEffect");
      let par=document.createElement("p");
      par.innerHTML="Paragrpah";
      document.body.appendChild(par);

    })
    let Add=(e)=>
    {
      if(e.target.name==="value1")
      {
        values.v1=e.target.value;
      }
      else if(e.target.name==="value2")
      {
        values.v2=e.target.value;
      }
    }
    let update=(op)=>
    {
      document.getElementById("output1").style.display="block";
      if(op==="+")
      {
        setvalues(state=>{
            return {...state,output:parseInt(values.v1)+parseInt(values.v2)}
        })
      }
        else if(op==="-")
        {
          setvalues(state=>{
            return {...state,output:parseInt(values.v1)-parseInt(values.v2)}
        })
        }
        else if(op==="*")
        {
          setvalues(state=>{
            return {...state,output:parseInt(values.v1)*parseInt(values.v2)}
        })
        }
        else if(op==="/")
        {
          setvalues(state=>{
            return {...state,output:parseInt(values.v1)/parseInt(values.v2)}
        })
        }
    }
    return(
        <div className="content">
          {console.log("rendrr")}
        <div className="subcont">
        <h1>Calculations Using Function Component</h1>
        <label>Enter Value1</label>
        <input type="text" name="value1" onChange={Add} />
        <label>Enter Value2</label>
        <input type="text" name="value2" onChange={Add} />
        <div id="output1">
        <label>Output</label>
        <input type="text" name="output" value={values.output} />
        </div>
        <button className="btnclass" onClick={()=>update("+")}>Add</button>
        <button className="btnclass" onClick={()=>update("-")}>Sub</button>
        <button className="btnclass" onClick={()=>update("*")}>Mul</button>
        <button className="btnclass" onClick={()=>update("/")}>Div</button>
        </div>
        </div>
    )
}
export default Calc;