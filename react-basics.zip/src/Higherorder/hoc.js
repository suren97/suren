import React,{Component} from "react";

function Hoc(HocComponent)
{
return class extends Component
{
render()
{
    return(
        <div>
            <h1>Higher Order Components</h1>
            <HocComponent></HocComponent>
        </div>
    );
}
}
}
export default Hoc;