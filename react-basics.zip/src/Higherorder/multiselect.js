import React,{Component} from "react";
import Hoc from "./hoc";

const names=["A","B","C","D","E"];

class Higher extends Component
{
constructor(props)
{
    super(props);
    this.state={
        name:"",
    }
}
render()
{
    return(
        <div>
           <h1>Components</h1>
           {names.map((v,i)=>
           {
            return v;
           })}
        </div>
    )
}
}
Higher=Hoc(Higher);
export default Higher;