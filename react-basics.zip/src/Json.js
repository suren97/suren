import {useState,useEffect} from "react";

function json()
{
    // componentDidMount()
    // {
    // fetch("https://randomuser.me/api/")
    // .then((response)=>response.json())
    // .then((data)=>console.log(data.results));
    // }
  return(
    <div>
        <h1>Structuring using JSON Elements</h1>
    </div>
  )
}
