import {useState,useEffect,useRef, useLayoutEffect} from "react";
function DispHook()
{
    const [counter,setcounter]=useState(0);
    const names=useRef(null);
    const [details,updetails]=useState({
        Name:"Johny",
        Empid:200,
        Company:"TY",
        Salary:25000
    });
    const [numbers,setnum]=useState([1,2,3,4]);
    const [data,setData]=useState("");
    useEffect(()=>{
        fetch('https://randomuser.me/api/')
        .then((response)=>response.json())  
        .then((data)=>setData(data.results));
        //  console.log(data);
         var evt=document.getElementById("focus");
         evt.style.backgroundColor="lightgrey";
    },[]);

  useEffect(()=>{
    // console.log("you clicked:"+counter+"times");
  });

    let reportobj=()=>
    {
        let val="";
        for(let x in details)
        {
            val+=" "+x+": "+details[x];
        }
        return val;
    }

    const update=()=>
    {
        updetails(state=>{
            return {...state,Name:"Ajin Johny",Empid:420}
        })
    }

    const updatename=()=>
    {
       setnum((state)=>{
        return state.map((v,i)=>
        {
            if(v==3)
            {v=43}
            return v;
        })
       })
    }
    let handleinp=()=>
    {
        console.log(names.current.value)
    }
    return(
        <div>
              {console.log("Render")}
            <h1>Function Components</h1>
            <h1>Setting up Hook</h1>
            Counters:{counter}
            <br></br>
            <button type="button" onClick={()=>setcounter(counter-1)}>Decrease</button>
            <br></br>
            <button type="button" onClick={()=>setcounter(counter+1)}>Increase</button>
            <hr></hr>
            <h1>Setting up Hook using Object</h1>
            {reportobj()}
            <br></br>
            <button type="button" onClick={update}>Update</button>
            <hr></hr>
            <h1>Numbers</h1>
            Numbers:{numbers+" "}
            <button type="button" onClick={updatename}>Update Name</button>
            <hr></hr>
            <h1>Focusable Input</h1>
            <input type="text" ref={names} id="focus" onChange={()=>handleinp()} autoFocus />
        </div>
    )
}
export default DispHook;