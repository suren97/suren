import { useEffect, useState } from "react";

function Update()
{
    const [obj,setobj]=useState([]);
    const [usinput,setinp]=useState("");
    let updatearr=()=>
    {
      setobj(oldarr=>[...oldarr,usinput])
    }
    let handleinput=(e)=>
    {
      setinp(e.target.value);
    }
    return(
        <div>
            <h1>Updating an Array</h1>
            <label>Enter names:</label>
            <input type="text" onChange={handleinput} />
            {obj}
            <button type="button" onClick={updatearr}>Update</button>
        </div>
    )
}

export default Update;