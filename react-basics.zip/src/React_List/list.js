import React,{Component} from "react";

const car=["Audi","BMW","Benz","Maruti","Honda","Suzuki"];
class List extends Component
{
    constructor(props)
    {
        super(props);
        this.state={
            cars:"",
            input:""
        }
    }
    handleinp(e)
    {
    this.setState({input:e.target.value});
    }
    update()
    {
     this.setState((state)=>
     {
        return {cars:state.input};
     })
    }
    render()
    {
        return(
            <div>
                <h1>List Elements</h1>
                <input type="text" onChange={(e)=>this.handleinp(e)}></input>
                <button type="button" onClick={()=>this.update()}>Update</button>
                {this.state.cars}
            </div>
        )
    }
}

export default List;