import axios from "axios";
import { useEffect,useState } from "react";

function Loop()
{
    let arrele=["Ben","stewards","Anderson","Braden","Einsten","Harry"];
    const [input,setinput]=useState();
    let stud=[
        {
            id:1,
            name:"Jack",
            email:"jackson@gmail.com"
        },
        {
            id:2,
            name:"Mathew",
            email:"mathew@gmail.com"
        },
        {
            id:3,
            name:"Anderson",
            email:"anderson@gmail.com"
        },
        {
            id:4,
            name:"Mitchell",
            email:"mitchell@gmail.com"
        },
        {
            id:5,
            name:"Gord",
            email:"gord@gmail.com"
        }
    ]

    useEffect(()=>{
         axios.get("https://jsonplaceholder.typicode.com/posts")
         .then((response)=>{ response.data.length=5; setinput(response.data)})
    },[]);

    let deleteobj=(id)=>
    {
      let final=input.filter((v,i)=>
      {
       if(v.id!==id)
       {
        return v;
       }
      })
      setinput(final)
      console.log(final);
    }
    return(
        <div>
            <h1>Looping an Array in React</h1>
            <ul>
            {arrele.map((v,i)=>{
              return  <li key={i}>{v}</li>
            })}
            </ul>
            <hr></hr>
            <h1>Looping in array of objects</h1>
            <ul>
            {stud.map((v,i)=>
            {
                return <li key={i}>{v.name}</li>
            })}
            </ul>
            <hr></hr>
            <h1>Delete Axios Request</h1>
            <table className="tstyle">
            <tbody>
            <tr>
                <th>Id</th>
                <th>Title</th>
                <th>Body</th>
                <th>Delete</th>
            </tr>
              {input && input.map((v,i)=>{
                return (
                    <tr>
                        <td>{i+1}</td>
                        <td>{v.title}</td>
                        <td>{v.body}</td>
                        <td>
                        <button type="button" onClick={()=>deleteobj(v.id)}>Delete</button>
                        </td>
                    </tr>
                )
              })}
            </tbody>
            </table>
        </div>
    )
}
export default Loop;