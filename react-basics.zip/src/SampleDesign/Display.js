function Display(props)
{
    console.log(props);
return(
    <div>
        <h1>Display elements</h1>
        <div>{Object.values(props)}</div>
    </div>
)
}
export default Display;