import { useState } from "react";
import Logout from "./Logout";

function Login(props)
{
const [stat,setstat]=useState(false);
return(
    <div>
        <h1>LoginPage</h1>
        <h2>Hi {props.name} you have logged into the webpage</h2>
        <button type="button" onClick={()=>setstat(true)}>Logout</button>
        {stat ? <Logout main={false} /> : ""}
    </div>
)
}
export default Login;