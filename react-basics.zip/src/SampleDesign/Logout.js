import Mainpage from "./Mainpage";

function Logout(props)
{
    console.log(props)
  return(
    <div>
        <h1>You have Logged out from the webpage</h1>
    </div>
  )
}
export default Logout;