import Login from "./Login";
import {useState} from "react";

function Mainpage()
{
    const [stat,setstat]=useState(false);
    console.log(stat);
 
    return(
        <div>
            <h1>Mainpage</h1>
            <button type="button" onClick={()=>setstat(true)}>Login</button>
            {stat ? <Login name="Surendar" status={stat} /> : " "}
            <br></br>
        </div>
    )
}

export default Mainpage;