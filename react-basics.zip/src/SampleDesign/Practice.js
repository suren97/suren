import {useState} from "react";
import Display from "./Display";

function Practice()
{
    const [name,setname]=useState("");
    const [price,setprice]=useState("");
    const [id,setid]=useState("");
    const [disp,setdisp]=useState(false);
    let submit=()=>
    {
      let uname=name;
      let uprice=price;
      let empid=id;
      console.log(uname+" "+uprice+" "+empid);
      setdisp(true);
    //   window.location.href="Display.js";
    }
    return(
        <div>
            <h1>Handling Events using Fucntion Components</h1>
           <div className="maincontent">
             <label>Enter Empid:</label>
             <input type="text" onChange={(e)=>setid(e.target.value)}/>
             <label>Enter Name:</label>
             <input type="text" onChange={(e)=>setname(e.target.value)}/>
             <label>Enter City:</label>
             <input type="text" onChange={(e)=>setprice(e.target.value)}/>
             <button type="button" onClick={submit}>Submit</button>
           </div>
        </div>
    )
}
export default Practice;