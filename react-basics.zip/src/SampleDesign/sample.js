function WebSample()
{
    return (
        <div>
            <header>
                Sample Webdesign Using ReactJs
            </header>
            <nav>
                <ul>
                    <li>Home</li>
                    <li>Gallery</li>
                    <li>About us</li>
                    <li>Achievements</li>
                </ul>
            </nav>
            <div class="main-content">
            <div class="grid1">
            <p>Content</p>
            </div>
            <div class="grid2">
                <p>Subcontent</p>
            </div>
            </div>
            <footer>
              <p>Footer</p>
            </footer>
        </div>
    )
}
export default WebSample;