import {useState} from "react";

function Search()
{
const [inp,setinp]=useState(true);
const [srch,setsrch]=useState();
const country=["India","Japan","USA","Dubai","Africa","Brazil","Europe","Indonesia"];

let handleinput=(e)=>
{
let val=e.target.value;
let fil=country.filter((v,i)=>
{
  return v.toLocaleLowerCase().match(val.toLocaleLowerCase());
})
if(val)
{
setsrch(fil);
setinp(false);
}
else
{
setsrch("");
setinp(true);
}
}

return(
    <div>
    <h1>Searching Filter</h1>
    <input type="text" onChange={(e)=>handleinput(e)} />
    <ul>
            {inp ? country.map((v,i)=>
            {
              return <li>{v}</li>;
            }):srch && (
            srch.map((v,i)=>
            {
              return <li>{v}</li>;
            })
        )}
    </ul>
    <ul>
     
    </ul> 
    </div>
)
}
export default Search;