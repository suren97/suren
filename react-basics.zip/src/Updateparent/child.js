function Child({setvalue})
{
return(
    <div>
    <h1>Child Component</h1>
    <button type="button" onClick={()=>setvalue("Parent Components Updated")}>Update Parent</button>
    </div>
)
}
export default Child;