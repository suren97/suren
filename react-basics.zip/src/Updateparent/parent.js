import {useState} from "react";
import Child from "./child";

function Child2()
{
    let prev=(e)=>
    {
        e.preventDefault();
       console.log("prev function"); 
    }
    return(
        <div>
            <p>Dynamic Child Component under Parent Component</p>
            <button type="button"onClick={(e)=>prev(e)}>Prevent</button>
        </div>
    )
}

function Parent()
{
const [value,setvalue]=useState("The Parent components data");
return(
    <div>
    <h1>Parent Component</h1>
    {value}
    <Child setvalue={setvalue} />
    <Child2 />
    </div>
)
}
export default Parent;