import React,{Component} from "react";

class Comp_class extends React.Component
{
render()
{
    return(
        <div>
            <h1>Class Components</h1>
            <h2>{this.props.prop}</h2>
        </div>
    );
}
}
export default Comp_class;