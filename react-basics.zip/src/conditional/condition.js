import {useState} from "react";
import Success from "./success";
import Fail from "./fail";
function Condition()
{
    const [stat,setstat]=useState("");
    const [obj,setobj]=useState({
        Empid:100,
        Empname:"Akash",
        Role:"Associate"
    });
  let status=(op)=>
  {
   setstat(op);
  }
  function getobj()
  {
    let val="";
    for(let y in obj)
    {
     val+=y+": "+obj[y]+"; ";
    }
   return val;
  }
  function update()
  {
    setobj(prev=> 
        {
       return {...prev,Empname:"Ashok"}
    })
  }
  return(
    <div>
        <h1>Conditions</h1>
        <button type="button" className="btnclass" onClick={()=>status("Success")}>Success</button>
        <button type="button" className="btnclass" onClick={()=>status("Failed")}>Failed</button>
        {stat=="Success" ?(
            <Success />
        ):(
            <Fail />
        )}
        <hr></hr>
        <h2>Objects</h2>
        {getobj()}
        <button type="button" className="btnclass" onClick={()=>update()}>Update</button>
    </div>
  )
}
export default Condition;