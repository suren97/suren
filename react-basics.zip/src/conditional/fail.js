function Fail()
{
    return(
        <h1>Fail</h1>
    )
}
export default Fail;