function Sample(props)
{
    return(
        <div>
            <h1>Sample page for Function Component</h1>
            <h2>Hi {props.name} Welcome to React</h2>
        </div>
    )
}
export default Sample;