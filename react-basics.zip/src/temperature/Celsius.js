import Temparature from "./Convert";
import {useState} from "react";

function Celsius()
{
    return(
        <div className="temp">
            <fieldset>
            <legend>Celsius:</legend>
            <input type="text" />
            </fieldset>
        </div>
    )
}
export default Celsius;