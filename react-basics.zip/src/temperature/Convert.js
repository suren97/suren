import {useState} from "react";

function Temparature()
{
    const [celsius,setcel]=useState(0.0);
    const [fahrn,setfahrn]=useState(0.0);

    function toCelsius(fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
      }
      
      function toFahrenheit(celsius) {
        return (celsius * 9 / 5) + 32;
      }
      
    let handlecel=(e)=>
    {
      setcel(e.target.value);
      setfahrn(toFahrenheit(e.target.value));
    }
    let handlefah=(e)=>
    {
        setfahrn(e.target.value);
        setcel(toCelsius(e.target.value));
    }
    return(
        <div>
       <div className="temp">
        <fieldset>
            <legend>Celsius:</legend>
            <input type="text" value={celsius} onChange={(e)=>handlecel(e)} />
            </fieldset> 
       </div>
       <br></br>
       <div className="temp">
        <fieldset>
            <legend>Fahrenheit:</legend>
            <input type="text" value={fahrn} onChange={(e)=>handlefah(e)} />
            </fieldset> 
       </div>
       </div>
    )
}
export default Temparature;