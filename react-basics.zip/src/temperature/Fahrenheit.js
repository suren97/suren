function Fahrenheit()
{
    return(
        <div>
            <div className="temp">
            <fieldset>
            <legend>Fahrenheit:</legend>
            <input type="text" />
            </fieldset>
        </div>
        </div>
    )
}
export default Fahrenheit;