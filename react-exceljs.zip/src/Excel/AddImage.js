import { Workbook } from "exceljs";
import FileSaver from "file-saver";
import ShipImg from "./Ship.png";

function AddImage()
{
    const workbook=new Workbook();
    const worksheet=workbook.addWorksheet("SampleExcel");
    // const ShipImg=process.env.PUBLIC_URL+"/Ship.png";
    // console.log(ShipImg)

let DownloadImageExcel=()=>
{
  const rowdata=[
    {empid:3211,name:"surendar"},
    {empid:4321,name:"imran"},
    {empid:5462,name:"vikram"},
    {empid:4393,name:"vinoth"}
  ];

  const columns=[
    {header:"EmpCode",key:"empid",width:30},
    {header:"EmpName",key:"name",width:30}
  ];
   
  worksheet.columns=columns;
  rowdata.map(v=>{
    worksheet.addRow(v)
  })

//Image
let reader=new FileReader();

// img.addEventListener("change",(e)=>
// {
//   console.log(e)
// })

// let reader=new FileReader();
// reader.onload=function(){
//    console.log(reader.result)
// }
// reader.readAsDataURL(image)

worksheet.eachRow(obj=>
{
    obj.alignment={
        vertical:"middle",
        horizontal:"left"
    }
})

  // workbook.xlsx.writeBuffer().then(buffer => { 
  //   const blob = new Blob([buffer], 
  //   {
  //       type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
  //   })  
  //   FileSaver.saveAs(blob, "Sample"); 
  // })

}

let DownloadExcel=()=>
{
    DownloadImageExcel();
}

let handlefiles=e=>
{
  let files=e.target.files[0];
  console.log("files",files)
  // let reader=new FileReader();
  // reader.onload=function(){
  //     console.log(reader.result)
  // }
  // reader.readAsDataURL(files)
}


return(
    <>
    <header>
        <h1>Add Image</h1>
    </header>
    <button onClick={()=>DownloadExcel()}>Download Image Excel</button>
    <input type="file" onChange={(e)=>handlefiles(e)} />
    </>
)

}

export default AddImage;