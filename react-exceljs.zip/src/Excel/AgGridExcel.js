import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "ag-grid-enterprise";
import { useState,useMemo } from "react";
import FileSaver from "file-saver";

function AgGridExcel()
{
const [rowData] = useState([
     { make: "Toyota", model: "Celica", price: 35000 },
     { make: "Ford", model: "Mondeo", price: 32000 },
     { make: "Porsche", model: "Boxster", price: 72000 },
     { make: "Toyota", model: "Celica", price: 35000 },
     { make: "Ford", model: "Mondeo", price: 32000 },
     { make: "Porsche", model: "Boxster", price: 72000 }
]);
const [GridApi,setApi]=useState();
   
const [columnDefs] = useState([
       { field: 'make' },
       { field: 'model' },
       { field: 'price' }
]);

const excelStyles=useMemo(()=>
{
    return [
      {
        id: "cell",
        alignment: {
          horizontal: "center",
        },
      },
      {
        id: "greyBackground",
        alignment: {
          vertical:"center",
          horizontal: "center",
        },
        interior: {
          color: "#b5e6b5",
          pattern: "Solid",
        },
      },
    ];
})

const defaultColDef=({
    flex:1
})

let onGridReady=params=>
{
  setApi(params.api);
}

 let ExportExcel=async()=>
 {

  //  console.log(GridApi);
   const fileName = "myfile.txt";
   const inpelem=document.createElement("input");
   inpelem.type="file";

  //  if ("showSaveFilePicker" in window) {
  //    // `showSaveFilePicker` is supported, so use it
  //    window.showSaveFilePicker().then((fileHandle) => {
  //      // Handle the selected file
  //    });
  //  } else {
  //    // `showSaveFilePicker` is not supported, so provide a fallback
  //    const fileInput = document.createElement("input");
  //    fileInput.type = "file";
  //    fileInput.addEventListener("change", (event) => {
  //      const file = event.target.files[0];
  //      // Handle the selected file
  //    });
  //    fileInput.click();
  //  }


  //  var text = "Hello, world!";
  //  var blob = new Blob([text], { type: "text/plain" });
  //  console.log(window)
  //  window.saveAs(blob, "hello.txt");
    // let blob=GridApi.getDataAsExcel();
    // const options = {
    //     suggestedName: "Export", // default file name
    //     types: [
    //       {
    //         description: "Excel file",

    //         accept: {
    //           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
    //             [".xlsx"],
    //         },
    //       },
    //     ],
    //  };
    // const HandleExcel = await window.showSaveFilePicker(options);
    // const writable = await HandleExcel.createWritable();
    // await writable.write(blob);
    // await writable.close();
 }
    return (
      <>
        <div>
          <header>
            <h1>AgGridExcel</h1>
          </header>
        </div>
        <button onClick={() => ExportExcel()}>Export Excel</button>
        <div
          className="ag-theme-alpine"
          style={{ height: 300, width: "100%", marginTop: "5%" }}
        >
          <AgGridReact
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            onGridReady={onGridReady}
            excelStyles={excelStyles}
          ></AgGridReact>
          <a href="#"></a>
          {/* <input type="file" /> */}
        </div>
      </>
    );
}

export default AgGridExcel;