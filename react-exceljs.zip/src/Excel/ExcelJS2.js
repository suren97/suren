import { useEffect,useState } from "react";
import { Workbook } from "exceljs";
import FileSaver from "file-saver";

function Excel2Js()
{
const [rowdata,setrow]=useState();
const columns=[
    {
        header:"Athlete",
        key:"athlete",
        width:20
    },
    {
        header:"Age",
        key:"age",
        width:20
    },
    {
        header:"Sport",
        key:"sport",
        width:20
    },
    {
        header:"Date",
        key:"date",
        width:20
    },
    {
        header:"TotalMedals",
        key:"total",
        width:20
    }
]

const worksheetname="Athlete_Details";
const filename="Athlete"


useEffect(()=>
{
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>response.json())
    .then((data)=>{data.length=20;setrow(data)})
},[])

let DownloadExcelFile=({columnData,rows,worksheetname,filename})=>
{
    const workbook=new Workbook();
    const worksheet=workbook.addWorksheet(worksheetname);
    //columns
    worksheet.columns=columnData;

    //First row fill data
    const headerStyling=worksheet.getRow(1);
    headerStyling.eachCell(cell=>
    {
      cell.fill={
        type:"pattern",
        pattern:"solid",
        fgColor:{argb:"5d6f7e"}
      };
      cell.font={
        color:{argb:"FFFAFA"},
        bold:true,
        size:12
      }
    })

    rows.forEach(item=>
    {
        worksheet.addRow(item)
    })

    workbook.xlsx.writeBuffer().then(buffer => {   
        const blob = new Blob([buffer], 
        {
            type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
        })  
        FileSaver.saveAs(blob, filename); 
    })
}

const Transferdata={
     columnData:columns,
     rows:rowdata,
     worksheetname:worksheetname,
     filename:filename
}

let DownloadExcel=()=>
{
    DownloadExcelFile(Transferdata);
}

return(
        <div>
            <header>
                <h1>Sample Excel Download</h1>
            </header>
            <button onClick={()=>DownloadExcel()}>
                Download Excel
            </button>
        </div>
)
}

export default Excel2Js