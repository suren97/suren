import React,{ Component } from "react";

class Flexbox extends Component
{
  render()
  {
    return(
        <div>
            <header>
                <h1>CSS Flexbox</h1>
            </header>
            <div className="flexcontainer">
                <div className="box" />
                <div className="box" />
                <div className="box" />
                <div className="box" />
                <div className="box" />
                <div className="box" />
                <div className="box" />
                <div className="box" />
                <div className="box" />
                <div className="box" />
            </div>
        </div>
    )
  }
}

export default Flexbox;