import { Workbook } from "exceljs";
import FileSaver from "file-saver";

function HeaderFoot()
{
const rows=[
    {name:"surendar",status:"active"},
    {name:'naren',status:"Inactive"},
    {name:"harin",status:"active"},
    {name:"posch",status:"inactive"}
];
const columns=[{header:"Name",key:"name",width:25},{header:"Status",key:"status",width:25}];

let DownloadExcel=()=>
{
const workbook=new Workbook();
const worksheet=workbook.addWorksheet("Test");
worksheet.columns=columns;
rows.map(v=>{
    worksheet.addRow(v)
})

workbook.xlsx.writeBuffer().then(buffer => {   
    const blob = new Blob([buffer], 
    {
        type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
    })  
    FileSaver.saveAs(blob, "sample"); 
})

}

return(
    <>
    <h1>Header and Footer JS</h1>
    <button onClick={()=>DownloadExcel()}>Download</button>
    </>
)
}

export default HeaderFoot;