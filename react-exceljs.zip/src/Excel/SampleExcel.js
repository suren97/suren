import { Workbook } from "exceljs";
import FileSaver from "file-saver";

function SampleExcel()
{
const stackWeightListcolDef=[
{
    headerName:'TwBayNo',
    field:'twinbayNo'
},
{
    headerName:'StackNo',
    field:'stackNo'
},
{
    headerName:'BayNo',
    field:'bayNo'
},
{
    headerName:'RowNo',
    field:'rowNo'
},
{
    headerName:'MaxWt',
    field:'maxweight'
},
{
    headerName:'TotWt',
    field:'totalweight'
},
{
    headerName:'RemWt',
    field:'remainval'
}
];
const Rowdata=[
    {twinbayNo:3,stackNo:2,bayNo:1,rowNo:2,maxweight:25000,totalweight:230,remainval:4300},
    {twinbayNo:5,stackNo:4,bayNo:4,rowNo:3,maxweight:34000,totalweight:2332,remainval:34353},
    {twinbayNo:7,stackNo:7,bayNo:8,rowNo:8,maxweight:459392,totalweight:4343,remainval:4334},
    {twinbayNo:12,stackNo:3,bayNo:2,rowNo:2,maxweight:62326,totalweight:434,remainval:6642},
    {twinbayNo:6,stackNo:8,bayNo:9,rowNo:9,maxweight:747484,totalweight:6565,remainval:3423},
    {twinbayNo:9,stackNo:9,bayNo:3,rowNo:1,maxweight:3234743,totalweight:545,remainval:6556}
];

const DownloadExcelSingleTable=({headerData,bodyDataArr,
worksheetName,fileSaverName})=>
{
    const workbook=new Workbook();
    const worksheet = workbook.addWorksheet(worksheetName);
    
    worksheet.mergeCells(['A2:B2']);
    worksheet.mergeCells(['A3:B3']);
    worksheet.mergeCells(['A1:B1']);
    worksheet.mergeCells(['D1:E1']);
    worksheet.mergeCells(['D2:E2']);
    worksheet.mergeCells(['D3:E3']);      
    worksheet.mergeCells(['D4:E4']);      
    worksheet.mergeCells(['G1:H1']);      
    worksheet.mergeCells(['G2:H2']);      
    worksheet.mergeCells(['G3:H3']);      
    worksheet.mergeCells(['G4:H4']);      
    worksheet.mergeCells(['J1:K1']);      
    worksheet.mergeCells(['J2:K2']); 
    worksheet.mergeCells(['J3:K3']);
    worksheet.mergeCells(['J4:K4']); 
    worksheet.mergeCells(['D6:H6']); 
    worksheet.mergeCells(['A4:B4']);
    worksheet.getCell('D6').value = "StackWeightList";

    const mergedCells = [Object.keys(worksheet._merges)];
    mergedCells[0].forEach(cell => {
        worksheet.getCell(cell).font = {
        size: 12,
        bold: true
    };
    worksheet.getCell(cell).fill = {
        type: 'pattern', 
        pattern: 'solid',
        fgColor: { argb: '70db70' }
     };
    });
    
    const emptyCell = ['C1', 'C2', 'C3', 'C4', 'I1', 'I2', 'I3', 'I4'];
    emptyCell.forEach(item => { 
        worksheet.getCell(item).fill = {
            type:'pattern',
            pattern:'solid',
            fgColor: { argb: 'adebad' }
        };
    });

    worksheet.getCell("A2").value="Service";
    worksheet.getCell("A3").value="VesselName";
    worksheet.getCell("A4").value="Voyage";

    worksheet.getCell("D1").value="Vessel";
    worksheet.getCell("D2").value="Service";
    worksheet.getCell("D3").value="VesselName";
    worksheet.getCell("D4").value="Voyage";
    worksheet.getCell("A1").value="Vessel";

    worksheet.getCell('C1').value = ':';
    worksheet.getCell('C2').value = ':';
    worksheet.getCell('C3').value = ':';
    worksheet.getCell('C4').value = ':';
    worksheet.getCell('I1').value = ':'; 
    worksheet.getCell('I2').value = ':';
    worksheet.getCell('I3').value = ':';
    worksheet.getCell('I4').value = ':';

    worksheet.getCell("G1").value="Vessel";
    worksheet.getCell("G2").value="Service";
    worksheet.getCell("G3").value="VesselName";
    worksheet.getCell("G4").value="Voyage";

    worksheet.getCell("J1").value="Vessel";
    worksheet.getCell("J2").value="Service";
    worksheet.getCell("J3").value="VesselName";
    worksheet.getCell("J4").value="Voyage";

    let coldata=stackWeightListcolDef.map(v=>v.headerName);
    let cols=[];
    coldata.forEach(data=>{ cols.push({name:data}) })
    worksheet.addTable({
        name:'table1',
        ref:'A8',
        columns:[...cols],
        rows: []
    });
    
    worksheet.columns.forEach(columns => { 
        columns.width = 15; 
    });

    worksheet.getRow(8).eachCell(cell => {
         cell.font = {
            size: 12,
            bold: true
        };
        cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'ffb366' }
        };
        cell.border = {
            left: { style: 'hair' }, 
            right: { style: 'hair' } 
        };
    });

    bodyDataArr.forEach(item=>
    {
       worksheet.addRow([
           item.twinbayNo,
           item.stackNo,
           item.bayNo,
           item.rowNo,
           item.maxweight,
           item.totalweight,
           item.remainval
       ])
    })

    worksheet.eachRow(item=>{
        item.alignment={
            vertical:"middle",
            horizontal:"center"
        }
    })

    workbook.xlsx.writeBuffer().then(buffer => {   
        const blob = new Blob([buffer], 
        {
            type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
        })  
        FileSaver.saveAs(blob, fileSaverName); 
     })
}
const tankSequenceWorksheetName = 'Tank Sequnce Template';
const tankSequenceFileSaverName = 'Tank Sequence Template.xlsx'; 
const tankSequenceTemplateArgObj = { 
    headersDataArr: stackWeightListcolDef,
    bodyDataArr:Rowdata,      
    worksheetName: tankSequenceWorksheetName,
    fileSaverName: tankSequenceFileSaverName 
};

let DownloadExcel=()=>
{
  DownloadExcelSingleTable(tankSequenceTemplateArgObj);
}

return(
<div>
<header>
<h1>ExcelDownload</h1>
</header>
<div>
<button onClick={()=>DownloadExcel()}>DownloadExcel</button>
</div>
</div>
)
}

export default SampleExcel;