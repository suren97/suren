import { Workbook } from "exceljs";
import FileSaver from "file-saver";
import { useEffect, useState } from "react";

function Sports_Excel()
{
const [rowdata,setrow]=useState();
const ColumnsData=[
     {
        header:"Athlete",
        key:"athlete",
        width:150
     },
     {
        header:"Country",
        key:"country",
        width:150
     },
     {
        header:"Sport",
        key:"sport",
        width:150
     },
     {
        header:"Age",
        key:"age",
        width:150
     },
     {
        header:"Date",
        key:"date",
        width:150
     },
     {
        header:"Year",
        key:"year",
        width:150
     },
     {
        header:"Total Medals",
        key:'total',
        width:150
     }
]
const topdata=[
    {
        LeagueName:"FIFA",
        Country:"Germany",
        Code:"#0GER",
        Date:"20-03-2023",
        Year:"2023",
        Total:8
    }
]

useEffect(()=>
{
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>response.json())
    .then((data)=>{data.length=20;setrow(data)});
},[])

const TransferData={
      columnData:ColumnsData,
      TopData:topdata[0],
      rowData:rowdata,
      worksheetname:"Sports",
      filename:"Athlete"
}

let Downloadfile=({columnData,rowData,worksheetname,filename,TopData})=>
{
    const workbook=new Workbook();  
    const worksheet=workbook.addWorksheet(worksheetname);
    let first=Object.keys(TopData).slice(0,3);
    let second=Object.keys(TopData).slice(-3);
    
    first.forEach((value,index)=>{
         worksheet.mergeCells([`A${index+1}:B${index+1}`])
         worksheet.getCell(`A${index+1}`).value=value;
         worksheet.getCell(`C${index+1}`).value=":";
         worksheet.mergeCells([`D${index+1}:E${index+1}`])
         worksheet.getCell(`D${index+1}`).value=TopData[value];
    })

    second.forEach((value,index)=>
    {  
        worksheet.mergeCells([`G${index+1}:H${index+1}`])
        worksheet.getCell(`G${index+1}`).value=value;
        worksheet.getCell(`I${index+1}`).value=":";
        worksheet.mergeCells([`J${index+1}:K${index+1}`])
        worksheet.getCell(`J${index+1}`).value=TopData[value];
    })

    worksheet.mergeCells(['A5:K5']);
    worksheet.getCell('A5').value="List of Athlete Details";
    const coldata=columnData.map(v=>v.header);
    let cols=[];
    coldata.forEach(v=>cols.push({name:v}))

    worksheet.addTable({
        name:"Table1",
        ref:"A6",
        columns:[...cols],
        rows:[]
    });

    worksheet.getRow(6).eachCell(cell=>{
        cell.font={
            font:20,
            bold:true
        }
    })

    rowData.map(v=>{
        worksheet.addRow([
            v.athlete,
            v.country,
            v.sport,
            v.age,
            v.date,
            v.year,
            v.total
        ])
    })


    workbook.xlsx.writeBuffer().then(buffer => {   
        const blob = new Blob([buffer], 
        {
            type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
        })  
        FileSaver.saveAs(blob, filename); 
     })
}

let DownloadExcel=()=>
{
  Downloadfile(TransferData)
}

return(
    <div>
        <header>
        <h1>Sports Excel</h1>
        </header>
        <div className="download">
        <button onClick={()=>DownloadExcel()}>Download Excel</button>
        </div>
    </div>
)
}

export default Sports_Excel;