import { BrowserRouter as Router,Routes,Route } from "react-router-dom";
import Navbar from "./Screens/Navigation/Navbar";
import Home from "./Screens/Admin/Home";
import AddBook from "./Screens/Admin/AddBook";
import AddUser from "./Screens/Admin/AddUser";
import FileSaver from "./Screens/FileSaver";

function App() {
  return (
      <Router>
          <Routes>
            <Route path="/" element={<FileSaver />}>
              <Route index element={<Home />}></Route>
              <Route path="/addbook" element={<AddBook />} ></Route>
              <Route path="/adduser" element={<AddUser />}></Route>
            </Route>
          </Routes>
      </Router>
  )
}

export default App;
