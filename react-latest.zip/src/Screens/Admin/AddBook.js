import { AppBar, IconButton, Toolbar, Box, Typography, TextField,Stack } from "@mui/material";
import { Book } from "@mui/icons-material";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { AgGridReact } from "ag-grid-react";
import { useEffect, useState } from "react";

function AddBook() {
  const [rowdata,setrow]=useState();
  const [columnDef,setcolumn]=useState([
    {field:"make"},
    {field:"model"},
    {field:"price"}
  ]);

  useEffect(()=>
  {

  },[])
  
  return (
    <>
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static" elevation={1}>
          <Toolbar>
            <IconButton size="medium" edge="start" color="inherit">
              <Book />
            </IconButton>
            <Typography variant="h6" sx={{ flexGrow: 1, ml: 3 }}>
              Add Books
            </Typography>
          </Toolbar>
        </AppBar>
      </Box>
      {/* <div className="body-container">
          <Stack direction={"row"}> 
              <TextField 
              variant="outlined"
              label="Username"
              />
          </Stack>
      </div> */}
      <div className="ag-theme-alpine">
           <AgGridReact 
           columnDefs={columnDef}
           rowData={rowdata}
           />
      </div>
    </>
  );
}

export default AddBook;
