import { AppBar, IconButton, Toolbar, Box, Typography } from "@mui/material";
import { Person } from "@mui/icons-material";

function AddUser() {
  return (
    <>
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static">
          <Toolbar>
            <IconButton size="medium" edge="start" color="inherit">
              <Person />
            </IconButton>
            <Typography variant="h6" sx={{ flexGrow: 1, ml: 3 }}>
              Add Users
            </Typography>
          </Toolbar>
        </AppBar>
      </Box>
    </>
  );
}

export default AddUser;
