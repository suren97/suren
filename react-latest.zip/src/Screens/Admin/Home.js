import { AppBar, IconButton, Toolbar,Box, Typography } from "@mui/material";
import { Dashboard } from "@mui/icons-material";

function Home()
{
return(
    <>
    <Box sx={{flexGrow:1}}>
        <AppBar position="static">
            <Toolbar>
                <IconButton
                size="medium"
                edge="start"
                color="inherit"
                >
                    <Dashboard />
                </IconButton>
                <Typography variant="h6" sx={{flexGrow:1,ml:3}}>Dashboard</Typography>
            </Toolbar>
        </AppBar>
    </Box>
    </>
)
}

export default Home;