import { Stack, TextField,Typography,Button } from "@mui/material";
import Booklogo from "./Booklogo.jpg"

function LoginPage()
{
    return (
      <div className="loginpage">
        <div className="logincontainer">
          <div className="formcontainer">
            <div className="formsInput">
              <Stack
                direction={"column"}
                spacing={5}
                alignItems={"center"}
                justifyContent={"space-around"}
              >
                <img className="logoimg" src={Booklogo} />
                <TextField
                  id="outlined-basic"
                  label="Username"
                  variant="outlined"
                  fullWidth
                />
                <TextField
                  id="outlined-basic"
                  label="Password"
                  variant="outlined"
                  fullWidth
                />
              </Stack>
              <Button variant="contained" fullWidth sx={{ mt: 4 }}>
                Login
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
}

export default LoginPage;