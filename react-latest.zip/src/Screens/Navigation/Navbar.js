import { Outlet } from "react-router-dom";

function Navbar()
{
    return (
      <>
        <div className="navbar">
          <ul>
            <li>
              <a href="/">Home</a>
            </li>
            <li className="dropdown">
              <a href="javascript:void(0)" className="dropbtn">Management &nbsp;<i class="fa fa-caret-down"></i></a>
              <div className="dropdown-content">
                   <a href="/addbook">Add Books</a>
                   <a href="adduser">Add Users</a>
              </div>
            </li>
            <li className="logoutbox">
              <a href="#">Logout</a>
            </li>
          </ul>
        </div>
        <Outlet />
      </>
    );
}

export default Navbar;