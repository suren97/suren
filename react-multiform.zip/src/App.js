import { BrowserRouter,Routes,Route } from "react-router-dom";
import Mainpage from "./Components/Mainpage";
import Navbarpage from "./Components/Navbarpage";
import ReduxStore from "./Redux/Store";
import { Provider } from "react-redux";

function App() {
  return (
    <div>
      <Provider  store={ReduxStore}>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navbarpage/>} >
          <Route  index element={<Mainpage />} />
        </Route>
      </Routes>
      </BrowserRouter>
      </Provider>
      {/* <Mainpage /> */}
      </div>
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
  );
}

export default App;
