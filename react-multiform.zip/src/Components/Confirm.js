import { useSelector,useDispatch } from "react-redux";
import { Formdata,Mainstep } from "../Redux/Data";

function Confirm(props)
{
    let values=props.inputs;
    const dispatch=useDispatch();
    const step=useSelector((state)=>state.StepData.mainsteps);
    const forms=useSelector((state)=>{console.log(state.StepData)})

    let submit=()=>
    {
      let val=window.confirm("Are you sure want to Submit ?");
      if(val)
      {
      window.scrollTo(0,0);
      dispatch(Mainstep(step+1));
      dispatch(Formdata(values));
      }
    }

    return(
        <div>
            {step==3 ? (
            <div>
            <h2>Confirmation</h2>
            <div className="formcontainer">
            <div className="forms">
                <label>Firstname</label>
                <input type="text" value={values.fname} disabled={true} />
            </div>
            <div className="forms">
                <label>Lastname</label>
                <input type="text" value={values.lname} disabled={true} />
            </div>
            <div className="forms">
                <label>Email</label>
                <input type="text" disabled={true} value={values.email}  />
            </div>
            <div className="forms">
                <label>Mobile</label>
                <input type="text" disabled={true} value={values.mobile} />
            </div>
            <div className="forms">
                <label>Degree</label>
                <input type="text" disabled={true} value={values.degree} />
            </div>
            <div className="forms">
                <label>Course</label>
                <input type="text" disabled={true} value={values.course} />
            </div>
            <div className="forms">
                <label>YOP</label>
                <input type="text" disabled={true} value={values.yop} />
            </div>
            <div className="forms">
                <label>Percentage</label>
                <input type="text" disabled={true} value={values.percent} />
            </div>
            <div style={{textAlign:"center"}}>
                <button type="button" className="submitbtn" onClick={()=>submit()}>Submit</button>
            </div>
            </div>
            <button className="prevbtn" onClick={props.handleprev}>Previous</button>
            </div>
            ):(
              <div>
               <h2>Thank you for Submission</h2>
               <div>
                </div>
              </div>
            )}
            </div>
    )
}

export default Confirm;