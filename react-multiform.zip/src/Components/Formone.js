function Formone(props)
{
let statevalues=props.inputs;
let errvalues=props.errinput;

return(
    <div>
        <h2>Basic Information</h2>
        <div className="formcontainer">
            <div className="forms">
                <label>FirstName</label>
                <input type="text" name="fname" value={statevalues.fname} onChange={(e)=>props.handlechange(e)} />
                <span className="errormsg">{errvalues.fnamerr}</span>
            </div>
            <div className="forms">
                <label>LastName</label>
                <input type="text" name="lname" value={statevalues.lname} onChange={(e)=>props.handlechange(e)} />
                <span className="errormsg">{errvalues.lnamerr}</span>
            </div>
            <div className="forms">
                <label>Email</label>
                <input type="text" name="email" value={statevalues.email} onChange={(e)=>props.handlechange(e)} />
                <span className="errormsg">{errvalues.emailerr}</span>
            </div>
            <div className="forms">
                <label>Mobile</label>
                <input type="number" name="mobile" value={statevalues.mobile} onChange={(e)=>props.handlechange(e)} />
                <span className="errormsg">{errvalues.mobilerr}</span>
            </div>
            {/* <div style={{textAlign:"center"}}>
                <button className="submitbtn">Submit</button>
            </div> */}
            <div style={{display:"flex",justifyContent:"right",marginRight:30}}>
                <button className="nextbtn" onClick={props.handlenext}>Next</button>
            </div>
        </div>
    </div>
)
}
export default Formone;