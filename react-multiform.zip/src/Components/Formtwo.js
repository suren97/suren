function Formtwo(props)
{
let statevalues=props.inputs;
let errvalues=props.errinput;

return (
    <div>
    <h2>Education Information</h2>
    <div className="formcontainer">
        <div className="forms">
            <label>Select Degree</label>
            <select name="degree" value={statevalues.degreeindex} onChange={props.handledegree}>
                {props.Degreeoptions && props.Degreeoptions.map((v,i)=>
                {
                   return <option  value={v.value}>{v.label}</option>
                })}
            </select>
            <span className="errormsg">{errvalues.degreerr}</span>
        </div>
        <div className="forms">
            <label>Select Course</label>
             <select name="course" value={statevalues.course} onChange={(e)=>props.handlechange(e)}>
                {props.Courseoption && props.Courseoption.map((v,i)=>
                {
                   return <option>{v.label}</option>
                })}
             </select>
             <span className="errormsg">{errvalues.courserr}</span>
        </div>
        <div className="forms">
            <label>YOP</label>
            <input type="date" name="yop" value={statevalues.yop} onChange={(e)=>props.handlechange(e)} />
            <span className="errormsg">{errvalues.yoperr}</span>
        </div>
        <div className="forms">
            <label>Percentage</label>
            <input type="number" id="percent" name="percent" value={statevalues.percent} onChange={(e)=>props.handlepercent(e)} />
            <span className="errormsg">{errvalues.percenterr}</span>
        </div>
        {/* <div style={{textAlign:"center"}}>
            <button className="submitbtn">Submit</button>
        </div> */}
        <div>
            <span style={{marginLeft:30}}>
          <button className="prevbtn" onClick={props.handleprev}>Previous</button>
          </span>
          <span style={{float:"right",marginRight:30}}>
            <button className="nextbtn" onClick={props.handlenext}>Next</button>
        </span>
        </div>
        {/* <div style={{display:"inline-block"}}>
        <div style={{marginLeft:30,float:"left"}}>
        <button className="nextbtn">Previous</button>
        </div>
        <div style={{float:"right",marginRight:30}}>
        <button className="nextbtn">Next</button>
        </div>
        </div> */}
    </div>
</div>
)
}

export default Formtwo;