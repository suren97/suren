import { useEffect, useState } from "react";
import Formone from "./Formone";
import Formtwo from "./Formtwo";
import Confirm from "./Confirm";
import { useSelector,useDispatch } from "react-redux";
import {Mainstep} from "../Redux/Data";

function Mainpage()
{
    const [step,setstep]=useState(1);
    // const [mainstep,setmain]=useState(1);
    const [prevstep,setprev]=useState();
    const [width,setwidth]=useState();
    const [state,setstate]=useState({
      fname:"",
      lname:"",
      email:"",
      mobile:"",
      degree:"",
      degreeindex:"",
      course:"",
      yop:"",
      percent:""
    }
    );
    const dispatch=useDispatch(); 
    const [errmsg,seterr]=useState({
        fnamerr:"",
        lnamerr:"",
        emailerr:"",
        mobilerr:"",
        degreerr:"",
        courserr:"",
        yoperr:"",
        percenterr:""
    });    
    const reduxstep=useSelector((state)=> state.StepData.mainsteps);
  const [mainstep,setmain]=useState(reduxstep);
    console.log("Mainsteps",reduxstep)

    useEffect(()=>
    {
        // dispatch(Mainstep(step))
    },[step]);

    let handleDegree=e=>
    {
    let val=e.target.value;
    Degreeoptions.map((v,i)=>
    {
        if(v.value==val)
        {
            state.degree=v.label
            state.degreeindex=val;
        }
    })
    setcourseopt([{label:"Select Options"}]);
     Courses.filter((v,i)=>
     {
        if(v.id == val)
        {
           setcourseopt((prev)=>
           {
             return [...prev,{label:v.label,value:val}]
           })
        }
     })
    }

const [Degreeoptions,setdegoptions]=useState([
        {label:"Select Options"},
        {label:"B.E/B.Tech",value:1},
        {label:"Arts and Science",value:2},
        {label:"MBA",value:3},
        {label:"BArch",value:4}
]);
    
const [Courseoption,setcourseopt]=useState([
    {label:"Select Options"}
]);

const Courses=[
    {label:"ECE",id:1},
    {label:"EEE",id:1},
    {label:"CSE",id:1},
    {label:"IT",id:1},
    {label:"Aeronautical",id:1},
    {label:"Civil",id:1},
    {label:"Mechanical",id:1},
    {label:"B.com",id:2},
    {label:"Bsc Computer",id:2},
    {label:"Bsc Maths",id:2},
    {label:"Microbiology",id:2},
    {label:"Msc Computer",id:2},
    {label:"Msc Maths",id:2},
    {label:"Accounting",id:3},
    {label:"Human Resources Management",id:3},
    {label:"Finance",id:3},
    {label:"Marketing",id:3},
    {label:"Management",id:3},
    {label:"Arch Technology",id:4},
    {label:"Arch Engineering",id:4},
    {label:"Arch Design",id:4},
    {label:"Arch History",id:4}
];


    const Nextstep=()=>
    {
       let data={};
       if(step===1)
       {
        data.fname=state.fname;
        data.lname=state.lname;
        data.email=state.email;
        data.mobile=state.mobile;
        if(FirstFormvalidation(data))
        {
          window.scrollTo(0,0);
          setstep(step+1);
          dispatch(Mainstep(mainstep+1));
        }
       }
       if(step===2)
       {
         data.degree=state.degree;
         data.course=state.course;
         data.yop=state.yop;
         data.percent=state.percent;
         if(SecondFormValidation(data))
         {
          window.scrollTo(0,0);
          setstep(step+1);
         
          dispatch(Mainstep(mainstep+2));
         }
       }
       if(step===3)
       {
        setstep(step+1);
        dispatch(Mainstep(mainstep+1));
       }

    }

    let FirstFormvalidation=(data)=>
    {
    let nameval=/^[A-Za-z]+$/;
    let numval=/^[0-9]+$/;
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    if(data)
    {
    // First name Validation
    if(!data.fname)
    {
      seterr((prev)=>
      {
        return {...prev,fnamerr:"Firstname should not be Empty"}
      })
      return false;
    }
    if(data.fname.match(nameval))
    {
      seterr((prev)=>
      {
        return {...prev,fnamerr:" "}
      })
    }
    else
    {
      seterr((prev)=>
      {
        return {...prev,fnamerr:"Not a Valid Name"}
      })
      return false;
    }

    // Lastname Validation
    if(!data.lname)
    {
        seterr((prev)=>
      {
        return {...prev,lnamerr:"Lastname should not be Empty"}
      })
      return false; 
    }
    if(data.lname.match(nameval))
    {
      if(data.lname.toLowerCase()===data.fname.toLowerCase())
      { 
        seterr((prev)=>
        {
            return {...prev,lnamerr:"Lastname should not be same as Firstname"}
        }) 
        return false;
      }
      else
      {
      seterr((prev)=>
      {
        return {...prev,lnamerr:" "}
      })
      }
    }
    else
    {
      seterr((prev)=>
      {
        return {...prev,lnamerr:"Invalid Name"}
      })
      return false;
    }

// Email Validation
if(!data.email)
{
  seterr((prev)=>{
    return {...prev,emailerr:"Email Cannot be Empty"}
  });
  return false;
}
if(mailformat.test(data.email))
{
  seterr((prev)=>{
    return {...prev,emailerr:""}
  })
}
else
{
  seterr((prev)=>{
    return {...prev,emailerr:"Invalid Email Address"}
  })
  return false;
}

//-------------------------------------------------------------------//

// Number Validation
    if(!data.mobile)
    {
      seterr((prev)=>
      {
         return {...prev,mobilerr:"Mobile Number Cannot be Empty"};
      })
      return false;
    }
    if(data.mobile.match(numval))
    {
      if(data.mobile.length < 10 || data.mobile.length > 10)
      {
       seterr((prev)=>{
        return {...prev,mobilerr:"Invalid Mobile Number"}
       })
       return false;
      }
      seterr((prev)=>{
         return {...prev,mobilerr:""};
      });
    }
    else
    {
      seterr((prev)=>
      {
        return {...prev,mobilerr:"Invalid Mobile Number"}
      })
      return false;
    }
}
return true;
}

let SecondFormValidation=(data)=>
{
  if(data)
  {
  //Degreee Validation
if(!data.degree)
{
   seterr((prev)=>
   {
    return {...prev,degreerr:"Please Select Degree"};
   }) 
   return false;
}
else
{
    seterr((prev)=>
    {
        return {...prev,degreerr:""};
    })
}

// Course Validation   
if(!data.course)
{
      seterr((prev)=>
      {
         return {...prev,courserr:"Please Select Course"};
      })
      return false;
}
 else
 {
    seterr((prev)=>
    {
        return {...prev,courserr:""};
    })
 }

// Year Validation
if(!data.yop)
{
  seterr((prev)=>
  {
    return {...prev,yoperr:"Date Cannot be empty"}
  })
  return false;    
}
if(data.yop)
{
  var d = new window.Date(data.yop);
  var curtyear=new window.Date().getFullYear();
  var year=d.getFullYear();
  if(year < curtyear-20 || curtyear < year)
  {
   seterr((prev)=>
   {
    return {...prev,yoperr:"Invalid Year"}
   })
   return false;
  }
  seterr((prev)=>{
    return {...prev,yoperr:""}
  })
}
if(!data.percent)
{
  seterr((prev)=>
  {
    return {...prev,percenterr:"Percentage should not be empty"}
  })
  return false;
}
if(data.percent)
{
var x = parseFloat(data.percent).toFixed(2);
// console.log("Orgper",data.percent);
// console.log("percent",x);
if(x!==data.percent)
{
  seterr((prev)=>
  {
    return {...prev,percenterr:"Invalid Percentage"}
  })
  return false;
}
if (isNaN(x) || x < 0 || x > 100) {
    seterr((prev)=>
    {
      return {...prev,percenterr:"Invalid Percentage"}
    })
  return false;
}
else
{
  seterr((prev)=>
  {
    return {...prev,percenterr:""}
  })
}
}
}
  return true;
}

const Prevstep=()=>
{
    setstep(step - 1);
}

let handleinputs=e=>
{
  let name=e.target.name;
  let value=e.target.value;  
  setstate((prev)=>
  {
     return {...prev,[name]:value}
  })
}

let handlepercent=e=>
{
  let name=e.target.name;
  let value=e.target.value;
  setstate((prev)=>
  {
    return {...prev,[name]:value}
  })
}


switch(step)
    {
        case 1:
            return(
                <div>
                      <Formone 
                      handlenext={Nextstep} 
                      errinput={errmsg} 
                      inputs={state} 
                      handlechange={handleinputs} 
                      />
                </div>
            )
        
        case 2:
            return(
                    <div>
                      <Formtwo 
                      handlenext={Nextstep} 
                      errinput={errmsg} 
                      inputs={state}  
                      handlechange={handleinputs} 
                      handleprev={Prevstep} 
                      handledegree={handleDegree} 
                      handlepercent={handlepercent}
                      Degreeoptions={Degreeoptions}
                      Courseoption={Courseoption}
                      />
                    </div>
            )
        
        case 3:
            return(
                <div>
                      <Confirm 
                      handleprev={Prevstep} 
                      inputs={state} 
                      currentstep={step}
                      />
                </div>
            )
    }
}

export default Mainpage;