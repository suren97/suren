import { useState,useEffect } from "react";
import { Outlet } from "react-router-dom";
import { useSelector,useDispatch } from "react-redux";
import Mainstep from "../Redux/Data";

function Navbarpage()
{
const step=useSelector((state)=> state.StepData.mainsteps)
console.log("Navpage",step)

useEffect(()=>
{
let elem=document.getElementById("bar");
if(step===1)
{
 let step1=document.getElementById("step1");
 step1.style.backgroundColor="green";
 elem.style.width="18%";
 elem.style.backgroundColor="green";
 elem.style.borderRadius="20px";
 elem.style.height="15px"
}
if(step===2)
{
 let step2=document.getElementById("step2");
 step2.style.backgroundColor="green";
 elem.style.width="50%";
 elem.style.backgroundColor="green";
 elem.style.borderRadius="20px";
 elem.style.height="15px";
 elem.style.transition="2s"
}
if(step==3)
{
 let step3=document.getElementById("step3");
 step3.style.backgroundColor="green";
 elem.style.width="84%";
 elem.style.backgroundColor="green";
 elem.style.borderRadius="20px";
 elem.style.height="15px";
 elem.style.transition="2s"
}
if(step > 3)
{
 elem.style.width="100%";
 elem.style.backgroundColor="green";
 elem.style.borderRadius="20px";
 elem.style.height="15px";
 elem.style.transition="3s";
 elem.style.transitionTimingFunction="ease"
}
},[step]);
return(
    <div>
        <header>
            <h1>MultiStep Form</h1>
        </header>
        <div className="outerbar">
        <p id="bar"></p>
        <div className="progressbar">
         <div className="circlenumber" id="step1"><span>1</span></div>
         <div className="circlenumber" id="step2"><span>2</span></div>
         <div className="circlenumber" id="step3"><span>3</span></div>
        </div>
        </div>
        <div className="container">
            <Outlet  />
        </div>
    </div>
)
}
export default Navbarpage;