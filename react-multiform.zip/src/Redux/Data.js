import { createSlice } from "@reduxjs/toolkit";
import produce from "immer";

const initialState={
   mainsteps:1,
   formonedata:[],
   formtwodata:[],
   formdata:[]
}

const Data=createSlice({
    name:"Steps",
    initialState,
    reducers:{
        Mainstep:(state,action)=>
        {
            return produce(state,(draft)=>{
                // console.log(action)
                draft.mainsteps=action.payload
            })
        },
        Formonedata:(state,action)=>
        {
            return produce(state,(draft)=>
            {
                draft.formonedata.push(action.payload);
            })
        },
        Formtwodata:(state,action)=>
        {
            return produce(state,(draft)=>
            {
                draft.formtwodata.push(action.payload);
            })
        },
        Formdata:(state,action)=>
        {
            return produce(state,(draft)=>
            {
                console.log("Redux FormData",action)
                draft.formdata.push(action.payload);
            })
        }
    }
})

export const Datareducer=Data.reducer;
export const {Mainstep,Formdata}=Data.actions;
