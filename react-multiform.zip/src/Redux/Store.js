import { configureStore } from "@reduxjs/toolkit";
import { Datareducer } from "./Data";

const ReduxStore=configureStore({
    reducer:{
      StepData:Datareducer
    }
})

export default ReduxStore;