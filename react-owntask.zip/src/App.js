import {BrowserRouter,Routes,Route} from "react-router-dom";
import Login from "./Screens/Login";
import Navbar from "./Screens/Navbar";
import { useSelector } from "react-redux";

//Admin Screens
import Admin_home from "./Screens/AdminScreens/Admin_home";
import Add_Users from "./Screens/AdminScreens/Add_user";
import Add_mentors from "./Screens/AdminScreens/Add_mentors";
import Mapping from "./Screens/AdminScreens/Mapping";

//User Screens
import Users from "./Screens/UserScreens/Users";
import Quizpage from "./Screens/UserScreens/Quizpage";
import StartQuiz from "./Screens/UserScreens/StartQuiz";
import ResultPage from "./Screens/UserScreens/ResultPage";

//Mentor Screens
import Dashboard from "./Screens/MentorScreens/Dashboard";
import MentUserlist from "./Screens/MentorScreens/MentUserlist";
import CreateQuiz from "./Screens/MentorScreens/CreateQuiz";
import MapQuiz from "./Screens/MentorScreens/MapQuiz";

import MegaMenu from "./Hamburger/MegaMenu";
import CSS_Position from "./Hamburger/CSS_Position";
import SampleElement from "./Screens/MentorScreens/Sample";
import SampleButton from "./Screens/MentorScreens/Button";


function App() {
  const stage=useSelector((state)=>{return state.CheckData.stage});

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />}></Route>
        </Routes>
        {stage === 1 ? (
          <Routes>
            <Route path="admin" element={<Navbar />}>
              <Route index element={<Admin_home />} />
              <Route path="addusers" element={<Add_Users />} />
              <Route path="addmentors" element={<Add_mentors />} />
              <Route path="mapusers" element={<Mapping />} />
            </Route>
          </Routes>
        ) : (
          ""
        )}
        {stage === 2 ? (
          <Routes>
            <Route path="user" element={<Navbar />}>
              <Route index element={<Users />} />
              <Route path="quizpage" element={<Quizpage />} />
              <Route path="startquiz/:quizid" element={<StartQuiz />} />
              <Route
                path="startquiz/result/:status/:score"
                element={<ResultPage />}
              />
            </Route>
          </Routes>
        ) : (
          ""
        )}
        {stage === 3 ? (
          <Routes>
            <Route path="ment" element={<Navbar />}>
              <Route index element={<Dashboard />} />
              <Route path="userslist" element={<MentUserlist />} />
              <Route path="createquiz" element={<CreateQuiz />} />
              <Route path="mapquiz" element={<MapQuiz />} />
            </Route>
          </Routes>
        ) : (
          ""
        )}
      </BrowserRouter>
    </>
  );
}

export default App;
