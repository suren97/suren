function CSS_Position()
{
    return(
        <>
        <div className="bluebox"></div>
        <div className="yellowbox"></div>
        <div>
            <h2>Sample First</h2>
            <p>The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
            </p>
            <p>
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
            </p>
            <p>
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
            </p>
            <p>
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
            </p>
            <p>
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
            </p>
            <p>
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
                The demo then changes the flex-basis on the first item. It will then grow and 
                shrink from that flex-basis. This means that, for example, when the flex-basis of
                the first item is 200px, it will start out at 200px but then shrink 
                to fit the space available with the other items being at least min-content sized.
            </p>
        </div>
        </>
    )
}

export default CSS_Position;