import React,{Component} from "react";

class MegaMenu extends Component
{

componentDidMount(){
   const hamburger=document.querySelector("#hamburger");
   
   const mainmenu=document.querySelector(".menu");
   const menu=mainmenu.querySelector(".menu-main");
   const closeMenu=document.querySelector("#close");
   const goBack=mainmenu.querySelector(".go-back");
   closeMenu.addEventListener("click",()=>
   {
       mainmenu.style.display="none"
   })
   hamburger.addEventListener("click",()=>
   {
       mainmenu.style.display="block"
   })

   let subMenu;
   menu.addEventListener("click",(e)=>{
      if(e.target.closest(".menu-item-has-children"))
      {
        const hasChildren=e.target.closest(".menu-item-has-children");
        showSubMenu(hasChildren);
      }
   })
   goBack.addEventListener("click",()=>{
      hideSubMenu();
   })
   function showSubMenu(hasChildren){
     subMenu=hasChildren.querySelector(".sub-menu");
     subMenu.classList.add("active");
     subMenu.style.animation="slideLeft 0.5s ease forwards"
     const menuTitle=hasChildren.querySelector("i").parentNode.childNodes[0].textContent;
     mainmenu.querySelector(".current-menu-title").innerHTML=menuTitle;
     mainmenu.querySelector(".mobile-menu-head").classList.add("active");
   }

   function hideSubMenu()
   {
    subMenu.style.animation="slideRight 0.5s ease forwards"
    setTimeout(()=>{
         subMenu.classList.remove("active");
    },300)
    mainmenu.querySelector(".current-menu-title").innerHTML="";
    mainmenu.querySelector(".mobile-menu-head").classList.remove("active");
   }
}

render()
{
    return(
        <>
        {/* Headers Start */}
        <header className="header">
          <div className="container">
            <div className="row v-center">
               <div className="header-item item-left">
                 {/* Mobile Menu Triggers */}
                 <div className="mobile-menu-trigger" id="hamburger">
                    <span>&#9776;</span>
                  </div>
                  <div className="logo">
                    <a href="#">MyStore</a>
                  </div>
               </div>
               {/* Menu starts */}
               <div className="header-item item-center">
                    <nav className="menu">
                        <div className="mobile-menu-head">
                            <div className="go-back"><i className="fa fa-angle-left"></i></div>
                            <div className="current-menu-title"></div>
                            <div className="mobile-menu-close" id="close">&times;</div> 
                        </div>
                        <ul className="menu-main">
                            <li>
                                <a href="#">Home</a>
                            </li>
                            <li className="menu-item-has-children">
                                <a href="#">Shop <i className="fa fa-angle-down"></i></a>
                                <div className="sub-menu mega-menu mega-menu-column-4">
                                    <div className="list-item">
                                        <h4 className="title">Clothes</h4>
                                        <ul>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li> 
                                        </ul>
                                        <h4 className="title">Section-2</h4>
                                        <ul>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                        </ul>
                                    </div>
                                    <div className="list-item">
                                        <h4 className="title">Sports</h4>
                                        <ul>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li> 
                                        </ul>
                                        <h4 className="title">Section-2</h4>
                                        <ul>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                        </ul>
                                    </div>
                                    <div className="list-item">
                                        <h4 className="title">Accessories</h4>
                                        <ul>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li> 
                                        </ul>
                                        <h4 className="title">Section-2</h4>
                                        <ul>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                        </ul>
                                    </div>
                                    <div className="list-item">
                                        <h4 className="title">Footwears</h4>
                                        <ul>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li> 
                                        </ul>
                                        <h4 className="title">Section-2</h4>
                                        <ul>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                            <li><a href="#">Product List</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li className="menu-item-has-children">
                                <a href="#">Blog <i className="fa fa-angle-down"></i></a>
                                <div className="sub-menu single-column-menu">
                                   <ul>
                                     <li><a href="#">standard Layout</a></li>
                                     <li><a href="#">grid Layout</a></li>
                                     <li><a href="#">single Post Layout</a></li>
                                   </ul>
                                </div>
                            </li>
                            <li className="menu-item-has-children">
                                <a href="#">Pages <i className="fa fa-angle-down"></i></a>
                                <div className="sub-menu single-column-menu">
                                   <ul>
                                     <li><a href="#">Login</a></li>
                                     <li><a href="#">Register</a></li>
                                     <li><a href="#">Faq</a></li>
                                     <li><a href="#">404 Pages</a></li>
                                   </ul>
                                </div>
                            </li>
                            <li>
                                <a href="#">Contact</a>
                            </li>
                        </ul>
                    </nav>
               </div>
                {/* Menu Ends */}
               <div className="header-item item-right">
                  <a href="#"><i className="fa fa-search"></i></a>
                  <a href="#"><i className="fa fa-heart"></i></a>
                  <a href="#"><i className="fa fa-shopping-cart"></i></a>
               </div>
            </div>
          </div>
        </header>
        {/* Header Ends */}

         {/* Banner Starts */}
          <section className="banner-section">

          </section>
          {/* Banner Ends */}
        </>
    )
}
}

export default MegaMenu;