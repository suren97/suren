import React,{Component} from "react";

class ResponsiveMenu extends Component
{
componentDidMount()
{
    let ham=document.querySelector("#ham");
    let navbar=document.querySelector("#dropdown");
    let resp=document.querySelector(".resdropdown");
    let dropdown=document.querySelector(".dropdown-content");
    ham.addEventListener("click",(e)=>
    {
    ham.style.display="none";
    resp.style.width="50%";
    resp.style.display="block"
    })
}

CloseNav()
{
    let ham=document.querySelector("#ham");
    let resp=document.querySelector(".resdropdown");
    resp.style.width="0px";
    resp.style.display="none"
    ham.style.display="block";

    // ham.addEventListener("click",(e)=>
    // {
    // ham.style.display="block";
    // resp.style.width="0px";
    // resp.style.display="none"
    // })  
}

render()
{
return(
        <div>
        <div className="hamburger" id="ham">
        <div>&#9776;</div>
        </div>
        <div className="container">
        <nav>
        <ul>
            <div className="dropdown resdropdown" id="dropdown">
            <a href="javascript:void(0)" class="closebtn" onClick={()=>this.CloseNav()}>×</a>
                <li><a href="#">News &nbsp;&nbsp;<i class="fa fa-caret-down"></i></a></li>
                    <div className="dropdown-content resdropcontent">
                        <div className="row">
                            <div className="column">
                                 <h3>Category 1</h3>
                                 <a href="#">Link 1</a>
                                 <a href="#">Link 2</a>
                                 <a href="#">Link 3</a>
                            </div>
                            <div class="column">
                                 <h3>Category 2</h3>
                                 <a href="#">Link 1</a>
                                 <a href="#">Link 2</a>
                                 <a href="#">Link 3</a>
                            </div>
                            <div class="column">
                                 <h3>Category 3</h3>
                                 <a href="#">Link 1</a>
                                 <a href="#">Link 2</a>
                                 <a href="#">Link 3</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="dropdown resdropdown">
                <li><a href="#">Facts &nbsp;&nbsp;<i class="fa fa-caret-down"></i></a></li>
                <div className="dropdown-content resdropcontent">
                        <div className="row">
                            <div className="column">
                                 <h3>Category 1</h3>
                                 <a href="#">Fact 1</a>
                                 <a href="#">Fact 2</a>
                                 <a href="#">Fact 3</a>
                            </div>
                            <div class="column">
                                 <h3>Category 2</h3>
                                 <a href="#">Fact 1</a>
                                 <a href="#">Fact 2</a>
                                 <a href="#">Fact 3</a>
                            </div>
                            <div class="column">
                                 <h3>Category 3</h3>
                                 <a href="#">Fact 1</a>
                                 <a href="#">Fact 2</a>
                                 <a href="#">Fact 3</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="dropdown resdropdown">
                <li><a href="#">Weather &nbsp;&nbsp;<i class="fa fa-caret-down"></i></a></li>
                <div className="dropdown-content resdropcontent">
                        <div className="row">
                            <div className="column">
                                 <h3>Category 1</h3>
                                 <a href="#">Weather 1</a>
                                 <a href="#">Weather 2</a>
                                 <a href="#">Weather 3</a>
                            </div>
                            <div class="column">
                                 <h3>Category 2</h3>
                                 <a href="#">Weather 1</a>
                                 <a href="#">Weather 2</a>
                                 <a href="#">Weather 3</a>
                            </div>
                            <div class="column">
                                 <h3>Category 3</h3>
                                 <a href="#">Weather 1</a>
                                 <a href="#">Weather 2</a>
                                 <a href="#">Weather 3</a>
                            </div>
                        </div>
                    </div>
                </div>
            </ul>
        </nav>
        </div>
        </div>
    )
}
}

export default ResponsiveMenu;