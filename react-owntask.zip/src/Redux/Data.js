import { createSlice } from "@reduxjs/toolkit";
import produce from "immer";
import {persistor} from "../index";

const initialState={
    stage:1,
    adminLog:{username:"Surendar",password:"Suren@1967"},
    userdata:[],
    mentordata:[],
    mappedlist:[],
    Quiz:[],
    mappedQuiz:[],
    CompQuiz:[],
    QuizId:0,
    Logout:[]
}

const Data=createSlice({
    name:"CheckData",
    initialState,
    reducers:{
      stage:(state,action)=>
      {
      
        return produce(state,(draft)=>{
            draft.stage=action.payload
        })
      },
      Adduser:(state,action)=>
      {
        console.log(action)
        return produce(state,(draft)=>{
            draft.userdata.push(action.payload);
        })
      },
      Deleteuser:(state,action)=>
      {
        return produce(state,(draft)=>{
          let index=action.payload
            draft.userdata.splice(index,1);
        })
      },
      Deletementor:(state,action)=>
      {
        return produce(state,(draft)=>
        {
          let index=action.payload
          draft.mentordata.splice(index,1);
        })
      },
      Addmentors:(state,action)=>
      {
        return produce(state,(draft)=>{
            draft.mentordata.push(action.payload);
        })
      },
      MappedList:(state,action)=>
      {
        return produce(state,(draft)=>{
           draft.mappedlist.push(action.payload);
        })
      },
      AddQuiz:(state,action)=>
      {
        return produce(state,(draft)=>
        {
          draft.QuizId=draft.QuizId+1
          draft.Quiz.push(action.payload)
        })
      },
      MappedQuiz:(state,action)=>
      {
        return produce(state,(draft)=>{
          if(action.payload.value === "update")
          {
             let num=state.mappedQuiz.findIndex(checkindex);
             function checkindex(value) {
              return value.quizid == action.payload.quizId;
            }
            draft.mappedQuiz.splice(num,1);
            draft.CompQuiz.push(action.payload)
          }
          else
          {
            draft.mappedQuiz.push(action.payload)
          }
        })
      },
      CompleteQuiz:(state,action)=>
      {
        return produce(state,(draft)=>{
          console.log(action)
          draft.CompQuiz.push(action.payload)
        })
      },
      LogOut:(state,action)=>
      {
         return initialState;
      }
    }
});

export const Datareducer=Data.reducer;
export const {
  stage,
  Adduser,
  Deleteuser,
  LogOut,
  CompleteQuiz,
  Addmentors,
  Deletementor,
  MappedList,
  MappedQuiz,
  AddQuiz,
} = Data.actions;