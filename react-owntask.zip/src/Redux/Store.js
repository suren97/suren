import { configureStore } from "@reduxjs/toolkit";
import { Datareducer, LogOut } from "./Data";
import storage from "redux-persist/lib/storage";
import {persistReducer} from "redux-persist";
import localforage from "localforage";
import { combineReducers } from "@reduxjs/toolkit";
import { MappedQuiz } from "./Data";

const persistConfig={
  key:"root",
  version:1,
  storage:localforage
}

const reducer=combineReducers({
  CheckData:Datareducer
})

const persistedReducer=persistReducer(persistConfig,reducer);

const getMiddleware1=({getState,dispatch})=>next=>action=>
{
  if(action.type === "CheckData/CompleteQuiz")
  {
      action.payload.value="update"
      dispatch(MappedQuiz(action.payload))
  }
  else
  {
  return next(action)
  }
}

// const logoutMiddleware =
//   ({ getState, dispatch }) =>
//   (next) =>
//   (action) => {
//     console.log(action)
//     if (action.type === "CheckData/LogOut") {
//       // action.payload.value = "update";
//       // dispatch(MappedQuiz(action.payload));
//     } else {
//       return next(action);
//     }
//   };


const middlewares=[
  getMiddleware1,
  // logoutMiddleware
];

export const ReduxStore=configureStore({
  reducer:persistedReducer,
  middleware:getDefaultMiddleware=>
  getDefaultMiddleware({
      immutableCheck:false,
      serializableCheck:false,
  }).concat(middlewares)
})

// export const ReduxStore=configureStore({
//    reducer:persistedReducer
// })

