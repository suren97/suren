import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import {
    Stack,
    Icon,
    TextField,
    InputAdornment,
    InputLabel,
    Button,
  } from "@mui/material";
  import {
    PersonAddAltOutlined,
    EmailOutlined,
    PersonOutlineOutlined,
    PhoneAndroidOutlined,
    KeyOutlined,
    DeleteOutlineOutlined,
  } from "@mui/icons-material";
import { Grid } from "@mui/material";
import { useEffect, useState,useRef } from "react";
import { useSelector,useDispatch } from "react-redux";
import { Adduser,Deleteuser } from "../../Redux/Data";
import "ag-grid-enterprise";

function Add_Users()
{
const [rowdata,setrowdata]=useState([]);
const GridRef=useRef(null);
const [columnDefs,setcolumn]=useState([
    {field:"username"},
    {field:"email"},
    {field:"mobile"},
    {field:"password"},
    {
      field:"action",
      cellRenderer:p=>Displaybutton(p)
    }
]);
const [del,setdel]=useState();

function Displaybutton(params)
{
  return(
    <Button color="error" size="small" sx={{p:0.5,mb:1}} variant="contained" onClick={()=>Delete(params)} ><DeleteOutlineOutlined />&nbsp;Delete</Button>
  )
}

function Delete(params)
{
  let rowind=params.rowIndex;
  dispatch(Deleteuser(rowind));
  setdel(rowind);
}

const defaultColDef=({
    flex:1,
    sortable:true
});
const [inputs,setinputs]=useState({
    username:"",
    email:"",
    mobile:"",
    password:""
});
const dispatch=useDispatch();
const state=useSelector((state)=>{return state.CheckData});
const [id,setid]=useState({userid:state.userdata ? state.userdata.length : 0 });

let handlesubmit=()=>{
    const { username, email, mobile, password } = inputs;
    let data = {};
    data.id=id.userid;
    data.username = username;
    data.email = email;
    data.mobile = mobile;
    data.password = password;
    setid(id.userid+1);
    dispatch(Adduser(data));
    setinputs((prev)=>
    {
        return {...prev,username:"",email:"",mobile:"",password:""}
    })
}

let handleChange=(e)=> {
    setinputs((prev)=>
    {
        return {...prev,[e.target.name]:e.target.value}
    })
}

useEffect(()=>
{
  setrowdata(state.userdata);
},[id,del]);


return(
    <>
    <div className="headercontent">
      <Stack direction={"row"} spacing={1.5}>
        <Icon>
          <PersonAddAltOutlined />
        </Icon>
        <div>Add Users</div>
      </Stack>
    </div>
    <div className="fieldcontainer">
      <Grid container gap={5} sx={{ justifyContent: "center" }}>
        <Grid xs={5}>
          <TextField
            fullWidth
            className="textcontainer"
            id="input-with-icon-textfield"
            label="Username"
            name="username"
            value={inputs.username}
            onChange={(e) =>handleChange(e)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <PersonOutlineOutlined />
                </InputAdornment>
              ),
            }}
            variant="outlined"
          />
        </Grid>
        <Grid xs={5}>
          <TextField
            fullWidth
            className="textcontainer"
            id="input-with-icon-textfield"
            name="email"
            label="Email"
            value={inputs.email}
            onChange={(e) => handleChange(e)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <EmailOutlined />
                </InputAdornment>
              ),
            }}
            variant="outlined"
          />
        </Grid>
        <Grid xs={5}>
          <TextField
            fullWidth
            className="textcontainer"
            id="input-with-icon-textfield"
            label="Mobile"
            name="mobile"
            value={inputs.mobile}
            onChange={(e) => handleChange(e)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <PhoneAndroidOutlined />
                </InputAdornment>
              ),
            }}
            variant="outlined"
          />
        </Grid>
        <Grid xs={5}>
          <TextField
            fullWidth
            className="textcontainer"
            id="input-with-icon-textfield"
            label="Password"
            name="password"
            value={inputs.password}
            onChange={(e) => handleChange(e)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <KeyOutlined />
                </InputAdornment>
              ),
            }}
            variant="outlined"
          />
        </Grid>
      </Grid>
      <div style={{ textAlign: "center" }}>
        <Button
          sx={{ mt: 5, p: 1 }}
          variant="contained"
          onClick={() => handlesubmit()}
        >
          Submit
        </Button>
      </div>
    </div>
    <div className="ag-theme-alpine tablecontainer">
      <AgGridReact
        ref={GridRef}
        rowData={rowdata}
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
      />
    </div>
  </>
)
}

export default Add_Users;