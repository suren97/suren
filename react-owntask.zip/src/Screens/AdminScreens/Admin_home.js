import { HomeOutlined } from "@mui/icons-material";
import { Icon,Stack } from "@mui/material";

function Admin_home()
{
    return(
        <>
        <div className="headercontent">
            <Stack direction={"row"} spacing={1}>
               <Icon><HomeOutlined /></Icon><div>Home</div>
            </Stack>
        </div>
        </>
    )
}

export default Admin_home;