import React, { Component } from "react";
import { Stack, Icon, Grid, Select, MenuItem, Button } from "@mui/material";
import { Merge } from "@mui/icons-material";
import { connect } from "react-redux";
import { AgGridReact } from "ag-grid-react";
import { MappedList } from "../../Redux/Data";
import { bindActionCreators } from "redux";
import { DeleteOutlineOutlined } from "@mui/icons-material";

class Mapping extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userslist: props.userdata,
      mentorslist: props.mentordata,
      mappedlist: props.mappedlist,
      GridRef: React.createRef(),
      api: [],
      columnDefs: [
        { field: "username" },
        { field: "mentorname" }
      ],
      defaultColDef: {
        sortable: true,
        flex: 1,
        filter: true,
      },
      selectedusers: "",
      selectedmentors: "",
      id: props.mappedlist ? props.mappedlist.length : 0,
    };
  }

  DisplayButton(params) {
    return (
      <Button
        color="error"
        size="small"
        sx={{ p: 0.5, mb: 1 }}
        variant="contained"
        onClick={() => this.Delete(params)}
      >
        <DeleteOutlineOutlined />
        &nbsp;Delete
      </Button>
    );
  }

  Delete(params) {
    console.log(params);
  }

  componentDidMount() {
    let users = this.state.userslist.filter((v) =>
      !this.state.mappedlist.map(v2=>v2.username).includes(v.username)
    );
    // let users2 = this.state.userslist.filter((v) =>
    //     this.state.mappedlist.every(v2=>v2.username !== v.username)
    // );
    this.setState({ userslist: users });
  }

  handleChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  onGridReady = (params) => {
    this.setState({ api: params.api });
  };

  handleSubmit() {
    let data = {};
    data.id = this.state.id;
    data.username = this.state.selectedusers;
    data.mentorname = this.state.selectedmentors;
    let users=this.state.userslist.filter(v=>v.username !== this.state.selectedusers);
    this.setState({ userslist: users, id: this.state.id + 1,selectedmentors:"" });
    this.props.MappedList(data);
  }

  componentDidUpdate() {
    setTimeout(() => {
      this.state.api.setRowData(this.props.mappedlist)
    }, 1);
  }

  render() {
    return (
      <>
        <div className="headercontent">
          <Stack direction={"row"} spacing={1.5}>
            <Icon>
              <Merge />
            </Icon>
            <div>Map Users</div>
          </Stack>
        </div>
        <Stack
          display="flex"
          flexDirection={"row"}
          justifyContent="center"
          gap={10}
          sx={{ mt: 10 }}
        >
          <select
            className="mapcontainer"
            name="selectedusers"
            value={this.state.selectedusers}
            onChange={(e) => this.handleChange(e)}
          >
            <option>----Select Options----</option>
            {this.state.userslist.map((v, i) => {
              return <option>{v.username}</option>;
            })}
          </select>
          <select
            className="mapcontainer"
            name="selectedmentors"
            value={this.state.selectedmentors}
            onChange={(e) => this.handleChange(e)}
          >
            <option>----Select Options----</option>
            {this.state.mentorslist.map((v, i) => {
              return <option>{v.username}</option>;
            })}
          </select>
        </Stack>
        <div style={{ textAlign: "center" }}>
          <Button
            sx={{ mt: 3 }}
            variant="contained"
            onClick={() => this.handleSubmit()}
          >
            Submit
          </Button>
        </div>
        <div className="ag-theme-alpine tablecontainer">
          <AgGridReact
            ref={this.state.GridRef}
            rowData={this.state.mappedlist}
            columnDefs={this.state.columnDefs}
            defaultColDef={this.state.defaultColDef}
            onGridReady={this.onGridReady}
          />
        </div>
      </>
    );
  }
}

const mapStateToprops = (state) => {
  return {
    userdata: state.CheckData.userdata,
    mentordata: state.CheckData.mentordata,
    mappedlist: state.CheckData.mappedlist,
  };
};

const dispatchToprops = (dispatch) => {
  return bindActionCreators(
    {
      MappedList: MappedList,
    },
    dispatch
  );
};

export default connect(mapStateToprops, dispatchToprops)(Mapping);
