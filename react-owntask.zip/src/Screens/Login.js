import {TextField,Select,Stack,Button } from "@mui/material";
import { useContext, useEffect, useState } from "react";
import { useSelector,useDispatch } from "react-redux";
import { stage } from "../Redux/Data";


export const handleactivity=()=>
{
  console.log("mousemoving")
}

function Login()
{
const [name,setname]=useState();
const [pass,setpass]=useState();
const dispatch=useDispatch();
const getAdmin=useSelector((state)=>{
  return state.CheckData.adminLog
})
const getUsers=useSelector((state)=>{ return state.CheckData.userdata });
const getMentors=useSelector((state)=>{ return state.CheckData.mentordata });

function checkAdmin(data)
{
   if(data)
   {
     if(data.name !== getAdmin.username)
     {
      return false;
     } 
     if(data.password !== getAdmin.password)
     {
      return false;
     }
     return true;
   }
}

function checkUsers(data)
{
  let check="";
  if(data)
  {
    check=getUsers.some(v=>{ return v.username === data.name && data.password === v.password })
  }
  return check
}

function checkMentors(data)
{
  let check="";
  if(data)
  {
    check=getMentors.some(v=>{return v.username === data.name && data.password === v.password })
  }
  return check
}


// useEffect(()=>
// {
 
// },[])

const Submit=()=>
{
   let data={};
   data.name=name;
   data.password=pass;
   if(checkAdmin(data))
   {
      alert("Logged in Successfully");
      dispatch(stage(1));
      localStorage.setItem("login",JSON.stringify(data));
      window.location.href="/admin";
   }
   else if(checkUsers(data))
   {
      alert("Logging in User");
      dispatch(stage(2));
      localStorage.setItem("login",JSON.stringify(data))
      window.location.href="/user";
   }
   else if(checkMentors(data))
   {
      alert("Logging in Mentor");
      dispatch(stage(3));
      localStorage.setItem("login",JSON.stringify(data));
      window.location.href="/ment"
   }
   else
   {
    alert("Invalid Credential");
   }
}

const handletext=e=>
{
    let value=e.target.value;
    if(e.target.name=="user")
    {
        setname(value);
    }
    else
    {
        setpass(value); 
    }
}

return(
    <div className="fullpage">
    <div className="logcontainer">
    <h1 style={{textAlign:"center"}}>Login</h1>
    <Stack direction={"column"} spacing={6}>
    <TextField
    fullWidth
    variant="outlined"
    label="Username"
    name="user"
    onChange={(e)=>handletext(e)}
    />
    <TextField 
    fullWidth
    variant="outlined"
    label="Password"
    type="password"
    onChange={(e)=>handletext(e)}
    />
    <Button variant="contained" sx={{p:1}} onClick={()=>Submit()}>Submit</Button>
    </Stack>
    </div>
    </div>
)
}

export default Login;
