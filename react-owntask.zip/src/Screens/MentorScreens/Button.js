import { Button } from "@mui/material";
import { useEffect,useState } from "react";
import UserButton from "./UserButton";

function SampleButton()
{
let usertype="User";
const [id,setid]=useState(1);

useEffect(()=>
{
  console.log(id)
},[id]);

let setAtt=()=>
{
  let bt=document.querySelector("#btn");
  
}

return(
      <>
      {/* <UserButton
      id="btn" 
      variant="outlined"
      // {...{variant:"contained"}}
      /> */}
      {console.log(<Button></Button>)}
        <Button 
        id="btn"
        variant="contained"
        >
          Primary
        </Button>
        <button onClick={()=>setAtt()}>Set Attribute</button> 
        </>
    )
}

export default SampleButton;