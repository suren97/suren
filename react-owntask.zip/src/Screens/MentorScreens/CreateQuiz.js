import React,{Component} from "react";
import { Quiz } from "@mui/icons-material";
import { Stack,Icon,Typography, TextField,Button, Select, Divider } from "@mui/material";
import {connect} from "react-redux";
import { AddQuiz } from "../../Redux/Data";
import { bindActionCreators } from "redux";

class CreateQuiz extends Component
{
constructor(props)
{
    super(props)
    this.state={
       questno:0,
       questions:[
        {quizId:props.QuizId,mentorname:"",quiztopic:"",questionno:"",question:"",options:[{option1:""},{option2:""},{option3:""},{option4:""}],answerkey:""}
       ],
       quiztopic:"",
       Display:false
    }
}

AddQuestion()
{
   this.setState({Display:true,questno:this.state.questno+1});
   let ques={questionno:"",question:"",options:[{option1:""},{option2:""},{option3:""},{option4:""}]}
   if(this.state.questno > 0)
   {
     this.state.questions.push(ques);
   }
}

handlechange(e)
{
   this.setState({[e.target.name]:e.target.value})
}

handletextarea(e,i)
{
  let mentname=JSON.parse(localStorage.getItem("login"));
  this.state.questions[i].mentorname=mentname.name
  this.state.questions[i].quiztopic=this.state.quiztopic;
  this.state.questions[i].question=e.target.value;
  this.state.questions[i].quizId=this.props.QuizId
}

handleoptions(e,mainindex,optionindex)
{
  this.state.questions[mainindex].questionno=mainindex+1
  this.state.questions[mainindex].options[optionindex]=e.target.value
}

handleanswer(e,index)
{
  this.state.questions[index].answerkey=e.target.value;
}

handleSubmit()
{
  let data={};
  data.quiz=this.state.questions
  this.props.AddQuiz(data)  
  this.setState({
    questions:[
      {quizId:this.props.QuizId,mentorname:"",quiztopic:"",questionno:"",question:"",options:[{option1:""},{option2:""},{option3:""},{option4:""}],answerkey:""}
     ],
     quiztopic:"",
     Display:false
  }) 
  alert("Submitted Successfully");
}

render()
{
    return(
    <>
    <div className="headercontent">
      <Stack direction={"row"} spacing={1.5}>
        <Icon>
          <Quiz />
        </Icon>
        <div>Create Quiz</div>
      </Stack>
    </div>
    <div className="quizcontainer">
    <Stack direction={"row"} gap={3} alignItems="center" flexWrap={"wrap"} sx={{p:2}} >
       <label>Quiz Topic</label>
       <input type="text" name="quiztopic" value={this.state.quiztopic} onChange={(e)=>this.handlechange(e)} />
       {this.state.Display ? (
        <>
            {this.state.questions.map((v,i)=>
            {
                return(
                    <>
                    <label>Question {i+1}</label>
                    <textarea name="question" onChange={(e)=>this.handletextarea(e,i)} />
                    <label>Options:</label>
                        {v.options.map((v,opitonindex)=>
                        {
                            return (
                                <>
                                 <TextField 
                                 className="optioncontainer" 
                                 label={Object.keys(v)} 
                                 onChange={(e)=>{this.handleoptions(e,i,opitonindex)}}
                                />
                                </>
                            )
                        })}
                    <label>Enter AnswerKey:</label>
                    <TextField style={{width:"80%"}} name="answerkey" onChange={(e)=>this.handleanswer(e,i)} />
                    </>
                )
            })}
        </>
       ):(
        " "
       )}
    </Stack>
    <Button variant="contained" onClick={()=>this.AddQuestion()}>Add Question</Button>
    <br></br>
    {this.state.Display ? ( <Button sx={{m:3}} style={{float:"right",textAlign:"center"}} variant="contained" color="success" onClick={()=>this.handleSubmit()}>Submit</Button> ):("")}
    </div>
    </>
    )
}
}

const mapStateToprops=state=>
{
    return{
      Quiz:state.CheckData.Quiz,
      QuizId:state.CheckData.QuizId
    }
}

const dispatchToprops=dispatch=>
{
  return bindActionCreators(
    {
       AddQuiz:AddQuiz
    },
    dispatch
   )
}

// export default CreateQuiz
export default connect(mapStateToprops,dispatchToprops)(CreateQuiz);