import React,{ Component } from "react";

class Dashboard extends Component
{
  render()
  {
    return(
        <div>
            <header>
                <h1>Dashboard</h1>
            </header>
        </div>
    )
  }
}

export default Dashboard;