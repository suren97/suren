import React,{ Component } from "react";
import { Stack,Icon,Button } from "@mui/material";
import { Merge } from "@mui/icons-material";
import { connect } from "react-redux";
import { MappedQuiz } from "../../Redux/Data";
import { bindActionCreators } from "redux";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

class MapQuiz extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            quiz:props.Quiz,
            GridRef:React.createRef(),
            userlist:[],
            quizoption:[],
            selectedquiz:"",
            selecteduser:"",
            rowdata:props.mappedQuiz,
            columnDefs:[
             {headerName:"Quizname",field:"quiz"},
             {headerName:"Username",field:"user"}
            ],
            defaultColDef:({
               flex:1
            }),
            id:props.mappedQuiz ? props.mappedQuiz.length : 0
        }
    }

componentDidMount()
{
    let quizname=this.state.quiz.map(v=>v.quiz[0].quiztopic);
    this.setState({quizoption:quizname});

    let loginuser=JSON.parse(localStorage.getItem("login"));
    let users=this.props.mappedlist.filter(v=> v.mentorname === loginuser.name )
    this.setState({userlist:users})
}

handleChange(e)
{
   this.setState({[e.target.name]:e.target.value})
}

handleSubmit()
{
    const {selecteduser,selectedquiz}=this.state;
    let quizId="";
    this.state.quiz.map((v,i)=> {
      if(v.quiz[0].quiztopic === selectedquiz)
      {
          quizId=v.quiz[0].quizId
      }
    })
    let data={};
    data.id=this.state.id +1
    data.quizid=quizId
    data.quiz=selectedquiz;
    data.user=selecteduser;
    let quizname=this.state.quizoption.filter(v=>v !== selectedquiz )
    this.setState({quizoption:quizname,selecteduser:""});
    this.setState({id:this.state.id+1});
    this.props.MappedQuiz(data);
}

componentDidUpdate()
{
   setTimeout(()=>{
      this.state.GridRef.current.api.setRowData(this.props.mappedQuiz)
   },1)
}

render()
{
    return(
    <>
    <div className="headercontent">
      <Stack direction={"row"} spacing={1.5}>
        <Icon>
          <Merge />
        </Icon>
        <div>Map Users</div>
      </Stack>
    </div>
    <Stack display="flex" flexDirection={"row"} justifyContent="center" gap={10} sx={{mt:10}}>
    <select 
      className="mapcontainer"
      name="selectedquiz"
      value={this.state.selectedquiz}
      onChange={(e)=>this.handleChange(e)}
      >
      <option>----Select Quiz----</option>
      {this.state.quizoption.map((v,i)=>
      {
         return <option>{v}</option>
      })}
      </select>
      <select
      className="mapcontainer"
      name="selecteduser"
      value={this.state.selecteduser}
      onChange={(e)=>this.handleChange(e)}
      >
       <option>----Select User----</option>
       {this.state.userlist.map((v,i)=>
       {
         return <option>{v.username}</option>
       })}
      </select>
    </Stack>
    <div style={{textAlign:"center"}}>
   <Button sx={{mt:3}} variant="contained" onClick={()=>this.handleSubmit()}>Submit</Button>
   </div>
   <div className="ag-theme-alpine tablecontainer">
       <AgGridReact 
       ref={this.state.GridRef}
       rowData={this.state.rowdata}
       columnDefs={this.state.columnDefs}
       defaultColDef={this.state.defaultColDef}
       />
   </div>
    </>
    )
  }
}

const mapStateToprops=state=>
{
    return{
        Quiz:state.CheckData.Quiz,
        userdata:state.CheckData.userdata,
        mappedlist:state.CheckData.mappedlist,
        mappedQuiz:state.CheckData.mappedQuiz
    }
}

const dispatchToprops=dispatch=>
{
  return bindActionCreators(
    {
       MappedQuiz:MappedQuiz
    },
    dispatch
   )
}


export default connect(mapStateToprops,dispatchToprops)(MapQuiz);
// export default MapQuiz;