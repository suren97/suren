import React,{ Component } from "react";
import { Stack,Icon } from "@mui/material";
import { People } from "@mui/icons-material";
import { AgGridReact } from "ag-grid-react";
import { connect } from "react-redux";

class MentUserlist extends Component
{
constructor(props)
{
    super(props)
    this.state={
        columnDefs:[
            {field:"username"},
            {field:"email"},
            {field:"mobile"}
        ],
        defaultColDef:({
            flex:1,
            sortable:true,
            filter:true
        }),
        rowdata:[]
    }
}

componentDidMount()
{
    let loginuser=JSON.parse(localStorage.getItem("login"));
    let rows=this.props.userdata.filter(v=>this.props.mappedlist.some(v1=>v1.mentorname === loginuser.name && v.username === v1.username ))
    this.setState({rowdata:rows})
}

render()
{
    return(
    <>
    <div className="headercontent">
      <Stack direction={"row"} spacing={1.5}>
        <Icon>
          <People />
        </Icon>
        <div>UsersList</div>
      </Stack>
    </div>
    <div className="ag-theme-alpine tablecontainer">
      <AgGridReact 
      rowData={this.state.rowdata}
      columnDefs={this.state.columnDefs}
      defaultColDef={this.state.defaultColDef}
      />
    </div>
    </>
    )
}
}

const mapStateToprops=state=>
{
   return{
       mappedlist:state.CheckData.mappedlist,
       userdata:state.CheckData.userdata
   }
}

export default connect(mapStateToprops,null)(MentUserlist);