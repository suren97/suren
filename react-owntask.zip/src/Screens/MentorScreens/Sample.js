//NOTE:
//1. This code is to Convert Map entries to Array Element and Array to Map entries
//2. We used Recursive function Method to implement the code 

function SampleElement() {
  const NEW_SONATA_MAP_TYPE="MAP"  
  let mapelem = new Map();
  mapelem.set(117, 3);
  mapelem.set(261, 3);
  mapelem.set(119, 3);
  let mapelem2 = new Map();
  mapelem2.set(2, mapelem);
  let transelem = transformToArray(mapelem2);
  let transfrom=transformFromArray(transelem);

  function transformToArray(dataToTransform) {
    if (dataToTransform instanceof Map) {
      const transformedData = new Map();
      dataToTransform.forEach((v, k) => {
        if (
          v instanceof Map ||
          v instanceof Array ||
          v instanceof Set ||
          v instanceof Object
        ) {
            transformedData.set(k,transformToArray(v));
        } else {
          transformedData.set(k, v);
        }
      });
      return Array.from(transformedData);
    }
  }

  function transformFromArray(arrayData, key = "ss") {
    if(NEW_SONATA_MAP_TYPE){
         const transformedData = new Map() 
         arrayData.forEach((v) => { 
            console.log(v)
            if(v[1] instanceof Array || v[1] instanceof Object){
                 transformedData.set(v[0], transformFromArray(v[1])) 
                }else {
                     transformedData.set(v[0], v[1]);
                     }
                     })
     return transformedData
   }
  };

  return (
    <div>
      <header>1</header>
    </div>
  );
}

export default SampleElement;
