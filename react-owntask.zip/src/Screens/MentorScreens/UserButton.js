import { Button } from "@mui/material"

function UserButton(props)
{
    return(
        <div>
            <Button
            variant={props.variant}
            >
                User
            </Button>
        </div>
    )
}

export default UserButton