import { Link,Outlet } from "react-router-dom";
import { Button } from "@mui/material";
import { useSelector,useDispatch } from "react-redux";
import {LogOut} from "../Redux/Data";

function Navbar()
{
const dispatch=useDispatch();

let logout=()=>
{
  // dispatch(LogOut()
  localStorage.removeItem("login");
  window.location.href="/"
}  

const stage=useSelector((state)=>{return state.CheckData.stage});

return(
    <div>
      {stage === 1 ? (
      <ul>
        <li><Link to="/admin">Home</Link></li>
        <li><Link to="addusers">Add Users</Link></li>
        <li><Link to="addmentors">Add Mentors</Link></li>
        <li><Link to="mapusers">Mapping</Link></li>
        <li name="button"><Button variant="contained" color="error" onClick={()=>logout()}>Logout</Button></li>
      </ul>
      ):(
        ""
      )}
      {stage === 2 ? (
        <ul>
          <li><Link to="/user">Dashboard</Link></li>
          <li><Link to="quizpage">Quiz</Link></li>
          <li name="button"><Button variant="contained" color="error" onClick={()=>logout()}>Logout</Button></li>
        </ul>
      ):(
        ""
      )}
      {stage === 3 ? (
      <ul>
        <li><Link to="/ment">Dashboard</Link></li>
        <li><Link to="userslist">UsersList</Link></li>
        <li><Link to="createquiz">Create Quiz</Link></li>
        <li><Link to="mapquiz">Map Quiz</Link></li>
        <li name="button"><Button variant="contained" color="error" onClick={()=>logout()}>Logout</Button></li>
      </ul>
      ):(
        ""
      )}
      <Outlet />
    </div>
)
}

export default Navbar;