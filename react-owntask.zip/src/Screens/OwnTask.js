import { useState } from "react";

function OwnTask()
{
  const [bookname,setbook]=useState([
    { title: 'The Catcher in the Rye', author: 'J.D. Salinger', year: 1951 },
    { title: 'To Kill a Mockingbird', author: 'Harper Lee', year: 1960 },
    { title: '1984', author: 'George Orwell', year: 1949 },
    { title: 'One Hundred Years of Solitude', author: 'Gabriel Garcia Marquez', year: 1967 },
    { title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', year: 1925 },
    { title: 'Pride and Prejudice', author: 'Jane Austen', year: 1813 },
    { title: 'Moby-Dick', author: 'Herman Melville', year: 1851 },
    { title: 'War and Peace', author: 'Leo Tolstoy', year: 1869 },
    { title: 'The Lord of the Rings', author: 'J.R.R. Tolkien', year: 1954 },
]);

//console.log(Math.floor(1966/10)*10)
const booksbydecade=checkyear(bookname);
console.log(booksbydecade)

function checkyear(books)
{
    const counts={};
    let data={};
    for(const book of books)
    {
        const decade=Math.floor(book.year/10)*10;
        const decadeLabel=`${decade}s`;
        if(counts[decadeLabel])
        {
            console.log(counts[decadeLabel])
            counts[decadeLabel]++;
        }
        else
        {
            counts[decadeLabel]=1;
        }
    }
    return counts;
}
    
return(
    <div>
        <header>
            <h1>Sample Own</h1>
        </header>
    </div>
)
}

export default OwnTask;