import {TextField,Select,Stack,Button } from "@mui/material";
import React,{Component} from "react";

// document.addEventListener("DOMContentLoaded",ready);
// function ready()
// {
//     alert("DOM is ready");
// }

// window.onload=function()
// {
//     alert("Page loaded");
// }

window.addEventListener("unload",()=>{
    alert("Unloading..");
})


class Sample_Login extends Component
{
constructor(props)
{
    super(props)
    this.state={
        name:"",
        password:""
    }
    
}

inputListener()
{
  console.log("window")
}

ready()
{
    console.log("Ready State");
}

componentDidMount()
{
    // console.log("did");
    window.addEventListener("storage",this.inputListener);
}


handletext(e)
{
    let value=e.target.value;
    if(e.target.name=="user")
    {
        this.setState({name:value});
    }
    else
    {
        this.setState({password:value})
    }
}

Submit()
{
  let data={};
  data.name=this.state.name;
  data.password=this.state.password;
  console.log(data)
  localStorage.setItem("credentials",JSON.stringify(data));
}

render()
{
    return(
        <>
        <div className="logcontainer">
        <h1 style={{textAlign:"center"}}>Login</h1>
        <Stack direction={"column"} spacing={6}>
        <TextField 
        fullWidth
        variant="outlined"
        label="Username"
        name="user"
        onChange={(e)=>this.handletext(e)}
        />
        <TextField 
        fullWidth
        variant="outlined"
        label="Password"
        type="password"
        onChange={(e)=>this.handletext(e)}
        />
        <Button id="btn" variant="contained" sx={{p:1}} onClick={()=>this.Submit()}>Submit</Button>
        </Stack>
        </div>
        </>
    )
}
}

export default Sample_Login;