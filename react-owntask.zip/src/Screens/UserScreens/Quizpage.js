import { Stack,Icon } from "@mui/material";
import { Assessment } from "@mui/icons-material";
import { useSelector,useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import {Button} from "@mui/material";

function Quizpage(props)
{
const data=useSelector((state)=>state.CheckData)
const [quiz,setquiz]=useState();
const userlog=JSON.parse(localStorage.getItem("login"));

useEffect(()=>
{ 
  let getquiz=data.mappedQuiz.filter(v=>v.user === userlog.name);
  setquiz(getquiz);
},[]);

let DirectQuiz=(params)=>
{
  console.log(params)
  window.location.href=`startquiz/${params.quizid}`
}

return(
    <>
    <div className="headercontent">
      <Stack direction={"row"} spacing={1.5}>
        <Icon>
          <Assessment />
        </Icon>
        <div>Quiz</div>
      </Stack>
    </div>
    {quiz && quiz.map((v,i)=>
    {
       return <div className="quizlist">
        <div className="grid1" style={{fontSize:"1.2rem",fontWeight:"bold",color:"green"}}>{v.quiz}</div>
        <div className="grid2" style={{justifySelf:"right"}}>
        <Button  variant="contained" sx={{width:120,p:1,mr:6,fontSize:"0.9rem"}} onClick={()=>DirectQuiz(v)} >
            Start quiz
        </Button>
        </div>
    </div>
    })}
    </>
)
}

export default Quizpage;