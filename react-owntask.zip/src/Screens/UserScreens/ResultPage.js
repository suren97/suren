import { Stack,Icon } from "@mui/material";
import { useParams } from "react-router-dom";

function ResultPage()
{
let getresult=useParams();
console.log(getresult);

return(
    <>
    {getresult.status==="pass" ? (
      <div className="resultcontent">
         Congratualtions ! You have Completed the Quiz.
         your Score is {getresult.score}
      </div>
      ):(
      <div className="resultcontent">
      
      </div>
      )}
    </>
)
}

export default ResultPage;