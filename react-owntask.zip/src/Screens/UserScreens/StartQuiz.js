import { Stack,Icon,Button,Typography,Paper,RadioGroup,FormLabel,FormControlLabel,Radio } from "@mui/material";
import { Assessment } from "@mui/icons-material";
import { useParams } from "react-router-dom";
import { useEffect,useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { CompleteQuiz } from "../../Redux/Data";

function StartQuiz()
{
let getid=useParams();
const fetchdata=useSelector((state)=>state.CheckData);
const [Question,setQuestion]=useState();
const [selectedoption,setoptions]=useState({});
const localdata=JSON.parse(localStorage.getItem("login"));
const dispatch=useDispatch();

useEffect(()=>
{
  let quizList=fetchdata.Quiz;
  let getdata=quizList.filter(v=>v["quiz"].some(v=>v.quizId == getid.quizid))
  setQuestion(getdata[0].quiz);
},[]);

let handleRadio=(e)=>
{
    setoptions((prev)=>
    {
        return {...prev,[e.target.name]:e.target.value} 
    })
}

const handleSubmit=()=>
{
   let data={};
   let result=0;
   data.quizId=getid.quizid;
   data.answers=selectedoption;
   data.username=localdata.name;
   let getquiz=fetchdata.Quiz;
   let totalques;
   getquiz.map(v=>{
    v["quiz"].map((val,ind)=>
    {
      if(val.quizId == getid.quizid)
      {
        totalques=v["quiz"].length;
        if(parseInt(selectedoption[val.questionno])+1 == val.answerkey)
        {
          result=result+1;
        }
      }
    })
   })
   let pass=Math.floor(totalques/2);
   if(result > pass)
   {
    dispatch(CompleteQuiz(data));
    window.location.href=`result/pass/${pass}`
   }
   else
   {
    // window.location.href=`result/fail/${pass}`
   }
}

return(
    <>
    <div className="headercontent">
      <Stack direction={"row"} spacing={1.5}>
        <Icon>
          <Assessment />
        </Icon>
        <div>Write Quiz</div>
      </Stack>
    </div>
    <div className="quescontainer">
        {Question && Question.map((v,i)=>{
         return <div className="questans">
            <Stack direction={"column"}>
                <Paper elevation={1} sx={{p:2}}>
                <Typography variant="p"><span>{v.questionno}.</span>&nbsp;{v.question}</Typography>
                <div style={{marginTop:"1%"}}>
                <FormLabel id="demo-controlled-radio-buttons-group">Select Answer</FormLabel>
                <RadioGroup
                aria-labelledby="demo-controlled-radio-buttons-group"
                name="controlled-radio-buttons-group"
                onChange={(e)=>handleRadio(e)}
                >
                    {v.options.map((v2,i)=>{
                   return <FormControlLabel 
                    name={v.questionno}
                    value={i}
                    control={<Radio />} 
                    label={v2}
                    labelPlacement="end" 
                    />
                  })}
                </RadioGroup>
                </div>
                </Paper>
            </Stack>
        </div>
        })}
    </div>
    <div style={{textAlign:"center",padding:10,margin:10}}>
        <Button variant="contained" size="large" onClick={()=>handleSubmit()}>Submit</Button>
    </div>
    </>
)
}

export default StartQuiz;