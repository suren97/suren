import React,{ Component } from "react";
import { Stack,Icon } from "@mui/material";
import { DashboardCustomize } from "@mui/icons-material";


class Users extends Component
{
constructor(props)
{
    super(props)
    this.state={
             
    }
}

componentDidMount()
{
    
}

render()
{
    return(
       <>
    <div className="headercontent">
      <Stack direction={"row"} spacing={1.5}>
        <Icon>
          <DashboardCustomize />
        </Icon>
        <div>Dashboard</div>
      </Stack>
    </div>
       </>
    )
}
}

export default Users;