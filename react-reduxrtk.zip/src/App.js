import Countstore from "./RTK/Counter/Countstore";
import {Provider} from "react-redux";
import Countview from "./RTK/Counter/Countview";
import Userview from "./RTK/User/userview";
import Userstore from "./RTK/User/userstore";
import Selector_Redux from "./RTK/Selectors/Selector";
import SelectorStore from "./RTK/Selectors/SelectStore";
import ReduxEStore from "./RTK/EntityAdapter/EntityStore";
import Entity from "./RTK/EntityAdapter/SingleEntity";
import VesselGM from "./RTK/User/VesselGM";
import MultiEntity from "./RTK/EntityAdapter/MultiEntity";
import SetEntity from "./RTK/EntityAdapter/SetEntity";

function App() {
  return (
    <div className="App">
      <Provider store={SelectorStore}>
        <Selector_Redux />
        {/* <SetEntity /> */}
      </Provider>

      {/* <Provider store={Countstore}>
        <Countview />
       </Provider>
       <Provider store={Userstore}>
       <Userview />
       </Provider> */}
    </div>
  );
}

export default App;
