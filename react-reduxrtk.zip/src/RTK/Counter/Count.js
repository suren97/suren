import { createSlice } from "@reduxjs/toolkit";
import produce from "immer";

const initialState={
    count:10,
    address:{
        street:"123 Main st.",
        city:"Boston",
        state:"MA",
        country:{
            name:"USA",
            pin:1333
        }
    }
};

const countaction=createSlice({
    name:"Count",
    initialState,
    reducers:{
        increase:(state)=>{
            state.count ++;
        },
        decrease:(state)=>{
            state.count --;
        },
    }
});


export const countReducer=countaction.reducer;
export const {increase,decrease} =countaction.actions;
