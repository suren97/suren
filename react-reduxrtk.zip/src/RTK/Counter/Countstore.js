import { configureStore } from "@reduxjs/toolkit";
import {countReducer} from "./Count";

const Countstore=configureStore({
      reducer:{
        count:countReducer
      }
});

export default Countstore;