import { useDispatch, useSelector } from "react-redux";
import { increase,decrease } from "./Count";


function Countview()
{
const count=useSelector((state)=>{return state.count.count})
const dispatch=useDispatch();
return(
    <div>
    <h1>Count View -{count}</h1>
    <button type="button" onClick={()=>dispatch(increase())}>Increase</button>
    <button type="button" onClick={()=>dispatch(decrease())}>Decrease</button>
    </div>
)
}

export default Countview;