import {createEntityAdapter,createSlice} from "@reduxjs/toolkit";

const usersAdapter=createEntityAdapter();

const initialState=usersAdapter.getInitialState();

const usersSlice=createSlice({
         name:"users",
         initialState,
         reducers:{
            addUser:usersAdapter.addOne,
            updateUser:usersAdapter.updateOne,
            removeUser:usersAdapter.removeOne,
            AddMany:usersAdapter.addMany,
            UpdateMany:usersAdapter.updateMany,
            RemoveMany:usersAdapter.removeMany,
            setOne:usersAdapter.setOne,
            setMany:usersAdapter.setMany,
            removeall:usersAdapter.removeAll,
            upsertone:usersAdapter.upsertOne
         },
})

export const { 
   addUser,
   updateUser,
   removeUser,
   AddMany,
   UpdateMany,
   RemoveMany,
   setOne,
   setMany,
   removeall,
   upsertone
 }=usersSlice.actions;
export default usersSlice.reducer;