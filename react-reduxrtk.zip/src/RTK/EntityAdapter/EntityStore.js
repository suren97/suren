import {configureStore} from "@reduxjs/toolkit";
import usersSlice from "./EntityRedux";

const ReduxEStore=configureStore({
    reducer:{
        Entitystore:usersSlice
    }
})

export default ReduxEStore;