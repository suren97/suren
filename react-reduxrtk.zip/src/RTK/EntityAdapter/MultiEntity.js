import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { AgGridReact } from "ag-grid-react";
import { useState,useRef, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { AddMany,UpdateMany,RemoveMany } from "./EntityRedux";

function MultiEntity()
{
const GridRef=useRef();
const dispatch=useDispatch();
const reduxdata=useSelector((state)=>state.Entitystore);
const [rowdata,setrow]=useState([]);
const [reset,setreset]=useState(true);

const mergedata=[
    {id:1,name:"surendar",email:"surendar@gmail.com",mobile:9827672772},
    {id:2,name:'vinoth',email:"vinoth@gmail.com",mobile:8783662721},
    {id:3,name:"vignesh",email:"vignesh@gmail.com",mobile:9928276222},
    {id:4,name:"Kumar",email:"kumar@gmail.com",mobile:7846738383}
]

const updatedData=[
    {id:1,name:"williams",email:"williams@gmail.com",mobile:9827672772},
    {id:2,name:'vinoth',email:"vinoth@gmail.com",mobile:8783662721},
    {id:3,name:"george",email:"george@gmail.com",mobile:9928276222},
    {id:4,name:"Kumar",email:"kumar@gmail.com",mobile:7846738383}
]

const [columnDef,setcolumn]=useState([
    {field:"name"},
    {field:"email"},
    {field:"mobile"}
])

const defaultColDef=({
    flex:1,
    editable:true
})

useEffect(()=>{
    let getReduxData = Object.values(reduxdata.entities);
    setrow(getReduxData);
},[reset])

let EntityMany=()=>{
    dispatch(AddMany(mergedata))
    setreset(!reset)
}   

let EntityUpdate=()=>{
const updateRow=updatedData.reduce((prev,curt)=>{
    prev.push({id:curt.id,changes:curt})
    return prev
},[]); 
dispatch(UpdateMany(updateRow))
setreset(!reset);
}

let EntityRemove=()=>{
    let DelteIds=GridRef.current.props.rowData.map(v=>v.id);
    dispatch(RemoveMany(DelteIds));
    GridRef.current.api.applyTransaction({remove:GridRef.current.props.rowData})
}

return(
        <>
        <div>
            <header>
                <h1>MultiEntityAdapter (Multi CRUD)</h1>
            </header>
              <button onClick={()=>EntityMany()}>Add Many</button>
              <button onClick={()=>EntityUpdate()}>Update Many</button>
              <button onClick={()=>EntityRemove()}>Remove Many</button>
            <div className="ag-theme-alpine tablecontainer">
              <AgGridReact 
              ref={GridRef}
              rowData={rowdata}
              columnDefs={columnDef}
              defaultColDef={defaultColDef}
              />
            </div>
        </div>
        </>
)

}

export default MultiEntity;