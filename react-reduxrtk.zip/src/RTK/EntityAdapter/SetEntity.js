import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { AgGridReact } from "ag-grid-react";
import { useState,useRef, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setOne,setMany,removeall, upsertone } from "./EntityRedux";

function SetEntity()
{
const GridRef=useRef();
const dispatch=useDispatch();
const reduxdata=useSelector((state)=>state.Entitystore);
console.log(reduxdata)
const [rowdata,setrow]=useState([]);
const [refreshit,setrefresh]=useState(false);
const [id, setid] = useState(1);
const [inputdata, setinputdata] = useState({
    name: "",
    email: "",
    mobile: "",
    location: "",
});
const [updatebtn, setupd] = useState(false);
const [columnDef, setcolumn] = useState([
    { field: "name" },
    { field: "email" },
    { field: "mobile" },
    { field: "location"},
    {
      field: "action",
      cellRenderer: (params) => Displaybutton(params),
    },
]);
const defaultColDef = {
    flex: 1
};

let Displaybutton = (params) => {
    return (
      <>
        <button onClick={() => updateData(params)}>Update</button>
        <button onClick={() => DeleteData(params)}>Delete</button>
      </>
    );
  };

  let updateData = (params) => {
    setupd(true);
    setid(params.data.id);
    setinputdata({ ...params.data });
  };

  let DeleteData = (params) => {
    // dispatch(removeUser(params.data.id));
    params.api.applyTransaction({ remove: [params.data] });
  };

let handleinputs = (e) => {
    setinputdata({ ...inputdata, [e.target.name]: e.target.value });
};

useEffect(() => {
    let getReduxData = Object.values(reduxdata.entities);
    setrow(getReduxData);
}, [id, updatebtn,refreshit]);

let handleSubmit=()=>
{
    let data = {};
    data.id = id;
    data.name = inputdata.name;
    data.email = inputdata.email;
    data.mobile = inputdata.mobile;
    data.location = inputdata.location;
    // dispatch(upsertone(data))
    dispatch(setOne(data));
    setid(id + 1);
    setinputdata({ name: "", email: "", mobile: "", location: "" });
}

let update=()=>
{
    let data = {};
    data.id = id;
    data.name = inputdata.name;
    data.email = inputdata.email;
    data.mobile = inputdata.mobile;
    data.location = inputdata.location;
    dispatch(setOne(data));
    setupd(false);
    setinputdata({ name: "", email: "", mobile: "", location: "" });
}

let ESetMany=()=>
{
    const setUsers=[
        {id:1,name:"kings",email:"kings@gmail.com",mobile:8848383211,location:"jaipur"},
        {id:3,name:"Lakshman",email:"lakshman@gmail.com",mobile:883482321,location:"kolkata"},
        {id:4,name:"vigesh",email:"vigesh@gmail.com",mobile:7736367373,location:"mumbai"}
    ]
    dispatch(setMany(setUsers))
    setrefresh(!refreshit)
}

let USetMany=()=>
{
    const updUsers=[
        {id:1,name:"Royce",email:"Royce@gmail.com",mobile:7663733732,location:"jaipur"},
        {id:3,name:"Lakshman",email:"laksh@gmail.com",mobile:883482321,location:"kolkata"},
        {id:4,name:"ashok",email:"ashok@gmail.com",mobile:7736367373,location:"mumbai"}
    ]
    dispatch(setMany(updUsers))
    setrefresh(!refreshit)
}

let EremoveMany=()=>
{
  dispatch(removeall()) 
  setrefresh(!refreshit)
}

return(
          <>
          <div>
            <header>
                <h1>CreateEntityAdapter (SetEntity)</h1>
            </header>
        <div className="entityname">
        <label>Name:</label>
        <input
          type="text"
          name="name"
          value={inputdata.name}
          onChange={(e) => handleinputs(e)}
        />
        <label>Email:</label>
        <input
          type="text"
          name="email"
          value={inputdata.email}
          onChange={(e) => handleinputs(e)}
        />
        <label>Mobile:</label>
        <input
          type="text"
          name="mobile"
          value={inputdata.mobile}
          onChange={(e) => handleinputs(e)}
        />
        <label>Location:</label>
        <input
          type="text"
          name="location"
          value={inputdata.location}
          onChange={(e) => handleinputs(e)}
        />
        <button
          onClick={() => {
            updatebtn ? update() : handleSubmit();
          }}
        >
          {updatebtn ? "Update" : "Submit"}
        </button>
      </div>
      <button onClick={()=>ESetMany()}>SetMany</button>
      <button onClick={()=>USetMany()}>UpdateMany</button>
      <button onClick={()=>EremoveMany()}>Remove All</button>
      <div className="ag-theme-alpine tablecontainer">
        <AgGridReact
          ref={GridRef}
          columnDefs={columnDef}
          rowData={rowdata}
          defaultColDef={defaultColDef}
        />
      </div>
    </div>
    </>
)

}

export default SetEntity;