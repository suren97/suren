import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { AgGridReact } from "ag-grid-react";
import { useState, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { addUser,updateUser,removeUser,AddMany,UpdateMany } from "./EntityRedux";

function SingleEntity() {
  const [rowdata, setrow] = useState();
  const reduxdata = useSelector((state) => state.Entitystore);
  const [refreshit,setrefresh]=useState(false);
  const GridRef=useRef();
  const dispatch = useDispatch();
  const [id, setid] = useState(1);
  const [inputdata, setinputdata] = useState({
    name: "",
    email: "",
    mobile: "",
    location: "",
  });
  const [columnDef, setcolumn] = useState([
    { field: "name" },
    { field: "email" },
    { field: "mobile" },
    { field: "location"},
    {
      field: "action",
      cellRenderer: (params) => Displaybutton(params),
    },
  ]);
  const [updatebtn, setupd] = useState(false);

  let Displaybutton = (params) => {
    return (
      <>
        <button onClick={() => updateData(params)}>Update</button>
        <button onClick={() => DeleteData(params)}>Delete</button>
      </>
    );
  };

  let updateData = (params) => {
    setupd(true);
    setid(params.data.id);
    setinputdata({ ...params.data });
  };

  const defaultColDef = {
    flex: 1,
    // enableCellChangeFlash: true,
  };

  useEffect(() => {
    let getReduxData = Object.values(reduxdata.entities);
    setrow(getReduxData);
  }, [id, updatebtn,refreshit]);

let handleinputs = (e) => {
    setinputdata({ ...inputdata, [e.target.name]: e.target.value });
};

let handleSubmit = () => {
    let data = {};
    data.id = id;
    data.name = inputdata.name;
    data.email = inputdata.email;
    data.mobile = inputdata.mobile;
    data.location = inputdata.location;
    dispatch(addUser(data));
    setid(id + 1);
    setinputdata({ name: "", email: "", mobile: "", location: "" });
};

let update = () => {
    let data = {};
    data.id = id;
    data.name = inputdata.name;
    data.email = inputdata.email;
    data.mobile = inputdata.mobile;
    data.location = inputdata.location;
    dispatch(updateUser({ id: id, changes: { ...data } }));
    setupd(false);
    setinputdata({ name: "", email: "", mobile: "", location: "" });
};

let DeleteData = (params) => {
    dispatch(removeUser(params.data.id));
    params.api.applyTransaction({ remove: [params.data] });
};


return (
    <div>
      <header>
        <h1>CreateEntityAdapter (Single CRUD)</h1>
      </header>
      <div className="entityname">
        <label>Name:</label>
        <input
          type="text"
          name="name"
          value={inputdata.name}
          onChange={(e) => handleinputs(e)}
        />
        <label>Email:</label>
        <input
          type="text"
          name="email"
          value={inputdata.email}
          onChange={(e) => handleinputs(e)}
        />
        <label>Mobile:</label>
        <input
          type="text"
          name="mobile"
          value={inputdata.mobile}
          onChange={(e) => handleinputs(e)}
        />
        <label>Location:</label>
        <input
          type="text"
          name="location"
          value={inputdata.location}
          onChange={(e) => handleinputs(e)}
        />
        <button
          onClick={() => {
            updatebtn ? update() : handleSubmit();
          }}
        >
          {updatebtn ? "Update" : "Submit"}
        </button>
      </div>
     {/* <button onClick={()=>EntityMany()}>Add Many</button>
     <button onClick={()=>EntityUpdate()}>Update Many</button> */}
      <div className="ag-theme-alpine tablecontainer">
        <AgGridReact
          ref={GridRef}
          columnDefs={columnDef}
          rowData={rowdata}
          defaultColDef={defaultColDef}
        />
      </div>

    </div>
  );
}

export default SingleEntity;
