import { createSelector } from "@reduxjs/toolkit";

const selectname=(state,name)=>{
    return [state,name];
 }
//  const selectcount=(state)=>{
//     //  console.log("selectcount",state.SelectRedux.count);
//      return state.SelectRedux.count;
//  }
//  const selectcount2=(state)=>{
//     //  console.log("selectcount",state.count);
//      return state.SelectRedux2.count
//  }

export const selectCartTotal = createSelector(
        [selectname],
        ([state,name])=>{
            console.log("state",state)
            console.log("name",name)
            if(state.SelectRedux.count > 5)
            {

            }
            // if(count > 5 && count2 > 5)
            // {
            //     return names
            // }
            // else
            // {
            //     return [{name:"David"}];
            // }
        }
);

// export const selectCartTotal1 = createSelector(
//     [selectcount,selectcount2,selectname],
//     (count,count2,names)=>{
//         if(count > 5 && count2 > 5)
//         {
//             return names
//         }
//         else
//         {
//             return [{name:"David"}];
//         }
//     }
// );