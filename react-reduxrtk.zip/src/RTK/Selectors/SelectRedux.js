import { createSlice,createSelector } from "@reduxjs/toolkit";


const initialState={
    dataname:[{name:"surendar"},{name:"Akash"},{name:"Federal"}],
    count:0
}

const SelectRedux=createSlice({
         name:"Selectors",
         initialState,
         reducers:{
            NameSelector(state,action)
            {
               state.dataname=[...state.dataname,action.payload];
            },
            IncrementSelector(state,action)
            {
                console.log(action)
                state.count++
            },
            DecrementSelector(state,action)
            {
                state.count--
            }
         }
})

export const {NameSelector,IncrementSelector,DecrementSelector}=SelectRedux.actions;
export default SelectRedux.reducer;