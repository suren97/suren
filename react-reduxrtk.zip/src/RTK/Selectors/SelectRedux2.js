import { createSlice,createSelector } from "@reduxjs/toolkit";


const selectname=state=>{
   console.log("selectname",state);
   return state.dataname
}

// const selectcount=state=>{
//     console.log("selectcount",state.count);
//     return state.count;
// }

// export const selectCartTotal = createSelector(
//     [selectcount,selectname],
//     (count,names)=>{
//         // {console.log(names)}
//         if(count > 5)
//         {
//             return names
//         }
//         else
//         {
//             return [{name:"David"}];
//         }
//     }
// );

const initialState={
    dataname:[{name:"surendar"},{name:"Akash"},{name:"Federal"}],
    count:0
}

const SelectRedux2=createSlice({
         name:"Selectors",
         initialState,
         reducers:{
            NameSelector(state,action)
            {
               state.dataname=[...state.dataname,action.payload];
            },
            IncrementSelector2(state,action)
            {
                state.count++
            },
            DecrementSelector2(state,action)
            {
                state.count--
            }
         }
})

export const {NameSelector,IncrementSelector2,DecrementSelector2}=SelectRedux2.actions;
export default SelectRedux2.reducer;