import { combineReducers, configureStore } from "@reduxjs/toolkit";
import SelectRedux from "./SelectRedux";
import SelectRedux2 from "./SelectRedux2";

const rootReducer=combineReducers({
    SelectRedux,
    SelectRedux2
})

const SelectorStore=configureStore({
   reducer:rootReducer
})

export default SelectorStore;