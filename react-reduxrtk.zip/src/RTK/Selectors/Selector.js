import { useSelector,useDispatch } from "react-redux";
import { useState } from "react";
import { selectCartTotal } from "./CreateSelector";
import { IncrementSelector,DecrementSelector } from "./SelectRedux";
import { IncrementSelector2,DecrementSelector2 } from "./SelectRedux2";
import SelectorStore from "./SelectStore";

function Selector_Redux()
{
const dispatch=useDispatch();
const reduxdata=useSelector((state)=>state.SelectRedux);
const reduxdata2=useSelector((state)=>state.SelectRedux2);
const StoreState=SelectorStore.getState();
const getData=selectCartTotal(StoreState,"first");
console.log(reduxdata)
return(
    <>
    <div>
        <h1>Selectors</h1>
        <div className="selectors">
        <div>Counts1: {reduxdata?.count}</div>
        <div>Counts2: {reduxdata2?.count}</div>
       <div>Names: {getData && getData.map(v=>{
       return <div>{v.name}</div>
       })}
        </div>
        <br></br>
        <button onClick={()=>dispatch(IncrementSelector())}>Increment Count</button>
        <button onClick={()=>dispatch(DecrementSelector())}>Decrement Count</button>
        <button onClick={()=>dispatch(IncrementSelector2())}>Increment Count(2)</button>
        <button onClick={()=>dispatch(DecrementSelector2())}>Decrement Count(2)</button>
        </div>
    </div>
    </>
)    
}

export default Selector_Redux;