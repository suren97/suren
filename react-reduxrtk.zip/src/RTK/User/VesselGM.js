import React,{Component} from "react";
import { connect } from "react-redux";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { AgGridReact } from "ag-grid-react";

const mapStateToprops=state=>
{
  return{
    user:state.user.user.filter(value=>value.name !== null).reduce((prev,current)=>{
        if(current.name === "Default")
        {
            prev.unshift(current)
        }
        else
        {
            prev.push(current)
        }
        return prev
    },[])
  }
}


class VesselGM extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
            columnDef:[
                {field:"name"}
            ],
        }
    }
    
render()
{
    return(
        <div>
            <header>
                <h1>Vessel GM</h1>
            </header>
            <div className="ag-theme-alpine" style={{height:300,marginTop:"5%"}}>
            <AgGridReact 
            columnDefs={this.state.columnDef}
            rowData={this.props.user}
            defaultColDef={{flex:1}}
            />
            </div>
        </div>
    )
}

}

export default connect(mapStateToprops,null)(VesselGM)
// export default VesselGM;