import {createSlice} from "@reduxjs/toolkit";
import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const initialState={
    loading:false,
    user:[{id:1,name:33},{id:2,name:22},{id:3,name:454},{id:8,name:null},{id:4,name:7463},
    {id:5,name:"Default"},{id:6,name:8477},{id:7,name:652}],
    error:""
}

export const fetchusers=createAsyncThunk("user/fetchusers",()=>{
   return axios
   .get("https://jsonplaceholder.typicode.com/users")
   .then((response)=>{ return response.data })
});

const userslice=createSlice({
    name:"users",
    initialState,
    extraReducers:(builder)=>
    {
        builder.addCase(fetchusers.pending,(state)=>
        {
           state.loading=true
        });
        builder.addCase(fetchusers.fulfilled,(state,action)=>
        {
            state.loading=false;
            state.user=action.payload;
        });
        builder.addCase(fetchusers.rejected,(state,action)=>
        {
           state.loading=false;
           state.user=[];
           state.error=action.error.message
        })
    }
});

export const userReducer=userslice.reducer;



