import { configureStore, getDefaultMiddleware } from "@reduxjs/toolkit";
import {userReducer} from "./user";
import Logger from "redux-logger";


const Userstore=configureStore({
   reducer:{
    user:userReducer
   },
   // middleware:(getDefaultMiddleware)=>getDefaultMiddleware().concat(Logger)
});

export default Userstore;