import { useEffect } from "react";
import { useSelector,useDispatch } from "react-redux";
import { fetchusers } from "./user";

function Userview()
{
const user=useSelector((state)=>state.user);
const dispatch=useDispatch();

useEffect(()=>
{
dispatch(fetchusers());
},[]);

return(
    <div>
    <h1>UserLists</h1>
    {user.user.length ? (
    <div>
    {user.user.map((v)=>
    {
        return <p>{v.name}</p>
    })}
    </div>
    ):( " " )}
    </div>
 )
}

export default Userview;