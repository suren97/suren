import { BrowserRouter,Routes,Route } from "react-router-dom";
import Mainpage from "./Screens/Mainpage";
import Product from "./Screens/Products";
import ReduxStore from "./Redux/Store";
import { Provider } from "react-redux";
import Dealers from "./Screens/Dealers";
import AddProduct from "./Screens/AddProduct";
import AddDealer from "./Screens/AddDealer";
import Home from "./Screens/Home";

function App() {
  return (
   <div>
    <Provider store={ReduxStore} >
    <BrowserRouter>
    <Routes>
     <Route path="/" element={<Mainpage />} >
      <Route path="/home" element={<Home />} />
      <Route path="/addProduct" element={<AddProduct />} />
      <Route path="/addDealer" element={<AddDealer />}/>
     <Route path="/product" element={<Product />}/>
     <Route path="/dealers" element={<Dealers />}/>
     </Route>
    </Routes>
    </BrowserRouter>
    </Provider>
   </div>
  );
}

export default App;
