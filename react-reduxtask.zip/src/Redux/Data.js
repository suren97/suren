import { createSlice } from "@reduxjs/toolkit";
import produce from "immer";

const initialState={
    productmaster:[],
    dealermaster:[],
    products:[],
    dealers:[]
};

const Data=createSlice({
    name:"Products",
    initialState,
    reducers:{
        Productmaster:(state,action)=>
        {
            return produce(state,(draft)=>{
                draft.productmaster.push(action.payload);
            })
        },
        updateProductmaster:(state,action)=>
        {
           return produce(state,(draft)=>
           {
            let [qty,payload]=[...action.payload];
            let n=draft.productmaster.findIndex((v,i)=>
            {
                if(v.id === payload.id)
                {
                    return i+1;
                }
            });
            draft.productmaster.splice(n,1,payload);
           })
        },
        Dealermaster:(state,action)=>
        {
           return produce(state,(draft)=>
           {
               draft.dealermaster.push(action.payload)
           })
        },
        Addproduct:(state,action)=>
        {
            return produce(state,(draft)=>{
                draft.products.push(action.payload);
            })
        },
        AddDealer:(state,action)=>
        {
            return produce(state,(draft)=>{
                draft.dealers.push(action.payload);
            })
        },
        updateProducts:(state,action)=>
        {
            return produce(state,(draft)=>
            {
             console.log(action.payload)
             let payload=action.payload;
             let n=draft.products.findIndex((v,i)=>
             {
                 if(v.productid == payload.products)
                 {
                     return i+1;
                 }
             });
             draft.products.splice(n,1);
            })
        }
    }
});

export const Datareducer=Data.reducer;
export const {Productmaster,updateProducts,updateProductmaster,Dealermaster,Addproduct,AddDealer}=Data.actions;
