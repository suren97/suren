import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { Dealermaster } from "../Redux/Data";


function AddDealer()
{
//Dealers
const [rowdata,setrow]=useState();
const [columnDefs,setcolumn]=useState([
    {field:"Dealername"},
    {field:"email"},
    {field:"mobile"},
    {field:"location"}

]);
const defaultCol=({
    flex:1
});
const state=useSelector((state)=>{ return state.productData.dealermaster });
const Dealname=state;
const dispatch=useDispatch();
const [LocOptions,setlocopt]=useState([
  {label:"Select Options"},
  {label:"Chennai",value:1},
  {label:"Erode",value:2},
  {label:"Salem",value:3},
  {label:"Vellore",value:4}
]);
const [location,setlocation]=useState([{label:"Select Options",value:0}]);
const [Dealername,setdealername]=useState();
const [email,setemail]=useState();
const [mobile,setmobile]=useState();
const [id,setid]=useState(1);
const [errmsg,seterr]=useState({
       dealerr:"",
       emailerr:"",
       moberr:"",
       locerr:""
});

useEffect(()=>
{
setrow(Dealname);
},[id]);

const handlesubmit=()=>
{
  let data={};
  data.id=id;
  data.Dealername=Dealername;
  data.email=email;
  data.mobile=mobile;
  data.location=location;
  if(data)
  {
    if(CheckValidation(data))
    {
    dispatch(Dealermaster(data));
    setid(id+1);
    setdealername("");
    setemail("");
    setmobile("");
    setlocation({label:"Select Options",value:0});
    }
  }
}

let CheckValidation=data=>
{
let nameval=/^[A-Za-z]+$/;
let numval=/^[0-9]+$/;
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
console.log(data)
if(data)
{
  //Dealername Validation
  if(!data.Dealername)
  {
    seterr((prev)=>
    {
      return {...prev,dealerr:"Dealername can't be empty"}
    })  
    return false;   
  }
  if(data.Dealername.match(nameval))
  {
    seterr((prev)=>
    {
      return {...prev,dealerr:""}
    })
  }
  else
  {
    seterr((prev)=>
    {
      return {...prev,dealerr:"Invalid Dealername"}
    })
    return false;
  }

  //Email Validation
  if(!data.email)
  {
    seterr((prev)=>
    {
      return {...prev,emailerr:"Email Can't be Empty"}
    })
    return false;
  }
  if(data.email.match(mailformat))
  {
    seterr((prev)=>
    {
      return {...prev,emailerr:""}
    })
  }
  else
  {
    seterr((prev)=>
    {
      return {...prev,emailerr:"Invalid Email Address"}
    })
    return false;
  }

  //Number Validation
  if(!data.mobile)
  {
    seterr((prev)=>
    {
      return {...prev,moberr:"Mobile Number can't be Empty"}
    })
    return false;
  }
  if(data.mobile.match(numval))
  {
    seterr((prev)=>
    {
      return {...prev,moberr:""}
    })
  }
  else
  {
    seterr((prev)=>
    {
      return {...prev,moberr:"Invalid Mobile Number"}
    })
    return false;
  }

  //Location Validation
  if(data.location.value==0)
  {
    seterr((prev)=>
    {
      return {...prev,locerr:"Please Select Location"}
    })
    return false;
  }
  else
  {
    seterr((prev)=>
    {
      return {...prev,locerr:""}
    })
  }
  }
  return true;
}

return(
        <div>
        <div className="headercontent">
        <div>Add Dealers</div>
     </div>
     <div className="Addproducts">
     <div className="flexcontainer">
     <div className="forms">
    <label>Dealer</label>
    <input type="text" value={Dealername} onChange={(e)=>setdealername(e.target.value)} />
    <div className="errormsg">{errmsg.dealerr}</div>
    </div>
    <div className="forms">
    <label>Email</label>
    <input type="text" value={email} onChange={(e)=>setemail(e.target.value)} />
    <div className="errormsg">{errmsg.emailerr}</div>
    </div>
    <div className="forms">
    <label>Mobile</label>
    <input type="number" value={mobile} onChange={(e)=>setmobile(e.target.value)} />
    <div className="errormsg">{errmsg.moberr}</div>
    </div>
    <div className="forms">
     <label>Location</label>
     <select value={location} onChange={(e)=>setlocation(e.target.value)}>
      {LocOptions && LocOptions.map((v,i)=>{
      return <option>{v.label}</option>
       })}
     </select>
     <div className="errormsg">{errmsg.locerr}</div>
    </div>
    </div>
    <div>
    <button className="formbtn" onClick={()=>handlesubmit()}>Submit</button>
    </div>
    </div>
    <div className="Addproducts">
        <h2>Dealers List</h2>
         <div className="ag-theme-alpine" style={{height:300,padding:4}}>
            <AgGridReact
            rowData={rowdata}
            defaultColDef={defaultCol}
            columnDefs={columnDefs}
            />
         </div>
        </div>
     </div>
    )
}

export default AddDealer;