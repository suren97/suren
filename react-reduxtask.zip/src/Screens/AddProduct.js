import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { Productmaster } from "../Redux/Data";

function AddProduct()
{
//States
const [rowdata,setrow]=useState();
const [columnDefs,setcolumn]=useState([
    {field:"productname"},
    {field:"stocks"},
    {field:"price"}
]);
const defaultCol=({
    flex:1
});
const state=useSelector((state)=>{ return state.productData.productmaster });
const prodname=state;
const dispatch=useDispatch();
const [productname,setproduct]=useState();
const [stocks,setstocks]=useState();
const [price,setprice]=useState();
const [id,setid]=useState(1);
const [errmsg,seterr]=useState({
    proerr:"",
    pricerr:"",
    stockerr:""
})

useEffect(()=>
{
let datalist=[];

if(prodname)
{
datalist=prodname.filter((v,i)=>
    {
        if(v.stocks > 0)
        {
            return v;
        }
    })
}

if(datalist.length)
{
    setrow(datalist);
}
else
{
    setrow("");
}
},[id]);

const handlesubmit=()=>
{
   let data={};
   data.id=id;
   data.productname=productname;
   data.stocks=stocks;
   data.price=price;
   if(data)
   {
     if(CheckValidation(data))
     {
        dispatch(Productmaster(data));
        setid(id+1);
        setproduct("");
        setstocks("");
        setprice("");
     } 
   }
}

let CheckValidation=(data)=>
{
let nameval=/^[A-Za-z]+$/;
let numval=/^[0-9]+$/;
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

if(data)
{
//Proname Validation
if(!data.productname)
{
    seterr((prev)=>
    {
        return {...prev,proerr:"ProductName can't be empty"}
    })
    return false;
}
if(data.productname.match(nameval))
{
    seterr((prev)=>
    {
        return {...prev,proerr:""}
    })
}
else
{
seterr((prev)=>
{
    return {...prev,proerr:"Invalid product name"}
})
return false;
}

//Stock Validation
if(!data.stocks)
{
    seterr((prev)=>
    {
        return {...prev,stockerr:"Stock can't be Empty"}
    })
    return false;
}
if(data.stocks.match(numval))
{
   seterr((prev)=>
   {
    return {...prev,stockerr:""}
   })
}
else
{
    seterr((prev)=>
    {
        return {...prev,stockerr:"Invalid Entry"}
    })
    return false;
}

//Price Validation
if(!data.price)
{
    seterr((prev)=>
    {
        return {...prev,pricerr:"Price can't be Empty"}
    })
    return false;
}
if(data.price.match(numval))
{
    seterr((prev)=>
    {
        return {...prev,pricerr:" "}
    })
}
else
{
    seterr((prev)=>
    {
        return {...prev,pricerr:"Invalid Price"}
    })
    return false;
}
}
return true;
}

return(
    <div>
        <div className="headercontent">
        <div>Add Products</div>
     </div>
     <div className="Addproducts">
     <div className="flexcontainer">
     <div className="forms">
    <label>Products</label>
    <input type="text" value={productname} onChange={(e)=>setproduct(e.target.value)} />
    <div className="errormsg">{errmsg.proerr}</div>
    </div>
    <div className="forms">
    <label>Stocks</label>
    <input type="number" value={stocks} onChange={(e)=>setstocks(e.target.value)} />
    <div className="errormsg">{errmsg.stockerr}</div>
    </div>
    <div className="forms">
    <label>Price</label>
    <input type="number" value={price} placeholder="Rate Per product price" onChange={(e)=>setprice(e.target.value)} />
    <div className="errormsg">{errmsg.pricerr}</div>
    </div>
    </div>
    <div>
    <button className="formbtn" onClick={()=>handlesubmit()}>Submit</button>
    </div>
    </div>
    <div className="Addproducts">
        <h2>Product List</h2>
         <div className="ag-theme-alpine" style={{height:300,padding:4}}>
            <AgGridReact
            rowData={rowdata}
            defaultColDef={defaultCol}
            columnDefs={columnDefs}
            />
         </div>
        </div>
     </div>
    )
}
export default AddProduct;