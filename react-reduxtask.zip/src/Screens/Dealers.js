import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { AddDealer } from "../Redux/Data";
import { updateProducts } from "../Redux/Data";

function Dealers()
{
//States
const [rowdata,setrow]=useState();
const [columnDefs,setcolumn]=useState([
    {field:"products"},
    {field:"Dealername"},
    {field:"email"},
    {field:"mobile"},
    {field:"location"}

]);
const defaultColDef=({
     flex:1,
     sortable:true
});
const [Dealername,setdealer]=useState();
const [email,setemail]=useState();
const [products,setproducts]=useState();
const [mobile,setmobile]=useState();
const [location,setlocation]=useState();
const [proname,setproname]=useState();
const [qty,setqty]=useState();
const [price,setprice]=useState();
const [id,setid]=useState(1);
const [noshow,setshowopt]=useState(true);

//Dealers manage
const state=useSelector((state)=>{ return state.productData.dealers });
const dealer=state;
//Dealer master
const Dealers=useSelector((state)=>{ return state.productData.dealermaster });
const DealOptions=[];
if(Dealers.length)
{
    DealOptions.push({label:"Select Options"});
    Dealers.filter((v,i)=>
    {
        DealOptions.push({label:v.Dealername,value:id});
    })
}
const Products=useSelector((state)=>{ return state.productData.products });
const [ProOptions,setoptions]=useState([{value:"Select Options"}]);
const [showOptions,setshow]=useState(false);

//Products
const dispatch=useDispatch();

useEffect(()=>
{
  setrow(dealer)
  if(location)
  { 
    let checklocation=Products.filter((v2,ind)=>
    {
        if(v2.location===location)
        {
            return v2;
        }
    })
    // console.log("prod",checklocation);
    if(checklocation.length)
    {
        setoptions([{label:"Select Options",value:" "}]);
        checklocation.map((v,i)=>{
        setoptions((prev)=>
        {
           return [...prev,{label:v.products,value:v.productid}] 
        })
        setshow(true);
    })
    }
    else
    {
        setshow(false);
    }
  }

},[id,location,showOptions]);

let handlesubmit=()=>
{
    let data={};
    data.id=id;
    data.Dealername=Dealername;
    data.mobile=mobile;
    data.email=email;
    data.location=location;
    data.products=products;
    if(data)
    {
        dispatch(AddDealer(data));
        dispatch(updateProducts(data));
        setid(id+1);
        setdealer({label:"Select Options"});
        setemail("");
        setmobile("");
        setlocation("");
        setoptions([{label:"Select Options",value:""}]);
        setproname("");
        setqty("");
        setprice("");
    }
}

let handledealer=val=>
{ 
  setdealer(val);
  if(Dealers)
  {
    Dealers.filter((v,i)=>
    {
        if(v.Dealername===val)
        {
           setemail(v.email);
           setmobile(v.mobile);
           setlocation(v.location);
           setoptions([{label:"Select Options",value:" "}]);
        }
    })
  }  
}

let handleproducts=e=>
{
    setproducts(e);
    if(Products)
    {
      Products.map((v,i)=>
      {
        if(v.productid==e)
        {
            setproname(v.products);
            setqty(v.quantity);
            setprice(v.price);
            setshowopt(!noshow);
        }
      })
    }
}
// console.log("Optioons",ProOptions)
return(
       <div>
        <div className="headercontent">
            <div>Manage Dealers</div>
        </div>
        <div className="Addproducts">
            <div className="flexcontainer">
            <div className="forms">
            <label>Dealer</label>
             <select value={Dealername} onChange={(e)=>handledealer(e.target.value)} >
              {DealOptions && DealOptions.map((v,i)=>
              {
                  return <option>{v.label}</option>
              })}
             </select>
             </div>
             <div className="forms">
            <label>Email</label>
             <input type="text" value={email} disabled={true}  />
             </div>
             <div className="forms">
            <label>Mobile</label>
             <input type="text" value={mobile} disabled={true}  />
             </div>
             <div className="forms">
            <label>Branch</label>
            <input type="text" disabled={true} value={location}  />
             </div>
             {showOptions ? (
                <>
             <div className="forms">
                <label>ProductID</label>
                <select onChange={(e)=>handleproducts(e.target.value)}>
                {ProOptions && ProOptions.map((v,i)=>
                {
                   return <option value={v.value}>{`${v.label+"-"+v.value}`}</option>
                })}
                </select>
             </div>
             <div className="forms">
                <label>Productname</label>
                <input type="text" value={proname} disabled={true} />
             </div>
             <div className="forms">
                <label>Quantity</label>
                <input type="text" value={qty} disabled={true} />
             </div>
             <div className="forms">
                <label>Total Price</label>
                <input type="text" value={price} disabled={true} />
             </div>
            </>
             ):(
                " "
             )}
             {noshow ? (
               " "
             ):(
                <div>
                {/* <h3 style={{padding:10,marginLeft:8,color:"darkgrey"}}>No Products Available</h3> */}
                </div>
             )}
            </div>
            {showOptions ? (
            <div>
                <button className="formbtn" onClick={(e)=>handlesubmit()}>Confirm</button>
             </div>
             ):(
               " "
             )}
        </div>
        <div className="Addproducts">
        <h2>Dealers Table</h2>
         <div className="ag-theme-alpine" style={{height:300,padding:4}}>
            <AgGridReact
            rowData={rowdata}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            />
         </div>
        </div>
       </div>
)
}

export default Dealers;