import { useEffect, useState } from "react";
import { useSelector,useDispatch } from "react-redux";

function Home()
{
const state=useSelector((state)=>{ return state.productData.dealers });
const dealer=state;
let getdata=()=>
{
console.log("getdata")
if(dealer.length)
{
   return <div className="Addproducts">
    <div className="flexcontainer">
    {dealer.map((v,i)=>{
     return <div className="boxmodel">
        <div className="smallcontent">
            <i className="fa fa-user icon"></i>
            <span className="para"><b>DealerName -</b>{v.Dealername}</span>
        </div>
        <div className="smallcontent">
            <i className="fa fa-envelope icon"></i>
            <span className="para"><b>Email -</b>{v.email}</span>
        </div>
        <div className="smallcontent">
            <i className="fa fa-phone icon"></i>
            <span className="para"><b>Mobile -</b>{v.mobile}</span>
        </div>
        <div className="smallcontent">
            <i className="fa fa-globe icon"></i>
            <span className="para"><b>Location -</b>{v.location}</span>
        </div>
        <div className="smallcontent">
            <i className="fa fa-shopping-cart icon"></i>
            <span className="para"><b>ProductID -</b>{v.products}</span>
        </div>
    </div>
    })}
    </div>
    </div>
}
else
{
    return(
    <div className="Addproducts">
    <div className="flexcontainer">   
    No Recors to Show
    </div>
    {/* <div className="divbox">
        No Records to show
        No Records to show
        No Records to show
        No Records to show
        No Records to show
        No Records to show
        No Records to show
        No Records to show
        No Records to show
        No Records to show
        No Records to show
        No Records to show
        No Records to show
    </div> */}
    </div>
    )
}
}

    return(
        <div>
            <div className="headercontent">
               <div>Dashboard</div>
            </div>
            {getdata()}
        </div>
    )
}

export default Home;