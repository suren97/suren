import { Link,Outlet } from "react-router-dom";

function Mainpage()
{
    return(
        <div>
            <header>
                <h1>Stocks Management</h1>
            </header>
            <div className="content">
            <div className="navbar">
            <ul>
                <Link to="/home">Home</Link>
                <div className="dropdown">
                    <Link to="#">Add Stocks &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i className="fa fa-caret-down"></i></Link>
                    <div className="dropdown-content">
                        <Link to="/addProduct">Add Product</Link>
                        <Link to="/addDealer">Add Dealer</Link>
                    </div>
                </div>
                <div className="dropdown">
                <Link to="#">Manage Stocks &nbsp;&nbsp;&nbsp;&nbsp;<i className="fa fa-caret-down"></i></Link>
                    <div className="dropdown-content">
                        <Link to="/product">Products</Link>
                        <Link to="/dealers">Dealers</Link>
                    </div>
                </div>
                {/* <Link to="/product">Product</Link>
                <Link to="/dealers">Dealers</Link> */}
                {/* <li><a href="#">Home</a></li>
                <li><a href="/product">Product</a></li>
                <li><a href="/dealers">Dealers</a></li> */}
            </ul>
            </div>
            <div className="content2">
            <Outlet />
            </div>
            </div>
        </div>
    )
}

export default Mainpage;