import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useEffect, useState,useMemo } from "react";
import { useSelector,useDispatch } from "react-redux";
import { Addproduct } from "../Redux/Data";
import { updateProductmaster } from "../Redux/Data";

function Product()
{
//Options
const LocOptions=[
    {label:"Select Options"},
    {label:"Chennai",value:1},
    {label:"Erode",value:2},
    {label:"Salem",value:3},
    {label:"Vellore",value:4}
];

//States
const [rowdata,setrow]=useState();
const [columnDefs,setcolumn]=useState([
        {field:"productid"},
        {field:"products"},
        {field:"quantity"},
        {field:"price"},
        {field:"location"}
]);
const defaultColDef=({
    sortable:true,
    flex:1
});

//States
    const [products,setproducts]=useState();
    const [productid,setprodid]=useState(1000);
    const [qty,setqty]=useState();
    const [price,setprice]=useState();
    const [location,setlocation]=useState([{label:"Select Options",value:0}]);
    const [id,setid]=useState(1);
    const [ProOptions,setpro]=useState([{label:"Select Options"}]);
    const [errmsg,seterr]=useState({
        proerr:"",
        qtyerr:"",
        locerr:""
    });
 
const dispatch=useDispatch();
const state=useSelector((state)=>{ return state.productData.products });
const prod=state;
const prodname=useSelector((state)=>{ return state.productData.productmaster });

// const ProOptions=[];
let setprod=useMemo(()=>
{
    if(prodname.length)
    {
        // ProOptions.push({label:"Select Options"})
        prodname.map((v,i)=>
        {
            if(v.stocks>0)
            {
               setpro((prev)=>
               {
                  return [...prev,{label:v.productname,value:v.id}]
               })
            // ProOptions.push({label:v.productname,value:v.id})
            }
        })   
    }

},[]);


useEffect(()=>{ 
    setrow(prod);
},[id]);

//Submit
let handlesubmit=()=>
{
       var data={};
       data.id=id;
       data.products=products;
       data.productid=productid;
       data.quantity=qty;
       data.price=price;
       data.location=location;
       if(data)
       {
        if(CheckValidation(data))
        {
          setprodid(productid+1);
          dispatch(Addproduct(data));
          if(prodname.length)
          {
            prodname.filter((v,i)=>
            {
                let valdata={};
                valdata={...v};
                valdata.stocks=parseInt(v.stocks)-parseInt(qty);
                if(v.productname === products)
                {
                    dispatch(updateProductmaster([qty,valdata]));
                }
            })
          }
          setproducts({label:"Select Options",value:0})
          setid(id+1);
          setqty("");
          setprice("");
          setlocation({label:"Select Options",value:0});
        }
    }
}

  const CheckValidation=data=>
  {
    if(data)
    {
        console.log("data",data)
      //Products Validation
      if(data.products.value==0)
      {
        seterr((prev)=>
        {
          return {...prev,proerr:"Please Select Product"}
        })
        return false;
      }
      else
      {
        seterr((prev)=>
        {
          return {...prev,proerr:""}
        })
      }

      //Qty Valiation
      let numval=/^[0-9]+$/;
      if(!data.quantity)
      {
        seterr((prev)=>
        {
           return {...prev,qtyerr:"Please Enter Quantity"} 
        })
        return false;
      }
      if(data.quantity.match(numval))
      {
        seterr((prev)=>
        {
            return {...prev,qtyerr:""}
        })
      }
      else
      {
        seterr((prev)=>
        {
            return {...prev,qtyerr:"Invalid Entry"}
        })
        return false;
      }

      //Location Validation
      if(data.location[0].value==0)
      {
       seterr((prev)=>
       {
          return {...prev,locerr:"Please Select Location"}
       })
       return false;
      }  
      else
      {
        seterr((prev)=>
        {
            return {...prev,locerr:""}
        })
      } 
    }
    return true;
  }

  const handleqty=(value)=>
  {
    let check=value;
     prodname.map((v,i)=>
     {
        if(v.productname===products)
        {
            if(v.stocks < parseInt(check))
            {
              seterr((prev)=>
              {
                return {...prev,qtyerr:`Stock is lesser than you entered,Current stock is ${v.stocks}`}
              })
            }
            setqty(value);
            setprice(v.price * value);
        }
     })
  }
// console.log("errormsg",errmsg)
    return(
        <div>
            <div className="headercontent">
               <div>Manage Products</div>
            </div>
            <div className="Addproducts">
            <div className="flexcontainer">
            <div className="forms">
            <label>Products</label>
             <select id="products" value={products} onChange={(e)=>setproducts(e.target.value)} >
             {ProOptions && ProOptions.map((v,i)=>
             {
                return <option>{v.label}</option>
             })}
             </select>
             <div className="errormsg">{errmsg.proerr}</div>
             </div>
             <div className="forms">
            <label>Quantity</label>
             <input type="text" value={qty} onChange={(e)=>handleqty(e.target.value)} />
             <div className="errormsg">{errmsg.qtyerr}</div>
             </div>
             <div className="forms">
            <label>Price</label>
             <input type="text" disabled={true} value={price} />
             </div>
             <div className="forms">
            <label>Location</label>
             <select value={location} onChange={(e)=>setlocation(e.target.value)} >
             {LocOptions && LocOptions.map((v,i)=>
             {
                return <option>{v.label}</option>
             })}
             </select>
             <div className="errormsg">{errmsg.locerr}</div>
             </div>
             <div>
                <button className="formbtn" onClick={(e)=>handlesubmit()}>Submit</button>
             </div>
        </div>
        </div>
        <div className="Addproducts">
            <h2>Product Table</h2>
            <div className="ag-theme-alpine" style={{height:300,padding:4}} >
                <AgGridReact 
                rowData={rowdata}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                />
            </div>
        </div>
        </div>
    )
}

export default Product;