import Hookusestate from './React_Hooks/usestate';
import HookReducer from './React_Hooks/usereducer';
import HookEffect from './React_Hooks/useffect';
import HookRef from './React_Hooks/useref';
import Uselayouteff from './React_Hooks/uselayouteff';
import HookContext from './React_Hooks/usecontxt';
import Urlfetch from './React_Hooks/customhooks/hook';
import Useimperative from './React_Hooks/imperative';
import React from 'react';
import Component1 from './React_Hooks/usecontext/Component1';
import Axpost from './Axios/axpost';
import ComplexReduce from './UseReducer/Usereducer';
import Parent from './UseCallback/Parent';
import State_Immute from './Immutable/State_Immute';
import ParentPage from './Memo_Cb/ParentPage';
import SampleTest from './Sample_Test/Smp_Test';

function App() {
  return (
    <React.Fragment>
      {/* <ParentPage /> */}
      {/* <State_Immute /> */}
      <Parent />
      {/* <ComplexReduce /> */}
      {/* <Axpost /> */}
      {/* <Component1 /> */}
    {/* <Hookusestate />
    <hr></hr>
    <HookReducer />
    <hr></hr>
    <HookEffect />
    <hr></hr>
    <HookRef />
    <hr></hr>
    <Uselayouteff />
    <hr></hr>
    <HookContext />
    <hr></hr>
    <Urlfetch />
    <hr></hr>
    <Useimperative /> */}
    </React.Fragment>
  );
}

export default App;
