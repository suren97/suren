import React,{Component} from "react";
import axios from "axios";

class Axpost extends Component
{
 componentDidMount()
 {
  const data=[{userId:1,title:"title",body:"body1"}]
  axios.post("https://jsonplaceholder.typicode.com/posts",data[0])
  .then((value)=>
  {
    console.log(value)
  })
 }
render()
{
    return(
        <div>
        <h1>Axios Post</h1>
        </div>
    )
}
}
export default Axpost;