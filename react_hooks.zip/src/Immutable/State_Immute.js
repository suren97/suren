import {useState} from "react";

function State_Immute()
{
const [person,setperson]=useState(
    {name:"Thinoj",eid:12330}
);
const [arr,setarr]=useState(
    ["Gambhir","Shewag","Tendulkar","Yuvraj"]
);
//Object Immutable
const updobj=()=>
{
const newobj={};
newobj.name="Arun"
newobj.eid=9876
setperson(newobj);
}
//Array Immutable
const updply=()=>
{
arr.push("Ganguly");
arr.push("Kumble");
let newarr=[...arr];
setarr(newarr);
}
return(
    <div>
    <h1>State Immutable</h1>
    <div>Name:{person.name}</div>
    <div>Id:{person.eid}</div>
    <button type="button" onClick={()=>updobj()}>Update Object</button>
    <h1>Array Immutable</h1>
    <div>Players:{arr+" "}</div>
    <button type="button" onClick={()=>updply()}>Update Players</button>
    </div>
)
}
export default State_Immute;