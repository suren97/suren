function ChildPage(props)
{
return(
    <div>
        <h1>ChildPage</h1>
        <p>{props.name}</p>
    </div>
)
}
export default ChildPage;