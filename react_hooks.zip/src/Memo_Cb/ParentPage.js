import {useMemo, useState} from "react";
import ChildPage from "./ChildPage";

function ParentPage()
{
const [count,setcount]=useState(0);
const person={name:"Vinoth",id:230};
console.log("render")
return(
    <div>
    <h1>ParentPage</h1>
    <button type="button" onClick={()=>setcount(count+1)}>Count -{count}</button>
    <ChildPage name={count} />
    </div>
  )
}

export default ParentPage;