import { useState,useEffect } from "react";

function CustomHook(users)
{
  const [data,setdata]=useState("");
  const url=users;
useEffect(()=>
{
  fetch(url)
  .then((response)=>response.json())
  .then((data)=>setdata(data[0]))
},[])
return [data];
}
export default CustomHook;