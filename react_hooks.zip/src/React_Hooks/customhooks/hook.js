import CustomHook from "./custom";
import {useEffect, useState} from "react";

function Urlfetch()
{
    const [data,setdata]=useState("");
    const url="https://jsonplaceholder.typicode.com/users";
    const get=CustomHook(url);
    useEffect(()=>
    {  
     setdata(get);
    },[]);
return(
    <div>
    <h1>Custom Hooks</h1>
    {data && data.map((v,i)=>
    {
        return "Id:"+v.id+"Username:"+v.username+"Email:"+v.email+"Website:"+v.website;
    })}
    </div>
)
}
export default Urlfetch;