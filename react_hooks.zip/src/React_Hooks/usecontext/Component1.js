import React,{ Component } from "react";
import Component2 from "./Component2";
import { Provider } from "./context";

const arr={id:1,name:"Suren"};

class Component1 extends Component
{
 render()
 {
    return(
    <Provider value={arr} >
       <Component2 />
    </Provider>
    )
 }
}
export default Component1;