import React,{ Component } from "react";
import { Consumer } from "./context";


class Component3 extends Component
{
 render()
 {
    return(
        <Consumer>
        {(name)=>{
        return(
        <div> 
        <h1>Iam at last Component {name.name}</h1>
        </div>
        )
        }}
        </Consumer>
    )
 }
}

export default Component3;