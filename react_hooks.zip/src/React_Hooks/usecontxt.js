import { useState,createContext,useContext } from "react";

const Data=createContext();

function HookContext()
{
const [user,setuser]=useState("Jessie");
return(
    <div>
    <h1>Hook UseContext</h1>
    <Data.Provider value={user}>
    <HookContext1 />
    </Data.Provider>
    </div>
)
}

function HookContext1()
{
    const use=useContext(Data);
return(
    <div>
    <h1>Hook UseContext1 {use}</h1>
    <HookContext2 usr={use} />
    </div>
)
}

function HookContext2(props)
{
return(
    <div>
    <h1>Hook UseContext2 {props.usr}</h1>
    <HookContext3 usr={props.usr} />
    </div>
)
}

function HookContext3(props)
{
return(
    <div>
    <h1>Hook UseContext3 {props.usr}</h1>
    </div>
)
}

export default HookContext;