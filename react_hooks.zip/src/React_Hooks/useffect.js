import {useEffect, useState} from "react";
import axios from "axios";

function HookEffect()
{
 const [data,setData]=useState();
 useEffect(()=>
 {
   axios.get("https://jsonplaceholder.typicode.com/users")
   .then((response)=>{
    setData(response.data);
   })
 },[]);

return(
    <div>
        <h1>Function HookEffect</h1>
        {data && data.map((v,i)=>
        {
           return ( <table>
            <tr>
            <td>{v.name}</td>
            </tr>
           </table>);
        })}
    </div>
)
}
export default HookEffect;