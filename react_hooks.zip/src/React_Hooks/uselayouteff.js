import { useState,useEffect,useLayoutEffect } from "react";

function Uselayouteff()
{
const [eff,seteff]=useState("");
const [layeff,setlayeff]=useState("");

useEffect(()=>
{
  seteff("data"); 
},[])

useLayoutEffect(()=>
{
    let prom=new Promise((resolve,reject)=>
    {
      fetch("https://jsonplaceholder.typicode.com/users")
      .then((response)=>response.json())
      .then((data)=>{
         setTimeout(()=>{setlayeff(data[0])},3000)
      })  
    })
},[])

return(
    <div>
    <h1>UseLayoutEffect</h1>
    {eff}<br></br>
    {layeff.name}
    </div>
)
}
export default Uselayouteff;