import { useReducer } from "react";

const reducer=(state,action)=>
{
    console.log(state)
    switch(action.type)
    {
        case "Increment":
            return {count:state.count+1,btnclass:state.btnclass==="btnclass" ? "btnclassr" : "btnclass"};
        default:
            return state;
    }
}

function HookReducer()
{
    const [state,dispatch]=useReducer(reducer,{count:0,btnclass:"btnclass"});
return(
    <div>
    <h1>HookReducer</h1>
    &nbsp;&nbsp;{state.count}
    <button type="button"
    className={state.btnclass}
    onClick={()=>{
        dispatch ({type:"Increment"})
    }}>
        Counter
    </button>
    </div>
)
}

export default HookReducer;