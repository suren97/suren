import {useRef, useState} from "react";

function HookRef()
{
const name=useRef(null);
const [inpvalue,sinpvalue]=useState();

let handleinp=(e)=>
{
e.preventDefault();
console.log(name.current.value);
}

return(
    <div>
    <h1>Hook UseRef</h1>
    <label className="uname">Username:</label>
    <div className="refelem">
    <input type="text" ref={name}  onChange={(e)=>handleinp(e)}></input>
    </div>
    <button type="button" className="btnclass">Submit</button>
    </div>
   )
}
export default HookRef;