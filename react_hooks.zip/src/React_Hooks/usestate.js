import {useState} from "react";


function Hookusestate()
{
const [counter,setcounter]=useState(0);
let increment=()=>
{
   setcounter(counter + 1);
}
let decrement=()=>
{
   setcounter(counter - 1);
}
return(
    <div>
        <h1>React Hooks Usestate</h1>
        <button type="button"  className="btnclass" onClick={increment}>Increment</button>
        {counter}
        <button type="button" className="btnclassr" onClick={decrement}>Decrement</button>
    </div>
)
}
export default Hookusestate;