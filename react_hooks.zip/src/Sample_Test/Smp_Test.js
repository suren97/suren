import React,{ Component } from "react";


class SampleTest extends Component
{
  render()
  {
    return(
        <div>
        <h1></h1>
        </div>
    )
  }
}

export default SampleTest