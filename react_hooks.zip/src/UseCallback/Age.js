import React from "react";

function Age({text,count})
{
console.log(`Rendering ${text}`);
return(
    <div>
     <h4>The Age is {count}</h4>
    </div>
)
}
export default React.memo(Age);