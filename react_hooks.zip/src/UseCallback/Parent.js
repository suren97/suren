import Title from "./Title";
import Button from "./button";
import Age from "./Age";
import Salary from "./Salary";
import {useCallback, useContext, useMemo, useReducer, useRef, useState} from "react";

function Parent()
{
    const [age,setage]=useState(25);
    const [sal,setsal]=useState(25000);
 
    const IncAge=useCallback(()=>
    {
    return setage(age+1);
    },[age]);

    const SalInc=useCallback(()=>
    {
    return setsal(sal+1000);
    },[sal]);

    return(
        <div>
           <Title />
           <Button handle={IncAge}>Age</Button>
           <Age text={"Age"} count={age} />
           <Button handle={SalInc}>Salary</Button>
           <Salary text={"Salary"} count={sal} />
        </div>
    )
}
export default Parent;