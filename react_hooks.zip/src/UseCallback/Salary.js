import React from "react";

function Salary({text,count})
{
console.log(`Rendering ${text}`);
return(
    <div>
    <h4>The Salary is {count}</h4>
    </div>
)
}
export default React.memo(Salary);