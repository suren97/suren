import React from "react";

function Button({handle,children})
{
    console.log("Button Rendering")
    return(
       <button type="button" onClick={handle}>
        {children}
       </button>
    )
}
export default React.memo(Button);