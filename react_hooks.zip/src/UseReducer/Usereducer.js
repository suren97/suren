import {useReducer} from "react";

const reducer=(state,action)=>
{
    console.log(state)
  switch(action.type)
  {
    case "Increment1":
    return {...state,count:state.count+action.value}
    case "Decrement1":
    return {...state,count:state.count-action.value}
    case "Reset1":
    return {...state,count:0}
    case "Increment2":
    return {...state,secondcount:state.secondcount+action.value}
    case "Decrement2":
    return {...state,secondcount:state.secondcount-action.value}
    case "Reset2":
    return {...state,secondcount:0}
  }
}

function ComplexReduce()
{
const [state,dispatch]=useReducer(reducer,{count:0,secondcount:0})
return(
    <div>
    <h1>Complex Reducer Function</h1>
    <div className="counters">
    <label>Counter 1:</label>
     <input type="text" value={state.count}></input>
     <button type="button" 
     onClick={()=>dispatch({type:"Increment1",value:1})}
     >
    Increment
     </button>
     <button type="button" 
     onClick={()=>dispatch({type:"Decrement1",value:1})}
     >
    Decrement
     </button>
     <button type="button" 
     onClick={()=>dispatch({type:"Reset1"})}
     >
    Reset
     </button>
     {/* Counter2 */}

     <label>Counter 2:</label>
     <input type="text" value={state.secondcount}></input>
     <button type="button" 
     onClick={()=>dispatch({type:"Increment2",value:5})}
     >
    Increment
     </button>
     <button type="button" 
     onClick={()=>dispatch({type:"Decrement2",value:5})}
     >
    Decrement
     </button>
     <button type="button" 
     onClick={()=>dispatch({type:"Reset2"})}
     >
    Reset
     </button>
    </div>
    </div>
)
}
export default ComplexReduce;