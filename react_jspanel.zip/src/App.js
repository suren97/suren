import {BrowserRouter,Routes,Route} from "react-router-dom";
import Panel_themePos from "./JS_Panel/Panel_themePos";
import Js_panelicons from "./JS_Panel/Panel_icons";
import Ajax_Panel from "./Panel_Ajax";
import Empty_Node from "./JS_Panel/Empty_Node";
import Panel_extend from "./JS_Panel/Panel_extend";
import Get_Panel from "./JS_Panel/Panel_getPanel";
import Panel_position from "./JS_Panel/Panel_position";
import Add_closecontrol from "./JS_PanelOption/JS_addclosecontrol";
import Panel_closeonEsc from "./JS_PanelOption/Js_closeonEscape";
import JS_Config from "./JS_PanelOption/JS_Config";
import JS_Content from "./JS_PanelOption/JS_Content";
import Global_callback from "./JS_Panel/Global_callback";
import Panel_Content from "./JS_PanelOption/Content";
import Sample_page from "./JS_Panel_Methods/Sample_page";
import Panel_Drag from "./JS_PanelOption/Dragit/Drag";
import Footer_toolbar from "./JS_PanelOption/Footer_tool";
import Header_Panel from "./JS_PanelOption/Header/JS_Header";
import Panel_parentsize from "./JS_PanelOption/Parent_Resize/Panel_parentresize";
import Panel_resize from "./JS_PanelOption/Parent_Resize/Panel_Resize";
import Panel_addControl from "./JS_Panel_Methods/Panel_addControl";
import Ag_grid from "./JS_Panel_Methods/Sample_page";
import Import_AgGrid from "./JS_Panel_Methods/Ag_Grid";
import Panel_close from "./JS_Panel_Methods/Panel_close";
import Panel_Control from "./JS_Panel_Methods/Panel_Control";
import Panel_properties from "./Panel_Properties/Panel_properties";
import Panel_Progressbar from "./Panel_Properties/Panel_Progressbar";
import Panel_status from "./Panel_Properties/Panel_status";
import JSpanel_Events from "./Panel_Events/JSPanel_Events";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Header_Panel />}/>
        <Route path="/agGrid" element={<Sample_page />}/>
        <Route path="/close" element={<Panel_close />} />
        <Route path="/control" element={<Panel_Control />}/>
        {/* <Route path="/properties" element={<Panel_properties/>}/> */}
        <Route path="/properties" element={<Panel_status/>}/>
        <Route path="/events" element={<JSpanel_Events />}/>
      </Routes>
    </BrowserRouter>
  )
}

export default App;
