import { jsPanel } from "jspanel4";

function Empty_Node()
{
    jsPanel.create({
        content:"<h3>Heading content...</h3>",
        callback:panel=>{
            window.setTimeout(()=>
            {
              jsPanel.emptyNode(panel.content);
            },2000);
        }
    });
 return(
    <div>
        <header>
            <h1>Empty_Node</h1>
        </header>
    </div>
 )
}

export default Empty_Node;