import { jsPanel } from "jspanel4";

function Global_callback()
{

jsPanel.globalCallbacks = panel =>
{
  if(panel.options.paneltype === "standard")
  {
    panel.titlebar.addEventListener("dblclick",()=>{
        panel.status !== 'maximized' ? panel.maximize() : panel.normalize();
    })
  }
}

// jsPanel.toggleClass(document.querySelector("#infotext"),'para');

let panel_one=()=>
{
  jsPanel.create({
    headerTitle:"First Panel",
    theme:"info",
    content:"<p id=infotext>Panel content</p>"
  })
}

let panel_two=()=>
{
  jsPanel.create({
    headerTitle:"Second Panel",
    theme:"primary"
  })
}

return(
    <div>
        <header>
        <h1>JS Panel Global_Callback</h1>
        <button onClick={()=>panel_one()}>Panel 1</button>
        <button onClick={()=>panel_two()}>Panel 2</button>
        </header>
    </div>
)
}
export default Global_callback;