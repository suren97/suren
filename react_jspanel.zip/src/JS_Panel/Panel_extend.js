import { jsPanel } from "jspanel4";

function Panel_extend()
{
let open=()=>
{
    jsPanel.extend({
        one:function(){
           panel.setTheme("info");
           panel.setHeaderTitle("Demo...");
        }
    });
    let panel=jsPanel.create();
    panel.one();
}

return(
    <div>
        <header>
            <h1>Panel Extends</h1>
        </header>
        <button className="openbtn" onClick={()=>open()}>Create Panel</button>
    </div>
)
}

export default Panel_extend;