import { jsPanel } from "jspanel4";

function Get_Panel()
{
    jsPanel.create({setStatus:"minimized"});
    jsPanel.create({position:'center 50 50',theme:"info"});
    jsPanel.create({position:'center 100 100',theme:"primary"})
    let panelIds=jsPanel.getPanels(function(){
        return this.classList.contains('jsPanel-standard');
    }).map(panel=>panel.id);
    console.log(panelIds)
    return(
        <div>
            <header>
                <h1>Get Panels</h1>
            </header>
        </div>
    )
}

export default Get_Panel;