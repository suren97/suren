import { jsPanel } from "jspanel4";

function Js_panelicons()
{
  const Open=()=>
  {
    jsPanel.create({
        headerTitle:"JS Panel Icons",
        border:'1px lightgrey',
        panelSize:'400 200',
        boxShadow:1,
        footerToolbar:'<span id="btn-close1" class="jsPanel-ftr-btn">'+jsPanel.icons.close+'</span>',
        callback:panel=>{
            let btnClose = panel.footer.querySelector('#btn-close1');
            jsPanel.setStyle(btnClose.querySelector('svg'), {height: '18px', cursor: 'pointer'});
            btnClose.addEventListener('click', () => {
                panel.close();
            });
        }
    });
  }

    return(
        <div>
        <header>
         <h1>JS Panel Icons</h1>
        </header>
         <button className="openbtn" onClick={()=>Open()}>Open Demo Panel</button>
        </div>
    )
}

export default Js_panelicons;