import { jsPanel } from "jspanel4";

function Panel_position()
{
let elem=document.createElement("div");
let para=document.createElement("p");
para.innerHTML="Panel Content";
elem.className="para";
elem.appendChild(para);
jsPanel.create({
    headerTitle:"Demo panels",
    content:elem
});
return(
    <div>
        <header>
        <h1>JS Panel_Position</h1>
        </header>
    </div>
)
}

export default Panel_position;