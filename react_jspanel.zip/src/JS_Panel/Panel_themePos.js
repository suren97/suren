import { jsPanel } from "jspanel4";
import { useEffect, useState } from "react";

function Panel_themePos()
{
const [panelcolor,setpanelcolor]=useState([
    {label:"primary",value:"primary"},
    {label:"secondary",value:"secondary"},
    {label:"info",value:"info"},
    {label:"success",value:"success"},
    {label:"warning",value:"warning"},
    {label:"danger",value:"danger"},
    {label:"light",value:"light"},
    {label:"dark",value:"dark"},
    {label:"none",value:"none"}
]);
const [fillcolor,setcolor]=useState([
    {label:"filled",value:"filled"},
    {label:"filledlight",value:"filledlight"},
    {label:"filleddark",value:"filleddark"}
]);
const [theme,settheme]=useState();

useEffect(()=>{
jsPanel.create({
    headerTitle:"Demo Panel",
    theme:theme,
    position:{
       my:"left-top",
       at:"left-top",
       offsetX:45,
       autoposition:"down",
    },
    headerToolbar:"<p>Header</p>",
    footerToolbar:"<p>Footer</p>"
})
},[theme]);

 return(
    <div>
        <header>
        <h1>JS_Panel ThemePosition</h1>
        {/* <button className="openbtn" onClick={()=>openpanel()}>Open Panel</button> */}
        </header>
        <div>
        <h1>Panel Theme</h1>
        <div className="panelcontent">
        <div style={{fontSize:18}}>Panel Current Theme is <b>{theme}</b></div>
        <br></br>
        <label>Select Panel Theme:</label>
        <select onChange={(e)=>settheme(e.target.value)}>
            {panelcolor.length ? panelcolor.map((v,i)=>{
                return <option>{v.label}</option>
            }):(
                ""
            )}
        </select>
        <hr></hr>
       <h1>Panel Border</h1>
        </div>
        </div>
    </div>
 )
}
export default Panel_themePos;