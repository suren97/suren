import { jsPanel } from "jspanel4";
import { render } from "react-dom";
import Sample_page from "../JS_Panel_Methods/Sample_page";

let Demo=()=>
{
  return(
    <div>
        <h1>Demo contents...</h1>
    </div>
  )
}

function Panel_Content()
{
//panel style using css
// jsPanel.create({
//     headerTitle:"Content",
//     closeOnEscape:true,
//     css:{
//         content:"classA",
//         ftr:"classB",
//         panel:"classC"
//     }
// });

//data in panel
jsPanel.create({
    closeOnEscape:true,
    data:"sample data",
    callback:function(){
        this.content.innerHTML=`<p>${this.options.data}</p>`
    }
})

// Inserting a Panel_Content using String
// jsPanel.create({
//    closeOnEscape:true,
//    content:p=>{
//     p.content.innerHTML="String content"
//    },
//    contentSize:{
//     width:400,
//     height:200
//    },
//    contentOverflow:"scroll"
// });

// Node will be appended to content section using ParentNode.append()
let Open=()=>
{
let elem=document.createElement("p");
elem.innerHTML="Appending element in the panel using parent Node..."
jsPanel.create({
    closeOnEscape:true,
    headerTitle:"Panel Content using ParentNode",
    content:elem
})
}

// Appending element using a function
let fun_Pan=()=>
{
jsPanel.create({
     headerTitle:"Panel Function",
     content:panel=>{
        let contentpanel=document.getElementsByClassName("jsPanel-content");
        let div=document.createElement("div");
        panel.content.append(div);
     }
    //  content:(panel)=>{
    //     let ele=document.createElement("p");
    //     ele.className="setpara";
    //     ele.textContent=<Sample_page />;
    //     panel.content.append(ele);
    //  }
}).maximize()
}

let cont_fetch=()=>
{
jsPanel.create({
    data:<Sample_page />,
    callback:function(){
        this.content.innerHTML=`<p>${this.data}</p>`
    }
})
}

return(
    <div>
        <header>
        <h1>JS Panel Content</h1>
        </header>
        <button className="openbtn" onClick={()=>Open()}>Open Panel (Using Append)</button>
        <button className="openbtn" onClick={()=>fun_Pan()}>Open Panel (Using Function)</button>
        <button className="openbtn" onClick={()=>cont_fetch()}>Open Panel (Using fetch)</button>
    </div>
)
}
export default Panel_Content;