import { jsPanel } from "jspanel4";

function Panel_Drag()
{
jsPanel.create({
    closeOnEscape:true,
    dragit:{
        // axis:"y",
        // containment:[10]
        // cursor:"grab"
        // disable:true,
        // disableOnMaximized:false,
        // grid:[50,50]
        opacity:0.9
    },
    footerToolbar:"footer"
})
return(
    <div>
        <header>
            <h1>Panel_Drag</h1>
        </header>
    </div>
)
}
export default Panel_Drag;