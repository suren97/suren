import { jsPanel } from "jspanel4";

function Footer_toolbar()
{

jsPanel.create({
  footerToolbar:[
    '<span class="flex-auto">Some text content</span>',
  ]
});

return(
    <div>
    
    </div>
)
}
export default Footer_toolbar;