import { jsPanel } from "jspanel4";

//onbeforeClose
//onfronted
//onclosed

function Header_Panel()
{

const Randomcolor=()=>
{
let colorArr=["primary","secondary","info","success","warning","danger","light","dark","goldenrod"];
return colorArr[Math.floor(Math.random()*colorArr.length)];
}

jsPanel.create({
    headerControls:{
        normalize:"disable",
        smallify:"remove"
    },
    headerLogo:"./logo512.png",
    position:"center 50 50",
    callback:function(){
        this.setHeaderTitle(this.id);
    },
    onbeforeclose:function(panel){
        return window.confirm("Are you sure want to close panel");
    }
})
jsPanel.globalCallbacks=panel=>
{
    if(panel.options.paneltype==="standard")
    {
      panel.addEventListener("click",()=>
      {
         panel.options.onfronted.push(function(panel,status){
            let theme=Randomcolor();
            panel.setTheme(theme);
         })
      })
    }
    // return {
    //      onfronted:function(panel,status){
    //     let theme=Randomcolor();
    //     panel.setTheme(theme);
    // }
    // }
}

let samp=()=>
{
    return(
        <div className="jspanel">
            <p>Paragraph content</p>
        </div>
    )
}

return(
    <div>
        <header>
            <h1>Header Panel</h1>
        </header>
    </div>
)
}

export default Header_Panel;