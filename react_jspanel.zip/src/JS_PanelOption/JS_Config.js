import { jsPanel } from "jspanel4";
import axios from "axios";
import { useEffect, useState } from "react";


function JS_Config()
{
const [rowdata,setrow]=useState();

let hintconfig={
    // header:false,
    border:"thin",
    addCloseControl:1,
    closeOnEscape:true
};

useEffect(()=>{
    axios.get("https://jsonplaceholder.typicode.com/users")
    .then((resp)=>setrow(resp.data))
},[]);

let openpanel=()=>
{
jsPanel.create({
    config:hintconfig,
    callback:function()
    {
        if(rowdata)
        {
            rowdata.map((v,i)=>
            {
                this.content.innerHTML+=v.name
            })
        }
    }
})
}

return(
    <div>
        <header>
        <h1>JS Config</h1>
        </header>
        <button className="openbtn" onClick={()=>openpanel()}>Open Panel</button>
    </div>
)
}
export default JS_Config;