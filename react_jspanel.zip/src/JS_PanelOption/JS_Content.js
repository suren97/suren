import { jsPanel } from "jspanel4";
import Sample_page from "../JS_Panel_Methods/Sample_page";


function JS_Content()
{

let samp_func=()=>
{
  let con=Sample_page();
  return con.props.children.props.children;
}

const open=()=>
{
 jsPanel.create({
    container:"body",
    content:jsPanel.strToHtml(`<div>
        <h1>Header</h1>
        ${samp_func()}
    </div>`),
    // callback:panel=>{
    //   panel.content.append(jsPanel.strToHtml(<div>
    //     {Sample_page()}
    // </div>));
    // },
    position:{
        my:"left",
        at:"left",
        offsetX:30,
        offsetY:100
    }
 })
}

// const open=()=>
// {
// jsPanel.create({
//     closeOnEscape:true,
//     footerToolbar:"Footer Content",
//     container:"body",
//     content:p=>{
//       let div=document.createElement("div");
//       p.content.append(div);
//     },
//     position:"center-top 0 15 down"
// })
// //   jsPanel.create({
// //      headerTitle:"Big Content in Panel",
// //      closeOnEscape:true,
// //      callback:[
// //         panel=>{
// //             let data=sample_fun();
// //             panel.content.append(<div dangerouslySetInnerHTML={{__html:data}}/>);
// //         }
// //      ]
// //   });
// }

return(
    <div>
        <header>
            <h1>JS_Panel Content</h1>
        </header>
        <button className="openbtn" onClick={()=>open()}>Open Panel</button>
        {/* {sample_fun()} */}
    </div>
)
}
export default JS_Content;