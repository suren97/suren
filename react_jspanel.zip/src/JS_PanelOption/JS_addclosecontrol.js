import { jsPanel } from "jspanel4";

function Add_closecontrol()
{

let openpanel=()=>
 {
  jsPanel.create({
    header:true,
    // addCloseControl:1,
    footerToolbar:"footers",
    animateIn:"jsPanelFadeIn",
    animateOut:"jsPanelFadeOut",
    autoclose:{
        time:'3s',
        progressbar:true
    },
    border:"1px dashed black",
    borderRadius:'7px',
    boxShadow:1,
    //Callback will be invoked when the jspanel inserted into the document.

    //Callback using function
    // callback:function()
    // {
    //    this.content.innerHTML='<p>Added via using Option called Callback</p>'
    // }

    //Callback using an array
    callback:[
        panel=>{
            panel.content.innerHTML='Content placed using an Callback array...';
        }
    ]
  });
 }

return(
    <div>
        <header>
        <h1>Js Panel Options</h1>
        </header>
        <button className="openbtn" onClick={()=>openpanel()}>Open Panel</button>
        <ul>
           <li><h4>addCloseControl</h4></li>
           <li><h4>animateIn</h4></li>
           <li><h4>animateOut</h4></li>
           <li><h4>autoClose</h4></li>
           <li><h4>border</h4></li>
           <li><h4>borderRadius</h4></li>
           <li><h4>boxShadow</h4></li>
           <li><h4>callback</h4></li>
           <li><h4>closeOnEscape</h4></li>
        </ul>
    </div>
)
}
export default Add_closecontrol;