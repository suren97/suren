import { jsPanel } from "jspanel4";

function Panel_closeonEsc()
{
jsPanel.create({
    closeOnEscape:true
})

jsPanel.create({
    closeOnEscape:()=>
    {
        return false;
    },
    theme:"success",
    position:"center 50 50",
    content:"Js panel contents..."
})

// jsPanel.create({
//     closeOnEscape:true
// })

// jsPanel.create({
//     theme:"info",
//     position:"center 50 50",
//     content:"<p>This panel will not close when hitting ESC...</p>"
// })

// jsPanel.create({
//     closeOnEscape:true,
//     position:"Center 50 50",
//     callback:function()
//     {
//         let content=this.content;
//         jsPanel.create({
//             container:content,
//             theme:"warning",
//             contentSize:'200 80'
//         })
//     }
// })

return(
    <div>
       <header>
        <h1>Panel_Options CloseonEscape</h1>
        </header> 
    </div>
)
}
export default Panel_closeonEsc;