import { jsPanel } from "jspanel4";

function Panel_resize()
{

let createpanel=()=>
{
  jsPanel.create({
    resizeit:{
        handles:"e,se",
    }
  })

  
}

return(
    <div>
        <header>
        <h1>Panel_Resize</h1>
        </header>
        <button className="openbtn" onClick={()=>createpanel()}>Create Panel</button>
    </div>
)
}

export default Panel_resize;