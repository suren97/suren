import { jsPanel } from "jspanel4";

function Panel_parentsize()
{

let panel=jsPanel.create({
     contentSize:"500 300",
     headerTitle:"Parent Panel",
     theme:"primary",
     contentOverflow:"hidden",
     callback:panel=>{
        panel.classList.add("jsPanel-jsPanel-error");
     }
});

jsPanel.create({
    contentSize:"200 200",
    theme:"secondary",
    headerTitle:"Child Panel",
    container:panel.content,
    minimizeTo:"parent",
    onparentresize:true,
    maximizedMargin:10
})

return(
    <div>
        <header>
            <h1>Panel_ParentResize</h1>
        </header>
    </div>
)
}

export default Panel_parentsize;