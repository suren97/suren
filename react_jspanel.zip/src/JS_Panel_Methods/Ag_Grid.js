import { jsPanel } from "jspanel4";
import Ag_grid from "./Sample_page";

function Import_AgGrid()
{
let openpanel=()=>
{
  let panel=jsPanel.create({
    headerTitle:"AgGrid Panel",
       content:panel=>
       {
         let frame=document.createElement("iframe");
         frame.src="http://localhost:3000/agGrid"
         frame.width="100%";
         frame.height="100%";
         panel.content.appendChild(frame);
       }
    }).maximize();
    console.log(panel.size)
}

return(
    <div>
        <header>
                <h1>Ag Grid</h1>
        </header>
        <button className="openbtn" onClick={()=>openpanel()}>Open Panel</button>
    </div>
)

}

export default Import_AgGrid;