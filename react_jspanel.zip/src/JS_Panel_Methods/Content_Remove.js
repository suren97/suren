import { jsPanel } from "jspanel4";

function Content_Remove()
{

let panelcreate=()=>
{
jsPanel.create({
    id:"drag_panel",
    headerTitle:"DragIt Panel Header",
    content:"<p>Panel Headers....</p>",
    footerToolbar:"Footer",
    theme:"primary"
})
}

//Disable DragIt
let Disable=()=>
{
document.querySelector("#drag_panel").dragit("disable").setTheme("danger");
}

//Enable DragIt
let Enable=()=>
{
document.querySelector("#drag_panel").dragit("enable").setTheme("success");
}


let panel;
const Open=()=>
{    
panel=jsPanel.create({
  headerTitle:"Panel Content Remove",  
  content:p=>
  {
    p.content.innerHTML="Panel content....";
  }
})
}

const Removecont=()=>
{
  panel.contentRemove(function() {
    this.setTheme('warning')
  });
}

return(
    <div>
        <header>
            <h1>Remove Content</h1>
        </header>
        <button className="openbtn" onClick={()=>panelcreate()}>Open panel</button>
        <button className="openbtn" onClick={()=>Disable()}>Disable Dragit</button>
        <button className="openbtn" onClick={()=>Enable()}>Enable Dragit</button>
        {/* <button className="openbtn" onClick={()=>Open()}>Open panel</button>
        <button className="openbtn" onClick={()=>Removecont()}>Remove content</button> */}
    </div>
)
}

export default Content_Remove;