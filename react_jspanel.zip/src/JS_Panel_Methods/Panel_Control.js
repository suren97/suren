import { jsPanel } from "jspanel4";

function Panel_Control()
{
const Create=()=>
{
    jsPanel.create({
        headerTitle:"Panel Control status"
    }).setControlStatus('minimize','disable')
}

return(
    <div>
        <header>
        <h1>Panel Control Status</h1>
        </header>
        <button onClick={()=>Create()}>Create</button>
    </div>
   )
}

export default Panel_Control;