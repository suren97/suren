import { jsPanel } from "jspanel4";

function Panel_addControl()
{
//Add Control
  let Openpanel=()=>
  {
    // jsPanel.create({
    //     headerTitle:"Add Control",
    //     // content:"Adding Controls to the Header of Panel"
    // }).addControl({
    //     html:"<span class=hamburg></span><span class=hamburg></span><span class=hamburg></span>",
    //     name:"menu",
    //     handler:(panel,control)=>{
    //         panel.content.innerHTML='<p>You Clicked the menu control</p>'
    //     },
    //     position:6,
    // })
     var toolbar=[
        '<span class=hamburg></span>'
     ];
    jsPanel.create({
        headerTitle:"Add Toolbar",
        content:"Adding Toolbar to the header..",
    }).addToolbar("header",toolbar,(panel)=>{
        panel.addEventListener("click",()=>
        {
            alert("clicked at the toolbar");
        })  
    })
  }

return(
        <div>
            <header>
                <h1>Panel_AddControl</h1>
            </header>
            <button onClick={()=>Openpanel()}>Open Panel</button>
        </div>
    )
}

export default Panel_addControl;