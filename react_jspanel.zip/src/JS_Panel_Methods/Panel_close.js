import { jsPanel } from "jspanel4";
import Content_Remove from "./Content_Remove";

function Panel_close()
{

let panel;

let Openpanel=()=>
{
panel=jsPanel.create({
    headerTitle:"Panel Methods",
    content:p=>
    {
        let elem=document.createElement("iframe");
        elem.src="http://localhost:3000/agGrid";
        elem.width="100%"
        elem.height="100%"
        p.content.append(elem);
    } 
}).maximize();

jsPanel.create({
    headerTitle:"Child Panel",
    theme:"warning",
    container:panel.content,
    content:"Child Panel"
})
}

let Closepanel=()=>
{
  panel.close();
}

let CloseChildpanel=()=>
{
    panel.closeChildpanels();
}

return(
    <div>
        <Content_Remove />
        <header>
        <h1>Panel Close</h1>
        </header>
        <button className="openbtn" onClick={()=>Openpanel()}>Open panel</button>
        <button className="openbtn" onClick={()=>Closepanel()}>Close panel</button>
        <button className="openbtn" onClick={()=>CloseChildpanel()}>Close Childpanel</button>
    </div>
)
}

export default Panel_close;