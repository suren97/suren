import {AgGridReact} from "ag-grid-react";
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import 'ag-grid-enterprise';
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import axios from "axios";

function Ag_grid()
{
const [rowdata,setrow]=useState();
const [column,setcolumn]=useState([
    {field:"make"},
    {field:"model"},
    {field:"price"}
]);

const defaultColDef = useMemo( ()=> ({
    sortable: true,
    filter:true,
    flex:1
    //rowGroup:true
}));

useEffect(()=>{
   axios
   .get("https://www.ag-grid.com/example-assets/row-data.json")
   .then((response)=>{
     setrow((prev)=>
     {
        return [...response.data]
     })
})
},[]);

const cellclickedListener=useCallback((e)=>{
   console.log("Cell_Cliked",e);
},[]);


return(
    <div>
        <header>
        <h1>Basics of AG_Grid</h1>
        </header>
        <div className="tablecontainer">
        <div className="ag-theme-alpine" style={{height:450,margin:"auto"}}>
        <AgGridReact
        onCellClicked={(e)=>cellclickedListener(e)}
        rowData={rowdata}
        columnDefs={column}
        defaultColDef={defaultColDef}
        animateRows={true}
        rowSelection="multiple"
        />
        </div>
        </div>
    </div>
)
}

export default Ag_grid;