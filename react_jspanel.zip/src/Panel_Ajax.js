import { jsPanel } from "jspanel4";

function Ajax_Panel()
{
    const Open=()=>
    {
    jsPanel.ajax({
          url:"https://jsonplaceholder.typicode.com/users",
          done:(xhr)=>{
            jsPanel.create({
                content:xhr.responseText
            })
          }
    })
    }
    return(
        <div>
            <header>
                <h1>Ajax Panel</h1>
            </header>
            <button className="openbtn" onClick={()=>Open()}>Open Panel</button>
        </div>
    )
}

export default Ajax_Panel;