import { jsPanel } from "jspanel4";

function JSpanel_Events()
{
let handler=function(event){
    console.log(event);
}
//panel fronted
// document.addEventListener('jspanelfronted',handler,false);
//panel loaded
// document.addEventListener('jspanelloaded',handler,false);
//panel beforeclose
document.addEventListener('jspanelbeforeclose',handler,false);
let panel_front=()=>
{
   jsPanel.create({
    position:{
        at:"left-bottom",
        my:"left-bottom",
        offsetY:5,
        offsetX:5
    }
   }).maximize();
}

return(
    <div>
        <header>
        <h1>JS Panel Fronted</h1>
        </header>
        <button className="openbtn" onClick={()=>panel_front()}>Panel Fronted</button>
    </div>
)
}

export default JSpanel_Events;