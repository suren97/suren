import { jsPanel } from "jspanel4";

//Progressbar
//SnappableTo

function Panel_Progressbar()
{
//ProgressBar
let Progpanel=()=>
{
jsPanel.create({
    callback:panel=>{
        panel.progressbar.classList.add('active')
        panel.progressbar.style.background="crimson";
        panel.progressbar.querySelector(".jsPanel-progressbar-slider").style.width='40%'
    },
    footerToolbar:'<span>Footer Toolbar</span>'
}).footer.style.backgroundColor='red'
}

//SnappableTo
let Snappanel=()=>
{
jsPanel.create({
   dragit:{
    snap:true,
    drag:function(){
      this.content.innerHTML=`<p>Panel Snappable ${this.snappableTo}</p>`;
    },
    stop:function(){
      this.content.innerHTML=`<p>Panel Snapped ${this.snapped}</p>`
    }
   }
})
}

return(
    <div>
        <header>
            <h1>Panel_ProgressBar</h1>
        </header>
        <button className="openbtn" onClick={()=>Progpanel()}>Progress Panel</button>
        <button className="openbtn" onClick={()=>Snappanel()}>Snappable Panel</button>
    </div>
)
}

export default Panel_Progressbar;