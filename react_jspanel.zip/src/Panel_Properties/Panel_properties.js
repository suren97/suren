import { jsPanel } from "jspanel4";

function Panel_properties()
{

let Open=()=>
{
   jsPanel.create({
      headerTitle:"Panel Properties",
      headerToolbar:"<span><i class='far fa-clipboard'></i></span>"
   }).addControl({
         html:"<span><i class='fas fa-align-justify'></i></span>",
         position:6
   }).controlbar.style.border="2px solid red"
}

return(
    <div>
        <header>
            <h1>Panel Properties</h1>
        </header>
      <button className="openbtn" onClick={()=>Open()}>Open Panel</button>
    </div>
)
}

export default Panel_properties;