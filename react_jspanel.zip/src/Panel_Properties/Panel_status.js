import { jsPanel } from "jspanel4";

function Panel_status()
{

let create=()=>
{
  jsPanel.create({
      theme:"warning",
      onstatuschange:function(){
        this.setHeaderTitle(this.status)
      }
  }).maximize()
}

return(
    <div>
    <button onClick={()=>create()}>Panel Status</button>
    </div>
)
}

export default Panel_status;