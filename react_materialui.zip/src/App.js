import MainPage from "./MainPage";
import {BrowserRouter,Routes,Route} from "react-router-dom";
import Button_Component from "./Components/Buttons/Button";
import BtnGroup from "./Components/Buttons/ButtonGroup";
import Slider_Component from "./Components/Sliders/Sliders";
import Discrete_Slider from "./Components/Sliders/Discreteslider";
import Switches from "./Components/Switch/Switches";
import Toggle from "./Components/Toggle/Toggle";
import Avatar_Component from "./Components/Avatar/Avatar";
import Floating_Btn from "./Components/Floating_Action/Floatingbtn";
import Stack from "./Components/Stack/Stack";
import Rating_Component from "./Components/Rating/Rating";
import Custom_Rating from "./Components/Rating/Custom_Rating";
import Basic_List from "./Components/List/Basic_List";
import FolderList from "./Components/List/Folder_List";
import TransferList from "./Components/List/TransferList";
import BoxLayout from "./Components/Layouts/Box";
import Container_Component from "./Components/Layouts/Container";
import Grid_Container from "./Components/Layouts/Grid/Grid";
import Stack_Layout from "./Components/Layouts/Stack";
import MUI_Chip from "./Components/Chip/Chip";
import ChipArray from "./Components/Chip/ChipArray";
import MUI_Dividers from "./Components/Divider/MUI_Dividers";
import MUI_Badge from "./Components/Badge.js/MUI_Badge";
import Basic_Txtfield from "./Components/TextField/Basics_Txt";
import ToolTip from "./Components/ToolTip/Tooltip";
import AutoComplete_Component from "./Components/AutoComplete/AutoComplete";
import Radio_group from "./Components/Radio_Group/Radio_group";
import Basic_Alert from "./Components/Alert/Basic_Alert";
import Back_drop from "./Components/BackDrop/Back_drop";
import MUI_Dialog from "./Components/Dialog/MUI_Dialog";
import Alert_Dialog from "./Components/Dialog/Alert_Dialog";
import MUI_Progress from "./Components/Progress/Progress";
import MUI_Skeleton from "./Components/Skeleton/Skeleton";
import MUI_Snackbar from "./Components/Snackbar/Snackbar";
import Custom_Snackbar from "./Components/Custom_Snackbar/Custom_Snackbar";
import FabIntegrationbar from "./Components/FabIntegrationbar.js/FabIntegrationbar";
import SlideDirection from "./Components/FabIntegrationbar.js/SlideDirection";
import Snackbar_transition from "./Components/Snackbar/Snackbar_transitions";
import Practice_mui from "./Practice_mui";
import Stack_Component from "./Components/Stack/Stack";
import Accordion_Component from "./Components/Accordion/Accordion";
import Appbar from "./Components/AppBar/Appbar";
import Card_Component from "./Components/Card/Card";
import Bottom_Nav from "./Components/BottomNavigation/Bottom_Nav";
import Bread_Component from "./Components/BreadCrumbs/Breadcrumb";
import Drawer_Comp from "./Components/Drawer/Drawer_Comp";
import Menu_Component from "./Components/Menu/Menu_Comp";
import Speed_Component from "./Components/SpeedDial/Speed_dial";
import Stepper_Component from "./Components/Stepper/Stepper";

function App() {
  return (
    <div>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route index element={<AutoComplete_Component />} />
        {/* <Route index element={<List_Component />} /> */}
      </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App;
