import React,{ Component } from "react";
import { Accordion,
    AccordionSummary,
    AccordionDetails,
    Typography,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    TextField,
    Stack,
    IconButton,
    DialogActions,
 } from "@mui/material";
 import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
 import Close  from "@mui/icons-material/Close";

class Accordion_Component extends Component
{
 constructor(props)
 {
    super(props);
    this.state={
        accordions:[],
        id:0,
        accordtitle:"",
        accorddetail:"",
        openaccord:false
    }
 }

 handleSubmit=()=>
 {
   let {accordtitle,accorddetail,id,accordions}=this.state;
   let data={};
   data.id=id+1;
   data.accordion=accordtitle;
   data.accorddetail=accorddetail;
   let y=[...accordions,data];
   this.setState({accordions:y,accorddetail:"",accordtitle:"",openaccord:false,id:id+1})
 }

 handleinputs=e=>
 {
    this.setState({[e.target.name]:e.target.value})
 }

 handleClose=()=>
 {
    this.setState({open:false})
 }

 handleClose=()=>
 {
    this.setState({openaccord:false})
 }

 handleOpen=()=>
 {
    this.setState({openaccord:true})
 }

 render()
 {
    const {openaccord}=this.state;
    console.log(this.state.accordions);
    return(
        <div>
            <header><h1>Accordion - MUI</h1></header>
            <Dialog open={openaccord} maxWidth={"xs"} onClose={this.handleClose} fullWidth>
                <DialogTitle>Add Accordion 
                    <IconButton
                    sx={{
                        position:"absolute",
                        right:8,
                        top:10
                    }}
                    onClick={()=>this.handleClose()}
                    >
                        <Close />
                    </IconButton>
                </DialogTitle>
                <DialogContent>
                <Stack direction={"column"} spacing={3}>
                    <TextField
                    name="accordtitle"
                    label="AccordionTitle"
                    variant="standard"
                    fullWidth
                    onChange={(e)=>this.handleinputs(e)}
                    />
                    <TextField 
                    name="accorddetail"
                    label="AccordionDetail"
                    variant="standard"
                    multiline
                    rows={3}
                    onChange={(e)=>this.handleinputs(e)}
                    />
                </Stack>
                </DialogContent>
                <DialogActions>
                    <Button 
                    variant="contained" 
                    color="primary"
                    onClick={()=>this.handleSubmit()}
                    >
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>
            <div className="stackcenter">
                <Button variant="contained" color="primary" onClick={()=>this.handleOpen()}>Add Accordion</Button>
            </div>
            <div className="stackcenter">
              {this.state.accordions ? this.state.accordions.map((v)=>( 
                  <Accordion>
                    <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    id={v.id}
                    >
                        <Typography>{v.accordion}</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <Typography>{v.accorddetail}</Typography>
                    </AccordionDetails>
                  </Accordion>
              )):(
                ""
              )}
            </div>
        </div>
    )
 }
}

export default Accordion_Component;