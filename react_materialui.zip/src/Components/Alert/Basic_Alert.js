import { Alert,Stack,Divider, AlertTitle,Button, Collapse } from "@mui/material";
import { Help } from "@mui/icons-material";
import { useState } from "react";

function Basic_Alert()
{
const [open,setopen]=useState(true);

return(
    <div>
        <header>
            <h1>Basic Alert</h1>
        </header>
        <div className="stackcenter">
            <Stack direction={"column"} spacing={2}>
            <Alert severity="success">Success Alert Message</Alert>
            <Alert severity="warning">Warning Alert Message</Alert>
            <Alert severity="info">Info Alert Message</Alert>
            <Alert severity="error">Error Alert Message</Alert>
            </Stack>
        </div>
        <Divider />
        <h2>Alert Description</h2>
        <div className="stackcenter">
            <Stack direction="column" spacing={2}>
                <Alert severity="error">
                    <AlertTitle>Error</AlertTitle>
                    This is an error alert - <strong>Check it out</strong>
                </Alert>
                <Alert severity="warning">
                    <AlertTitle>Warning</AlertTitle>
                    This is an Warning alert - <strong>Check it out</strong>
                </Alert>
                <Alert severity="info">
                    <AlertTitle>Info</AlertTitle>
                    This is an Info alert - <strong>Check it out</strong>
                </Alert>
                <Alert>
                    <AlertTitle>Success</AlertTitle>
                    This is an Success alert - <strong>Check it out</strong>
                </Alert>
            </Stack>
        </div>
        <Divider />
        <h2>Alert Action</h2>
        <div className="stackcenter">
            <Stack direction={"column"} spacing={2}>
                 <Alert onClose={()=>{}}>This is a Success Alert</Alert>
                 <Alert action={<Button variant="outlined" color="success" size="small">UNDO</Button>}>
                    This is a Success Alert Message
                 </Alert>
            </Stack>
        </div>
        <Divider />
        <h2>Alert Transition</h2>
        <div className="stackcenter">
            <Stack direction="column">
                <Collapse in={open}>
                <Alert onClose={()=>setopen(false)}>Close Me !!!!</Alert>
                </Collapse>
            </Stack>  
            <Button 
            sx={{m:1}}
            disabled={open}
            variant="contained"
            onClick={()=>setopen(!open)}
            >
                ReOpen
            </Button>
        </div>
        <Divider />
        <h2>Icons</h2>
        <div className="stackcenter">
            <Stack direction="column">
                <Alert icon={<Help />}>Icon Change in Alert Message</Alert>
            </Stack>
        </div>
        <Divider />
        <h2>Variants</h2>
        <div className="stackcenter">
           <Stack direction="column" spacing={3}>
              <Alert variant="outlined">Variant Outlined Alert Message</Alert>
              <Alert variant="filled" color="success">Variant Filled Alert Message</Alert>
           </Stack>
        </div>
    </div>
)
}

export default Basic_Alert;