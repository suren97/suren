import React,{ Component } from "react";
import { AppBar,IconButton,Toolbar, Typography,Button } from "@mui/material";
import { Menu,Search } from "@mui/icons-material";

class Appbar extends Component
{
render()
{
    return(
        <div>
            <header>
                <h1>AppBar - MUI</h1>
            </header>
            <div className="stackcenter">
                <AppBar position="static">
                    <Toolbar>
                       <IconButton
                       size="large"
                       edge="start"
                       color="inherit"
                       sx={{mr:2}}
                       >
                          <Menu />
                       </IconButton>
                       <Typography variant="h6" sx={{flexGrow:1}}>News</Typography>
                       <Button color="inherit">Login</Button>
                    </Toolbar>
                </AppBar>
            </div>
            <div className="stackcenter">
               <AppBar position="static">
                   <Toolbar>
                        <IconButton
                        size="large"
                        color="inherit"
                        edge="start"
                        sx={{mr:2}}
                        >
                            <Menu />
                        </IconButton>
                        <Typography variant="h6" sx={{flexGrow:1}}>MUI</Typography>
                        <Search>
                                <Search />
                        </Search>
                   </Toolbar>
               </AppBar>
            </div>
        </div>
    )
}
}

export default Appbar;