import { Autocomplete, TextField,Stack,Box, Divider, Checkbox } from "@mui/material";
import { CheckBox } from "@mui/icons-material";

let dval={label:"sample",year:4001};

const top10Films = [
    { label: 'The Shawshank Redemption', year: 1994 },
    { label: 'The Godfather', year: 1972 },
    { label: 'The Godfather: Part II', year: 1974 },
    { label: 'The Dark Knight', year: 2008 },
    { label: '12 Angry Men', year: 1957 },
    { label: "Schindler's List", year: 1993 },
    { label: 'Pulp Fiction', year: 1994 },
    {
      label: 'The Lord of the Rings: The Return of the King',
      year: 2003,
    },
    { label: 'The Good, the Bad and the Ugly', year: 1966 },
    { label: 'Fight Club', year: 1999 },
];  

const countries= [
    { code: 'AD', label: 'Andorra', phone: '376' },
    {
      code: 'AE',
      label: 'United Arab Emirates',
      phone: '971',
    },
    { code: 'AF', label: 'Afghanistan', phone: '93' },
    {
      code: 'AG',
      label: 'Antigua and Barbuda',
      phone: '1-268',
    },
    { code: 'AI', label: 'Anguilla', phone: '1-264' },
    { code: 'AL', label: 'Albania', phone: '355' },
    { code: 'AM', label: 'Armenia', phone: '374' },
    { code: 'AO', label: 'Angola', phone: '244' },
    { code: 'AQ', label: 'Antarctica', phone: '672' },
    { code: 'AR', label: 'Argentina', phone: '54' },
    { code: 'AS', label: 'American Samoa', phone: '1-684' },
    { code: 'AT', label: 'Austria', phone: '43' }
];

function AutoComplete_Component()
{

let handleMulti=(e)=>
{
  console.log(e.target.value)
}

  return (
    <div>
      <header>
        <h1>MUI - AutoComplete</h1>
      </header>
      <h2>Combo Box</h2>
      <div className="stackcenter">
        <Autocomplete
          disablePortal
          options={top10Films}
          sx={{ width: 300 }}
          renderInput={(params) => <TextField {...params} label="Movie" />}
        />
      </div>
      <h2>Types of Props in AutoComplete</h2>
      <div className="stackcenter">
        <Stack direction="row" gap={5}>
          <Autocomplete
            disableCloseOnSelect
            options={top10Films}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField
                {...params}
                variant="standard"
                label="disableCloseonSelect"
              />
            )}
          />
          <Autocomplete
            clearOnEscape
            options={top10Films}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField {...params} variant="standard" label="ClearonEscape" />
            )}
          />
          <Autocomplete
            disableClearable
            options={top10Films}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField
                {...params}
                variant="standard"
                label="disableClearable"
              />
            )}
          />
          <Autocomplete
            includeInputInList
            options={top10Films}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField
                {...params}
                variant="standard"
                label="IncludeInputList"
              />
            )}
          />
        </Stack>
      </div>
      <Divider />
      <h2>Country Select</h2>
      <div className="stackcenter">
        <Autocomplete
          options={countries}
          sx={{ width: 300 }}
          renderOption={(props, option) => (
            <Box>
              <img
                src={`https://flagcdn.com/w20/${option.code.toLowerCase()}.png`}
                srcSet={`https://flagcdn.com/w40/${option.code.toLowerCase()}.png 2x`}
                alt=""
              />
              {" " + option.label}
            </Box>
          )}
          renderInput={(params) => (
            <TextField {...params} label="Choose Country" />
          )}
        />
      </div>
      <Divider />
      <h2>Group By</h2>
      <div className="stackcenter">
        <Autocomplete
          options={top10Films}
          sx={{ width: 300 }}
          groupBy={(option) => option.label}
          renderInput={(params) => (
            <TextField {...params} label="Select Movies" />
          )}
        />
      </div>
      <Divider />
      <h2>Disable Options</h2>
      <div className="stackcenter">
        <Autocomplete
          options={top10Films}
          sx={{ width: 300 }}
          getOptionDisabled={(option) => option.year >= 2000}
          renderInput={(params) => (
            <TextField {...params} label="Disabled Options" />
          )}
        />
      </div>
      <Divider />
      <h2>Multiple Values</h2>
      <div className="stackcenter">
        <Autocomplete
          multiple
          defaultValue={[{ label: "sampddsdsdle", year: 4001 }]}
          options={top10Films}
          getOptionLabel={(option) => option.label}
          sx={{ width: 400 }}
          onChange={(e) => handleMulti(e)}
          renderInput={(params) => (
            <TextField {...params} label="Multi Options" />
          )}
        />
      </div>
      <Divider />
      <h2>Checkbox Values</h2>
      <div className="stackcenter">
        <Autocomplete
          multiple
          options={top10Films}
          getOptionLabel={(option) => option.label}
          sx={{ width: 400 }}
          defaultValue={[top10Films[5]]}
          onChange={(e) => handleMulti(e)}
          renderOption={(props, option, { selected }) => (
            <li {...props}>
              <Checkbox checkedIcon={<CheckBox />} checked={selected} />
              {option.label}
            </li>
          )}
          renderInput={(params) => (
            <TextField {...params} label="Checkboxes" placeholder="Favorites" />
          )}
        />
      </div>
    </div>
  );
}

export default AutoComplete_Component;