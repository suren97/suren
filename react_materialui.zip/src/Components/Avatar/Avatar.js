import { Avatar, Stack,AvatarGroup } from "@mui/material";
import { Folder } from "@mui/icons-material";

function Avatar_Component()
{
 return(
    <div>
        <header>
            <h1>MaterialUI - Avatar</h1>
        </header>
        <h2>Avatar - Basics</h2>
        <div className="slidercont">
          <Stack spacing={2} direction="row">
          <Avatar>S</Avatar> 
          <Avatar>T</Avatar>   
          </Stack>
        </div>
        <h2>Avatar - Icons,Variants</h2>
        <div className="slidercont">
           <Stack spacing={4} direction="row">
            <Avatar variant="circular">K</Avatar>
            <Avatar variant="rounded">R</Avatar>
            <Avatar variant="square"><Folder /></Avatar>
           </Stack>
        </div>
        <h2>Avatar - Group</h2>
        <div className="slidercont">
        <Stack spacing={4} direction="row">
            <AvatarGroup max={4}>
                 <Avatar>1</Avatar>
                 <Avatar>2</Avatar>
                 <Avatar>3</Avatar>
                 <Avatar>4</Avatar>
            </AvatarGroup>
        </Stack>
        </div>
        <h2>Total Avatars</h2>
        <div className="slidercont">
             <Stack spacing={4} >
                <AvatarGroup max={2}>
                <Avatar>1</Avatar>
                 <Avatar>2</Avatar>
                 <Avatar>3</Avatar>
                 <Avatar>4</Avatar>
                </AvatarGroup>    
             </Stack>
        </div>
        </div>
 )    
}

export default Avatar_Component;