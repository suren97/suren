import { Button,Backdrop,Box,CircularProgress } from "@mui/material";
import { useState } from "react";

function Back_drop()
{
const [showdrop,setdrop]=useState(false);

let handleToggle=()=>
{
  setdrop(!showdrop);
}

let handleClose=()=>
{
  setdrop(false);
}

return(
    <div>
        <header>
        <h1>MUI - BackDrop</h1>
        </header>
        <div className="stackcenter">
            <Box>
                <Button onClick={()=>handleToggle()}>Show BackDrop</Button>
                <Backdrop
                sx={{color:'#fff',zIndex:(theme)=>theme.zIndex.drawer + 1}}
                open={showdrop}
                onClick={()=>handleClose()}
                >
                 <CircularProgress color="inherit" />   
                </Backdrop>
            </Box>
        </div>
    </div>
)
}

export default Back_drop;