import { 
    Badge,
    Divider,
    Stack,
    IconButton,
    Button,
    ButtonGroup,
    Box,
    Switch
} from "@mui/material";
import {Mail, NotificationsOutlined} from "@mui/icons-material";
import { Email,ShoppingCart,Add,Remove } from "@mui/icons-material";
import { useState } from "react";

function MUI_Badge()
{
const [notifications,setnotification]=useState(1);
const [show,setshow]=useState(0);

let visibleShow=(e)=>
{
  if(e.target.checked)
  {
    setshow(show+1);
  }
  else
  {
    setshow(0);
  }
}


return(
    <div>
        <header>
            <h1>Material UI - Badge</h1>
        </header>
        <div className="stackcenter">
            <h2>Basic Badge</h2>
            <Badge badgeContent={7} color="primary">
                  <NotificationsOutlined />
            </Badge>
            <div></div>
            <br></br>
            <Badge badgeContent={4} color="primary">
                  <Email color="action" />
            </Badge>
            <Divider />
            <h2>Customized Badge</h2>
            <IconButton>
                <Badge badgeContent={4} color="primary">
                <ShoppingCart />
                </Badge>
            </IconButton>
            <Divider />
            <h2>Badge Visibility</h2>
            <Box>
                <Badge badgeContent={notifications} color="secondary">
                <Email color="action" />
                </Badge>
                <div></div>
                <ButtonGroup>
                      <Button onClick={()=>setnotification(notifications-1)}><Remove /></Button>
                      <Button onClick={()=>setnotification(notifications+1)}><Add /></Button>
                </ButtonGroup>
            </Box>
            <br></br>
            <Box>
                <Badge badgeContent={show} color="primary" variant="dot">
                    <ShoppingCart color="action" />
                </Badge>
                <Switch onChange={(e)=>visibleShow(e)}></Switch>Show Badge
            </Box>
            <br></br>
            <h2>Badge Maximum Value</h2>
            <Box>
                <Badge color="info" badgeContent={100}>
                      <NotificationsOutlined />
                </Badge>
                <br></br>
                <br></br>
                <div></div>
                <Badge color="error" badgeContent={1000} max={999}>
                      <Mail color="action" />
                </Badge>
            </Box>
        </div>
    </div>
 )
}

export default MUI_Badge;