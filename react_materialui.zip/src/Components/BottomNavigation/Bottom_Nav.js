import { Avatar, ListItem, ListItemAvatar, ListItemText,Box,List, BottomNavigation,Paper,BottomNavigationAction } from "@mui/material";
import { Restore,Favorite,Archive } from "@mui/icons-material";
import { useState } from "react";

function Bottom_Nav()
{
const [nav,setnav]=useState();

let handlenav=(e,nv)=>
{
    setnav(nv);
}

return(
    <div>
        <header>
            <h1>MUI - Bottom Navigation</h1>
        </header>
        <div className="stackcenter">
           <Box width={400} border={1}>
             <List>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>A</Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="A" secondary="Alpha"></ListItemText>
                </ListItem>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>B</Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="B" secondary="Beta"></ListItemText>
                </ListItem>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>C</Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="C" secondary="Caret"></ListItemText>
                </ListItem>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>D</Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="D" secondary="Dense"></ListItemText>
                </ListItem>
             </List>
             <Paper elevation={3}>
                <BottomNavigation 
                showLabels 
                onChange={(e,nv)=>handlenav(e,nv)}
                value={nav}
                >
                     <BottomNavigationAction label="Recents" icon={<Restore />}/>
                     <BottomNavigationAction label="Favorites" icon={<Favorite />}/>
                     <BottomNavigationAction label="Archive" icon={<Archive />}/>
                </BottomNavigation>
             </Paper>
           </Box>
        </div>
    </div>
  )
}

export default Bottom_Nav;