import { Breadcrumbs,Typography,Link } from "@mui/material";

function Bread_Component()
{
 return(
    <div>
        <header>
            <h1>MUI - BreadCrumb</h1>
        </header>
        <div>
            <Breadcrumbs>
               <Link
               underline="hover"
               color="inherit"
               href="#"
               >
                MUI
               </Link>
               <Link
               underline="hover"
               color="inherit"
               >
                Core
                </Link>
               <Link
               
               >
                BreadCumbs
                </Link>
            </Breadcrumbs>
        </div>
    </div>
 )
}

export default Bread_Component;