import { Button } from "@mui/material";
import {IconButton} from "@mui/material";
import LoadingButton from "@mui/lab/LoadingButton";
import DeleteIcon from '@mui/icons-material/Delete';
import SendIcon from '@mui/icons-material/Send';
import AlarmIcon from "@mui/icons-material/Alarm";
import SaveIcon from "@mui/icons-material/Save";

function Button_Component()
{
let Get=()=>
{
 window.alert("Onclick button")
}

return(
    <div>
        <header>
            <h1>Button Component</h1>
        </header>
        <div className="flexcontainer">
        <div className="buttoncont">
        <Button variant="text">Text Variant Button</Button>
        </div>
        <div className="buttoncont">
         <Button variant="outlined">Text Outlined Button</Button>
        </div>
        <div className="buttoncont">
         <Button variant="contained">Button Contained</Button>
        </div>
        <div>
        <Button disabled variant="outlined">Disabled Button</Button>
        </div>
        <div>
        <Button variant="contained" href="#">Link Button</Button>
        </div>
        <div>
        <Button variant="contained" onClick={()=>Get()}>OnClick Button</Button>
        </div>
        </div>
        <div>
        <h2>Button Colors</h2>
        <div className="flexcontainer">
        <div>
            <Button variant="contained" color="primary">Primary</Button>
        </div>
        <div>
            <Button variant="contained" color="secondary">Secondary</Button>
        </div>
        <div>
            <Button variant="contained" color="warning">Warning</Button>
        </div>
        <div>
            <Button variant="contained" color="success">Success</Button>
        </div>
        <div>
            <Button variant="contained" color="info">Info</Button>
        </div>
        </div>
        <h2>Button Sizes</h2>
        <div className="flexcontainer">
        <div>
            <Button variant="contained" size="small">Small</Button>
        </div>
        <div>
            <Button variant="contained" size="medium">Medium</Button>
        </div>
        <div>
            <Button variant="contained" size="large">Large</Button>
        </div>
        </div>
        <h2>Upload Button</h2>
        <div>
            <div className="flexcontainer">
            <Button variant="contained">
            Upload File
            <input hidden={true} accept="image/*" type="file" />
            </Button>
            </div>
        </div>
        <h2>Buttons with Icon and Label</h2>
        <div className="flexcontainer">
        <div>
         <Button variant="outlined" startIcon={<DeleteIcon />} color="error">Delete</Button>
        </div>
        <div>
         <Button variant="contained" endIcon={<SendIcon />} color="primary">Send</Button>
        </div>
        </div>
        <h2>Icon Button</h2>
        <div className="flexcontainer">
        <div>
          <IconButton>
            <DeleteIcon />
          </IconButton>
          <IconButton color="primary">
            <SendIcon />
          </IconButton>
          <IconButton color="error">
            <AlarmIcon fontSize="large" />
          </IconButton>
        </div>
        </div>
    </div>
    <h2>Loading Buttons</h2>
    <div className="flexcontainer">
      <LoadingButton
      loading
      variant="outlined"
      >
        Save
      </LoadingButton>
      
      <LoadingButton 
      loading 
      loadingIndicator="Loading.."
      variant="contained"
      >
        Submit
      </LoadingButton>

      <LoadingButton
      loading
      loadingPosition="start"
      startIcon={<SaveIcon />}
      variant="contained"
      color="primary"
      >
        Save
      </LoadingButton>
    </div>
</div>
  )
}

export default Button_Component;