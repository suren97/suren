import { Button, ButtonGroup } from "@mui/material";

function BtnGroup()
{
const Buttons=[
   <Button>One</Button>,
   <Button>Two</Button>,
   <Button>Three</Button>
];

 return(
    <div>
        <header>
            <h1>Button Component - Button Group</h1>
        </header>
        <h2>Basic ButtonGroup</h2>
        <div className="groupcont">
            <ButtonGroup variant="contained">
                <Button>Button 1</Button>
                <Button>Button 2</Button>
                <Button>Button 3</Button>
            </ButtonGroup>
        </div>
        <h2>ButtonGroup Size and Colors</h2>
        <div className="groupcont">
            <ButtonGroup variant="text" size="large">
                <Button>Button 1</Button>
                <Button>Button 2</Button>
                <Button>Button 3</Button>
            </ButtonGroup>
        </div>
        <h2>Vertical Group</h2>
        <div className="groupcont">
             <ButtonGroup variant="contained" orientation="vertical">
                {Buttons}
             </ButtonGroup>
        </div>
    </div>
 )
}

export default BtnGroup;