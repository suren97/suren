import { Card, CardActions, CardContent,Typography,Button, CardHeader, Avatar, IconButton, CardMedia } from "@mui/material";
import { MoreVert,Favorite,Share } from "@mui/icons-material";
import ShipImg from "./Ship.png";

function Card_Component()
{
    return(
        <div>
            <header>
                <h1>MUI - Card</h1>
            </header>
            <h2>Basic Cards</h2>
            <div className="stackcenter">
               <Card sx={{ width:400 }} elevation={4}>
                  <CardContent>
                       <Typography sx={{fontSize:14}} color="text.secondary">Proverbs</Typography>
                       <Typography variant="h5" component="div">Tit for Tat</Typography>
                       <Typography sx={{mb:1.5}} color="text.secondary">adjective</Typography>
                       <Typography variant="body">Well Meaning and Kindly</Typography>
                  </CardContent>
                  <CardActions>
                     <Button size="small">Learn More</Button>
                  </CardActions>
               </Card>
            </div>
            <hr></hr>
            <h2>Complex Interactions</h2>
            <div className="stackcenter">
                <Card sx={{maxWidth:400}} variant="outlined">
                    <CardHeader
                    avatar={<Avatar>S</Avatar>}
                    action={
                        <IconButton>
                            <MoreVert />
                        </IconButton>
                    }
                    title="Surendar"
                    subheader="February 07,2023"
                    />
                    <CardMedia 
                    component="img"
                    height="194"
                    image={ShipImg}
                    />
                    <CardContent>
                        <Typography variant="body2" color="text.secondary">
                        This impressive paella is a perfect party dish and a fun meal to cook
                        together with your guests. Add 1 cup of frozen peas along with the mussels,
                        if you like.
                        </Typography>
                    </CardContent>
                    <CardActions>
                        <IconButton><Favorite /></IconButton>
                        <IconButton><Share /></IconButton>
                    </CardActions>
                </Card>
            </div>
            <hr></hr>
            <h2>Media Cards</h2>
            <div className="stackcenter">
                <Card sx={{width:400}}>
                    <CardMedia
                    sx={{height:140}}
                    image={ShipImg}
                    />
                    <CardContent>
                        <Typography gutterBottom variant="h5">Ship</Typography>
                    <Typography variant="body2" color="text.secondary">
                    A ship is a large watercraft that travels the world's oceans and other 
                    sufficiently deep waterways, carrying cargo or passengers, 
                    or in support of specialized missions, such as defense, research and fishing. 
                    Ships are generally distinguished from boats,
                    based on size, shape, load capacity and purpose
                    </Typography>
                    </CardContent>
                    <CardActions>
                        <Button size="small">Share</Button>
                        <Button size="small">Learn More</Button>
                    </CardActions>
                </Card>
            </div>
        </div>
    )
}

export default Card_Component;