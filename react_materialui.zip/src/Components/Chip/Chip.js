import { Chip,Stack,Divider,Avatar } from "@mui/material";
import { Face,Delete } from "@mui/icons-material";

function MUI_Chip()
{

let handlechip=e=>
{
    console.log(e.target.value)
    alert("Clicked Chip");
}

let handleDelete=(e)=>
{
    alert("Delete Icon");
}

let handleChiplink=e=>
{
    window.location.href="https://www.google.com/";
}


return(
    <div>
        <header>
            <h1>MUI - Chip</h1>
        </header>
        <div className="stackcenter">
        <h2>Basic Chip</h2>
        <Stack direction="row" spacing={2} >
        <Chip label="Chip Filled" variant="Filled"></Chip>
        <Chip label="Chip Outlined" variant="outlined"></Chip>
        </Stack>
        <br></br>
        <Divider />
        <h2>Chip Action</h2>
        <h2>OnClick</h2>
        <Stack direction={"row"} spacing={2} >
        <Chip label="Chip1" onClick={(e)=>handlechip(e)}></Chip>
        <Chip label="Chip2" variant="outlined" onClick={(e)=>handlechip(e)} ></Chip>
        </Stack>
        <h2>OnDelete</h2>
        <Stack direction={"row"} spacing={2} >
        <Chip label="Deletable" value={1} onDelete={(e)=>handleDelete(e)}></Chip>
        <Chip label="Deletable" value={2} variant="outlined" onDelete={(e)=>handleDelete(e)}></Chip>
        </Stack>
        <h2>Clickable and Deleteable</h2>
        <Stack direction="row" spacing={2}>
        <Chip 
        label="Clickable Deletable" 
        onClick={(e)=>handlechip(e)} 
        onDelete={(e)=>handleDelete(e)}
        >
        </Chip>
        <Chip 
        label="Clickable Deletable" 
        onClick={(e)=>handlechip(e)} 
        onDelete={(e)=>handleDelete(e)}
        variant="outlined"
        >
        </Chip>
        </Stack>
        <h2>Clickable Link</h2>
        <Stack direction={"row"} spacing={2}>
            <Chip
            label="Clickable Link1"
            onClick={(e)=>handleChiplink(e)}
            clickable
            >
            </Chip>
        </Stack>
        <br></br>
        <Divider />
        <h2>Custom Delete Icons</h2>
        <Stack direction={"row"} spacing={2}>
         <Chip
         label="Delete1"
         onDelete={(e)=>handleDelete(e)}
         deleteIcon={<Delete />}
         clickable
         >
         </Chip>
         <Chip
         label="Delete2"
         >
         </Chip>
        </Stack>
        <Divider />
        <h2>Chip Adornments</h2>
        <h2>Avatar Chip</h2>
        <Stack direction={"row"} spacing={2}>
        <Chip avatar={<Avatar></Avatar>} label="Avatar Chip1"></Chip>
        <Chip avatar={<Avatar></Avatar>} label="Avatar Chip2" variant="outlined"></Chip>
        </Stack>
        <h2>Icon Chip</h2>
        <Stack direction={"row"} spacing={2}>
        <Chip
        avatar={<Avatar><Face /></Avatar>}
        label="IconChip1"
        >
        </Chip>
        <Chip
        avatar={<Avatar>T</Avatar>}
        label="IconChip2"
        clickable
        >
        </Chip>
        </Stack>
        <h2>Color Chip</h2>
        <Stack direction={"row"} spacing={2}>
        <Chip color="primary" label="Chip1"></Chip>
        <Chip color="secondary" label="Chip2"></Chip>
        <Chip color="info" label="Chip3"></Chip>
        <Chip color="success" label="Chip4"></Chip>
        <Chip color="error" label="Chip5" size="small"></Chip>
        </Stack>
        <Divider />
        <Stack>
            
        </Stack>
        </div>
    </div>
  )
}

export default MUI_Chip;