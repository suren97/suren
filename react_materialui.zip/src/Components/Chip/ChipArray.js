import {Stack,Chip} from "@mui/material";
import { useState } from "react";
import Chip_Practice from "./Chip_Practice";


function ChipArray()
{
const [ChipItems,setChip]=useState([
    {label:"ReactJS",value:1},
    {label:"NodeJS",value:2},
    {label:"JAVA",value:3},
    {label:"SQL",value:4},
    {label:"PHP",value:5}
]);

let handleDelete=e=>
{
  setChip((prev)=>
  {
     return prev.filter((v,i)=>{ return v.value!== e.value })
  })
}

return(
        <div>
            <header>
                <h1>MUI - ChipArray</h1>
            </header>
            <Chip_Practice />
            {/* <div className="stackcenter">
            <Stack direction={"row"} spacing={2}>
            {ChipItems && ChipItems.map((v,i)=>
            {
           return <Chip
                label={v.label}
                onDelete={(e)=>handleDelete(v)}
                >
                </Chip>
            })}
                </Stack>
            </div> */}
        </div>
    )
}

export default ChipArray;