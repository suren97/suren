import {Chip,Stack,Button} from "@mui/material";
import { useState } from "react";

function Chip_Practice()
{
const [Chipdata,setChip]=useState([]);
const [input,setinput]=useState();
const [remid,setremid]=useState();

let handleinputs=e=>
{
  let val=e.target.value;
  setinput(val);
}

let handleSubmit=(val)=>
{
    setChip((prev)=>
    {
      return [...prev,{label:val,value:prev.length+1}]
    })
    setinput("");
}

let handleDelete=e=>
{
  Chipdata.splice(e,1);
  setremid(e);
  console.log(Chipdata)
}

return(
    <div className="stackcenter">
        <label>Enter Languages Name</label>
        <input type="text" value={input} onChange={(e)=>handleinputs(e)} />
        <Button variant="contained" onClick={()=>handleSubmit(input)} >Submit</Button>
        <Stack direction={"row"} spacing={2}>
            {Chipdata && Chipdata.map((v,i)=>{
         return  <Chip
            label={v.label}
            onDelete={()=>handleDelete(i)}
            >
            </Chip>
            })}
        </Stack>
    </div>
  )
}

export default Chip_Practice;