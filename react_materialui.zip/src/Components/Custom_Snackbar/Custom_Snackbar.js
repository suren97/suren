import {Stack,Button,Snackbar,IconButton} from "@mui/material";
import { Close } from "@mui/icons-material";
import { useState } from "react";

function Custom_Snackbar()
{
const [openbar,setbar]=useState();

let handleClose=()=>
{
    setbar(false);
}

let action=(
    <IconButton
    color="inherit"
    onClick={()=>handleClose()}
    >
       <Close />
    </IconButton>
)

return(
        <div>
            <header>
                <h1>MUI - Custom_Snackbar</h1>
            </header>
            <Stack>
                <Button variant="outlined" onClick={()=>setbar(true)} style={{margin:"5% auto",width:"30%"}}>Open Success SnackBar</Button>
                <Snackbar
                anchorOrigin={{vertical:"top",horizontal:"right"}}
                open={openbar}
                autoHideDuration={4000}
                onClose={handleClose}
                message="Custom SnackBar"
                action={action}
                />
            </Stack>
        </div>
)

}

export default Custom_Snackbar;