import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Divider,
    DialogContentText,
    TextField,
    AppBar,
    Toolbar,
    IconButton
} from "@mui/material";
import { useState,useRef } from "react";
import { Close } from "@mui/icons-material";

function Alert_Dialog()
{
const [opendiag,setdiag]=useState(false);
const [formdiag,setform]=useState(false);
const [fopen,setfopen]=useState(false);
const [dragdiag,setdrag]=useState(false);
const [mapdata,setmap]=useState([]);
const [scrolldiag,setscroll]=useState(false);
const ref=useRef(null);

const para=`Cras mattis consectetur purus sit amet fermentum.
Cras justo odio, dapibus ac facilisis in, egestas eget quam.
Morbi leo risus, porta ac consectetur ac, vestibulum at eros.
Praesent commodo cursus magna, vel scelerisque nisl consectetur et.`;

for(var i=1;i<10;i++)
{
mapdata.push(para);
}

let handleclose=()=>
{
    setdiag(false);
}

let handleformclose=()=>
{
    setform(false);
}

let handlefclose=()=>
{
    setfopen(false);
}

let handledrag=()=>
{
    setdrag(false);
}

let handlescrolldiag=()=>
{
    setscroll(false);
}

return(
   <div>
    <header>
        <h1>MUI - Alert Dialog</h1>
    </header>
    <div className="stackcenter">
    <Button variant="contained" onClick={()=>setdiag(true)}>Terms and Conditions</Button>
    </div>
    <Dialog open={opendiag} onClose={handleclose}>
        <DialogTitle>Terms and Conditions</DialogTitle>
        <DialogContent>
        Let Google help apps determine location. This means sending anonymous
        location data to Google, even when no apps are running.
        </DialogContent>
        <DialogActions>
            <Button onClick={()=>handleclose()}>Agree</Button>
            <Button onClick={()=>handleclose()}>DisAgree</Button>
        </DialogActions>
    </Dialog>
    <Divider />
    <h2>Form Dialog</h2>
    <div className="stackcenter">
      <Button variant="outlined" onClick={()=>setform(true)}>Open Form Dialog</Button>  
    </div>
    <Dialog open={formdiag} onClose={handleformclose} >
     <DialogTitle>Form Dialog</DialogTitle>
     <DialogContent>
        <DialogContentText>Share the Email Address for form Subscription</DialogContentText>
        <TextField 
        label="Email Address"
        variant="standard"
        fullWidth
        />
     </DialogContent>
     <DialogActions>
        <Button onClick={()=>handleformclose()}>Cancel</Button>
     </DialogActions>
    </Dialog>
    <Divider />
    <h2>Full Screen Dialog</h2>
    <div className="stackcenter">
      <Button onClick={()=>setfopen(true)}>Full Screen Dialog</Button>
    </div>
    <Dialog
    open={fopen}
    onClose={handlefclose}
    fullScreen
    >
    <AppBar><Toolbar><IconButton color="inherit" onClick={handlefclose}><Close /></IconButton></Toolbar></AppBar>
     <DialogTitle>Dialog Title</DialogTitle>
     <DialogContent>
        Full Screen Dialog Content
     </DialogContent>
    </Dialog>
    <Divider />
    <h2>Draggable Dialog</h2>
    <Button variant="outlined" onClick={()=>setdrag(true)}>
      Draggable Dialog
    </Button>
    <Dialog open={dragdiag} onClose={handledrag} draggable>
        <DialogTitle>Draggable Dialog</DialogTitle>
        <DialogContent>
            <DialogContentText>Draggable Dialog content Text</DialogContentText>
        </DialogContent>
    </Dialog>
    <Divider />
    <h2>Scroll Dialog</h2>
    <Button variant="outlined" onClick={()=>setscroll(true)}>Scroll Dialog</Button>
    <Dialog open={scrolldiag} onClose={handlescrolldiag}>
        <DialogTitle>Scroll Dialog</DialogTitle>
        <DialogContent>
            <DialogContentText>Scroll Dialog Text</DialogContentText>
            {mapdata.map((v,i)=>
            {
                return v;
            })}
        </DialogContent>
        <DialogActions>
            <Button variant="outlined" onClick={()=>handlescrolldiag()}>Close</Button>
        </DialogActions>
    </Dialog>
   </div>
)
}

export default Alert_Dialog;