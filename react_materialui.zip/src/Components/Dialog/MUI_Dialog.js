import {Button,Typography,Avatar,List,ListItem,Dialog} from "@mui/material";
import SimpleDialog from "./SimpleDialog";
import { useState } from "react";

function MUI_Dialog()
{
const [open,setopen]=useState(false);
const [selectedval,setselected]=useState();

let handleOpen=()=>
{
   setopen(true);
}

let handleListItem=(v)=>
{
    setopen(false)
    setselected(v);
}

return(
    <div>
        <header>
            <h1>MUI - Dialog</h1>
        </header>
        <Typography>Selected Account:{selectedval}</Typography>
        <div className="stackcenter">
             <Button variant="outlined" onClick={()=>handleOpen()}>Open Dialog</Button>
        </div>
        <SimpleDialog 
        open={open}
        handlelistItem={handleListItem}
        selectedvalue={selectedval}
        />
    </div>
)

}

export default MUI_Dialog;