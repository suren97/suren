import {Dialog,DialogTitle,List,ListItem,ListItemButton,ListItemAvatar,Avatar, ListItemText} from "@mui/material";
import {Person} from "@mui/icons-material";

const emails=['username@gmail.com','user02@gmail.com'];

function SimpleDialog(props)
{
let open=props.open;

return(
       <Dialog open={open}>
           <DialogTitle>Set Backup Account</DialogTitle>
           <List sx={{pt:0}}>
             {emails.map((v)=>(
                <ListItem>
                    <ListItemButton onClick={()=>props.handlelistItem(v)} key={v}>
                        <ListItemAvatar>
                            <Avatar>
                                <Person />
                            </Avatar>
                        </ListItemAvatar>
                        <ListItemText primary={v} />
                    </ListItemButton>
                </ListItem>
             ))}
           </List>
       </Dialog>
  )
}

export default SimpleDialog;