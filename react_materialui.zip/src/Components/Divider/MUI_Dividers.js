import { 
    List,
    ListItem,
    ListItemText,
    Divider,
    Paper,
    Stack,
    ListItemAvatar, 
    Avatar,
    Typography,
    Chip
} from "@mui/material";
import Call from "@mui/icons-material/Call";
import { useState } from "react";

function MUI_Dividers()
{
const [list,setlist]=useState([
    {label:"List1",value:1},
    {label:"List2",value:2},
    {label:"List3",value:3}
]);

let para=`Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Phasellus id dignissim justo.
Nulla ut facilisis ligula. Interdum
et malesuada fames ac ante ipsum primis in faucibus. Sed malesuada lobortis pretium.`;

return(
    <div>
    <h1>MUI_Dividers</h1>
    <div className="stackcenter">
    <h2>List Dividers</h2>
    <Stack direction={"row"} spacing={3} gap={5} flexWrap="wrap" justifyContent={"left"} > 
    <Paper style={{width:300}}>
            {list && list.map((v,i)=>
            {
            return <>
            <List>
                <ListItem>
                    <ListItemText>{v.label}</ListItemText>
                </ListItem>
            </List>
            <Divider orientation="horizontal" flexItem />
            </>
            })}
    </Paper>
    </Stack>
    <h2>Inset Dividers</h2>
    <Stack>
        <Paper elevation={0}>
            <List>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>
                        <Call />
                        </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="Heading 1" secondary="subHeading"></ListItemText>
                </ListItem>
                <Divider />
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>
                            <Call />
                        </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="Heading 2" secondary="subHeading"></ListItemText>
                </ListItem>
            </List>
        </Paper>
    </Stack>
    <h2>SubHeader Dividers</h2>
    <Stack>
        <Paper elevation={0}>
            <List>
                <ListItem>
                    <ListItemText primary="Photos" secondary="Jan 23,2023"></ListItemText>
                </ListItem>
                <Divider />
                <Typography sx={{fontSize:14,color:"lightgrey"}}>Divider</Typography>
                <li>
                        <ListItem>
                            <ListItemText primary="Work" secondary="Jan 12,2023"></ListItemText>
                        </ListItem>
                </li>
                <Divider variant="inset" />
                <Typography sx={{fontSize:14,color:"lightgrey",ml:9}}>GroupA</Typography>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>
                            <Call />
                        </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="Developer" secondary="Frontend"></ListItemText>
                </ListItem>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>
                            <Call />
                        </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="Tester" secondary="Quality"></ListItemText>
                </ListItem>
                <Divider variant="inset" />
                <Typography sx={{fontSize:14,color:"lightgrey",ml:9}}>GroupA</Typography>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>
                            <Call />
                        </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="Developer" secondary="Frontend"></ListItemText>
                </ListItem>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>
                            <Call />
                        </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="Tester" secondary="Quality"></ListItemText>
                </ListItem>
            </List>
        </Paper>
    </Stack>
    <h2>Dividers with Text</h2>
    <Stack>
        <Paper elevation="1">
            <List>
                <ListItem>
                    <ListItemText>{para}</ListItemText>
                </ListItem>
            </List>
        </Paper>
        <br></br>
        <Divider textAlign="left">Divider 1</Divider>
        <Paper elevation={1}>
            <List>
               <ListItem>
                   <ListItemText>{para}</ListItemText>
               </ListItem>
            </List>
        </Paper>
        <br></br>
        <Divider textAlign="right">Divider 2</Divider>
        <Paper elevation={1}>
             <List>
                <ListItem>
                    <ListItemText>{para}</ListItemText>
                </ListItem>
             </List>
        </Paper>
        <br></br>
        <Divider textAlign="center">Divider 3</Divider>
        <Paper elevation={1}>
             <List>
                <ListItem>
                    <ListItemText>{para}</ListItemText>
                </ListItem>
             </List>
        </Paper>
        <br></br>
        <Divider><Chip label="Divider"></Chip></Divider>
        <Paper>
            <List>
                <ListItem>
                    <ListItemText>{para}</ListItemText>
                </ListItem>
            </List>
        </Paper>
    </Stack>
    <h2>Vertical Divider with Text</h2>
    <Stack direction={"row"} spacing={2}>
    <Paper elevation={0}>
        {para}
        {para}
    </Paper>
    <Divider orientation="vertical" flexItem><Chip label="Vertical"></Chip></Divider>
    <Paper elevation={0}>
       {para}
       {para}
    </Paper> 
    </Stack>
    </div>
    </div>
)

}

export default MUI_Dividers;