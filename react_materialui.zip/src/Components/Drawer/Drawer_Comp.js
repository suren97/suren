import {Box,
    Drawer,
    Button,
    List,
    Divider,
    ListItem,
    ListItemButton,
    ListItemIcon,
    ListItemText
} from "@mui/material";
import { Inbox,Mail,Delete,Warning } from "@mui/icons-material";
import { useState } from "react";

function Drawer_Comp()
{
const [opendraw,setdraw]=useState();

let handleClose=()=>
{
  setdraw(false);
}

return(
        <div>
            <header>
                <h1>MUI - Drawer Component</h1>
            </header>
            <Button onClick={()=>setdraw(true)}>Left</Button>
            <Drawer
            anchor="left"
            open={opendraw}
            onClose={()=>handleClose()}
            >
           <Box sx={{width:250}}>
            <List>
                <ListItemButton>
                    <ListItemIcon><Mail /></ListItemIcon>
                <ListItemText primary="All Mails" />
                </ListItemButton>
            </List>
            <List>
                <ListItemButton>
                    <ListItemIcon><Inbox /></ListItemIcon>
                    <ListItemText primary="Inbox" />
                </ListItemButton>
            </List>
            <Divider />
            <List>
                <ListItemButton>
                    <ListItemIcon><Delete /></ListItemIcon>
                    <ListItemText primary="Trash" />
                </ListItemButton>
            </List>
            <List>
                <ListItemButton>
                    <ListItemIcon><Warning /></ListItemIcon>
                    <ListItemText primary="Spam" />
                </ListItemButton>
            </List>
           </Box>
            </Drawer>
        </div>
    )
}

export default Drawer_Comp;