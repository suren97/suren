import { Stack,Box,AppBar,Toolbar,IconButton, Typography,Fab, Snackbar } from "@mui/material";
import { Menu,Add } from "@mui/icons-material";
import { useState } from "react";

function FabIntegrationbar()
{
const [openbar,setbar]=useState(true);

let handleclose=()=>
{
  setbar(false);
}

return(
      <div>
        <header>
            <h1>MUI - FabIntegrationBar</h1>
        </header>
        <div className="stackcenter">
         <AppBar>
            <Toolbar>
                <IconButton
                edge="start"
                sx={{mr:2}}
                color="inherit"
                >
                    <Menu />
                </IconButton>
                <Typography>App Bar</Typography>
            </Toolbar>
         </AppBar>
         <Snackbar
         open={openbar}
         onClose={handleclose}
         autoHideDuration={4000}
         message="Snackbar Popup"
         />
         <Fab color="secondary" sx={{position:"absolute",bottom:(theme)=>theme.spacing(2),right:(theme)=>theme.spacing(2)}}>
           <Add />
         </Fab>
        </div>
      </div>
 )
}

export default FabIntegrationbar;