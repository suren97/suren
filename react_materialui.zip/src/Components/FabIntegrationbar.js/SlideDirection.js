import { Snackbar,Button,Slide,IconButton,Alert } from "@mui/material";
import { Close } from "@mui/icons-material";
import { useState } from "react";


function SlideDirection()
{
const [opensnack,setsnack]=useState(true);

let action=(
        <IconButton color="inherit">
            <Close />
        </IconButton>
)

let handleclose=()=>
{
   setsnack(false);
}

return(
    <div>
        <header>
            <h1>SlideDirection</h1>
        </header>
        <div className="stackcenter">
            <Button variant="outlined">Show Success Snackbar</Button>
           <Snackbar
           open
           autoHideDuration={3000}
           onClose={handleclose}
           >
            <Alert severity="success">This is a Success Message !</Alert>
          </Snackbar>
        </div>
    </div>
)
}

export default SlideDirection;