import FloatingActionButton from "@mui/material/Fab";
import Stack from "@mui/material/Stack";
import AddIcon from "@mui/icons-material/Add";
import EditIcon from "@mui/icons-material/Edit";
import NavigateIcon from "@mui/icons-material/Navigation";
import FavortieIcon from "@mui/icons-material/Favorite";
import { FormControlLabel } from "@mui/material";

function Floating_Btn()
{
  return(
    <div>
        <header>
            <h1>Floating Action Button</h1>
        </header>
        <div className="slidercont">
            <Stack spacing={3} direction={"row"}>
                <FloatingActionButton color="primary">
                <AddIcon />
                </FloatingActionButton>
                <FloatingActionButton color="secondary">
                <EditIcon />
                </FloatingActionButton>
                <FloatingActionButton variant="extended">
                  <NavigateIcon />Navigate
                </FloatingActionButton>
                <FloatingActionButton>
                 <FavortieIcon />
                </FloatingActionButton>
            </Stack>
        </div>
    </div>
  )
}

export default Floating_Btn;