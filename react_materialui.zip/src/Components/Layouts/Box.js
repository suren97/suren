import { Box } from "@mui/system";

function BoxLayout()
{
 return(
    <div>
        <header>
            <h1>Material UI - Box Layout</h1>
        </header>
        <Box 
        sx={{
            width:300,
            height:200,
            margin:10,
            backgroundColor:"blue",
            '&:hover':{
                backgroundColor:"lightblue",
                opacity:[0.7]
            }
        }} 
        />
    </div>
 )
}

export default BoxLayout;