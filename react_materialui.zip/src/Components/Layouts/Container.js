import { Container } from "@mui/material";
import { Box } from "@mui/system";

function Container_Component()
{
 return(
    <div>
        <header>
            <h1>MUI - Container</h1>
        </header>
        <div className="stackcenter">
            <Container fixed>
                <Box sx={{height:300,backgroundColor:"lightgray"}} />
            </Container>
        </div>
    </div>
 )
}

export default Container_Component;