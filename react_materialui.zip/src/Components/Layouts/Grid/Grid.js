import { Grid,Box } from "@mui/material";

function Grid_Container()
{
    return(
        <div>
            <header>
                <h1>MUI - Grid Container</h1>
            </header>
            <Box sx={{flexGrow:0}}>
               <Grid container spacing={3} >
                    <Grid item xs={6} md={8}>
                        <p>xs=6 md=8</p>
                    </Grid>
                    <Grid item xs={6} md={4}>
                        <p>xs=6 md=4</p>
                    </Grid>
                    <Grid item xs={8}>
                         <p>xs=8</p>
                    </Grid>
                    <Grid item xs={4}>
                        <p>xs=4</p>
                    </Grid>
               </Grid>
            </Box>
        </div>
    )
}

export default Grid_Container;