import {Divider, Stack} from "@mui/material"


function Stack_Layout()
{
   return(
    <div>
        <header>
            <h1>Material - Stack</h1>
        </header>
        <div className="stackcenter">
    <Stack 
    direction={"row"}
    justifyContent="center"
    flexWrap={"wrap"}
    gap={5}
    >
        <div className="box">
            <p>Box 1</p>
        </div>
        <div className="box">
            <p>Box 2</p>
        </div>
        <div className="box">
            <p>Box 3</p>
        </div>
        <div className="box">
            <p>Box 4</p>
        </div>
        <div className="box">
            <p>Box 5</p>
        </div>
        <div className="box">
            <p>Box 5</p>
        </div>
    </Stack>
    </div>
    </div>
   )
}

export default Stack_Layout;