import { Collapse, List, ListItem, ListItemButton, ListItemIcon, ListItemText } from "@mui/material";
import Stack from "@mui/material/Stack";
import AddIcon from "@mui/icons-material/Add";
import { ExpandMore } from "@mui/icons-material";

function Basic_List()
{
    return(
        <div>
            <header>
                <h1>Material UI - Basic Lists</h1>
            </header>
            <div className="stackcenter">
                 <Stack>
                    <List>
                        <ListItem disablePadding>
                            <ListItemButton>
                                <ListItemIcon>
                                <AddIcon />
                                </ListItemIcon>
                                <ListItemText primary="Add" />
                            </ListItemButton>
                        </ListItem>
                        <List>
                            <ListItem disablePadding>
                                <ListItemButton>
                                    <ListItemIcon>
                                        <AddIcon />
                                    </ListItemIcon>
                                    <ListItemText primary="Down" />
                                </ListItemButton>
                                <ExpandMore />
                            </ListItem>
                        </List>
                        <Collapse in={true}>
                        <ListItemButton sx={{pl:5}}>
                                    <ListItemIcon>
                                         <AddIcon />
                                    </ListItemIcon>
                                    <ListItemText primary="Element" />
                                </ListItemButton>
                        </Collapse>
                    </List>
                 </Stack>
            </div>
        </div>
    )
}

export default Basic_List;