import {
    Stack,
    Collapse,
    List,
    ListItem,
    ListItemButton,
    ListItemIcon,
    ListItemAvatar,
    ListItemText,
    Avatar
} from "@mui/material";
import {Photo,Collections} from "@mui/icons-material";

function FolderList()
{
  return(
    <div>
        <header>
            <h1>Folder Lists</h1>
        </header>
        <div className="stackcenter">
           <Stack>
             <List>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar>
                            <Photo />
                        </Avatar>
                    </ListItemAvatar>
                    <ListItemText primary="Photos" secondary="Jan 25,2023" />
                </ListItem>
                <ListItem>
                        <ListItemAvatar>
                            <Avatar>
                                <Collections />
                            </Avatar>
                        </ListItemAvatar>
                        <ListItemText primary="Media" secondary="Jan 25,2023" />
                </ListItem>
             </List>
           </Stack>
        </div>
    </div>
  )
}

export default FolderList;