import { 
    Stack,
    List,
    ListItem,
    ListItemAvatar,
    ListItemButton,
    ListItemText,
    ListItemIcon,
    Checkbox,
    Paper
} from "@mui/material";
import { Phone,Photo,Groups,Person } from "@mui/icons-material";
import { useState } from "react";

function TransferList()
{
const [namelists,setnames]=useState([
    {label:"Anderson",value:1,group:"A"},
    {label:"Dennis",value:2,group:"A"},
    {label:"Flora",value:3,group:"A"},
    {label:"Kavin",value:4,group:"A"},
    {label:"Richard",value:5,group:"B"},
    {label:"Marshall",value:6,group:"B"},
    {label:"Laurence",value:7,group:"B"},
    {label:"Miller",value:8,group:"B"}
]);

return(
        <div>
            <header>
                <h1>Transfer List</h1>
            </header>
            <div className="stackcenter">
                <Stack direction={"row"}>
                    <Paper elevation={2} style={{width:300,height:400}} >
                    {namelists ? (
                         (namelists.map((v,i)=>
                         {
                            if(v.group==="A")
                            {
                           return <List>
                                     <ListItem>
                                      <ListItemAvatar>
                                        <Checkbox />
                                      </ListItemAvatar>
                                      <ListItemText primary={v.label} />
                                </ListItem>
                                </List>
                            }
                         }))
                    ):(
                        " "
                    )}
                    </Paper>
                    <Paper elevation={2} style={{width:300,height:400}} >
                    {namelists ? (
                         (namelists.map((v,i)=>
                         {
                            if(v.group==="B")
                            {
                           return <List>
                                     <ListItem>
                                      <ListItemAvatar>
                                        <Checkbox />
                                      </ListItemAvatar>
                                      <ListItemText primary={v.label} />
                                </ListItem>
                                </List>
                            }
                         }))
                    ):(
                        " "
                    )}
                    </Paper>
                </Stack>
            </div>
        </div>
    )
}

export default TransferList;