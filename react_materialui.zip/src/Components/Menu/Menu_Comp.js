import { Menu,Button, MenuItem } from "@mui/material";
import { useState } from "react";

function Menu_Component()
{
const [openmenu,setmenu]=useState();

let handleclose=()=>
{
  setmenu(false); 
}

let handleopen=()=>
{
  setmenu(true);
}

  return(
    <div>
        <header>
            <h1>MUI - Menu_Components</h1>
        </header>
        <h2>Basic Menu</h2>
        <div className="stackcenter">
            <Button onClick={()=>handleopen()}>DashBoard</Button>
            <Menu
            open={openmenu}
            >
                <MenuItem onClick={handleclose}>Profile</MenuItem>
                <MenuItem onClick={handleclose}>My Account</MenuItem>
                <MenuItem onClick={handleclose}>Logout</MenuItem>
            </Menu>
        </div>
    </div>
  )
}

export default Menu_Component;