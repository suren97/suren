import { useState } from "react";
import { CircularProgress,LinearProgress,Box,Divider,Stack,Typography } from "@mui/material";

function MUI_Progress()
{
const [progressbar,setprogress]=useState(25);

let setProgress=()=>
{
   setInterval(()=>
   {
      setprogress(progressbar >= 100 ? 0 : progressbar + 25)
   },2000) 
}

setProgress();

return(
    <div>
        <header>
            <h1>MUI - Progress</h1>
        </header>
        <div className="stackcenter">
            <h2>Circular Indeterminate ProgressBar</h2>
           <Box>
              <CircularProgress />
           </Box>
        </div>
        <Divider />
        <h2>Circular Determinate ProgressBar</h2>
        <Stack direction={"row"}>
             {/* <CircularProgress variant="determinate" value={25} />
             <CircularProgress variant="determinate" value={50} /> */}
             <CircularProgress variant="determinate" value={progressbar} />
        </Stack>
        <Divider />
        <h2>Linear Progress</h2>
        <Box sx={{width:'100%'}}>
            {/* <LinearProgress /> */}
        </Box>
        <h2>Linear Determinate</h2>
        <Box sx={{width:'100%'}}>
            {/* <LinearProgress variant="determinate" value={progressbar}  /> */}
        </Box>
        <Divider />
        <h2>Customized Progress</h2>
        <Box>
            <LinearProgress 
            variant="determinate"
            size={40}
            thickness={4}
            />
        </Box>
    </div>
  )
}

export default MUI_Progress;