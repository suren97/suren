import { RadioGroup,FormControl,FormControlLabel,FormLabel,Radio, Divider } from "@mui/material";


function Radio_group()
{
 return(
    <div>
        <header>
            <h1>MUI - Radio Group</h1>
        </header>
        <div className="stackcenter">
           <FormControl>
               <FormLabel>Gender</FormLabel>
               <RadioGroup
               defaultValue="male"
               >
                   <FormControlLabel value="female" control={<Radio />} label="Female"  />
                   <FormControlLabel value="male" control={<Radio />} label="Male" />
                   <FormControlLabel value="other" control={<Radio />} label="Other" />
               </RadioGroup>
           </FormControl>
        </div>
        <Divider />
        <h2>Direction RadioGroup</h2>
        <div className="stackcenter">
           <FormControl>
            <FormLabel>Radiobtn Direction</FormLabel>
               <RadioGroup row>
                     <FormControlLabel value="yes" control={<Radio />} label="Yes" />
                     <FormControlLabel value="no" control={<Radio/>} label="No" />
                     <FormControlLabel value="no data" control={<Radio/>} label="no data" />
               </RadioGroup>
           </FormControl>
        </div>
        <Divider />
        <h2>Label Placement</h2>
        <div className="stackcenter">
           <FormControl>
              <FormLabel>Label Position</FormLabel>
              <RadioGroup>
                  <FormControlLabel 
                  value="top" 
                  control={<Radio />} 
                  label="Top" 
                  labelPlacement="top"
                  />
                  
                  <FormControlLabel 
                  value="right" 
                  control={<Radio />} 
                  label="Right"
                  labelPlacement="right"
                  /> 

                  <FormControlLabel
                  value="bottom"
                  control={<Radio />}
                  label="bottom"
                  labelPlacement="bottom"
                  />
              </RadioGroup>
           </FormControl>
        </div>
    </div>
 )
}

export default Radio_group;