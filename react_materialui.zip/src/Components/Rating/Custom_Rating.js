import { styled } from "@mui/material/styles";
import  Box  from "@mui/material/Box";
import { Rating, Typography } from "@mui/material";

function Custom_Rating()
{
 return(
    <div>
        <header>
            <h1>Custom Rating</h1>
        </header>
        <div className="slidercont">
        <Box>
          <Typography>10 Stars</Typography>
          <Rating
          aria-label="customize-rating"
          defaultValue={2}
          max={10}
          />
        </Box>
        </div>
    </div>
 )
}
export default Custom_Rating;