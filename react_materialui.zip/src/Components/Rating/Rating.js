import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Rating from "@mui/material/Rating";
import { useEffect,useState } from "react";

function Rating_Component()
{
const [starvalue,setstar]=useState();

let handlerating=e=>
{
    console.log("Ratingname",e.target.name);
    console.log("Ratings",e.target.value)
}
useEffect(()=>
{
//   let id=document.getElementById("hover");
//   console.log(id);
//   id.addEventListener("mouseover",(e)=>
//   {
//     console.log("value",e);
//   })
},[]);

let handlehover=e=>
{
    let val=e.target.innerText.split(" ");
    setstar(val[0]);
    console.log(val)
    console.log(e.target.innerText)
}

 return(
    <div>
        <header>
            <h1>UI - Rating</h1>
        </header>
        <h2>Ratings</h2>
        <div className="slidercont">
        <Box>
           <Typography>Controlled</Typography>
           <Rating onChange={(e)=>handlerating(e)}  />
           <Typography>Read Only</Typography>
           <Rating defaultValue={2} onChange={(e)=>handlerating(e)} readOnly />
           <Typography>Disabled</Typography>
           <Rating disabled />
        </Box>
        </div>
        <h2>Ratings Precision (Half Ratings)</h2>
        <br></br>
        <h2>Half Rating</h2>
        <div className="slidercont">
        <Box>
            <Typography>Half Rating</Typography>
            <Rating precision={0.5} onChange={(e)=>handlerating(e)} />
        </Box>
        </div>
        <h2>Hover Feedback</h2>
        <div className="slidercont">
        <Box>
        {starvalue}
            <Typography>Hover Feedback</Typography>
            <Rating id="hover" value={starvalue} precision={0.5} onMouseOver={(e)=>handlehover(e)} />
        </Box>
        </div>
    </div>
 )
}

export default Rating_Component;