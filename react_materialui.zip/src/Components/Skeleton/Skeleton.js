import { Skeleton, Stack,Divider } from "@mui/material";

function MUI_Skeleton()
{
return(
   <div>
      <header>
        <h1>MUI - Skeleton</h1>
      </header>
      <h2>4 Variant Skeleton</h2>
      <Stack spacing={1} width={"50%"}>
          <Skeleton variant="text" />
          <Skeleton variant="circular" width={40} height={40} />
          <Skeleton variant="rectangular" width={500} height={20} />
          <Skeleton variant="rounded" width={500} height={20} />
      </Stack>
      <br></br>
      <Divider />
      <h2>Skeleton Animation</h2>
      <Stack spacing={1} width={"30%"}>
         <Skeleton />
         <Skeleton animation="wave" />
         <Skeleton animation="false" />
      </Stack>
   </div>
)
}

export default MUI_Skeleton;