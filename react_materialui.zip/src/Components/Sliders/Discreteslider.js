import { Slider } from "@mui/material";
import Stack from '@mui/material/Stack';
import { useState } from "react";

function Discrete_Slider()
{
//Mark for Second slideBar
const secmark=[];
for(var i=0;i<=100;i++)
{
    if(i%10==0)
    {
        secmark.push({value:i,label:i.toString()})
    }
}
console.log("Second",secmark)

//Marks for first slideBar
const marks=[
    {
        value:0,
        label:"0"
    },
    {
        value:10,
        label:"10"
    },
    {
        value:20,
        label:"20"
    },
    {
        value:30,
        label:"30"
    },
    {
        value:40,
        label:"40"
    },
    {
        value:50,
        label:"50"
    }
];
const [slidervalues,setvalues]=useState([20,30]);
const [noswapvalues,setnoswap]=useState([10,30]);

const handleMark=e=>
{
    console.log("Sliders",e.target.value)
}

const handleslider=e=>
{
    let newValue=e.target.value;
    setvalues(newValue);
}

const handleswap=e=>
{
    let newValue=e.target.value;
    setnoswap(newValue);
}

 return(
    <div>
        <header>
        <h1>Discrete_Slider</h1>
        </header>
        <h2>Discrete Slider</h2>
        <div className="slidercont">
        <Stack>
        <Slider 
        defaultValue={25}
        valueLabelDisplay="auto"
        step={10}
        marks
        min={10}
        max={100}
        />
        </Stack>
        </div>
        <h2>Custom Marks</h2>
        <div className="slidercont">
        <Stack>
            <Slider
            aria-label="Always visible"
            valueLabelDisplay="on"
            step={10}
            marks={marks}
            min={0}
            max={50}
            onChange={(e)=>handleMark(e)}
            />
        </Stack>
        </div>
        <h2>Range Slider(With Swap)</h2>
        <div className="slidercont">
           <Stack>
            <Slider 
            name="swap"
            value={slidervalues}
            step={10}
            marks={secmark}
            min={0}
            max={100}
            onChange={(e)=>handleslider(e)}
            />
           </Stack>
        </div>
        <h2>Range Slider (Without Swap)</h2>
        <div className="slidercont">
           <Stack height={300}>
            <Slider 
              orientation="vertical"
              value={noswapvalues}
              step={10}
              marks={secmark}
              min={0}
              max={100}
              color="secondary"
              track="inverted"
              onChange={(e)=>handleswap(e)}
              disableSwap
            />
           </Stack>
        </div>
    </div>
 )
}

export default Discrete_Slider;