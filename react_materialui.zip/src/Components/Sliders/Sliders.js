import { Slider } from "@mui/material";
import { VolumeUp } from "@mui/icons-material";
import { VolumeDown } from "@mui/icons-material";
import Stack from '@mui/material/Stack';

function Slider_Component()
{
let handleslide=e=>
{
   console.log("Volume",e.target.value)
}

return (
    <div>
        <header>
            <h1>React - Sliders</h1>
        </header>
        <h2>Basic Sliders</h2>
        <div className="slidercont">
            <Stack spacing={2} direction="row" alignItems={"center"} >
            <VolumeDown />
            <Slider onChange={(e)=>handleslide(e)} />
            <VolumeUp />
            </Stack>
        </div>
        <div className="slidercont">
            <Stack spacing={2} direction="row">
            <VolumeDown />
            <Slider defaultValue={50} disabled />
            <VolumeUp />
            </Stack>
        </div>
        <h2>Slider Size</h2>
        <div className="slidercont">
            <Stack>
                <Slider 
                size="small" 
                defaultValue={30}
                valueLabelDisplay="auto"
                />
            </Stack>
        </div>
    </div>
)
}

export default Slider_Component;