import { Snackbar,Button,IconButton } from "@mui/material";
import { Close } from "@mui/icons-material";
import { useState } from "react";

function MUI_Snackbar()
{
const [opensnack,setsnack]=useState(false);

let handleclick=()=>
{
   setsnack(true);
}

let handleClose=()=>
{
   setsnack(false);
}

let action=(
    <>
    <IconButton 
    size="small"
    aria-label="close"
    color="inherit"
    onClick={handleClose}
    >
         <Close />
    </IconButton>
    </>
)

return(
    <div>
       <header>
           <h1>MUI - Snackbar</h1>
        </header>    
        <div className="stackcenter">
            <Button onClick={()=>handleclick()}>Open SnackBar</Button>
           <Snackbar 
           open={opensnack}
           autoHideDuration={3000}
           onClose={handleClose}
           message="Note Archived"
           action={action}
           />
        </div>
    </div>
)

}

export default MUI_Snackbar;