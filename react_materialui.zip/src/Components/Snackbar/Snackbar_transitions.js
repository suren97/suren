import * as React from 'react';
import Button from '@mui/material/Button';
import Snackbar from '@mui/material/Snackbar';
import Fade from '@mui/material/Fade';
import Slide,{SlideProps } from '@mui/material/Slide';
import Grow,{GrowProps } from '@mui/material/Grow';
import { useState } from 'react';

function SlideTransition(SlideProps) {
  return <Slide {...SlideProps} direction="up" />;
}

function GrowTransition(GrowProps) {
  return <Grow {...GrowProps} />;
}

function Snackbar_transition()
{
const [Transition,setTransition]=useState();
const [open,setopen]=useState(true);

let handleClick=(effect)=>
{
    console.log(effect)
    setTransition(effect);
    setopen(true)
}

let handleClose=()=>
{
    setopen(false);
}

let SlideProps={
    appear:true,
    direction:"up"
}

let action=()=>
{
   return (
      <Button>
        
      </Button>
   ) 
}

return (
    <div>
        <header>
            <h1>MUI - Snackbar Transition</h1>
        </header>
      {/* <Slide {...SlideProps} > */}
      <Snackbar
        open
        onClose={handleClose}
        message="Snackbar Message"
        action={action}
      />
      {/* </Slide> */}
    </div>
  );
}


export default Snackbar_transition;