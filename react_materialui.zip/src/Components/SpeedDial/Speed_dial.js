import { Box,SpeedDial,SpeedDialAction,SpeedDialIcon } from "@mui/material";
import { FileCopy,Save,Print,Share } from "@mui/icons-material";
import * as React from "react";

const actions=[
    {icon:<FileCopy/>,name:"Copy"},
    {icon:<Save/>,name:"Save"},
    {icon:<Print/>,name:"Print"},
    {icon:<Share/>,name:"Share"}
];

function Speed_Component()
{
return(
    <div>
        <header>
            <h1>MUI - Speed_Dial-Component</h1>
        </header>
        <div className="stackcenter">
            <Box sx={{ height:320, transform: 'translateZ(0px)',flexGrow:1 }}>
               <SpeedDial
                ariaLabel="SpeedDial basic example"
                sx={{ position:'absolute', bottom: 16, right: 16 }}
               icon={<SpeedDialIcon/>}
               >
                {actions.map((val)=>(
                    <SpeedDialAction 
                    key={val.name}
                    icon={val.icon}
                    tooltipTitle={val.name}
                    />
                ))}
               </SpeedDial>
            </Box>
        </div>
    </div>
)
}

export default Speed_Component;