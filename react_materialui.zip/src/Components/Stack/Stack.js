import { Stack,Divider } from "@mui/material";

function Stack_Component()
{
 return(
    <div>
        <header>
            <h1>Material - Stack</h1>
        </header>
        <div className="stackcont">
        <Stack 
        direction={"column"}
        divider={<Divider />}
        >
            <div className="elemclass">Element 1</div>
            <div className="elemclass">Element 2</div>
            <div className="elemclass">Element 3</div>
        </Stack>
        </div>
    </div>
 )
}

export default Stack_Component;