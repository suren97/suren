function Stepper_Component()
{
return(
    <div>
        <header>
            <h1>MUI - Stepper Components</h1>
        </header>
    </div>
)
}

export default Stepper_Component;