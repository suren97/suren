import { Switch, FormGroup, FormControlLabel } from "@mui/material";

function Switches()
{
let handleswitch=e=>
{
  console.log(e.target.checked)
}

return(
    <div>
        <header>
        <h1>Switches</h1>
        </header>
        <h2>Basic Switches</h2>
        <div className="slidercont">
        <FormGroup>
            <FormControlLabel 
            control={<Switch defaultChecked onChange={(e)=>handleswitch(e)}
            color="success"
            />}
            label="Switch" 
            />
        </FormGroup>
        </div>
        <h2>Switch Color and Multiple Switches</h2>
        <div className="slidercont">
            <FormGroup>
                <FormControlLabel 
                control={<Switch color="secondary" />}
                label="Switch1"
                />
                <FormControlLabel
                control={<Switch color="success" />}
                label="Switch2"
                />
                <FormControlLabel
                control={<Switch color="error" />}
                label="Switch3"
                />
                <FormControlLabel
                control={<Switch color="warning" />}
                label="Switch4"
                />
            </FormGroup>
        </div>
    </div>
)
}
export default Switches;