import { TextField,Box,Stack,Divider, MenuItem, FormControl, InputLabel, Input, InputAdornment, FilledInput, OutlinedInput, FormControlLabel } from "@mui/material";
import { AccountCircle } from "@mui/icons-material";

function Basic_Txtfield()
{
const currencies = [
    {
        value: 'USD',
        label: '$',
    },
    {
        value: 'EUR',
        label: '€',
    },
    {
        value: 'BTC',
        label: '฿',
    },
    {
        value: 'JPY',
        label: '¥',
    },
];

return(
     <div>
        <header>
            <h1>Basic TextField</h1>
        </header>
        <div className="stackcenter">
            <Stack direction={"column"}>
                <TextField style={{margin:8}} id="basic_outlined" label="Text Outlined" variant="outlined" />
                <TextField style={{margin:8}} id="basic_filled" label="Text filled" variant="filled" />
                <TextField style={{margin:8}} id="basic_standard" label="Text_standard" variant="standard" />
            </Stack>
        </div>
        <Divider />
        <h2>Form Properties</h2>
        <div className="stackcenter">
           <Stack direction={"row"}>
               <TextField 
               required
               style={{margin:3}}
               id="text-required"
               label="Required"
               defaultValue="Hello World"
               />
               <TextField 
               disabled
               style={{margin:3}}
               id="text-disabled"
               label="Disabled"
               defaultValue="Disabled Txtfield"
               />
               <TextField 
               style={{margin:3}}
               type="password"
               label="Password"
               />
               <TextField 
               style={{margin:3}}
               label="Read Only"
               defaultValue="Read Only field"
               InputProps={{
                 readOnly:true
               }}
               />
               <TextField 
               style={{margin:3}}
               type="number"
               label="Number Textfield"
               InputProps={{
                 shrink:true
               }}
               />
               <TextField
               style={{margin:3}}
               id="outlined-search"
               label="Search field"
               type="search"
               />
               <TextField 
               style={{margin:3}}
               id="outlined-helper"
               label="Helper TextField"
               helperText="Helper Text"
               />
           </Stack>
        </div>
        <Divider />
        <h2>Validation Fields</h2>
        <div className="stackcenter">
          <TextField 
          style={{margin:3}}
          error
          id="outlined-error"
          label="Error msg field"
          />
          <TextField 
          style={{margin:3}}
          error
          id="outlined-helpererror"
          label="Helper Error field"
          helperText="Error Message"
          />
        </div>
        <Divider />
        <h2>MultiLine Field</h2>
        <div className="stackcenter">
            <TextField 
            style={{margin:3}}
            id="outline-multiline"
            label="Multiline Field"
            multiline
            />
            <TextField
            style={{margin:3}}
            label="Multiline with limit overflow"
            multiline
            maxRows={3}
            />
            <TextField 
            style={{margin:3}}
            id="outlined-multilinerows"
            label="Multiline with rowslimit"
            multiline
            rows={2}
            />
        </div>
        <Divider />
        <h2>TextField Select</h2>
        <div className="stackcenter">
          <Stack direction={"rows"}>
               <TextField
               select
               style={{margin:3}}
               id="outlined-select"
               label="Select"
               defaultValue="EUR"
               helperText="Please select your currency"
               >
               {currencies.map((v)=>{
                  return <MenuItem key={v.value} value={v.value}>
                    {v.label}
                  </MenuItem>
               })}
               </TextField>
               <TextField
               select
               style={{margin:3}}
               id="outlined-nativeSelect"
               label="Native_Select"
               defaultValue="EUR"
               SelectProps={{
                native:true
               }}
               helperText="Please Select your currency"
               >
                {currencies.map((v)=>
                {
                   return <option key={v.value} value={v.value}>{v.label}</option>
                })}
               </TextField>
          </Stack>
        </div>
        <Divider />
        <h2>Icon Adornment</h2>
        <div className="stackcenter">
           <Stack direction={"row"}  gap={10}>
              <FormControl variant="standard">
                   <InputLabel>With a Start Adornment</InputLabel>
                   <Input
                   id="input-icon-adornment"
                   startAdornment={
                     <InputAdornment position="start">
                         <AccountCircle />
                     </InputAdornment>
                   }
                   />
              </FormControl>
              <TextField 
              variant="standard"
              id="input-icon-Textfield"
              label="TextField Icon label"
              InputProps={{
                startAdornment:(
                    <InputAdornment position="start">
                        <AccountCircle />
                    </InputAdornment>
                )
              }}
              />
              <Box sx={{display:"flex",alignItems:"flex-end"}}>
                   <AccountCircle sx={{color:"action",mr:1}} />
                   <TextField variant="standard" />
              </Box>
           </Stack>
        </div>
        <Divider />
        <h2>Input Adornments</h2>
        <div className="stackcenter">
         <Stack direction={"row"} gap={10}>
            <FormControl variant="standard">
                <InputLabel>Text Adornments</InputLabel>
                <Input 
                label="Text Adornments"
                startAdornment={
                    <InputAdornment position="start">Kg</InputAdornment>
                }
                />
            </FormControl>
            <TextField 
            variant="standard"
            id="textfield-adornments"
            label="Textfield adornments"
            InputProps={{
                endAdornment:(
                    <InputAdornment position="start" id="text">gms</InputAdornment>
                )
            }}
            />
         </Stack>
        </div>
     </div>
)
}

export default Basic_Txtfield;