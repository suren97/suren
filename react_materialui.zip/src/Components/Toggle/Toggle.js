import {Box,Divider,Stack,ToggleButton,ToggleButtonGroup} from "@mui/material";
import { FormatAlignCenter,FormatAlignLeft,FormatAlignRight,FormatAlignJustify,Check } from "@mui/icons-material";
import { useState } from "react";
import * as React from 'react';

function Toggle()
{
const [togglevalue,setvalue]=useState();
const [selected,setselected]=useState(false);

const handleAlignment = e=>{
    console.log(e.target.value)
}


return(
        <div>
            <header>
                <h1>MUI - Toggle Button</h1>
            </header>
            <h2>Toggle Buttons</h2>
            <div className="stackcenter">
             <Stack direction="row">
                  <ToggleButtonGroup
                  value={togglevalue}
                  exclusive
                  onClick={handleAlignment}
                  >
                      <ToggleButton value="left" aria-label="left-aligned">
                          <FormatAlignLeft />
                      </ToggleButton>
                      <ToggleButton value="center" aria-label="centered">
                          <FormatAlignCenter />
                      </ToggleButton>
                      <ToggleButton value="right" aria-label="right-aligned">
                           <FormatAlignRight />
                      </ToggleButton>
                      <ToggleButton value="Justify" disabled>
                           <FormatAlignJustify />
                      </ToggleButton>
                  </ToggleButtonGroup>
             </Stack>
            </div>
            <Divider />
            <h2>StandAlone Toggle</h2>
            <div className="stackcenter">
               <ToggleButton
               value="Check"
               selected={selected}
               onChange={()=>setselected(!selected)}
               >
                    <Check />
               </ToggleButton>
            </div>
        </div>
    )
}

export default Toggle;