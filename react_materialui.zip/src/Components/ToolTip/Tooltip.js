import { Box,Divider,Grid,IconButton,Button,Fade,Zoom,Tooltip } from "@mui/material";
import {Delete,Add} from "@mui/icons-material";
import { useState } from "react";

const longText = `Aliquam eget finibus ante, non facilisis lectus. Sed vitae 
dignissim est, vel aliquam tellus.Praesent non nunc mollis, fermentum neque at, 
semper arcu.Nullam eget est sed sem iaculis gravida eget vitae justo.`;

function ToolTip()
{
const [open,setopen]=useState(false);

let handleOpen=()=>
{
    setopen(true);
}

let handleClose=()=>
{
    setopen(false);
}

return(
    <div>
        <header>
            <h1>MUI - ToolTip Components</h1>
        </header>
        <h2>Basic ToolTips</h2>
        <div className="stackcenter">
            <Box>
           <Tooltip title="Delete" placement="bottom" >
              <IconButton size="large">
                  <Delete />
              </IconButton>
           </Tooltip>
           </Box>
        </div>
        <Divider />
        <h2>Positioned ToolTips</h2>
        <div className="stackcenter">
         <Box sx={{textAlign:"center"}}>
            <Tooltip title="Positioned Tooltips" placement="right">
                 <IconButton>
                       <Add sx={{fontSize:"35px"}} />
                 </IconButton>
            </Tooltip> 
         </Box>
        </div>
        <Divider />
        <h2>Arrow ToolTips</h2>
        <div className="stackcenter">
          <Box>
                <Tooltip title="Arrow Tooltip" arrow>
                    <Button>Arrow Tooltip</Button>
                </Tooltip>
          </Box>
        </div>
        <Divider />
        <h2>Triggers Tooltip</h2>
        <div className="stackcenter">
            <Grid container>
                <Grid item>
                      <Tooltip disableFocusListener title="Tooltip">
                          <Button>Hover or Touch</Button>
                      </Tooltip>
                </Grid>
                <Grid item>
                    <Tooltip disableHoverListener title="Focus Tooltip">
                        <Button>Focus or Touch</Button>
                    </Tooltip>
                </Grid>
            </Grid>
        </div>
        <Divider />
        <h2>Controlled Tooltip Component</h2>
        <div className="stackcenter">
            <Grid container>
                <Tooltip title="Controlled ToolTip" open={open} onOpen={handleOpen} onClose={handleClose} >
                   <Button>Controlled</Button>
                </Tooltip>  
            </Grid>    
        </div>
        <Divider />
        <h2>Tooltip Width</h2>
        <div className="stackcenter">
            <Tooltip title={longText}>
                <Button sx={{m:1}}>Default Width [300px]</Button>
            </Tooltip> 
        </div>
        <Divider />
        <h2>Transition Tooltip</h2>
        <div className="stackcenter">
          <Tooltip title={"Grow Tooltip"}>
               <Button>Grow</Button>
          </Tooltip>
          <Tooltip
          TransitionComponent={Fade}
          TransitionProps={{timeout:2000}}
          title="Fade"
          >
               <Button>Fade</Button>
          </Tooltip>
          <Tooltip
          TransitionComponent={Zoom}
          TransitionProps={{timeout:2000}}
          title="Zoom"
          >
               <Button>Zoom</Button>
          </Tooltip>
        </div>
    </div>
)
}

export default ToolTip;