function MainPage()
{
    return(
        <div>
            <header>
                <h1>Material UI - React</h1>
            </header>
        </div>
    )
}

export default MainPage;