import { Avatar, Button,ButtonGroup,Checkbox, Divider, Rating, Slider, Switch } from "@mui/material";
import { BookmarkBorder,Favorite,Bookmark,Add } from "@mui/icons-material";
import Fab from "@mui/material/Fab";
import { useState } from "react";

function Practice_mui()
{
const [slidervalue,setvalue]=useState([20,40]);

let handlerating=e=>
{
    console.log(e.target.value)
}

let handleslider=e=>
{
    console.log(e.target.value)
    setvalue(e.target.value);
}

let handleswitch=e=>
{
    console.log(e.target.checked)
}

return (
    <div>
        <header>
            <h1>MUI - Practice</h1>
        </header>
        <div className="stackcenter">
            <h2>Buttons and Buttons Group</h2>
             <Button variant="text" color="secondary">Confirm</Button>
             <ButtonGroup 
             disableElevation
             orientation="vertical"
             >
                <Button variant="contained" color="primary">Button 1</Button>
                <Button variant="contained" color="secondary">Button 2</Button>
                <Button variant="contained" color="error">Button 3</Button>
             </ButtonGroup>
             <h2>Checkbox</h2>
             <div>
                <Checkbox defaultChecked color="secondary" size="medium" />
                <Checkbox 
                icon={<BookmarkBorder />}
                checkedIcon={<Bookmark />}
                />
             </div>
             <h2>FloatingActionButton</h2>
             <Fab color="primary" size="small">
                <Add />
             </Fab>
             <Fab color="secondary" variant="extended" >
                <Bookmark />BookMark
             </Fab>
             <h2>Ratings</h2>
             <Rating defaultValue={2.5} precision={0.5} onChange={(e)=>handlerating(e)} />
             <div>
             <Rating max={10} defaultValue={3} />
             </div>
             <h2>Slider</h2>
             <div className="slidercont">
             <Slider 
             defaultValue={20}
             onChange={(e)=>handleslider(e)}
             />
             </div>
             <div className="slidercont">
            <h2>Discrete Slider</h2>
            <Slider 
            step={10}
            marks
            min={0}
            max={50}
            defaultValue={20}
            />
             </div>
             <h2>Range Slider</h2>
             <div className="slidercont">
             <Slider
             disableSwap
             value={slidervalue}
             step={10}
             marks
             min={10}
             max={100}
             onChange={(e)=>handleslider(e)}
             />
             </div>
             <h2>Switch</h2>
             <Switch onChange={(e)=>handleswitch(e)}></Switch>
             <h2>Avatar</h2>
             <Avatar>S</Avatar>
        </div>
    </div>
  )
}

export default Practice_mui;