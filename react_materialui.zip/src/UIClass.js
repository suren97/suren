import React,{Component} from "react";
import { TextField } from "@mui/material";


class UIClass extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
           
        }
    }

render()
{
    return(
        <div>
           <TextField />
        </div>
    )
}
}

export default UIClass;