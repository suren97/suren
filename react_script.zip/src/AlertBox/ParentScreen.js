import { Button } from "@mui/material";
import { useEffect,useState } from "react";
import Confirmation from "./Confirmation";
import { useSelector,useDispatch } from "react-redux";
import { SaveComponent,CloseComponent } from "../Redux/Slice";

function ParentScreen(props)
{
const reduxdata=useSelector((state)=>{
    return state.Components
})

const [reset,setreset]=useState(1);
const [Popup,setPopup]=useState();

// useEffect(()=>
// {
//    setPopup(reduxdata.Popup)
// },[reset])

const dispatch=useDispatch();

let GetAlert=()=>
{
    dispatch(SaveComponent(<Confirmation />));
    setreset(reset+1);
}

let CloseAlert=()=>
{
  dispatch(CloseComponent());
}

return (
  <>
    <div>
      <header>
        <h1>ParentScreen Component</h1>
      </header>
      <div>
        <Button variant="contained" sx={{ m: 3 }} onClick={() => GetAlert()}>
          Confirmation
        </Button>
        <Button variant="contained" sx={{ m: 3 }} onClick={() => CloseAlert()}>
          Cancel
        </Button>
      </div>
      {reduxdata.Popup}
    </div>
  </>
);
}

export default ParentScreen;