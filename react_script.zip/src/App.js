import JS_Recap from "./JS_Advanced/JS_Recap";
import ParentScreen from "./AlertBox/ParentScreen";
import ReduxStore from "./Redux/Store";
import { Provider } from "react-redux";
import Encryption from "./Encryption/Encryption";
import ExcelEncryption from "./Encryption/ExcelEncryption";
import {BrowserRouter as Router,Routes,Route} from "react-router-dom";
import SideNav from "./SonataSideNav/SideNav";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<SideNav />}></Route>
      </Routes>
    </Router>
  );
}

export default App;
