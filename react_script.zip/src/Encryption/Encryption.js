import { Button } from "@mui/material";
import { AES, enc } from "crypto-js";

function Encryption() {
  const savePlan = async (e) => {
    //Encryption
    let body = [
      { voyage: "DTX" },
      { voyage: "TTX" },
      { voyage: "AMD" },
      { voyage: "CHE" },
      { voyage: "TMX" },
    ]; 
    // Plan JSON Objects
    const fileName = "Plan";
    const encrypted_data = AES.encrypt(
      JSON.stringify(body),
      "SecretKey"
    ).toString();

      const bytes = AES.decrypt(encrypted_data, "SecretKey");
      const decrypted = JSON.parse(bytes.toString(enc.Utf8));
      // console.log(decrypted);

    if ("showSaveFilePicker" in window) {
    // Use the showSaveFilePicker API if available
      const options = {
        suggestedName: "Plan.json", // default file name

        types: [
          {
            description: "JSON file",

            accept: {
              "application/json": [".json"],
            },
          },
        ],
      };

      const handle = await window.showSaveFilePicker(options);

      const writable = await handle.createWritable();

      await writable.write(encrypted_data);

      await writable.close();
    } 
    else {
      const blob = new Blob([encrypted_data], { type: "application/json" });

      const url = await URL.createObjectURL(blob);

      const link = document.createElement("a");

      link.download = fileName + ".json";

      link.href = url;

      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);
    }
  };
  return (
    <div>
      <header>
        <h1>Encryption and Decryption</h1>
      </header>
      <div>
        <Button variant="contained" onClick={() => savePlan()}>
          SavePlan
        </Button>
      </div>
    </div>
  );
}

export default Encryption;