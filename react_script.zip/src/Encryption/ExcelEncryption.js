import { AES,enc } from "crypto-js";
import { Button } from "@mui/material";

function ExcelEncryption()
{

const saveExcel=async e=>
{
    let body = [
      { voyage: "DTX" },
      { voyage: "TTX" },
      { voyage: "AMD" },
      { voyage: "CHE" },
      { voyage: "TMX" },
    ]; 

    const encrypted_data = AES.encrypt(
        JSON.stringify(body),
        "SecretKey"
    ).toString();


     if ("showSaveFilePicker" in window) {
        const options = {
          suggestedName: "Plan.csv", // default file name

          types: [
            {
              description: "Excel file",

              accept: {
                "text/csv": [".csv"],
              },
            },
          ],
        };
        const handle = await window.showSaveFilePicker(options);

      const writable = await handle.createWritable();

      await writable.write(JSON.stringify(body));

      await writable.close();
     }
}   

return (
  <>
    <div>
      <header>
        <h1>Excel Encryption</h1>
      </header>
      <Button variant="contained" onClick={() => saveExcel()}>Save Excel</Button>
    </div>
  </>
);
}

export default ExcelEncryption;