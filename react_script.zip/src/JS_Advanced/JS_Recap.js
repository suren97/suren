function JS_Recap()
{

// alert("notnumber"/2);
let age=null;
console.log(age)

return(
        <>
        <header>
            <h1>JS_Recap</h1>
        </header>
        </>
)

}

export default JS_Recap;