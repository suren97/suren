import { createSlice } from "@reduxjs/toolkit";

const initialState={
    Popup:""
}

const ReduxSlice = createSlice({
  name: "component",
  initialState,
  reducers: {
    SaveComponent: (state, action) => {
      state.Popup = action.payload;
    },
    CloseComponent:(state,action)=>{
      state.Popup=action.payload
    }
  },
});

export const ReduxReducer=ReduxSlice.reducer;
export const { SaveComponent, CloseComponent } = ReduxSlice.actions;


