import { configureStore } from "@reduxjs/toolkit";
import { ReduxReducer } from "./Slice";

const ReduxStore = configureStore({
  reducer: {
    Components: ReduxReducer,
  },
});

export default ReduxStore;
