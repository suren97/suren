import Logo from "./svmhead.svg";
import { Button, ListItemIcon } from "@mui/material";
import {
  PushPinOutlined,
  ArticleOutlined,
  DvrOutlined,
  VisibilityOutlined,
  AssessmentOutlined,
  AssignmentOutlined,
  DirectionsBoatOutlined,
  ExpandLess,
  ExpandMore,
} from "@mui/icons-material";
import {
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Collapse
} from "@mui/material";
import { useEffect,useState } from "react";

function SideNav()
{
const [open,setopen]=useState(false);

useEffect(()=>
{
   let list=document.querySelectorAll("li");
   for(let j=0;j<list.length;j++)
   {
    list[j].setAttribute("id",`id${j+1}`);
    list[j].addEventListener("click",()=>
    {
        console.log(list[j])
        setopen(!open)
    })
   }
},[])  

return (
  <>
    <div className="bodycontent">
      <div className="Navbar">
        <div className="logocontainer">
          <img src={Logo}></img>
          <h2>SONATA</h2>
          <Button sx={{ marginLeft: "auto" }}>
            <PushPinOutlined sx={{ color: "white" }} />
          </Button>
        </div>
        <div>
          <h4>TTX - Toronto Express</h4>
        </div>
        <hr></hr>
        <div className="navlink">
          <ul>
            <List>
              <ListItem disablePadding>
                <ListItemButton>
                  <ListItemIcon sx={{ color: "white" }}>
                    <DvrOutlined />
                  </ListItemIcon>
                  <ListItemText primary="File" />
                  {open ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
              </ListItem>
              <Collapse in={open} timeout="auto" unmountOnExit>
                <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>{/* <StarBorder /> */}</ListItemIcon>
                    <ListItemText primary="Reset Vessel" />
                  </ListItemButton>
                </List>
                <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>{/* <StarBorder /> */}</ListItemIcon>
                    <ListItemText primary="Open Plan" />
                  </ListItemButton>
                </List>
                <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>{/* <StarBorder /> */}</ListItemIcon>
                    <ListItemText primary="Save Plan" />
                  </ListItemButton>
                </List>
                <List component="div" disablePadding>
                  <ListItemButton sx={{ pl: 4 }}>
                    <ListItemIcon>{/* <StarBorder /> */}</ListItemIcon>
                    <ListItemText primary="Settings" />
                  </ListItemButton>
                </List>
              </Collapse>

              <ListItem disablePadding>
                <ListItemButton>
                  <ListItemIcon sx={{ color: "white" }}>
                    <ArticleOutlined />
                  </ListItemIcon>
                  <ListItemText primary="System" />
                  {open ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
              </ListItem>

              <ListItem disablePadding>
                <ListItemButton>
                  <ListItemIcon sx={{ color: "white" }}>
                    <VisibilityOutlined />
                  </ListItemIcon>
                  <ListItemText primary="View" />
                  {open ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
              </ListItem>

              <ListItem disablePadding>
                <ListItemButton>
                  <ListItemIcon sx={{ color: "white" }}>
                    <AssignmentOutlined />
                  </ListItemIcon>
                  <ListItemText primary="Plan" />
                  {open ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
              </ListItem>

              <ListItem disablePadding>
                <ListItemButton>
                  <ListItemIcon sx={{ color: "white" }}>
                    <DirectionsBoatOutlined />
                  </ListItemIcon>
                  <ListItemText primary="Stability" />
                  {open ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
              </ListItem>

              <ListItem disablePadding>
                <ListItemButton>
                  <ListItemIcon sx={{ color: "white" }}>
                    <AssessmentOutlined />
                  </ListItemIcon>
                  <ListItemText primary="Reports" />
                  {open ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
              </ListItem>

              <ListItem disablePadding>
                <ListItemButton>
                  <ListItemIcon sx={{ color: "white" }}>
                    <AssessmentOutlined />
                  </ListItemIcon>
                  <ListItemText primary="AutoPlan" />
                  {open ? <ExpandLess /> : <ExpandMore />}
                </ListItemButton>
              </ListItem>
            </List>
          </ul>
        </div>
      </div>
    </div>
  </>
);
}

export default SideNav;