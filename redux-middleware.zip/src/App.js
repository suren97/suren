import SampleScreen from "./Sample/Screens";
import SampleScreen2 from "./Sample/Screen2";
import reduxStore from "./Redux/Store";
import { Provider } from "react-redux";
import Perform_Promise from "./Promises/Prom";
import Loadprom from "./Promises/Loading";
import AsyncThunk from "./Promises/Asyncthunk";
import React,{lazy,Suspense} from "react";
import FormSubmission from "./Promises/FormSubmission";

// const Lazycomp=lazy(()=>import("./Promises/Asyncthunk"));

function App() {
  return (
    <div className="App">
      <Provider store={reduxStore}>
        <FormSubmission />
        {/* <AsyncThunk /> */}
        {/* <Loadprom /> */}
        {/* <Perform_Promise /> */}
      {/* <SampleScreen />
      <SampleScreen2 /> */}
      </Provider>
    </div>
  );
}

export default App;
