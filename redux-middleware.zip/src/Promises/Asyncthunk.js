import { useSelector,useDispatch } from "react-redux";
import { getData } from "../Redux/Async";
import { useState } from "react";
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import axios from "axios";

function AsyncThunk()
{
const data=useSelector((state)=>state)
// let loading=data.sliceRedux.isLoading;
// let getdata=data.sliceRedux.data
const [loading,setloading]=useState(true);
// let loading=true;
const [getdata,setdata]=useState([]);
// let getdata=[];

const dispatch=useDispatch();

let CallData=()=>
{
 dispatch(getData())
}

let prom=new Promise((resolve,reject)=>
{
   setTimeout(()=>
   {
      axios.get("https://jsonplaceholder.typicode.com/users")
      .then((response)=>{
        if(response)
        {
          resolve(response)
        }
        else
        {
          reject("error")  
        }
      })
   },3000);   
})

prom.then((value)=>{ setdata(value); setloading(false)  })
prom.then((error)=>{ console.log(error)  })

return(
    <div>
        <header>
            <h1>Async Thunk</h1>
        </header>
        <button onClick={()=>CallData()}>GetData</button>
        {loading ? (
            <Box sx={{ display: 'flex' }}>
            <CircularProgress />
          </Box> 
        ):(
            <div>Name:{getdata.length ? getdata[0].name : ""}</div>
        )}
        {/* {loading ? (
        <Box sx={{ display: 'flex' }}>
          <CircularProgress />
        </Box>
        ):(
            <div>Name:{getdata.length ? getdata[0].name : ""}</div>
        )} */}
    </div>
)

}

export default AsyncThunk;