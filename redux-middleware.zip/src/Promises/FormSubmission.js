import React,{Component} from "react";
import { Button } from "@mui/material";
import axios from "axios";
import Ship from "./Ship.png";

class FormSubmission extends Component
{
    constructor(props)
    {
        super(props)
        this.state={
           url:"http://localhost:5000",
           firstname:"",
           lastname:"",
           email:"",
           mobile:"",
           address:"",
           city:"",
           pincode:"",
           pan:""
        }
    }

componentDidMount()
{
    const baseurl=this.state.url;
    axios.get(`${baseurl}/Formsdata`).then((response)=>{ 
        return response.data
    })
}

handleChange(e)
{
    this.setState({[e.target.name]:e.target.value})
}

handlesubmit()
{    
    const {firstname,lastname,email,mobile,address,city,pincode,pan,url}=this.state;
    let data={}
    data.firstname=firstname;
    data.lastname=lastname;
    data.email=email;
    data.mobile=mobile;
    data.address=address;
    data.city=city;
    data.pincode=pincode;
    data.pan=pan;
    let promise=new Promise((resolve,reject)=>{
    setTimeout(()=>
    {
        axios.post(`${url}/Formsdata`,data).then((response)=>{ 
           this.setState({responsedata:response.data})
           if(response)
           {
           resolve(response)
           }
           else
           {
            reject("error")
           }
        })
      },2000)
   })
   promise.then((value)=>{
    console.log(value)
   })
}

render()
{
    const {firstname,lastname,email,mobile,address,city,pincode,pan,responsedata}=this.state;

    return(
        <div>
            <h1>Forms Submission</h1>
            <div className="gridcontainer">
            <div className="grid1">
            <div>
                <p>Firstname</p>
                <input type="text" name="firstname" onChange={(e)=>this.handleChange(e)} />
            </div>
            <div>
                <p>Lastname</p>
                <input type="text" name="lastname" onChange={(e)=>this.handleChange(e)} />
            </div>
            <div>
                <p>Email</p>
                <input type="text" name="email" onChange={(e)=>this.handleChange(e)} />
            </div>
            <div>
                <p>Mobile</p>
                <input type="text" name="mobile" onChange={(e)=>this.handleChange(e)} />
            </div>
            <div>
                <p>Address</p>
                <input type="text" name="address" onChange={(e)=>this.handleChange(e)} />
            </div>
            <div>
                <p>City</p>
                <input type="text" name="city" onChange={(e)=>this.handleChange(e)} />
            </div>
            <div>
                <p>PinCode</p>
                <input type="text" name="pincode" onChange={(e)=>this.handleChange(e)} />
            </div>
            <div>
                <p>PAN</p>
                <input type="text" name="pan" onChange={(e)=>this.handleChange(e)} />
            </div>
            <div>
                <Button variant="contained">Submit</Button>
            </div>
            </div>
            <div className="grid2">
            <div>
                <p>Firstname</p>
                <input type="text" name="firstname" value={responsedata ? responsedata.firstname:""} />
            </div>
            <div>
                <p>Lastname</p>
                <input type="text" value={responsedata ? responsedata.lastname:""} />
            </div>
            <div>
                <p>Email</p>
                <input type="text" value={responsedata ? responsedata.email:""} />
            </div>
            <div>
                <p>Mobile</p>
                <input type="text" value={responsedata ? responsedata.mobile:""} />
            </div>
            <div>
                <p>Address</p>
                <input type="text" value={responsedata ? responsedata.address:""} />
            </div>
            <div>
                <p>City</p>
                <input type="text" value={responsedata ? responsedata.city:""} />
            </div>
            <div>
                <p>PinCode</p>
                <input type="text" value={responsedata ? responsedata.pincode:""} />
            </div>
            <div>
                <p>PAN</p>
                <input type="text" value={responsedata ? responsedata.pan:""} />
            </div>
            </div>
            </div>
        </div>
    )
}

}

export default FormSubmission;