import axios from "axios";
import { useEffect } from "react";

function Loadprom()
{
  useEffect(()=>
  {
     let promise=new Promise((resolve,reject)=>
     {
         axios.get("https://jsonplaceholder.typicode.com/users")
         .then((data)=>
         {
            if(data)
            {
            resolve(data)
            }
            else
            {
            reject("errr")
            }
         })
     })
     promise.then((value)=>
     {
        console.log(value)
     })
     promise.catch((error)=>
     {
        console.log(error)
     })
    

  },[]);

  return(
    <div>
       <header>
           <h1>Loading Promise...</h1>
       </header>
    </div>
  )
}

export default Loadprom;