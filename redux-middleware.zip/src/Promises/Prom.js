import axios from "axios";
import { useEffect } from "react";


function Perform_Promise()
{

// useEffect(()=>
// {
//   let promise=new Promise((resolve,reject)=>
//   {
//     setTimeout(()=>{
//     axios.get("https://jsonplaceholder.typicode.com/users")
//     .then((data)=>{
//         if(data.status===200)
//         {
//             resolve(data)
//         }
//     })
//     },1000)
//   });
//   promise.then(
//     function(value){ console.log(value)  }
//   )
//   promise.catch((error)=>{
//      console.log(error)
//   })
// },[])


// async function fn1()
// {
//     let get=await axios.get("https://jsonplaceholder.typicode.com/users")
//     console.log(get)
// }

function fn1()
{
    console.log("fn1")
    let prom=new Promise((resolve,reject)=>
    {
     let get=axios.get("https://jsonplaceholder.typicode.com/users");
     get.then((data)=>
     {
        resolve(data)
     })
     get.catch((err)=>
     {
        reject(err)
     })
    })
    prom.then((value)=>
    {
        console.log("Data Received")
    })
    prom.catch((err)=>
    {
        console.log(err)
    })
}

function fn2()
{
    console.log("fn2")
}

function fn3()
{
    console.log("fn3")
}

function fn4()
{
    console.log("fn4")
    let prom=new Promise((resolve,reject)=>
    {
    setTimeout(()=>{
    let get=axios.get("https://jsonplaceholder.typicode.com/users");
     get.then((data)=>
     {
        resolve(data)
     })
     get.catch((err)=>
     {
        reject(err)
    })
    },3000);
    })
    prom.then((value)=>
    {
        console.log("Data")
    })
    prom.catch((err)=>
    {
        console.log(err)
    })
}

function fn5()
{
    console.log("fn5")
}

fn1();
fn2();
fn3();
fn4();
fn5();

return(
        <div>
           <header>
            <h1>Promises</h1>
           </header>
        </div>
)

}

export default Perform_Promise;