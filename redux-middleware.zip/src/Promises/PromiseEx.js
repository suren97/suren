function PromiseEx()
{
    return(
        <div>
            <header>
                <h1></h1>
            </header>
        </div>
    )
}