import { combineReducers, createSlice } from "@reduxjs/toolkit"
import produce from "immer";

const initialState={
     data1:0,
     data2:0
}

const ActionData=createSlice({
    name:"check",
    initialState,
    reducers:{
     Check:(state,action)=>
     {
        return produce(state,(draft)=>
        {
           if(action.payload === "clear")
           {
             draft.data1=0
            //  draft.data2++
           }
           else
           {
           draft.data1=action.payload;   
           }
        })
     },
     Check2:(state,action)=>
     {
        return produce(state,(draft)=>
        {
           draft.data2=action.payload;
        })
     }   
    }
})

export const Actions=ActionData.reducer;
export const {Check,Check2}=ActionData.actions