import { createAsyncThunk,createSlice } from "@reduxjs/toolkit";
import axios from "axios";


const initialState={
    isLoading:false,
    data:[],
    errmsg:""
}

export const getData=createAsyncThunk("getData",async(data)=>{
    let response=await axios.get("https://jsonplaceholder.typicode.com/users")
    return response.data
})


const sliceRedux=createSlice({
    name:"Distance_Master",
    initialState,
    extraReducers:(builder)=>{
       builder.addCase(getData.pending,(state)=>{
         state.isLoading=true;
         state.errmsg="Error loading request"
       })
       builder.addCase(getData.fulfilled,(state,action)=>
       {
         state.isLoading=false;
         state.errmsg=null;
         state.data=action.payload
       })
    }
})

export default sliceRedux.reducer