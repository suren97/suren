import { createSlice } from "@reduxjs/toolkit";

const initialState={
    data1:0
}

const Reducer1=createSlice({
    name:"check",
    initialState,
    reducers:{
        Check:(state,action)=>
        {
            state.data1=action.payload
        }
    }
})

export const Reduce1=Reducer1.reducer
export const {Check}=Reducer1.actions