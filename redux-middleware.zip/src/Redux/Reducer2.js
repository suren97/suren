import { createSlice } from "@reduxjs/toolkit";

const initialState={
    data2:0
}

const Reducer2=createSlice({
    name:"check2",
    initialState,
    reducers:{
        Check2:(state,action)=>
        {
            state.data2=action.payload
        }
    }
})

export const Reduce2=Reducer2.reducer
export const {Check2}=Reducer2.actions