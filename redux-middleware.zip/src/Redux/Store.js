import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { logger } from "redux-logger";
import { Reduce1 } from "./Reducer1";
import { Reduce2 } from "./Reducer2";
import { Check } from "./Reducer1";
import sliceRedux from "./Async";



const getMiddleware1=({getState,dispatch})=>next=>action=>
{
    if(action.type === "check/Check2")
    {
       if(getState().data1 === 5 && action.payload === 5)
       {
           dispatch(Check("clear"))
       }
       else
       {
        return next(action)
       }
    }
    else
    {
        return next(action)
    }
}

const middlewares=[
    getMiddleware1
];

const rootReducer=combineReducers({
    Reduce1,
    Reduce2,
    sliceRedux
})


const reduxStore=configureStore({
    reducer:rootReducer,
    middleware:getDefaultMiddleware=>
    getDefaultMiddleware({
        immutableCheck:false,
        serializableCheck:false,
    }).concat(middlewares).concat(logger)
})



export default reduxStore;