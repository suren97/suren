import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { useEffect,useState } from "react";


function GridComponent()
{
const [columndef,setcol]=useState([
    {field:"athlete"},
    {field:"age"},
    {field:"date"},
    {field:"sport"},
    {field:"bronze"},
    {field:"silver"},
    {field:"gold"},
    {field:"total"}
]);

const defaultColDef=({
    sortable:true,
    flex:1
})
const [row,setrow]=useState();

// useEffect(()=>
// {
 
// },[])
let onGridReady=()=>
{
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
    .then((response)=>response.json())
    .then((data)=>{
        setrow(data)
    })
}

return(
        <>
            <div className="ag-theme-alpine" style={{height:300}}>
            <AgGridReact 
            rowData={row}
            columnDefs={columndef}
            defaultColDef={defaultColDef}
            onGridReady={onGridReady}
            />
            </div>
        </>
    )
}

export default GridComponent;