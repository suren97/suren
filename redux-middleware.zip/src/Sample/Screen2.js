import { useState } from "react";
import { useSelector,useDispatch } from "react-redux";
import { Check2 } from "../Redux/Reducer2";

function SampleScreen2()
{
const count=useSelector((state)=>state.Reduce2);
const dispatch=useDispatch();

let handlebutton=()=>
{
  dispatch(Check2(count.data2+1))
}

return(
        <>
        <div className="sample">
        <div>Child Count - {count.data2}</div>
        <button onClick={()=>handlebutton()}>Increment</button>
        </div>
        </>
    )
}

export default SampleScreen2;