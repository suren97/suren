import { useSelector,useDispatch } from "react-redux";
import { Check } from "../Redux/Reducer1";
import { jsPanel } from "jspanel4";
import ReactDOM from 'react-dom/client';
import GridComponent from "./GridComponent";

function SampleScreen()
{
const count=useSelector((state)=>state.Reduce1);
console.log(count)
const dispatch=useDispatch();

let openpanel=()=>
{
    jsPanel.create({
        headerTitle:"Port Master",
        headerControls:"closeonly xs"
    }).maximize();
    const root = ReactDOM.createRoot(document.querySelector('.jsPanel-content'));
    root.render(<GridComponent />)
}

let handlebutton=()=>
{
  dispatch(Check(count.data1+1))
}

return(
        <>
         {/* <button onClick={()=>openpanel()}>Open</button> */}
        <div className="sample">
        <div>Parent Count - {count.data1}</div>
        <button onClick={()=>handlebutton()}>Increment</button>
        <br></br>
        <br></br>
        <hr></hr>
        </div>
        </>
)

}

export default SampleScreen;