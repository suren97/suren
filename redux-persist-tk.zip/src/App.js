import { BrowserRouter as Router,Routes,Route } from "react-router-dom";
import Login from "./Screens/Login";
import Product from "./Screens/Products";
import DataElem from "./Screens/Data";
import CheckBoxData from "./Redux/CheckBoxData";
import AgGrid from "./Screens/ImmutabilityHelper/Grid";
import Basic_Immutability from "./Screens/ImmutabilityHelper/BasicImmutability";

function App()
{
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<AgGrid />} />
          <Route path="/product" element={<Product />} />
          <Route path="/data" element={<DataElem />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;