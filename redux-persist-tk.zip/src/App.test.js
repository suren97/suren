import { fireEvent as user, render, screen } from "@testing-library/react";
import Login from './Login';

// document.querySelector(".ag-row-first > div input[type=text]").value;

test('renders learn react link', () => {
  const { container } = render(<Login />);
  const AddRow = container.querySelector("#clickAdd");
  user.click(AddRow);
});
