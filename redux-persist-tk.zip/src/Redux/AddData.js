import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  AddData: [],
};

const AddDataSlice = createSlice({
  name: "AddData",
  initialState,
  reducers: {
    AddData: (state, action) => {
      state.AddData.push(action.payload);
    },
  },
});

export const AddDataSliceReducer = AddDataSlice.reducer;
export const { AddData } = AddDataSlice.actions;
