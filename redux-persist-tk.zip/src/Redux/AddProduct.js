import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  productdata: [],
};

const ProductSlice = createSlice({
  name: "product",
  initialState,
  reducers: {
    ProductData: (state, action) => {
      state.productdata.push(action.payload);
    },
  },
});

export const ProductSliceReducer = ProductSlice.reducer;
export const { ProductData } = ProductSlice.actions;
