import { Component } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import axios from "axios";

export default class CheckBoxData extends Component{
    constructor(props)
    {
        super(props)
        this.state={
            rowdata:[],
            columnDef:[
                {
                    field:"make"
                },
                {
                    field:'model'
                },
                {
                    field:"price"
                }
        ],
            defaultColDef:({flex:1})
        }
    }

   async componentDidMount()
   {
     const dataelem = await axios
       .get("https://www.ag-grid.com/example-assets/row-data.json")
       .then((response) => {
        response.data.length=10; 
        return response.data
    });
     console.log(dataelem)
   }


    render()
    {
        return(
            <>
            <header>
                <h1>Grid CheckBox</h1>
            </header>
            <div className="ag-theme-alpine" style={{margin:"5%",height:400}}>
                <AgGridReact 
                columnDefs={this.state.columnDef}
                rowData={this.state.rowdata}
                defaultColDef={this.state.defaultColDef}
                />
            </div>
            </>
        )
    }
}