import { createSlice } from "@reduxjs/toolkit";

const initialState={
    logindata:[]
}

const LoginSlice=createSlice({
    name:"login",
    initialState,
    reducers:{
        LoginData:(state,action)=>
        {
           state.logindata.push(action.payload);
        }
    }
})

export const LoginSliceReducer=LoginSlice.reducer;
export const {LoginData}=LoginSlice.actions