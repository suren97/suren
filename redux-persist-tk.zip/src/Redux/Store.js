import { combineReducers, configureStore, getDefaultMiddleware } from "@reduxjs/toolkit";
import { LoginSliceReducer } from "./LoginSlice";
import { ProductSliceReducer } from "./AddProduct";
import { AddDataSliceReducer } from "./AddData";
import persistReducer from "redux-persist/es/persistReducer";
import localforage from "localforage";

const persistConfig={
    key:"root",
    version:1,
    storage:localforage
}

const rootReducer=combineReducers({
      LoginSliceReducer,
      ProductSliceReducer,
      AddDataSliceReducer
})

const clearSomeReducer=({getState,dispatch})=>next=>action=>
{
    if (action.type === "AddData/AddData") {
        let getData=getState();
        console.log("atdata")
        // console.log(getData)
   } else {
     return next(action);
   }
}

const persistedReducer=persistReducer(persistConfig,rootReducer);

const middlewares=[
    clearSomeReducer
];

const store=configureStore({
     reducer:persistedReducer,
     middleware:getDefaultMiddleware=>
        getDefaultMiddleware({
          immutableCheck: false,
          serializableCheck: false,
        }).concat(middlewares)
})

export default store;