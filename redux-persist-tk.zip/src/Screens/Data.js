import { useSelector,useDispatch } from "react-redux";
import { AddData } from "../Redux/AddData";
import { useState } from "react";

function DataElem()
{
    const [Dataname,setname]=useState();
    const [Datacode,setcode]=useState();
    const dataselect=useSelector((state)=>{
      console.log(state)
    })
    const dispatch=useDispatch();
    
    let handleSubmit=()=>
    {
      let data={};
      data.dataname=Dataname;
      data.code=Datacode;
      dispatch(AddData(data));
    //   window.location.href="/"
    }

   return (
     <>
       <header>
         <h1>Data Elements</h1>
       </header>
       <div>
         <label>Data_Name:</label>
         <input type="text" onChange={(e) => setname(e.target.value)} />
         <label>Data Code:</label>
         <input type="text" onChange={(e)=>setcode(e.target.value)} />
         <button onClick={() => handleSubmit()}>Submit</button>
       </div>
     </>
   ); 
}

export default DataElem;