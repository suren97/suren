import { useEffect } from "react";
import update from "immutability-helper"

function Basic_Immutability()
{

useEffect(()=>
{
   const state1=["x"];
   const state2=update(state1,{$push:["y"]});
   //---------------------------------------
   const myData={x:{y:{z:[]}}};
   myData.x.y.z.push(71);
   //---------------------------------------
   const newData=Object.assign({},myData,{
    x:Object.assign({},myData.x,{
        y:Object.assign({},myData.x.y,{z:7})
    })
   });
   console.log(newData)
},[])

return(
    <>
    <header>
        <h1>Basic ImmutabilityHelper</h1>
    </header>
    </>
)
}

export default Basic_Immutability;