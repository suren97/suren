import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import {useEffect, useState} from "react"
import InputEditor from "./InputEditor";

function AgGrid() {
 const [rowdata,setrow]=useState();
 const [columnDef, setcolumn] = useState([
   {
     field: "make",
     editable: true,
     cellEditor:InputEditor,
   },
   { field: "model" },
   { field: "price" },
 ]);

 useEffect(()=>
 {
   fetch("https://www.ag-grid.com/example-assets/row-data.json")
   .then((response)=>response.json())
   .then((data)=>{
    data.length=10;
      setrow(data)
   })
 },[])

return (
    <>
      <header>
        <h1>GridComponents</h1>
      </header>
      <div className="ag-theme-alpine" style={{height:400,width:"100%",marginTop:"5%"}}>
        <AgGridReact 
        columnDefs={columnDef}
        rowData={rowdata}
        defaultColDef={{flex:1}}
        />
      </div>
    </>
  );
}

export default AgGrid;
