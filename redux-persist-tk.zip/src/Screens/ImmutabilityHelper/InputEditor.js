// export default function InputEditor(params)
// {
//     console.log(params)
//     return(
//         <>
//         <input type="text" value={params.value} />
//         </>
//     )
// }

import { forwardRef, useImperativeHandle,useState } from "react";

const InputEditor=forwardRef((props,ref)=>{
    let column=props.colDef.field;
    console.log(column)
    const [values,setvalue]=useState({
        make:props.data.make,
        model:props.data.model,
        price:props.data.price  
    })

    useImperativeHandle(ref,()=>{
        return {
            getValue() {
                return values[column]
            }
        }
    })

    let handleInput=e=>
    {
      setvalue({...values,[column]:e.target.value})
    }

    return(
        <>
        <input 
        type="text" 
        name={props.colDef.field} 
        value={values[column]}
        onChange={(e)=>handleInput(e)} 
        />
        </>
    )
})

export default InputEditor;