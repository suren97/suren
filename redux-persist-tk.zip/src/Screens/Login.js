import { useState } from "react";
import { useSelector,useDispatch } from "react-redux";
import { LoginData } from "../Redux/LoginSlice";

function Login()
{
   const [username,setname]=useState();
   const [email,setemail]=useState();
   const dispatch=useDispatch();

    let handleSubmit=()=>
    {
      let data={};
      data.name=username;
      data.email=email;
      dispatch(LoginData(data));
      window.location.href="/product"
    }

    return (
      <>
        <header>
          <h1>Login</h1>
        </header>
        <div>
          <label>Username:</label>
          <input type="text" onChange={(e) => setname(e.target.value)} />
          <label>Email:</label>
          <input type="text" onChange={(e)=>setemail(e.target.value)} />
          <button onClick={() => handleSubmit()}>Submit</button>
        </div>
      </>
    );
}

export default Login;