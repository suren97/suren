import { useSelector,useDispatch } from "react-redux";
import { useState } from "react";
import { ProductData } from "../Redux/AddProduct";

function Product()
{
const [prodname,setprod]=useState();
const [price,setprice]=useState();
const dispatch=useDispatch();

let handleSubmit=()=>
{
  let data={};
  data.proname=prodname;
  data.price=price;
  dispatch(ProductData(data));
  window.location.href="/data"
}

return (
  <div>
    <header>
      <h1>Product</h1>
    </header>
    <label>Product name:</label>
    <input type="text" onChange={(e) => setprod(e.target.value)} />
    <label>Product price:</label>
    <input type="text" onChange={(e)=>setprice(e.target.value)} />
    <button onClick={() => handleSubmit()}>Submit</button>
  </div>
);
}

export default Product;